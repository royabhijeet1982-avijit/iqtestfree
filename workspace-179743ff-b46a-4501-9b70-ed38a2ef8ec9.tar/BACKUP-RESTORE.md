# BrainMetrics — Page Protection & Backup System

**Purpose:** Jo bhi pages create hue hain (26-tool BrainMetrics site), wo kisi bhi karan se delete na ho jaye — workspace rollback, accidental deletion, git mistake, kuch bhi.

## Current protected state

- 11 routes live: `/`, `/test`, + 9 tool pages (`full-iq`, `matrix-reasoning`, `digit-span`, `reaction-time`, `visual-memory`, `stroop-test`, `mental-rotation`, `chimp-test`, `n-back`, `processing-speed`)
- Baseline commit: `88d76b4` (clean tree)

## The 5 protection layers

| Layer | What | Where | Survives |
|-------|------|-------|----------|
| 1 | Git commits (every task) | `$PROJECT/.git` | accidental file deletion, bad edits |
| 2 | Timestamped git bundles | `$PROJECT/backups/` | git mistakes, .git corruption |
| 3 | Timestamped bundles + tree tarballs | `/home/z/brainmetrics-backups/` (OUTSIDE project) | **full project-dir rollback** |
| 4 | Automation: post-commit hook + 30-min loop | `.git/hooks/post-commit`, background loop | human forgetfulness |
| 5 | (Optional, future) external git remote push | GitHub/GitLab | complete sandbox loss — needs user-provided repo URL + token |

> Layer 3 is the critical one: `/home/z/brainmetrics-backups/` lives **outside** `/home/z/my-project/`, so a workspace rollback of the project directory cannot touch it.

## What a backup contains

- `repo-<stamp>.bundle` — the ENTIRE git history in one file (all commits, all pages). Restorable via `git clone`.
- `tree-<stamp>.tar.gz` — the exact working-tree snapshot (src, scripts, configs, worklog, public) excluding `node_modules`, `.next`, `.git`.
- `LATEST` — stamp of the newest backup for one-command restore.
- Retention: newest 10 of each kind, per location.

## How to back up (anytime)

```bash
bash scripts/backup-project.sh
```

Auto-commits any dirty work first, then bundles. Safe to run any number of times.

## How to restore (3 scenarios)

**A. Koi page/file delete ho gayi (project intact):**
```bash
bash scripts/restore-project.sh --from-bundle          # safe preview -> /home/z/restore-<stamp>/
bash scripts/restore-project.sh --from-bundle --in-place   # actually overwrite project
```

**B. Project directory rollback ho gaya (pages gayab, /home/z/brainmetrics-backups zinda):**
```bash
bash scripts/restore-project.sh --list                     # see available backups
bash scripts/restore-project.sh --from-tree --in-place     # restore exact files + git history via bundle
# then: cd /home/z/my-project && bun install && bun run dev
```

**C. Sirf files chahiye, history nahi:**
```bash
bash scripts/restore-project.sh --from-tree           # safe extract -> /home/z/restore-tree-<stamp>/
```

Default restore is ALWAYS non-destructive (separate staging dir). `--in-place` is the explicit dangerous flag.

## Automation (Layer 4)

1. **post-commit hook** — every `git commit` immediately refreshes `/home/z/brainmetrics-backups/repo-latest-commit.bundle`. Even if the sandbox dies 1 second after a commit, the history bundle exists outside the project.
2. **30-minute background loop** — runs `backup-project.sh` every 30 min, logs to `/home/z/brainmetrics-backups/auto-backup.log`. PID in `/home/z/brainmetrics-backups/loop.pid`.

Check automation health:
```bash
ps -p "$(cat /home/z/brainmetrics-backups/loop.pid)" && echo "loop alive"
ls -la /home/z/brainmetrics-backups/
```

## Recommended final layer (user action)

Sandbox-level disaster (poora VM reset) se 100% bachne ke liye external remote best hai. Agar aap ek GitHub **private repo** URL + fine-grained token de dein, to ye one-liner setup ho jayega:

```bash
cd /home/z/my-project
git remote add origin git@github.com:<you>/brainmetrics.git   # ya https URL with token
git push -u origin main
```

Uske baad backup script me `git push` bhi add ho jayega (har backup ke saath off-site push).
