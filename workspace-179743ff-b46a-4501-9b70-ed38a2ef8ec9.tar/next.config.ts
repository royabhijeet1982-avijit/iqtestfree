import type { NextConfig } from "next";

// BUILD_STATIC=1 -> static export build (HTML/JS only) for static hosts
// e.g. Hostinger WordPress hosting (upload out/ via File Manager / FTP).
// Default build stays "standalone" (Node server) — unchanged behaviour.
const isStaticExport = process.env.BUILD_STATIC === "1";

const nextConfig: NextConfig = isStaticExport
  ? {
      output: "export",
      // trailingSlash -> /test/foo/index.html so Apache (Hostinger) serves
      // /test/foo/ without .htaccess rewrite rules
      trailingSlash: true,
      images: { unoptimized: true },
      typescript: {
        ignoreBuildErrors: true,
      },
      reactStrictMode: false,
    }
  : {
      output: "standalone",
      typescript: {
        ignoreBuildErrors: true,
      },
      reactStrictMode: false,
    };

export default nextConfig;
