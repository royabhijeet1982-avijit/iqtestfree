/* ------------------------------------------------------------------ */
/*  Mental Rotation Test - FAQ (single source)                         */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type MrotFaq = { question: string; answer: string };

export const MENTAL_ROTATION_FAQS: MrotFaq[] = [
  {
    question: "What is mental rotation?",
    answer:
      "Mental rotation is your ability to turn an object around in your mind's eye and imagine how it looks from a new angle. It is one of the most-studied spatial skills and a core component of general spatial ability, alongside navigation, visualisation and folding. In this test you see two cube figures and must judge whether the second is the first one rotated, or a mirrored copy - the same same-versus-mirrored judgment used in psychology labs for over fifty years.",
  },
  {
    question: "What are Shepard-Metzler figures?",
    answer:
      "They come from a famous 1971 Science paper by Roger Shepard and Jacqueline Metzler, 'Mental Rotation of Three-Dimensional Objects'. Participants saw drawings of arm-like assemblies of cubes and decided whether two drawings showed the same object or mirror images. The landmark finding: response time grew linearly with the angle between the drawings, as if people were physically rotating a mental image at a steady speed. Our test uses procedurally generated two-dimensional cousins of those figures, rendered as cube cells on a grid.",
  },
  {
    question: "What strategies improve mental rotation scores?",
    answer:
      "Three reliably help. First, anchor on one arm of the target figure and rotate that arm in steps rather than spinning the whole shape at once. Second, compare the order of arms around each junction - a mirror flips the handedness of the joints even when lengths match, so a wrong joint order means mirrored. Third, prioritise accuracy on your first sessions; speed follows once your eyes stop re-checking the easy angles.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Two signals combine into a Mental Rotation Index with a population mean of 100 and a standard deviation of 15. Accuracy (anchored at 78%, SD 12) carries 60% of the weight, and your rotation cost carries 40%: we regress your correct-trial response times against rotation angle to get milliseconds per degree - lower means your brain spins figures faster. The slope can only help if your accuracy clears the guessing zone, so clicking as fast as possible cannot farm a good score. Answers under 0.8 seconds are counted as rushed, and a median under 1.5 seconds with low accuracy flags the session with an honesty note.",
  },
  {
    question: "Are there gender or age differences in mental rotation?",
    answer:
      "Honestly: yes, in the lab. Mental rotation shows one of the largest average gender gaps in cognitive psychology and performance also shifts with age, which is why we avoid claiming precise demographic norms. Two caveats matter - the gap shrinks substantially with practice and with spatial experience such as 3D games or design work, and this test's population model is a simulated adult sample, not clinical norming data. Treat your result as an educational estimate of where you stand today, not a fixed trait.",
  },
  {
    question: "Can I retake the test?",
    answer:
      "Yes - retakes are unlimited and every session generates a fresh set of random figures from a new seed, so there is nothing to memorise between attempts. Expect a warm-up effect: most people gain a few points on their second run as the task format becomes familiar. Scores are computed in your browser and never stored, so each retake is a clean, private measurement.",
  },
];
