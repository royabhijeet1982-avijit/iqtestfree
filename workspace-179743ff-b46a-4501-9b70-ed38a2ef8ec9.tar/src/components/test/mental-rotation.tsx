"use client";

/* ------------------------------------------------------------------ */
/*  Mental Rotation Test - interactive UI                              */
/*  Shepard-Metzler-style comparison: two cube figures side by side,   */
/*  decide whether the second is the first one rotated or a mirrored   */
/*  copy. No time limit per item; response times are recorded for the  */
/*  rotation-slope score and the honesty panel. Scoring lives in       */
/*  mental-rotation-core.ts.                                           */
/*                                                                     */
/*  Testing hook: /test/mental-rotation?quick=1 shortens the session   */
/*  to 8 items so automated flow tests can run full sessions quickly.  */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  FlipHorizontal2,
  MousePointerClick,
  Rotate3d,
  RotateCcw,
  ShieldAlert,
  Shuffle,
  Timer,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  ITEM_COUNT,
  QUICK_ITEM_COUNT,
  generateItems,
  itemFingerprint,
  scoreMentalRotationSession,
  type Figure,
  type MrotAnswer,
  type MrotItem,
  type MrotScore,
} from "./mental-rotation-core";

type Phase = "intro" | "countdown" | "active" | "results";

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("mental-rotation-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

/**
 * Render one figure as a grid of cube cells. The grid is always
 * size x size so the cell scale matches between the two panels
 * (rotation and mirroring preserve the bounding-box size).
 */
function CubeFigure({ figure, tone }: { figure: Figure; tone: "target" | "candidate" }) {
  const n = figure.size;
  const filled = new Set(figure.cells.map((c) => `${c.x},${c.y}`));
  return (
    <div
      role="img"
      aria-label={`${tone === "target" ? "Figure A" : "Figure B"}: ${figure.cells.length} connected cubes`}
      className="grid aspect-square w-full max-w-[150px] gap-[3px] sm:max-w-[188px] sm:gap-1"
      style={{
        gridTemplateColumns: `repeat(${n}, minmax(0, 1fr))`,
        gridTemplateRows: `repeat(${n}, minmax(0, 1fr))`,
      }}
    >
      {Array.from({ length: n * n }, (_, i) => {
        const x = i % n;
        const y = Math.floor(i / n);
        const on = filled.has(`${x},${y}`);
        return (
          <div
            key={i}
            aria-hidden="true"
            className={[
              "rounded-[3px] sm:rounded-[4px]",
              on
                ? tone === "target"
                  ? "bg-gradient-to-br from-emerald-300 via-emerald-500 to-emerald-700 shadow-[inset_0_-2px_0_rgba(0,0,0,0.28),inset_0_2px_0_rgba(255,255,255,0.38)]"
                  : "bg-gradient-to-br from-zinc-500 via-zinc-700 to-zinc-900 shadow-[inset_0_-2px_0_rgba(0,0,0,0.45),inset_0_2px_0_rgba(255,255,255,0.14)]"
                : "bg-transparent",
            ].join(" ")}
          />
        );
      })}
    </div>
  );
}

function FigurePanel({ figure, tone, label }: { figure: Figure; tone: "target" | "candidate"; label: string }) {
  const dot = tone === "target" ? "bg-emerald-500" : "bg-zinc-800";
  return (
    <div className="flex min-w-0 flex-1 flex-col items-center gap-2 rounded-xl border border-border bg-muted/40 p-3 sm:p-4">
      <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <span aria-hidden="true" className={`h-2 w-2 rounded-full ${dot}`} />
        {label}
      </span>
      <div className="flex h-[150px] w-full items-center justify-center sm:h-[188px]">
        <CubeFigure figure={figure} tone={tone} />
      </div>
    </div>
  );
}

export function MentalRotationTest() {
  const searchParams = useSearchParams();
  const itemCount = useMemo(
    () => (searchParams.get("quick") === "1" ? QUICK_ITEM_COUNT : ITEM_COUNT),
    [searchParams]
  );

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [items, setItems] = useState<MrotItem[]>([]);
  const [index, setIndex] = useState(0);
  const [answerTick, setAnswerTick] = useState(0);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [score, setScore] = useState<MrotScore | null>(null);

  const itemsRef = useRef<MrotItem[]>([]);
  const indexRef = useRef(0);
  const answersRef = useRef<(MrotAnswer | null)[]>([]);
  const rtsRef = useRef<(number | null)[]>([]);
  const itemStartRef = useRef(0);

  /* ------------------------- session flow ------------------------- */

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const fresh = generateItems(seed, itemCount);
    itemsRef.current = fresh;
    indexRef.current = 0;
    answersRef.current = new Array(fresh.length).fill(null);
    rtsRef.current = new Array(fresh.length).fill(null);
    setItems(fresh);
    setIndex(0);
    setAnswerTick(0);
    setElapsedMs(0);
    setScore(null);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [itemCount]);

  const finish = useCallback(() => {
    const result = scoreMentalRotationSession(
      itemsRef.current,
      answersRef.current,
      rtsRef.current
    );
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  const answer = useCallback(
    (choice: MrotAnswer) => {
      const i = indexRef.current;
      if (answersRef.current[i] !== null) return; // already answered (exit animation)
      const item = itemsRef.current[i];
      if (!item) return;

      const now = performance.now();
      rtsRef.current[i] = Math.max(0, now - itemStartRef.current);
      answersRef.current[i] = choice;
      setAnswerTick((t) => t + 1);

      if (i + 1 >= itemsRef.current.length) {
        finish();
      } else {
        indexRef.current = i + 1;
        itemStartRef.current = performance.now();
        setElapsedMs(0);
        setIndex(i + 1);
      }
    },
    [finish]
  );

  /* Called by the countdown chain: anchors the first item's RT clock. */
  const beginSession = useCallback(() => {
    itemStartRef.current = performance.now();
    setElapsedMs(0);
    setPhase("active");
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  /* Countdown 3-2-1-GO. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginSession();
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginSession]);

  /* Live per-item reaction-time readout (reads the anchor, never writes it). */
  useEffect(() => {
    if (phase !== "active") return;
    const interval = setInterval(() => {
      setElapsedMs(performance.now() - itemStartRef.current);
    }, 100);
    return () => clearInterval(interval);
  }, [phase]);

  /* Keyboard input: 1 = same figure, 2 = mirrored figure. */
  useEffect(() => {
    if (phase !== "active") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key === "1") {
        event.preventDefault();
        answer("same");
      } else if (event.key === "2") {
        event.preventDefault();
        answer("different");
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, answer]);

  /* ------------------------- derived data -------------------------- */

  const currentItem = items[index] ?? null;
  // answer() increments the tick exactly once per answered item (double
  // answers are guarded), so the tick IS the answered count - no ref read.
  const answeredCount = answerTick;
  const progressPct = items.length > 0 ? (answerTick / items.length) * 100 : 0;
  const isQuick = itemCount === QUICK_ITEM_COUNT;

  /** Deterministic tutorial pair: a 90-degree "same" item. */
  const demoItem = useMemo(() => {
    const all = generateItems(20250915, ITEM_COUNT);
    return all.find((it) => it.isSame && it.angleDeg === 90) ?? (all[0] as MrotItem);
  }, []);

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="mental-rotation-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="mrot-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Rotate3d className="h-3.5 w-3.5" aria-hidden="true" />
                Spatial ability · {itemCount} figure pairs
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Are these two figures the same?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                You will see a pair of cube figures. The right one may be the
                left one turned in space - or it may be a mirrored copy that no
                rotation can match. Compare the arms and joints, decide, and
                answer at your own pace. Rotations get larger as you go.
              </p>
            </div>

            {demoItem && (
              <div className="mx-auto mt-6 max-w-lg rounded-xl border border-border bg-muted/60 p-4">
                <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Example pair
                </p>
                <div className="mt-3 flex items-stretch justify-center gap-3 sm:gap-5">
                  <FigurePanel figure={demoItem.target} tone="target" label="Figure A" />
                  <FigurePanel figure={demoItem.candidate} tone="candidate" label="Figure B" />
                </div>
                <div className="mt-3 text-center">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold tabular-nums text-muted-foreground">
                    <Rotate3d className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                    Rotation: {demoItem.angleDeg} degrees
                  </span>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    Figure B is Figure A turned 90 degrees - the same figure.
                    Every real pair is generated fresh on each attempt.
                  </p>
                </div>
              </div>
            )}

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                No time limit - think each pair through, but answer times are recorded.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Two answers per item: Same figure or Mirrored figure. Keys 1 and 2 work too.
              </li>
              <li className="flex gap-2.5">
                <Shuffle className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                A brand-new random set is generated for every attempt - retaking never repeats pairs.
              </li>
              <li className="flex gap-2.5">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Answers under 0.8s count as rushed; a median under 1.5s with low accuracy flags the session.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="mrot-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Rotate3d className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="mrot-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Get ready to compare figures
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
            <p className="mt-8 text-center text-sm text-muted-foreground">
              Figure A is on the left, Figure B on the right. Rotation angles
              grow from 0 to 270 degrees as the session continues.
            </p>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && currentItem && (
          <motion.div
            key="active"
            data-testid="mrot-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Header + progress */}
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Item {index + 1} of {items.length}
              </span>
              <span
                data-testid="mrot-item-timer"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-xs font-semibold tabular-nums text-muted-foreground"
              >
                {(elapsedMs / 1000).toFixed(1)}s
              </span>
            </div>
            <div
              data-testid="mrot-progress"
              className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Session progress"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(progressPct)}
            >
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-300 ease-out"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={index}
                data-testid="mrot-item"
                data-index={index}
                data-answer={currentItem.correctAnswer}
                data-angle={currentItem.angleDeg}
                data-fingerprint={itemFingerprint(currentItem)}
                initial={{ opacity: 0, x: 24 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -24 }}
                transition={{ duration: 0.25 }}
              >
                {/* Rotation badge */}
                <div className="mt-5 flex justify-center">
                  <span
                    data-testid="mrot-angle-badge"
                    className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-1.5 text-xs font-bold tabular-nums text-emerald-700"
                  >
                    <Rotate3d className="h-3.5 w-3.5" aria-hidden="true" />
                    Rotation: {currentItem.angleDeg} degrees
                  </span>
                </div>

                {/* The pair */}
                <div className="mt-4 flex items-stretch justify-center gap-3 sm:gap-5">
                  <FigurePanel figure={currentItem.target} tone="target" label="Figure A" />
                  <FigurePanel figure={currentItem.candidate} tone="candidate" label="Figure B" />
                </div>

                <p className="mt-5 text-center text-sm text-muted-foreground">
                  Is Figure B the same figure as A, or a mirrored copy?
                </p>

                {/* Answer buttons */}
                <div className="mx-auto mt-3 grid max-w-xl grid-cols-2 gap-3">
                  <button
                    type="button"
                    data-testid="mrot-btn-same"
                    aria-label="Same figure"
                    onClick={() => answer("same")}
                    className="inline-flex h-16 flex-col items-center justify-center gap-1 rounded-2xl border-2 border-border bg-card px-2 text-sm font-bold text-foreground transition-[translate,border-color,box-shadow,background-color] duration-150 hover:-translate-y-0.5 hover:border-primary hover:bg-emerald-50 hover:text-primary hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0 sm:h-20 sm:text-base"
                  >
                    <Rotate3d className="h-5 w-5 text-primary" aria-hidden="true" />
                    Same figure
                  </button>
                  <button
                    type="button"
                    data-testid="mrot-btn-different"
                    aria-label="Mirrored figure"
                    onClick={() => answer("different")}
                    className="inline-flex h-16 flex-col items-center justify-center gap-1 rounded-2xl border-2 border-border bg-card px-2 text-sm font-bold text-foreground transition-[translate,border-color,box-shadow,background-color] duration-150 hover:-translate-y-0.5 hover:border-primary hover:bg-emerald-50 hover:text-primary hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0 sm:h-20 sm:text-base"
                  >
                    <FlipHorizontal2 className="h-5 w-5 text-primary" aria-hidden="true" />
                    Mirrored figure
                  </button>
                </div>

                <p className="mt-3 hidden text-center text-xs text-muted-foreground sm:block">
                  Tip: keys 1 (same) and 2 (mirrored) select answers.
                </p>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="mrot-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            {score.valid ? (
              <div className="mx-auto max-w-2xl">
                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                    Your result
                  </p>
                  <span
                    data-testid="mrot-iq"
                    className="mt-2 block text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Mental Rotation Index · mean 100, SD 15
                  </p>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                    <span
                      data-testid="mrot-grade"
                      className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                    >
                      <Rotate3d className="h-4 w-4" aria-hidden="true" />
                      {score.grade.label}
                    </span>
                    <span
                      data-testid="mrot-percentile"
                      className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                    >
                      Higher than {score.percentile} in 100 adults
                    </span>
                  </div>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    {score.grade.blurb}
                  </p>
                </div>

                {score.rushed && (
                  <div
                    data-testid="mrot-rushed"
                    className="mt-6 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4"
                  >
                    <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-bold text-amber-800">
                        This session looked rushed
                      </p>
                      <p className="mt-1 text-sm leading-relaxed text-amber-800">
                        Your median answer time was{" "}
                        {(score.medianRtMs / 1000).toFixed(1)}s per item and{" "}
                        {Math.round(score.fastPct * 100)}% of answers landed
                        under 0.8s. Rotating figures takes thought - the score
                        below is computed honestly from your answers, but a
                        slower retake will estimate your spatial ability more
                        fairly.
                      </p>
                    </div>
                  </div>
                )}

                {/* Stat grid */}
                <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div
                    data-testid="mrot-accuracy"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round((score.correct / Math.max(1, score.answered)) * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      accuracy · {score.correct} / {score.answered}
                    </p>
                  </div>
                  <div
                    data-testid="mrot-median-rt"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.medianRtMs > 0 ? `${(score.medianRtMs / 1000).toFixed(1)}s` : "-"}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">median time per item</p>
                  </div>
                  <div
                    data-testid="mrot-slope"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.slopeMsPerDeg !== null ? score.slopeMsPerDeg.toFixed(1) : "-"}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">ms per degree (lower is faster)</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.fastCount}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">answers under 0.8s</p>
                  </div>
                </div>

                {score.nearChance && (
                  <p
                    data-testid="mrot-chance-note"
                    className="mt-4 rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-sm leading-relaxed text-amber-800"
                  >
                    Honesty note: with only two options per item, random
                    guessing lands near 50% accuracy. Your accuracy was close
                    to that floor, so this score may say more about pace than
                    about spatial skill - take a slower look on a retake.
                  </p>
                )}

                {/* Per-angle accuracy */}
                <div className="mt-8">
                  <p className="text-sm font-semibold text-foreground">
                    Accuracy by rotation angle
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    The classic mental-rotation signature: larger turns, slower and trickier judgments
                  </p>
                  <div className="mt-3 space-y-2.5">
                    {score.angleStats.map((stat) => (
                      <div key={stat.angle} data-testid={`mrot-angle-bar-${stat.angle}`}>
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold tabular-nums text-foreground">
                            {stat.angle} degrees
                          </span>
                          <span className="tabular-nums text-muted-foreground">
                            {stat.correct} / {stat.total}
                          </span>
                        </div>
                        <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-muted">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{
                              width: `${stat.total > 0 ? (stat.correct / stat.total) * 100 : 0}%`,
                            }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="h-full rounded-full bg-primary/85"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="mt-6 text-center text-xs leading-relaxed text-muted-foreground">
                  Educational estimate, not a clinical assessment. Every session
                  uses freshly generated figures, so retakes measure rotation
                  skill rather than memory.
                </p>

                <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button
                    type="button"
                    data-testid="mrot-retake"
                    onClick={start}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    Retake - new random figures
                  </button>
                  <a
                    href="/test"
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                  >
                    Try the Full IQ Test
                  </a>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-xl text-center" data-testid="mrot-invalid">
                <h3 className="text-xl font-bold text-foreground">This session was not scored</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {score.invalidReason}
                </p>
                <button
                  type="button"
                  data-testid="mrot-retake"
                  onClick={start}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color] hover:-translate-y-0.5 hover:bg-emerald-700"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Start a fresh session
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
