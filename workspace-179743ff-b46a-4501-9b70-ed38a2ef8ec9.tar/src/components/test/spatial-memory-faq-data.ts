/* ------------------------------------------------------------------ */
/*  Spatial Memory Test - FAQ (single source)                          */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type SmFaq = { question: string; answer: string };

export const SPATIAL_MEMORY_FAQS: SmFaq[] = [
  {
    question: "What is a spatial memory test and what does it measure?",
    answer:
      "A spatial memory test measures paired-associate binding: your ability to glue a WHAT (a symbol) to a WHERE (its exact cell) in a single glance and re-unite them later. Symbols take turns appearing inside grid cells, the board empties, and you send every symbol home by tapping it in the tray and then tapping its cell. Under the hood this exercises spatial encoding, associative binding and exact-place retrieval - the machinery you use when you park in a multi-storey car park, find a saved contact's position on screen, or reach for the light switch in a dark room without looking.",
  },
  {
    question: "How is this different from the Pattern Memory or Visual Memory tests?",
    answer:
      "Pattern Memory is about pure FORM - which tiles were lit, no symbols involved. Visual Memory is one cumulative pattern that grows level by level. This test is about BINDING: each round pairs specific symbols with specific cells, and you must later say which symbol sat where. It is also all-or-nothing scoring - a symbol placed one cell off scores exactly zero, while a pattern test gives partial credit for every tile you rebuild.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Each round is scored independently: the number of symbols placed in their exact studied cell, divided by the round's symbol count. Those five round scores are averaged and compared against an adult population model (mean about 0.62, SD 0.12), then mapped onto the standard IQ scale (mean 100, SD 15), clamped to 55-145 like all BrainMetrics tests. If you re-place a symbol during recall, only the final placement counts - so you can freely correct yourself before submitting.",
  },
  {
    question: "Why do the grids keep growing?",
    answer:
      "The five rounds run from a 3x3 grid with 3 symbols up to a 5x5 grid with 7. Growing the board does two things at once: it multiplies the number of candidate cells a symbol could belong to, and it spreads the pairs further apart - which forces your memory to hold genuinely spatial relationships instead of one compact clump. The average adult holds most of the small boards and loses ground on the 5x5, which is exactly where the score separates people.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "The average adult places about 62% of symbols into their exact home across the five rounds. Perfect recall on all 25 bindings maps to the index ceiling of 145, and around 88% average puts you in the top few percent. Two habits move the needle most: during study, narrate each pair to yourself (\"star, dead centre\"), and during recall, place the symbols you are CERTAIN about first - confidence ordering protects you from second-guessing the ones you truly know.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every run reseeds the generator for fresh symbols and fresh locations, so there is nothing to memorise between attempts. A small practice effect is normal: the second run usually improves because the task format is familiar, not because your binding got stronger. For tracking real change, run it two or three times in a sitting and compare weekly rather than hourly - sleep, stress and screen size all move spatial recall by a few percent, which is ordinary variation rather than genuine change.",
  },
];
