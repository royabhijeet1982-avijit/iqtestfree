/* ------------------------------------------------------------------ */
/*  Spatial Memory Test - pure scoring engine                          */
/*  Paradigm: symbol-location PAIRED ASSOCIATES. During STUDY each     */
/*  symbol appears inside its grid cell (one at a time, engine-paced), */
/*  binding "what" to "where". During RECALL the symbols come back in  */
/*  a shuffled tray and must be dragged - er, tapped - back into the   */
/*  cells they belonged to, while the grid keeps growing across five   */
/*  rounds (3x3 -> 5x5).                                               */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - pattern-memory: pure pattern FORM, no symbols. Here the WHAT    */
/*     and the WHERE are separate pieces that must be BOUND together   */
/*     and later re-united - the classic paired-associate structure.    */
/*   - visual-memory: cumulative rebuild of lit tiles. Here: discrete  */
/*     symbol-cell pairs, every placement an all-or-nothing judgement. */
/*                                                                     */
/*  Scoring honesty (anti-gaming by design):                           */
/*   - A placement scores only when the right symbol lands in the      */
/*     right cell. There is no partial credit for proximity, no        */
/*     penalty structure to exploit: random placement nets roughly     */
/*     1/cells per symbol, mashing cannot reach the anchor.            */
/*   - Study timing is engine-owned; cells carry machine hooks ONLY    */
/*     during the study flash (anti-cheat).                            */
/*   - Every run reseeds the RNG: fresh symbols, fresh locations.      */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Grid dimension per round (3 -> 5). */
export const ROUND_GRID_DIMS: readonly number[] = [3, 3, 4, 4, 5];

/** Symbol count per round (3 -> 7). */
export const ROUND_ITEM_COUNTS: readonly number[] = [3, 4, 5, 6, 7];

/** Total symbols shown across a full session. */
export const TOTAL_ITEMS = ROUND_ITEM_COUNTS.reduce((a, b) => a + b, 0);

/* -------------------- Engine-owned timing (ms) -------------------- */
/** How long each symbol stays visible in its cell during STUDY. */
export const STUDY_ON_MS = 1150;
/** Dark gap between study symbols. */
export const STUDY_GAP_MS = 250;
/** Idle pause before the first study symbol of a round. */
export const PRE_STUDY_MS = 450;
/** Feedback reveal length after a round's submission. */
export const FEEDBACK_MS = 950;

/** Shortened timings used by automated flow tests via ?quick=1. */
export const STUDY_ON_MS_QUICK = 320;
export const STUDY_GAP_MS_QUICK = 70;
export const PRE_STUDY_MS_QUICK = 150;
export const FEEDBACK_MS_QUICK = 200;

/* -------------------- Population model -------------------- */
/**
 * Adult mean / SD for the mean round score on growing paired-associate
 * grids (3x3/3 items up to 5x5/7 items). The index is the standard IQ
 * scale.
 */
export const SCORE_MEAN = 0.62;
export const SCORE_SD = 0.12;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** One bound pair: a symbol and the cell it lived in. */
export type SymbolLocation = {
  /** Glyph from SYMBOL_POOL. */
  symbol: string;
  /** Row-major cell index inside the round's gridDim x gridDim board. */
  cell: number;
};

/** One round: grid size, the study pairs, and the shuffled recall tray. */
export type SpatialRound = {
  /** 0-based round index. */
  round: number;
  /** Grid is gridDim x gridDim cells. */
  gridDim: number;
  /** The true pairs, in study presentation order. */
  pairs: SymbolLocation[];
  /** Tray order for recall (shuffled symbols). */
  tray: string[];
};

export type SpatialMemorySession = {
  rounds: SpatialRound[];
};

/** One user placement during recall. */
export type Placement = {
  round: number;
  symbol: string;
  cell: number;
  /** Time from recall opening to this placement in ms (null if absent). */
  rtMs: number | null;
};

export type RoundStat = {
  round: number;
  gridDim: number;
  items: number;
  /** Placements whose cell matched the symbol's true cell. */
  correct: number;
  /** max(0, correct / items) for this round. */
  score: number;
};

export type SpatialGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SpatialMemoryScore = {
  /** Total correct placements across the session. */
  correct: number;
  /** Total symbols shown across the session. */
  totalItems: number;
  /** Mean of the five per-round scores. */
  accuracy: number;
  /** Mean placement reaction time in ms (null when no timings). */
  avgRtMs: number | null;
  /** Per-round breakdown, one entry per round. */
  rounds: RoundStat[];
  /** IQ-scale spatial memory index (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: SpatialGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle of a copy - never mutates the input. */
export function shuffled<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i]!;
    out[i] = out[j]!;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Symbol pool                                                        */
/* ------------------------------------------------------------------ */

/**
 * 26 widely-supported BMP geometric/card/weather glyphs. Deliberately
 * NOT emoji (no colour-emoji rendering surprises) and visually
 * distinct even for common colour-vision deficiencies when combined
 * with position. No symbol repeats within a session (25 are used).
 */
export const SYMBOL_POOL: readonly string[] = [
  "●", "○", "■", "□", "▲", "△", "▼", "◆", "◇", "★", "☆", "✚",
  "✖", "♠", "♣", "♥", "♦", "☾", "☀", "♪", "♫", "❄", "❀", "⌂",
  "◉", "⊕",
];

/* ------------------------------------------------------------------ */
/*  Session building                                                   */
/* ------------------------------------------------------------------ */

/** Row (0-based) of a cell index on a dim x dim grid. */
export function rowOf(cell: number, dim: number): number {
  return Math.floor(cell / dim);
}

/** Column (0-based) of a cell index on a dim x dim grid. */
export function colOf(cell: number, dim: number): number {
  return cell % dim;
}

/** Manhattan distance between two cells on a dim x dim grid. */
export function manhattan(a: number, b: number, dim: number): number {
  return (
    Math.abs(rowOf(a, dim) - rowOf(b, dim)) +
    Math.abs(colOf(a, dim) - colOf(b, dim))
  );
}

/**
 * Build a full session (5 rounds) from a seed:
 *  1. Shuffle the symbol pool once - no symbol repeats in a session.
 *  2. Per round draw ROUND_ITEM_COUNTS distinct cells from the
 *     gridDim x gridDim board with a minimum MANHATTAN separation of 2
 *     between any two cells (touching cells blur the spatial code),
 *     then assign the next unused symbols in shuffle order.
 *  3. Tray = the round's symbols, shuffled.
 */
export function buildSpatialMemorySession(seed: number): SpatialMemorySession {
  const rng = mulberry32(seed);
  const pool = shuffled(SYMBOL_POOL, rng);
  const needed = ROUND_ITEM_COUNTS.reduce((a, b) => a + b, 0);
  if (pool.length < needed) {
    throw new Error(`symbol pool too small: ${pool.length} < ${needed}`);
  }

  const rounds: SpatialRound[] = [];
  let symbolCursor = 0;

  for (let r = 0; r < ROUND_GRID_DIMS.length; r++) {
    const dim = ROUND_GRID_DIMS[r]!;
    const count = ROUND_ITEM_COUNTS[r]!;
    const allCells = Array.from({ length: dim * dim }, (_, i) => i);

    // Backtracking draw: count cells, pairwise manhattan >= 2.
    const chosen: number[] = [];
    const order = shuffled(allCells, rng);
    let visits = 0;
    const backtrack = (startIdx: number): boolean => {
      if (chosen.length === count) return true;
      for (let idx = startIdx; idx < order.length; idx++) {
        if (++visits > 20000) return false;
        const cand = order[idx]!;
        let tooClose = false;
        for (const c of chosen) {
          if (manhattan(c, cand, dim) < 2) {
            tooClose = true;
            break;
          }
        }
        if (tooClose) continue;
        chosen.push(cand);
        if (backtrack(idx + 1)) return true;
        chosen.pop();
      }
      return false;
    };
    backtrack(0);
    // Manhattan >= 2 on any dim >= 3 with count <= 7 always succeeds;
    // if the guard tripped anyway, fall back to spread anchors.
    const cells =
      chosen.length === count
        ? chosen
        : allCells.filter((c) => rowOf(c, dim) % 2 === 0 && colOf(c, dim) % 2 === 0).slice(0, count);

    const pairs: SymbolLocation[] = cells.map((cell, i) => ({
      symbol: pool[symbolCursor + i]!,
      cell,
    }));
    symbolCursor += count;

    rounds.push({
      round: r,
      gridDim: dim,
      pairs,
      tray: shuffled(pairs.map((p) => p.symbol), rng),
    });
  }

  return { rounds };
}

/* ------------------------------------------------------------------ */
/*  Population model + grading                                         */
/* ------------------------------------------------------------------ */

/**
 * Map the mean round score onto the IQ scale (mean 100, SD 15).
 * Each round's correct/items is floored at 0 BEFORE averaging.
 */
export function spatialIndex(accuracy: number): number {
  const clamped = Math.min(1, Math.max(0, accuracy));
  const iq = Math.round(100 + (15 * (clamped - SCORE_MEAN)) / SCORE_SD);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const erf = (x: number): number => {
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * ax);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-ax * ax);
    return sign * y;
  };
  const z = (iq - 100) / 15;
  const pct = 0.5 * (1 + erf(z / Math.SQRT2)) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): SpatialGrade {
  if (iq < 85) {
    return {
      label: "Scattered",
      blurb: "The growing grids are scattering your placements right now - one more run usually locks in the bind-what-to-where rhythm and lifts the number.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - you re-unite symbols with their cells about as well as the general population as the board grows.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Anchored",
      blurb: "Better than most - your symbol-to-slot bindings hold firmly even on the 5x5 board with seven pairs in play.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier spatial binding - the kind of what-goes-where memory that shines in navigation, design and chess.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Cartographer",
    blurb: "Elite spatial recall - nearly every symbol returned to its exact home across all five growing grids.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a complete session from the raw placements. A placement counts
 * ONLY when its symbol lands in its true cell; duplicates for the same
 * symbol keep the LAST placement (the UI allows re-placing). Rounds
 * without any placement score 0.
 */
export function scoreSession(
  placements: readonly Placement[],
  session: SpatialMemorySession | null
): SpatialMemoryScore {
  let correct = 0;
  let totalItems = 0;
  let rtSum = 0;
  let rtCount = 0;

  const stats: RoundStat[] = [];

  if (!session) {
    const iq = spatialIndex(0);
    return {
      correct: 0,
      totalItems: 0,
      accuracy: 0,
      avgRtMs: null,
      rounds: [],
      iq,
      percentile: iqToPercentile(iq),
      grade: gradeForIq(iq),
    };
  }

  for (const round of session.rounds) {
    totalItems += round.pairs.length;
    const truth = new Map(round.pairs.map((p) => [p.symbol, p.cell]));
    // Last placement wins per symbol.
    const finalBySymbol = new Map<string, { cell: number; rtMs: number | null }>();
    for (const pl of placements) {
      if (pl.round !== round.round) continue;
      if (!truth.has(pl.symbol)) continue;
      finalBySymbol.set(pl.symbol, { cell: pl.cell, rtMs: pl.rtMs });
    }
    let roundCorrect = 0;
    for (const [symbol, place] of finalBySymbol) {
      if (place.cell === truth.get(symbol)) {
        roundCorrect++;
      }
      if (place.rtMs !== null && Number.isFinite(place.rtMs)) {
        rtSum += place.rtMs;
        rtCount++;
      }
    }
    const score = round.pairs.length > 0 ? Math.max(0, roundCorrect / round.pairs.length) : 0;
    correct += roundCorrect;
    stats.push({
      round: round.round,
      gridDim: round.gridDim,
      items: round.pairs.length,
      correct: roundCorrect,
      score,
    });
  }

  const accuracy =
    stats.length > 0 ? stats.reduce((a, s) => a + s.score, 0) / stats.length : 0;
  const iq = spatialIndex(accuracy);

  return {
    correct,
    totalItems,
    accuracy,
    avgRtMs: rtCount > 0 ? rtSum / rtCount : null,
    rounds: stats,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
