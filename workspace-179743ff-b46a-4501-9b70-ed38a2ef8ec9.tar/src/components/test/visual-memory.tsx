"use client";

/* ------------------------------------------------------------------ */
/*  Visual Memory Test - interactive UI                                */
/*  Corsi block tapping on a 3x3 grid: watch tiles light up one by     */
/*  one, then rebuild the sequence from memory. Levels add a tile and  */
/*  speed up the playback; two lives per run. Scoring lives in         */
/*  visual-memory-core.ts.                                             */
/*                                                                     */
/*  Testing hook: /test/visual-memory?quick=1 starts the run with a    */
/*  single life so automated flow tests finish quickly.                */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (playback | recall | feedback) and lit tiles carry the "is-lit"    */
/*  class plus data-lit="true" so playback can be observed.            */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Eye, Heart, MousePointerClick, RotateCcw, ShieldCheck, X, Zap } from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  QUICK_LIVES,
  START_LIVES,
  START_LEVEL,
  gradeClick,
  makeDistinctSequence,
  makeSequence,
  mulberry32,
  scoreRun,
  speedForLevel,
  type VisualMemoryScore,
} from "./visual-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "playback" | "recall" | "feedback";

type Flash = { tile: number; kind: "correct" | "wrong"; id: number } | null;

/** Idle pause before the first tile lights up. */
const PRE_PLAYBACK_MS = 600;
/** Gap between the last tile going dark and the recall phase. */
const RECALL_DELAY_MS = 350;
/** How long the success/fail feedback holds before the next level. */
const SUCCESS_HOLD_MS = 950;
const FAIL_HOLD_MS = 1400;
/** Click feedback duration. */
const FLASH_MS = 220;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("visual-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function VisualMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("playback");
  const [level, setLevel] = useState(START_LEVEL);
  const [lives, setLives] = useState(START_LIVES);
  const [maxLives, setMaxLives] = useState(START_LIVES);
  const [litTile, setLitTile] = useState<number | null>(null);
  const [revealTile, setRevealTile] = useState<number | null>(null);
  const [flash, setFlash] = useState<Flash>(null);
  const [placed, setPlaced] = useState(0);
  const [stageRing, setStageRing] = useState<"success" | "fail" | null>(null);
  const [score, setScore] = useState<VisualMemoryScore | null>(null);

  const rngRef = useRef<() => number>(() => 0.5);
  const seqRef = useRef<number[]>([]);
  const clickIndexRef = useRef(0);
  const lastMarkRef = useRef(0);
  const recallRtsRef = useRef<number[]>([]);
  const attemptsRef = useRef<import("./visual-memory-core").LevelAttempt[]>([]);
  const livesRef = useRef(START_LIVES);
  const levelRef = useRef(START_LEVEL);
  const activeStateRef = useRef<ActiveState>("playback");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const result = scoreRun(attemptsRef.current, recallRtsRef.current);
    setScore(result);
    setPhase("results");
    // Bring the score into view - the user is scrolled mid-card.
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  const beginRecall = useCallback(() => {
    activeStateRef.current = "recall";
    setActiveState("recall");
    clickIndexRef.current = 0;
    setPlaced(0);
    setLitTile(null);
    lastMarkRef.current = performance.now();
  }, []);

  const schedulePlayback = useCallback(
    (seq: number[], lv: number) => {
      clearTimers();
      activeStateRef.current = "playback";
      setActiveState("playback");
      setLitTile(null);
      setRevealTile(null);
      setStageRing(null);
      const { onMs, offMs } = speedForLevel(lv);
      let t = PRE_PLAYBACK_MS;
      seq.forEach((tile) => {
        timersRef.current.push(
          setTimeout(() => {
            setLitTile(tile);
          }, t)
        );
        t += onMs;
        timersRef.current.push(
          setTimeout(() => {
            setLitTile(null);
          }, t)
        );
        t += offMs;
      });
      timersRef.current.push(
        setTimeout(() => beginRecall(), t + RECALL_DELAY_MS)
      );
    },
    [beginRecall, clearTimers]
  );

  const beginLevel = useCallback(
    (lv: number) => {
      levelRef.current = lv;
      setLevel(lv);
      setPhase("active");
      const seq = makeSequence(lv, rngRef.current);
      seqRef.current = seq;
      clickIndexRef.current = 0;
      setPlaced(0);
      setRevealTile(null);
      setStageRing(null);
      schedulePlayback(seq, lv);
    },
    [schedulePlayback]
  );

  const start = useCallback(() => {
    clearTimers();
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rngRef.current = mulberry32(seed);
    attemptsRef.current = [];
    recallRtsRef.current = [];
    finishedRef.current = false;
    const startingLives = quickRef.current ? QUICK_LIVES : START_LIVES;
    livesRef.current = startingLives;
    levelRef.current = START_LEVEL;
    setMaxLives(startingLives);
    setLives(startingLives);
    setLevel(START_LEVEL);
    setScore(null);
    setFlash(null);
    setLitTile(null);
    setRevealTile(null);
    setStageRing(null);
    setPlaced(0);
    setCountdownValue(3);
    setPhase("countdown");
    // Align the card immediately so the countdown is actually in view.
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Countdown 3-2-1, then the first playback begins. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginLevel(START_LEVEL);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginLevel]);

  /* --------------------------- recall clicks ------------------------ */

  const handleTileClick = useCallback(
    (tile: number) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recall") return;
      const seq = seqRef.current;
      if (!seq || seq.length === 0) return;

      const idx = clickIndexRef.current;
      const now = performance.now();
      const rt = now - lastMarkRef.current;
      lastMarkRef.current = now;
      const outcome = gradeClick(seq, idx, tile);

      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
      setFlash({ tile, kind: outcome.correct ? "correct" : "wrong", id: now });
      flashTimerRef.current = setTimeout(() => setFlash(null), FLASH_MS);

      if (outcome.correct) {
        recallRtsRef.current.push(rt);
        if (outcome.complete) {
          attemptsRef.current.push({
            level: seq.length,
            sequence: seq.slice(),
            correctClicks: seq.length,
            cleared: true,
          });
          activeStateRef.current = "feedback";
          setActiveState("feedback");
          setStageRing("success");
          setLitTile(null);
          clearTimers();
          timersRef.current.push(
            setTimeout(() => beginLevel(levelRef.current + 1), SUCCESS_HOLD_MS)
          );
        } else {
          clickIndexRef.current = idx + 1;
          setPlaced(idx + 1);
        }
      } else {
        // Wrong click ends the attempt: consume a life, reveal the
        // expected tile, then retry the same length with a NEW sequence.
        attemptsRef.current.push({
          level: seq.length,
          sequence: seq.slice(),
          correctClicks: idx,
          cleared: false,
        });
        livesRef.current -= 1;
        setLives(livesRef.current);
        setRevealTile(seq[idx] ?? null);
        activeStateRef.current = "feedback";
        setActiveState("feedback");
        setStageRing("fail");
        clearTimers();
        timersRef.current.push(
          setTimeout(() => {
            setFlash(null);
            if (livesRef.current > 0) {
              const fresh = makeDistinctSequence(seq.length, rngRef.current, seq);
              seqRef.current = fresh;
              clickIndexRef.current = 0;
              setPlaced(0);
              schedulePlayback(fresh, seq.length);
            } else {
              finish();
            }
          }, FAIL_HOLD_MS)
        );
      }
    },
    [beginLevel, clearTimers, finish, schedulePlayback]
  );

  /* ------------------------- derived data -------------------------- */

  const demoSeq = useMemo(
    () => makeSequence(START_LEVEL, mulberry32(20240607)),
    []
  );
  const previewLit = useMemo(() => new Set(demoSeq), [demoSeq]);

  const clearedCount = score?.ladder.filter((r) => r.cleared).length ?? 0;
  const failedCount = (score?.attempts ?? 0) - clearedCount;
  const accuracy =
    score && score.tilesCorrect + failedCount > 0
      ? score.tilesCorrect / (score.tilesCorrect + failedCount)
      : 0;

  const statusText =
    activeState === "playback"
      ? "Watch the pattern..."
      : activeState === "recall"
        ? "Your turn - tap the tiles in order"
        : stageRing === "success"
          ? "Perfect - level cleared"
          : (lives ?? 0) > 0
            ? "Not quite - a life is gone. New pattern coming up."
            : "Out of lives - run over";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="visual-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="vm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                Corsi block tapping · {quick ? "1 life (quick run)" : "2 lives"}
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Watch the pattern, then rebuild it
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Tiles on the grid light up one by one. When the playback stops,
                tap them back in exactly the same order. Each level adds one
                more tile - how far can your visual span stretch?
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-[220px] rounded-xl border border-border bg-muted/60 p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                The grid
              </p>
              <div
                data-testid="vm-preview"
                aria-hidden="true"
                className="mx-auto mt-2 grid w-fit grid-cols-3 gap-1.5"
              >
                {Array.from({ length: 9 }).map((_, i) => (
                  <span
                    key={i}
                    className={[
                      "h-9 w-9 rounded-lg border sm:h-10 sm:w-10",
                      previewLit.has(i)
                        ? "border-emerald-600 bg-emerald-500"
                        : "border-border bg-secondary",
                    ].join(" ")}
                  />
                ))}
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                Real patterns are random and change every level.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Eye className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Playback is fixed: tiles light for a beat each, faster as levels rise. Timing never changes for anyone.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                One wrong tap ends the attempt and reveals the tile you missed.
              </li>
              <li className="flex gap-2.5">
                <Heart className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {quick
                  ? "Quick run: a single life - one miss ends the run."
                  : "Two lives per run: a failed level replays with a brand-new pattern of the same length."}
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Your score is your visual span - the longest sequence you ever clear.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="vm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Eye className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="vm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Level {START_LEVEL} · {START_LEVEL} tiles · eyes on the grid
            </p>
            <div className="mx-auto mt-5 w-fit" aria-hidden="true">
              <div className="grid grid-cols-3 gap-2">
                {Array.from({ length: 9 }).map((_, i) => (
                  <span key={i} className="h-10 w-10 rounded-lg border border-border bg-secondary sm:h-12 sm:w-12" />
                ))}
              </div>
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="vm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Level + lives header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="vm-level"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Level {level}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {level} tiles to remember
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span
                  data-testid="vm-progress"
                  className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
                >
                  {placed} / {level}
                </span>
                <span
                  data-testid="vm-lives"
                  className="flex items-center gap-1.5"
                  aria-label={`${lives} ${lives === 1 ? "life" : "lives"} remaining`}
                >
                  {Array.from({ length: maxLives }).map((_, i) => {
                    const alive = i < lives;
                    return (
                      <span
                        key={i}
                        data-life-lost={alive ? "false" : "true"}
                        className={[
                          "h-3.5 w-3.5 rounded-full border transition-colors duration-200",
                          alive
                            ? "border-emerald-600 bg-emerald-500"
                            : "border-border bg-transparent",
                        ].join(" ")}
                      />
                    );
                  })}
                </span>
              </div>
            </div>

            {/* Stage */}
            <div
              data-testid="vm-stage"
              data-phase={activeState}
              className={[
                "mx-auto mt-5 w-full max-w-[340px] rounded-2xl border-2 p-3 transition-[border-color,box-shadow] duration-300 sm:max-w-md sm:p-4",
                stageRing === "success"
                  ? "border-emerald-500 shadow-[0_0_32px_rgba(16,185,129,0.25)]"
                  : stageRing === "fail"
                    ? "border-red-400 shadow-[0_0_32px_rgba(239,68,68,0.18)]"
                    : "border-border",
              ].join(" ")}
            >
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                {Array.from({ length: 9 }).map((_, i) => {
                  const isLit = litTile === i;
                  const isRevealed =
                    revealTile === i && activeState === "feedback";
                  const lit = isLit || isRevealed;
                  const isFlashing = flash?.tile === i;
                  return (
                    <button
                      key={i}
                      type="button"
                      data-testid={`vm-tile-${i}`}
                      aria-label={`Tile ${i + 1}, row ${Math.floor(i / 3) + 1}, column ${(i % 3) + 1}`}
                      aria-pressed={lit}
                      data-lit={lit ? "true" : "false"}
                      data-flash={isFlashing ? flash!.kind : undefined}
                      disabled={activeState !== "recall"}
                      onClick={() => handleTileClick(i)}
                      className={[
                        "vm-tile aspect-square select-none rounded-2xl border-2 touch-manipulation transition-[background-color,border-color,transform,box-shadow] duration-150",
                        isFlashing && flash!.kind === "wrong"
                          ? "vm-flash-wrong scale-95 border-red-500 bg-red-500"
                          : isFlashing
                            ? "vm-flash-correct scale-95 border-emerald-600 bg-emerald-500"
                            : lit
                              ? "is-lit scale-[1.03] border-emerald-600 bg-emerald-500 shadow-[0_0_24px_rgba(16,185,129,0.5)]"
                              : "border-border bg-secondary hover:border-primary/60 active:scale-95 disabled:hover:border-border",
                      ].join(" ")}
                    />
                  );
                })}
              </div>
            </div>

            {/* Status */}
            <p
              data-testid="vm-status"
              aria-live="polite"
              className={[
                "mt-4 text-center text-sm font-semibold sm:text-base",
                stageRing === "fail"
                  ? "text-red-600"
                  : stageRing === "success"
                    ? "text-emerald-700"
                    : "text-muted-foreground",
              ].join(" ")}
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="vm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="vm-span"
                    data-final={score.span}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.span} duration={1.2} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Visual span · longest sequence cleared · adult mean 5.3
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="vm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="vm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <Eye className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="vm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Level ladder */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Your level ladder
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Green levels were cleared, red ones used a life
                </p>
                <div
                  data-testid="vm-ladder"
                  className="mt-3 flex flex-wrap items-center justify-center gap-2"
                >
                  {score.ladder.map((run) => (
                    <span
                      key={run.level}
                      data-testid={`vm-ladder-level-${run.level}`}
                      data-status={run.cleared ? "cleared" : "failed"}
                      className={[
                        "inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm font-bold tabular-nums",
                        run.cleared
                          ? "border-emerald-600 bg-emerald-600 text-white"
                          : "border-red-200 bg-red-50 text-red-600",
                      ].join(" ")}
                    >
                      {run.cleared ? (
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : (
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      L{run.level}
                    </span>
                  ))}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="vm-stat-tiles" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.tilesCorrect}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">tiles recalled</p>
                </div>
                <div data-testid="vm-stat-accuracy" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {Math.round(accuracy * 100)}%
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">click accuracy</p>
                </div>
                <div data-testid="vm-stat-recall" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.meanRecallMs !== null
                      ? `${(score.meanRecallMs / 1000).toFixed(2)}s`
                      : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg recall speed</p>
                </div>
                <div data-testid="vm-stat-attempts" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {clearedCount}
                    <span className="text-sm font-semibold text-muted-foreground"> / {score.attempts}</span>
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">levels cleared / attempts</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="vm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random patterns
                </button>
                <a
                  href="/test"
                  data-testid="vm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
