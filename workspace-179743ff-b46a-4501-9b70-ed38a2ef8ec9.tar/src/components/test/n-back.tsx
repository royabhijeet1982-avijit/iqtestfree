"use client";

/* ------------------------------------------------------------------ */
/*  N-Back Test - interactive UI                                       */
/*  Classic letter N-back (Kirchner 1958 lineage): letters appear one  */
/*  at a time and you press MATCH (SPACE / A, or the on-screen button) */
/*  whenever the current letter matches the one exactly N steps back.  */
/*  A run is five blocks with N = 1..5. All sequencing, scoring and    */
/*  IQ anchoring live in n-back-core.ts - this file only drives the    */
/*  2.8s trial rhythm and renders its outputs.                         */
/*                                                                     */
/*  Testing hook: /test/n-back?quick=1 runs two 12-trial blocks        */
/*  (N = 1..2) so automated flow tests can finish a full run quickly.  */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Brain,
  CheckCircle2,
  Keyboard,
  MousePointerClick,
  RotateCcw,
  ShieldCheck,
  Target,
  Timer,
  XCircle,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  BLOCK_N_VALUES,
  NBACK_LETTERS,
  PASS_THRESHOLD,
  QUICK_BLOCK_N_VALUES,
  STIMULUS_VISIBLE_MS,
  TRIAL_MS,
  buildBlocks,
  mulberry32,
  scoreBlock,
  summarizeResults,
  type BlockScore,
  type NBackBlock,
  type NBackResults,
  type TrialResponse,
} from "./n-back-core";

type Phase = "intro" | "countdown" | "active" | "block-summary" | "results";

type FlashKind = "hit" | "miss" | "false-alarm";
type Flash = { kind: FlashKind; id: number } | null;

/** Breathing room after "GO" / between blocks, before the first letter. */
const PRE_BLOCK_BEAT_MS = 1200;
/** How long the between-block summary stays up before auto-advancing. */
const BLOCK_SUMMARY_MS = 4200;
/** How long each feedback flash stays on screen. */
const FLASH_MS = 700;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("n-back-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

const pct = (fraction: number) => `${Math.round(fraction * 100)}%`;

const FLASH_COPY: Record<FlashKind, { text: string; cls: string }> = {
  hit: { text: "Hit!", cls: "text-emerald-600" },
  miss: { text: "Missed", cls: "text-red-500" },
  "false-alarm": { text: "False alarm", cls: "text-red-500" },
};

export function NBackTest({ quick = false }: { quick?: boolean }) {
  const blockNs = quick ? QUICK_BLOCK_N_VALUES : BLOCK_N_VALUES;
  const totalBlocks = blockNs.length;
  const maxN = blockNs[blockNs.length - 1];
  const passLabel = `${Math.round(PASS_THRESHOLD * 100)}%`;

  /* ----------------------------- state ----------------------------- */

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [currentBlock, setCurrentBlock] = useState<NBackBlock | null>(null);
  const [blockIdx, setBlockIdx] = useState(0);
  const [trialIndex, setTrialIndex] = useState(-1);
  const [currentLetter, setCurrentLetter] = useState("");
  const [letterVisible, setLetterVisible] = useState(false);
  const [respondedThisTrial, setRespondedThisTrial] = useState(false);
  const [flash, setFlash] = useState<Flash>(null);
  const [lastBlockScore, setLastBlockScore] = useState<BlockScore | null>(null);
  const [blockScores, setBlockScores] = useState<BlockScore[]>([]);
  const [results, setResults] = useState<NBackResults | null>(null);
  /** Render-readable mirror of blocksRef (ref reads are illegal during render). */
  const [blocks, setBlocks] = useState<NBackBlock[]>([]);
  /** Render-readable mirror of responsesRef: trial index -> responded. */
  const [responseLog, setResponseLog] = useState<Record<number, boolean>>({});

  /* ------------------------------ refs ----------------------------- */

  const blocksRef = useRef<NBackBlock[]>([]);
  const blockIdxRef = useRef(0);
  const trialIdxRef = useRef(-1);
  const responsesRef = useRef<TrialResponse[]>([]);
  const scoresRef = useRef<BlockScore[]>([]);
  const trialStartRef = useRef(0);
  const respondedRef = useRef(false);
  const phaseRef = useRef<Phase>("intro");
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    trialIdxRef.current = trialIndex;
  }, [trialIndex]);

  const addTimer = useCallback((fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms);
    timersRef.current.push(t);
    return t;
  }, []);

  /* Every timer dies on unmount - no orphans after navigation. */
  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
      timersRef.current = [];
    };
  }, []);

  /* --------------------------- feedback ---------------------------- */

  const showFlash = useCallback(
    (kind: FlashKind) => {
      const id = performance.now();
      setFlash({ kind, id });
      addTimer(() => {
        setFlash((f) => (f && f.id === id ? null : f));
      }, FLASH_MS);
    },
    [addTimer]
  );

  /* ------------------------- run lifecycle ------------------------- */

  const start = useCallback(() => {
    if (
      phaseRef.current === "countdown" ||
      phaseRef.current === "active" ||
      phaseRef.current === "block-summary"
    ) {
      return;
    }
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];

    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const blocks = buildBlocks(mulberry32(seed), { quick });
    blocksRef.current = blocks;
    setBlocks(blocks);
    blockIdxRef.current = 0;
    responsesRef.current = [];
    setResponseLog({});
    scoresRef.current = [];
    respondedRef.current = false;

    setCurrentBlock(null);
    setBlockIdx(0);
    setTrialIndex(-1);
    setCurrentLetter("");
    setLetterVisible(false);
    setRespondedThisTrial(false);
    setFlash(null);
    setLastBlockScore(null);
    setBlockScores([]);
    setResults(null);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [quick]);

  const finishRun = useCallback(() => {
    const summary = summarizeResults(scoresRef.current);
    setResults(summary);
    setPhase("results");
    // The user is scrolled mid-card after the last block - realign.
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  const beginBlock = useCallback((idx: number) => {
    const block = blocksRef.current[idx];
    if (!block) return;
    blockIdxRef.current = idx;
    responsesRef.current = [];
    setResponseLog({});
    respondedRef.current = false;
    setBlockIdx(idx);
    setCurrentBlock(block);
    setTrialIndex(-1); // -1 = get-ready beat before trial 0
    setRespondedThisTrial(false);
    setFlash(null);
    setLetterVisible(false);
    setCurrentLetter("");
    setPhase("active");
  }, []);

  const advanceFromSummary = useCallback(() => {
    if (phaseRef.current !== "block-summary") return;
    const next = blockIdxRef.current + 1;
    if (next >= blocksRef.current.length) finishRun();
    else beginBlock(next);
  }, [beginBlock, finishRun]);

  /* 3-2-1 countdown, then the first block starts. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginBlock(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginBlock]);

  /* ------------------------- trial driver -------------------------- */

  useEffect(() => {
    if (phase !== "active" || !currentBlock) return;

    // Get-ready beat before a block's first letter.
    if (trialIndex < 0) {
      const beat = setTimeout(() => setTrialIndex(0), PRE_BLOCK_BEAT_MS);
      return () => clearTimeout(beat);
    }

    // Block complete: score it with the core engine, show the summary beat.
    if (trialIndex >= currentBlock.trials.length) {
      const responses = currentBlock.trials.map(
        (_, i) => responsesRef.current[i] ?? { responded: false, rtMs: null }
      );
      const score = scoreBlock(currentBlock, responses);
      scoresRef.current = [...scoresRef.current, score];
      setBlockScores(scoresRef.current);
      setLastBlockScore(score);
      setPhase("block-summary");
      return;
    }

    // Regular trial: show the letter for STIMULUS_VISIBLE_MS, then a gap
    // until the full TRIAL_MS window closes and the next trial begins.
    const trial = currentBlock.trials[trialIndex];
    if (!trial) return;
    respondedRef.current = false;
    setRespondedThisTrial(false);
    setCurrentLetter(trial.letter);
    setLetterVisible(true);
    trialStartRef.current = performance.now();

    const hideT = setTimeout(() => setLetterVisible(false), STIMULUS_VISIBLE_MS);
    const nextT = setTimeout(() => {
      if (trial.isTarget && !respondedRef.current) showFlash("miss");
      setTrialIndex((i) => i + 1);
    }, TRIAL_MS);
    return () => {
      clearTimeout(hideT);
      clearTimeout(nextT);
    };
  }, [phase, currentBlock, trialIndex, showFlash]);

  /* Auto-advance the block summary; cancelled the moment the phase moves. */
  useEffect(() => {
    if (phase !== "block-summary") return;
    const t = setTimeout(advanceFromSummary, BLOCK_SUMMARY_MS);
    return () => clearTimeout(t);
  }, [phase, advanceFromSummary]);

  /* --------------------------- responding -------------------------- */

  const respond = useCallback(() => {
    if (phaseRef.current !== "active") return;
    if (respondedRef.current) return;
    const block = blocksRef.current[blockIdxRef.current];
    const idx = trialIdxRef.current;
    const trial = block?.trials[idx];
    if (!block || !trial || idx < 0 || idx >= block.trials.length) return;

    respondedRef.current = true;
    setRespondedThisTrial(true);
    responsesRef.current[idx] = {
      responded: true,
      rtMs: Math.max(0, Math.round(performance.now() - trialStartRef.current)),
    };
    setResponseLog((log) => ({ ...log, [idx]: true }));
    showFlash(trial.isTarget ? "hit" : "false-alarm");
  }, [showFlash]);

  /* Keyboard: SPACE and A log a match. Repeats ignored. */
  useEffect(() => {
    if (phase !== "active") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      const isMatchKey =
        event.code === "Space" ||
        event.key === " " ||
        event.key === "a" ||
        event.key === "A";
      if (!isMatchKey) return;
      event.preventDefault();
      respond();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, respond]);

  /* ------------------------- derived views ------------------------- */

  const blockTrials = currentBlock?.trials ?? [];
  const faRateOf = (s: BlockScore) =>
    s.nonTargetCount > 0 ? s.falseAlarms / s.nonTargetCount : 0;
  const nextBlockN = blocks[blockIdx + 1]?.n ?? null;
  const firstBlockN = blocks[0]?.n ?? 1;
  const isLastBlockDone = nextBlockN === null;
  const demoLetters = [NBACK_LETTERS[0], NBACK_LETTERS[2], NBACK_LETTERS[0]];

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="n-back-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="nb-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Brain className="h-3.5 w-3.5" aria-hidden="true" />
                Working memory · N = 1 → {maxN}
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Hold the stream, spot the repeat
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Letters appear one at a time. Press MATCH whenever the current
                letter is the same as the one exactly{" "}
                <span className="font-semibold text-foreground">N steps back</span>{" "}
                - and stay quiet when it is not.
              </p>
            </div>

            {/* N = 2 worked example */}
            <div className="mx-auto mt-6 max-w-md rounded-xl border border-border bg-muted/60 p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Example · N = 2
              </p>
              <div className="mt-3 flex items-center justify-center gap-3">
                {demoLetters.map((letter, i) => (
                  <span
                    key={i}
                    aria-hidden="true"
                    className={[
                      "flex h-14 w-14 items-center justify-center rounded-xl border-2 text-2xl font-black",
                      i === 2
                        ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                        : "border-border bg-card text-foreground",
                    ].join(" ")}
                  >
                    {letter}
                  </span>
                ))}
              </div>
              <p className="mt-3 text-center text-xs leading-relaxed text-muted-foreground">
                The last letter repeats the one from{" "}
                <span className="font-semibold text-foreground">two steps back</span>{" "}
                - that is a match. The letter between them does not matter.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {totalBlocks} blocks with N climbing 1 → {maxN}
                {quick ? " · about 1 minute" : " · about 6 minutes"} · one letter every{" "}
                {TRIAL_MS / 1000}s, visible {(STIMULUS_VISIBLE_MS / 1000).toFixed(1)}s.
              </li>
              <li className="flex gap-2.5">
                <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Press SPACE or A to log a match, or tap the MATCH button on a
                touch screen. The first N letters of each block are warm-up.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Balanced scoring: hits and correctly skipped non-matches both
                count. A block clears at {passLabel} balanced accuracy.
              </li>
              <li className="flex gap-2.5">
                <Target className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Practice hint: rehearse the rolling window with each letter -
                &ldquo;C, H, C&hellip;&rdquo; - and let lures that match only N-1 back go by.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="nb-start"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Brain className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · fresh random sequences every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="nb-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Get ready
            </p>
            <div className="mt-4 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
            <p className="mt-6 text-center text-sm text-muted-foreground">
              First block:{" "}
              <span className="font-bold text-foreground">N = {firstBlockN}</span>{" "}
              - press SPACE (or tap MATCH) when a letter matches the one from{" "}
              {firstBlockN} step
              {firstBlockN > 1 ? "s" : ""} back.
            </p>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && currentBlock && (
          <motion.div
            key="active"
            data-testid="nb-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Header: block position + N label */}
            <div className="flex items-center justify-between gap-3">
              <span className="rounded-full border border-border bg-muted/60 px-3 py-1 text-xs font-semibold text-muted-foreground tabular-nums">
                Block {blockIdx + 1} of {totalBlocks}
              </span>
              <span
                data-testid="nb-nlabel"
                className="rounded-full border border-emerald-200 bg-emerald-50 px-4 py-1 text-sm font-black text-emerald-700"
              >
                N = {currentBlock.n}
              </span>
            </div>

            {/* Progress dots: emerald = hit / correct rejection, red = miss / false alarm */}
            <div
              data-testid="nb-trial-progress"
              role="img"
              aria-label={`Trial ${Math.min(trialIndex + 1, blockTrials.length)} of ${blockTrials.length}`}
              className="mt-4 flex flex-wrap items-center justify-center gap-1.5"
            >
              {blockTrials.map((trial, i) => {
                const responded =
                  i <= trialIndex
                    ? i === trialIndex
                      ? respondedThisTrial
                      : (responseLog[i] ?? false)
                    : null;
                const good = responded === null ? null : trial.isTarget ? responded : !responded;
                return (
                  <span
                    key={i}
                    className={[
                      "h-2.5 w-2.5 rounded-full transition-colors duration-200",
                      good === null ? "bg-muted" : good ? "bg-primary" : "bg-red-400",
                      i === trialIndex ? "ring-2 ring-foreground/70 ring-offset-1" : "",
                    ].join(" ")}
                  />
                );
              })}
            </div>

            {/* Stimulus square */}
            <div
              data-testid="nb-stimulus"
              data-n={currentBlock.n}
              data-trial-index={trialIndex}
              data-letter={letterVisible ? currentLetter : ""}
              aria-label={
                letterVisible ? `Letter ${currentLetter}` : "Gap - no letter on screen"
              }
              className={[
                "relative mx-auto mt-5 flex h-44 w-44 items-center justify-center rounded-2xl border-2 transition-colors duration-150 sm:h-52 sm:w-52",
                flash
                  ? flash.kind === "hit"
                    ? "border-emerald-500"
                    : "border-red-400"
                  : "border-border",
                letterVisible ? "bg-secondary/70" : "bg-muted/40",
              ].join(" ")}
            >
              <AnimatePresence mode="wait">
                {letterVisible && (
                  <motion.span
                    key={`${trialIndex}-${currentLetter}`}
                    data-testid="nb-letter"
                    initial={{ scale: 0.7, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    transition={{ duration: 0.16 }}
                    className="select-none text-7xl font-black leading-none text-foreground sm:text-8xl"
                  >
                    {currentLetter}
                  </motion.span>
                )}
              </AnimatePresence>
              {trialIndex < 0 && (
                <span className="text-sm font-medium text-muted-foreground">
                  Get ready…
                </span>
              )}
            </div>

            {/* Live feedback (aria-live for screen readers) */}
            <div
              data-testid="nb-feedback"
              role="status"
              aria-live="polite"
              className="mt-3 flex h-7 items-center justify-center"
            >
              <AnimatePresence mode="wait">
                {flash && (
                  <motion.span
                    key={flash.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className={`text-base font-bold ${FLASH_COPY[flash.kind].cls}`}
                  >
                    {FLASH_COPY[flash.kind].text}
                  </motion.span>
                )}
              </AnimatePresence>
            </div>

            {/* MATCH button (min 44px touch target) */}
            <div className="mt-1 flex justify-center">
              <button
                type="button"
                data-testid="nb-match-btn"
                onClick={(e) => {
                  respond();
                  e.currentTarget.blur();
                }}
                disabled={respondedThisTrial}
                aria-label="Match - this letter repeats the one from N steps back"
                className={[
                  "flex h-16 w-full max-w-xs items-center justify-center gap-2 rounded-2xl border-2 text-lg font-black tracking-wide transition-[background-color,border-color,color,translate] active:translate-y-0",
                  respondedThisTrial
                    ? "border-emerald-300 bg-emerald-50 text-emerald-700"
                    : "border-primary bg-primary text-primary-foreground shadow-md hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg",
                ].join(" ")}
              >
                {respondedThisTrial ? (
                  <>
                    <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
                    Match logged
                  </>
                ) : (
                  <>
                    <MousePointerClick className="h-5 w-5" aria-hidden="true" />
                    MATCH
                  </>
                )}
              </button>
            </div>

            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
              <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
              SPACE or A logs a match · answers count any time before the next letter
            </p>
          </motion.div>
        )}

        {/* --------------------------- BLOCK SUMMARY --------------------------- */}
        {phase === "block-summary" && lastBlockScore && (
          <motion.div
            key="block-summary"
            data-testid="nb-block-summary"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-md text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Block {blockIdx + 1} of {totalBlocks} · N = {lastBlockScore.n}
              </p>
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${
                    lastBlockScore.passed
                      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                      : "border-border bg-muted/60 text-muted-foreground"
                  }`}
                >
                  {lastBlockScore.passed ? (
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <XCircle className="h-4 w-4" aria-hidden="true" />
                  )}
                  {lastBlockScore.passed ? "Block cleared" : `Below the ${passLabel} bar`}
                </span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-xl border border-border bg-muted/40 p-3">
                  <p className="text-xl font-bold tabular-nums text-foreground">
                    {pct(lastBlockScore.hitRate)}
                  </p>
                  <p className="text-xs text-muted-foreground">hits ({lastBlockScore.hits}/{lastBlockScore.targetCount})</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/40 p-3">
                  <p className="text-xl font-bold tabular-nums text-foreground">
                    {pct(faRateOf(lastBlockScore))}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    false alarms ({lastBlockScore.falseAlarms}/{lastBlockScore.nonTargetCount})
                  </p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                {isLastBlockDone
                  ? "That was the last block - computing your results…"
                  : `Next up: N = ${nextBlockN}. One more step back to track.`}
              </p>
              <button
                type="button"
                data-testid="nb-next-block"
                onClick={advanceFromSummary}
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg"
              >
                {isLastBlockDone ? "See results" : `Start the N = ${nextBlockN} block`}
              </button>
              <p className="mt-2 text-xs text-muted-foreground">
                Starts automatically in a few seconds.
              </p>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && results && (
          <motion.div
            key="results"
            data-testid="nb-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <span
                  data-testid="nb-iq"
                  className="mt-2 block text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                >
                  <CountUp to={results.iq} duration={1.6} />
                </span>
                <p className="mt-1 text-sm text-muted-foreground">
                  Working-Memory Index · same 100-point scale as an IQ test
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="nb-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${results.grade.className}`}
                  >
                    <Brain className="h-4 w-4" aria-hidden="true" />
                    {results.grade.label}
                  </span>
                  <span
                    data-testid="nb-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {results.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {results.grade.blurb}
                </p>
              </div>

              {/* Headline stats */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p
                    data-testid="nb-span"
                    className="text-2xl font-bold tabular-nums text-foreground"
                  >
                    N = {results.effectiveSpan}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">effective span</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {pct(results.composite)}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">composite accuracy</p>
                </div>
                <div className="col-span-2 rounded-xl border border-border bg-muted/40 p-4 text-center sm:col-span-1">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {results.blocks.filter((b) => b.passed).length} / {results.blocks.length}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">blocks cleared</p>
                </div>
              </div>

              {/* Per-block breakdown */}
              <div className="mt-8">
                <p className="text-sm font-semibold text-foreground">Block by block</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Signal detection per level - a block clears at {passLabel} balanced accuracy
                  (the mean of hit rate and correct-rejection rate).
                </p>
                <div className="mt-3 grid gap-2">
                  {results.blocks.map((s) => (
                    <div
                      key={s.n}
                      className="flex items-center gap-3 rounded-xl border border-border bg-muted/40 px-4 py-2.5"
                    >
                      <span className="w-14 shrink-0 text-sm font-black text-foreground">
                        N = {s.n}
                      </span>
                      <div className="flex flex-1 flex-wrap items-center gap-x-4 gap-y-0.5 text-xs text-muted-foreground">
                        <span>
                          Hits{" "}
                          <span
                            data-testid={`nb-hitrate-${s.n}`}
                            className="font-bold tabular-nums text-foreground"
                          >
                            {pct(s.hitRate)}
                          </span>
                        </span>
                        <span>
                          False alarms{" "}
                          <span
                            data-testid={`nb-farate-${s.n}`}
                            className="font-bold tabular-nums text-foreground"
                          >
                            {pct(faRateOf(s))}
                          </span>
                        </span>
                        <span className="hidden sm:inline">
                          Balanced{" "}
                          <span className="font-bold tabular-nums text-foreground">
                            {pct(s.balancedScore)}
                          </span>
                        </span>
                      </div>
                      <span
                        className={`shrink-0 rounded-full border px-2.5 py-0.5 text-xs font-bold ${
                          s.passed
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-border bg-card text-muted-foreground"
                        }`}
                      >
                        {s.passed ? "Cleared" : `Below ${passLabel}`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Anti-gaming / fairness note */}
              <p
                data-testid="nb-fairness"
                className="mt-6 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm leading-relaxed text-emerald-800"
              >
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                Fair-play note: N-back is mash-proof. Responding to every letter catches
                every target but floods false alarms, and never responding misses
                everything - both sink the balanced score to about 50%, which anchors to a
                low index. Only genuine detection scores well.
              </p>

              {quick && (
                <p className="mt-3 text-center text-xs text-muted-foreground">
                  Quick run ({results.blocks.length} blocks) - retake without{" "}
                  <code className="rounded bg-muted px-1 py-0.5">?quick=1</code> for the
                  full five-block run.
                </p>
              )}

              {/* Actions */}
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="nb-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random sequences
                </button>
                <a
                  href="/test"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  Try the Full IQ Test
                </a>
              </div>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm">
                <span className="text-xs text-muted-foreground">Related:</span>
                <a
                  href="/test/digit-span"
                  className="rounded-full border border-border bg-muted/40 px-3.5 py-1.5 font-medium text-foreground transition-[border-color,color] hover:border-primary hover:text-primary"
                >
                  Digit Span
                </a>
                <a
                  href="/test/processing-speed"
                  className="rounded-full border border-border bg-muted/40 px-3.5 py-1.5 font-medium text-foreground transition-[border-color,color] hover:border-primary hover:text-primary"
                >
                  Processing Speed
                </a>
                <a
                  href="/test/matrix-reasoning"
                  className="rounded-full border border-border bg-muted/40 px-3.5 py-1.5 font-medium text-foreground transition-[border-color,color] hover:border-primary hover:text-primary"
                >
                  Matrix Reasoning
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * Query-aware wrapper used by the /test/n-back page: reads ?quick=1 on
 * the client so the marketing page itself stays statically renderable.
 * Must render inside a Suspense boundary (useSearchParams requirement).
 */
export function NBackTestFromQuery() {
  const searchParams = useSearchParams();
  return <NBackTest quick={searchParams.get("quick") === "1"} />;
}
