/* ------------------------------------------------------------------ */
/*  Working Memory Test - pure scoring engine                          */
/*  Paradigm: Letter-Number Sequencing (WAIS Working Memory subtest).  */
/*                                                                     */
/*  A sequence mixes digits and letters (e.g. R 7 C 2). Elements are   */
/*  shown one at a time at engine-controlled pacing. Recall happens in */
/*  two mental streams: the digits in ASCENDING order first, then the  */
/*  letters in ALPHABETICAL order. Recalling the display order never   */
/*  works, so the mind has to hold everything AND reorganise it on the */
/*  fly - the "juggling" act that defines working memory.              */
/*                                                                     */
/*  Staircase: sequences start at 2 elements and grow by one. Two      */
/*  attempts are allowed per level (the second only after a failed     */
/*  first); one fully-correct recall advances to the next level, two   */
/*  misses at the same level end the run.                              */
/*                                                                     */
/*  Scoring: span = highest level cleared. A 0.5 partial-credit bonus  */
/*  is added when the discontinue level produced at least one recall   */
/*  with exactly one stream correct (you reorganised one stream but    */
/*  dropped the other), and a flawless full clear earns the same half  */
/*  step - the standard partial-credit idea from complex span          */
/*  research, kept to a single half-step so the number stays honest    */
/*  and explainable. The effective span is z-scored against a          */
/*  simulated adult population and mapped onto the IQ scale (mean      */
/*  100, SD 15) via an erf-based normal CDF.                           */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Every attempt is freshly randomised; after a miss the retry at  */
/*     the same level is always a DIFFERENT sequence.                  */
/*   - Elements never repeat inside a sequence, so a sorted answer has */
/*     exactly one correct form.                                       */
/*   - The display order is never the sorted answer, so parroting what */
/*     you saw can never score.                                        */
/*   - Submitting before the display finished, or with nothing typed,  */
/*     records an INVALID attempt that can never count toward a span.  */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Phonologically distinct capital letters (WAIS-style letter set). */
export const LETTERS = ["C", "F", "H", "K", "L", "Q", "R", "S", "T"] as const;
/** Digits 1-9 (0 is excluded - it is easily confused with O in recall). */
export const DIGITS = [1, 2, 3, 4, 5, 6, 7, 8, 9] as const;

/* --------------------------- pacing/config -------------------------- */

/** First sequence level in a normal session (1 digit + 1 letter). */
export const START_LEVEL = 2;
/** Attempts allowed per level in a normal session. */
export const ATTEMPTS_PER_LEVEL = 2;
/** First level in quick (practice) mode. */
export const QUICK_START_LEVEL = 5;
/** Attempts allowed per level in quick mode. */
export const QUICK_ATTEMPTS_PER_LEVEL = 1;
/** Levels stop here; clearing the top level ends the run. */
export const MAX_LEVEL = 9;

/** Per-element display time (normal mode). */
export const DISPLAY_MS = 1000;
/** Blank gap between elements (normal mode). */
export const QUICK_DISPLAY_MS = 450;
/** Per-element display time in quick mode. */
export const DISPLAY_GAP_MS = 250;
/** Blank gap between elements in quick mode. */
export const QUICK_GAP_MS = 120;

/* ------------------------- population model ------------------------- */

/**
 * Population norms for the letter-number span (span + 0.5 partial
 * credit). Anchored against a 1000-user simulated population whose
 * per-attempt success follows a capacity-based logistic model (see
 * scripts/verify-working-memory-core.ts): the average simulated adult
 * lands at ~100. SPAN_SD is set slightly tighter than the simulated
 * spread (the staircase adds luck noise to the observed spread) so the
 * top of the scale stays reachable for flawless runs.
 */
export const SPAN_MEAN = 7.0;
export const SPAN_SD = 1.2;

export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type WmTarget = {
  /** The exact display order (interleaved digits and letters). */
  display: string[];
  /** Digits used, in display order (subset of 1-9, distinct). */
  digits: number[];
  /** Letters used, in display order (subset of LETTERS, distinct). */
  letters: string[];
  /** Correct answers: digits ascending, letters alphabetical. */
  sortedDigits: number[];
  sortedLetters: string[];
  level: number;
};

export type WmAttempt = {
  level: number;
  /** 1-based attempt number within this level. */
  attemptIndex: number;
  target: WmTarget;
  /** Digits the user submitted (empty if none). */
  digitInput: number[];
  /** Letters the user submitted (empty if none). */
  letterInput: string[];
  /** Both streams exactly right. */
  correct: boolean;
  digitStreamCorrect: boolean;
  letterStreamCorrect: boolean;
  /** Anti-gaming validity: false = submit-before-show or empty input. */
  valid: boolean;
  invalidReason: string | null;
};

export type SessionConfig = {
  startLevel: number;
  attemptsPerLevel: number;
  displayMs: number;
  gapMs: number;
  quick: boolean;
};

export type WmGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type WmSessionResult = {
  /** Highest level with at least one fully-correct attempt (0 if none). */
  span: number;
  /** 0.5 when the discontinue level had a one-stream-correct recall. */
  partialBonus: number;
  /** span + partialBonus - the value z-scored against the population. */
  effectiveSpan: number;
  /** IQ-scale score (mean 100, SD 15), clamped to IQ_MIN..IQ_MAX. */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: WmGrade;
  quick: boolean;
  /** Total attempts across the session. */
  attempts: number;
  /** Fully-correct (and valid) attempts. */
  correct: number;
  /** Valid attempts where at least one stream came out right. */
  streamsPartlyCorrect: number;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Sequence construction                                              */
/* ------------------------------------------------------------------ */

/** Digit/letter split for a level. Even levels are balanced; odd
 *  levels randomly take the extra element on either side. */
export function mixForLevel(level: number, rng: () => number): [number, number] {
  const digits = Math.ceil(level / 2);
  const letters = level - digits;
  if (level % 2 === 0 || digits === letters) return [digits, letters];
  return rng() < 0.5 ? [digits, letters] : [letters, digits];
}

/** True when the display order already IS the sorted answer, so
 *  parroting the screen would score - those sequences are rejected. */
function displayIsSortedAnswer(display: readonly string[], sortedDigits: readonly number[], sortedLetters: readonly string[]): boolean {
  const sortedAsDisplay = [...sortedDigits.map(String), ...sortedLetters];
  if (display.length !== sortedAsDisplay.length) return false;
  return display.every((el, i) => el === sortedAsDisplay[i]);
}

/**
 * Draw a letter-number sequence for the given level.
 * Digits are distinct draws from 1-9, letters distinct draws from the
 * 9-letter set, and the interleaved display order is shuffled until it
 * is not the sorted answer (so recall always demands reorganisation).
 */
export function buildSequence(level: number, rng: () => number): WmTarget {
  const [nDigits, nLetters] = mixForLevel(level, rng);
  const sortedDigits = shuffle(DIGITS, rng).slice(0, nDigits).sort((a, b) => a - b);
  const sortedLetters = shuffle(LETTERS, rng).slice(0, nLetters).sort();
  let display: string[] = [];
  for (let i = 0; i < 50; i++) {
    display = shuffle([...sortedDigits.map(String), ...sortedLetters], rng);
    if (!displayIsSortedAnswer(display, sortedDigits, sortedLetters)) break;
  }
  return {
    display,
    digits: sortedDigits,
    letters: sortedLetters,
    sortedDigits,
    sortedLetters,
    level,
  };
}

/** Same-digit key for comparing sequences regardless of object identity. */
function seqKey(t: WmTarget): string {
  return t.display.join("-");
}

/**
 * Build a sequence that differs from every sequence in `exclude`.
 * Used after a failed attempt so the retry can never be the memorised
 * sequence. The display space at every level is far larger than 500,
 * so rejection sampling terminates in practice.
 */
export function differentSequence(level: number, rng: () => number, exclude: readonly WmTarget[]): WmTarget {
  const keys = exclude.map(seqKey);
  for (let i = 0; i < 500; i++) {
    const candidate = buildSequence(level, rng);
    if (!keys.includes(seqKey(candidate))) return candidate;
  }
  return buildSequence(level, rng);
}

/* ------------------------------------------------------------------ */
/*  Grading                                                            */
/* ------------------------------------------------------------------ */

/** Grade the two recall streams. Inputs are compared to the sorted
 *  answers element by element; length mismatches fail that stream. */
export function gradeStreams(
  target: WmTarget,
  digitInput: readonly number[],
  letterInput: readonly string[]
): { digitStreamCorrect: boolean; letterStreamCorrect: boolean; correct: boolean } {
  const digitStreamCorrect =
    digitInput.length === target.sortedDigits.length &&
    target.sortedDigits.every((d, i) => digitInput[i] === d);
  const letterStreamCorrect =
    letterInput.length === target.sortedLetters.length &&
    target.sortedLetters.every((l, i) => letterInput[i] === l);
  return { digitStreamCorrect, letterStreamCorrect, correct: digitStreamCorrect && letterStreamCorrect };
}

/**
 * Record one attempt with anti-gaming validation.
 * An attempt is INVALID (and can never count toward a span) if it was
 * submitted before the display finished, or if nothing at all was
 * typed. Numbers-only submissions are VALID but fail the letter
 * stream - partial answers get partial honesty, not a free pass.
 */
export function submitAttempt(params: {
  level: number;
  attemptIndex: number;
  target: WmTarget;
  digitInput: readonly number[];
  letterInput: readonly string[];
  wasShown: boolean;
}): WmAttempt {
  const { level, attemptIndex, target, digitInput, letterInput, wasShown } = params;
  const base = {
    level,
    attemptIndex,
    target,
    digitInput: [...digitInput],
    letterInput: [...letterInput],
  };
  if (!wasShown) {
    return {
      ...base,
      digitInput: [],
      letterInput: [],
      correct: false,
      digitStreamCorrect: false,
      letterStreamCorrect: false,
      valid: false,
      invalidReason: "Response was submitted before the sequence was shown.",
    };
  }
  if (digitInput.length === 0 && letterInput.length === 0) {
    return {
      ...base,
      correct: false,
      digitStreamCorrect: false,
      letterStreamCorrect: false,
      valid: false,
      invalidReason: "Empty response - nothing was submitted.",
    };
  }
  const grade = gradeStreams(target, digitInput, letterInput);
  return {
    ...base,
    ...grade,
    valid: true,
    invalidReason: null,
  };
}

/* ------------------------------------------------------------------ */
/*  Span + session scoring                                             */
/* ------------------------------------------------------------------ */

/** Highest level with at least one correct, valid attempt (0 if none). */
export function spanOfAttempts(attempts: readonly WmAttempt[]): number {
  let span = 0;
  for (const attempt of attempts) {
    if (attempt.valid && attempt.correct && attempt.level > span) span = attempt.level;
  }
  return span;
}

/**
 * Partial credit: 0.5 when the run discontinued at `span + 1` and at
 * least one attempt there reorganised exactly one stream correctly.
 * A flawless full clear of the top level also earns the extra half
 * step (there is no boundary above it to show a near-miss on).
 * Encourages near-misses without letting a broken run score as a span.
 */
export function partialBonusOf(attempts: readonly WmAttempt[], span: number): number {
  if (span >= MAX_LEVEL) return 0.5;
  const boundary = span + 1;
  return attempts.some(
    (a) => a.valid && a.level === boundary && !a.correct && a.digitStreamCorrect !== a.letterStreamCorrect
  )
    ? 0.5
    : 0;
}

/** Pacing + staircase parameters for normal or quick mode. */
export function sessionConfig(quick: boolean): SessionConfig {
  return quick
    ? {
        startLevel: QUICK_START_LEVEL,
        attemptsPerLevel: QUICK_ATTEMPTS_PER_LEVEL,
        displayMs: QUICK_DISPLAY_MS,
        gapMs: QUICK_GAP_MS,
        quick: true,
      }
    : {
        startLevel: START_LEVEL,
        attemptsPerLevel: ATTEMPTS_PER_LEVEL,
        displayMs: DISPLAY_MS,
        gapMs: DISPLAY_GAP_MS,
        quick: false,
      };
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map the effective span (span + partial bonus) onto the IQ scale
 * (mean 100, SD 15), clamped to IQ_MIN..IQ_MAX.
 */
export function spanToIq(effectiveSpan: number): number {
  const z = (effectiveSpan - SPAN_MEAN) / SPAN_SD;
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ-scale score -> population percentile (1..99), normal model. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ-scale score. */
export function gradeForIq(iq: number): WmGrade {
  if (iq < 85) {
    return {
      label: "Building",
      blurb: "The juggling act came apart early today - that is usually attention, sleep or unfamiliarity with the task rather than fixed capacity, so a warm-up retake often tells a fairer story.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in the everyday range - most adults reorganise about five or six mixed items, and that is exactly where you landed.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Above average",
      blurb: "Stronger than most - you can hold a set in mind, take it apart and put it back in a new order without losing pieces, which shows up in mental arithmetic and following multi-step directions.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Well above average",
      blurb: "Excellent juggling capacity - long mixed streams stay organised in your head, which pays off in reading comprehension, planning and complex problem solving.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite working memory - a level reached by only a few percent of adults. Even long sequences stayed available for full reorganisation on both streams.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/**
 * Score a completed session.
 *
 * Span = highest level with at least one correct, valid attempt.
 * Invalid attempts (empty or submit-before-show) never contribute, so
 * a session of nothing but rejected attempts scores the honest floor:
 * span 0 and the clamped minimum IQ - never an inflated number.
 */
export function scoreSession(attempts: readonly WmAttempt[], quick: boolean): WmSessionResult {
  const span = spanOfAttempts(attempts);
  const partialBonus = partialBonusOf(attempts, span);
  const effectiveSpan = span + partialBonus;
  const iq = spanToIq(effectiveSpan);
  const valid = attempts.filter((a) => a.valid);
  return {
    span,
    partialBonus,
    effectiveSpan,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
    quick,
    attempts: attempts.length,
    correct: valid.filter((a) => a.correct).length,
    streamsPartlyCorrect: valid.filter((a) => !a.correct && (a.digitStreamCorrect || a.letterStreamCorrect)).length,
  };
}
