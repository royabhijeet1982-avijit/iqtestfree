/* ------------------------------------------------------------------ */
/*  Visual Memory Test - pure scoring engine                           */
/*  Paradigm: Corsi block-tapping on a 3x3 grid. Tiles light up one    */
/*  by one; the user must reproduce the sequence in the exact order.   */
/*  The sequence grows by one tile per level and playback speeds up    */
/*  slightly, so the run becomes a self-paced staircase: your          */
/*  "visual span" is the longest sequence you ever cleared.            */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Sequences are random at every level, so nothing can be memorised*/
/*     from a previous run.                                            */
/*   - A failed level retries the SAME length with a DIFFERENT          */
/*     sequence, so guessing from a half-remembered pattern never pays.*/
/*   - Playback timing is fixed by the engine: no input can make tiles */
/*     light faster or slower, so there is no timing exploit.          */
/*   - A single wrong click ends the attempt: random mashing produces  */
/*     floor scores immediately instead of a high one.                 */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.        */
/* ------------------------------------------------------------------ */

/** Number of tiles on the board (3x3 grid, indices 0..8). */
export const GRID_TILES = 9;

/** First level (and therefore first sequence length) in tiles. */
export const START_LEVEL = 3;

/** Playback timing at the start level. */
export const BASE_ON_MS = 700;
export const BASE_OFF_MS = 250;

/** On-time shrinks by this many ms per level above START_LEVEL... */
export const SPEED_STEP_MS = 60;
/** ...but never below this floor. */
export const MIN_ON_MS = 280;

/** Lives: a failed level consumes one and retries the same length. */
export const START_LIVES = 2;

/** Shortened mode used by automated flow tests via ?quick=1. */
export const QUICK_LIVES = 1;

/** Span recorded when a run ends without clearing even the first level. */
export const SPAN_FLOOR = START_LEVEL - 1;

/** Population anchor for adult visual span (Corsi-style tasks). */
export const SPAN_MEAN = 5.3;
export const SPAN_SD = 1.4;

/** Composite z blend: mostly span, plus a small capped speed bonus. */
export const SPAN_WEIGHT = 0.8;
export const SPEED_WEIGHT = 0.2;

/** Recall-speed model: mean correct-click interval of a typical adult. */
export const SPEED_REF_MS = 900;
export const SPEED_SD_MS = 400;
/** Speed z is clamped to this band so the bonus stays small. */
export const SPEED_Z_CAP = 2;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** Outcome of a single graded recall click. */
export type ClickOutcome = {
  /** Whether the clicked tile matched the expected tile. */
  correct: boolean;
  /** True when this click was also the final tile (level cleared). */
  complete: boolean;
};

/** Record of one attempt at one level (failed attempts included). */
export type LevelAttempt = {
  /** Sequence length == level number. */
  level: number;
  /** The exact tiles that were played back. */
  sequence: number[];
  /** Correct clicks landed before the attempt ended. */
  correctClicks: number;
  /** Whether the full sequence was reproduced. */
  cleared: boolean;
};

export type LadderRun = { level: number; cleared: boolean };

export type MemoryGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type VisualMemoryScore = {
  /** Highest level cleared (SPAN_FLOOR when nothing was cleared). */
  span: number;
  /** Correct tile clicks across the whole run. */
  tilesCorrect: number;
  /** Total attempts made. */
  attempts: number;
  /** Levels from START_LEVEL up to the deepest attempt, with status. */
  ladder: LadderRun[];
  /** Mean interval between correct recall clicks (null if none). */
  meanRecallMs: number | null;
  /** Clamped speed z-score used in the composite (-SPEED_Z_CAP..+SPEED_Z_CAP). */
  speedZ: number;
  /** IQ-scale composite (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: MemoryGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */
/*  Sequences                                                          */
/* ------------------------------------------------------------------ */

/**
 * Build a random sequence of `level` tile indices (0..8). Tiles are
 * distinct in succession only: the same tile never appears twice in a
 * row, but tiles may legitimately repeat later in longer sequences.
 */
export function makeSequence(level: number, rng: () => number): number[] {
  const length = Math.max(1, Math.round(level));
  const seq: number[] = [];
  for (let i = 0; i < length; i++) {
    let tile = Math.floor(rng() * GRID_TILES);
    if (i > 0) {
      const prev = seq[i - 1]!;
      let guard = 0;
      while (tile === prev && guard < 50) {
        tile = Math.floor(rng() * GRID_TILES);
        guard++;
      }
      if (tile === prev) {
        // Deterministic fallback: any of the other 8 tiles, never prev.
        tile = (prev + 1 + Math.floor(rng() * (GRID_TILES - 1))) % GRID_TILES;
      }
    }
    seq.push(tile);
  }
  return seq;
}

/**
 * Retry helper: like makeSequence but guarantees the new sequence
 * differs from `previous` as a whole, so a failed attempt can never be
 * retried with the identical pattern (anti-memorisation rule).
 */
export function makeDistinctSequence(
  level: number,
  rng: () => number,
  previous: readonly number[]
): number[] {
  for (let i = 0; i < 20; i++) {
    const seq = makeSequence(level, rng);
    if (seq.join(",") !== previous.join(",")) return seq;
  }
  // Unreachable in practice; force a guaranteed difference at position 0
  // while keeping the no-immediate-repeat rule intact.
  const seq = makeSequence(level, rng);
  const options: number[] = [];
  for (let t = 0; t < GRID_TILES; t++) {
    if (t !== previous[0] && (seq.length < 2 || t !== seq[1]!)) options.push(t);
  }
  if (options.length > 0) seq[0] = options[Math.floor(rng() * options.length)]!;
  return seq;
}

/* ------------------------------------------------------------------ */
/*  Playback timing                                                    */
/* ------------------------------------------------------------------ */

/**
 * Fixed playback speed for a level: 700 ms lit / 250 ms dark at the
 * start level, easing down 60 ms per level to a 280 ms floor. The
 * engine owns this timing completely - the UI cannot alter it.
 */
export function speedForLevel(level: number): { onMs: number; offMs: number } {
  const onMs = Math.max(
    MIN_ON_MS,
    BASE_ON_MS - (Math.max(START_LEVEL, level) - START_LEVEL) * SPEED_STEP_MS
  );
  return { onMs, offMs: BASE_OFF_MS };
}

/* ------------------------------------------------------------------ */
/*  Grading                                                            */
/* ------------------------------------------------------------------ */

/**
 * Grade one recall click. `index` is the position the user is on
 * (0-based). A wrong click is always correct:false / complete:false -
 * the caller ends the attempt; the engine never lets a wrong click
 * count toward the score.
 */
export function gradeClick(
  sequence: readonly number[],
  index: number,
  tile: number
): ClickOutcome {
  const expected = sequence[index];
  const correct = expected !== undefined && tile === expected;
  return { correct, complete: correct && index === sequence.length - 1 };
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/** Recall interval -> clamped z (faster clicks = higher z). */
export function speedZFromRecall(meanRecallMs: number | null): number {
  if (meanRecallMs === null || !Number.isFinite(meanRecallMs)) return 0;
  const z = (SPEED_REF_MS - meanRecallMs) / SPEED_SD_MS;
  return Math.min(SPEED_Z_CAP, Math.max(-SPEED_Z_CAP, z));
}

/**
 * Blend span z (anchored to the adult population) with the small speed
 * bonus and map onto the IQ scale (mean 100, SD 15).
 */
export function compositeIq(span: number, speedZ: number): number {
  const spanZ = (span - SPAN_MEAN) / SPAN_SD;
  const z = SPAN_WEIGHT * spanZ + SPEED_WEIGHT * speedZ;
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the composite IQ. */
export function gradeForIq(iq: number): MemoryGrade {
  if (iq < 85) {
    return {
      label: "Building",
      blurb: "Your span is still warming up - a night of sleep and one more run usually adds a tile or two.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - a dependable visual working memory.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - you hold spatial patterns with little mental effort.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier span - the kind of visual memory that shines in design, navigation and chess.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite visual span - rarer than one person in fifty.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Run scoring                                                        */
/* ------------------------------------------------------------------ */

/**
 * Score a complete run (all attempts across all levels).
 *
 *  - span = highest level cleared, floored at SPAN_FLOOR when nothing
 *    was cleared (an honest "below 3 tiles" outcome).
 *  - tilesCorrect = every correct recall click, including clicks inside
 *    failed attempts - effort is recorded even when the level fails.
 *  - speed bonus uses the mean interval between CORRECT recall clicks,
 *    clamped so it can never dominate the span signal.
 */
export function scoreRun(
  attempts: readonly LevelAttempt[],
  recallRtsMs: readonly number[]
): VisualMemoryScore {
  let maxCleared = 0;
  let maxReached = 0;
  let tilesCorrect = 0;
  const clearedLevels = new Set<number>();

  for (const attempt of attempts) {
    maxReached = Math.max(maxReached, attempt.level);
    if (attempt.cleared) {
      maxCleared = Math.max(maxCleared, attempt.level);
      clearedLevels.add(attempt.level);
    }
    tilesCorrect += attempt.correctClicks;
  }

  const span = maxCleared > 0 ? maxCleared : SPAN_FLOOR;

  const ladder: LadderRun[] = [];
  for (let level = START_LEVEL; level <= maxReached; level++) {
    ladder.push({ level, cleared: clearedLevels.has(level) });
  }

  const rts = recallRtsMs.filter((rt) => Number.isFinite(rt) && rt >= 0);
  const meanRecallMs =
    rts.length > 0 ? rts.reduce((a, b) => a + b, 0) / rts.length : null;
  const speedZ = speedZFromRecall(meanRecallMs);
  const iq = compositeIq(span, speedZ);

  return {
    span,
    tilesCorrect,
    attempts: attempts.length,
    ladder,
    meanRecallMs,
    speedZ,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
