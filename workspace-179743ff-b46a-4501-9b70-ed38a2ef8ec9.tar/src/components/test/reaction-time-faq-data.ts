/* ------------------------------------------------------------------ */
/*  Reaction Time Test - FAQ (single source)                           */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type RtFaq = { question: string; answer: string };

export const REACTION_TIME_FAQS: RtFaq[] = [
  {
    question: "What is a reaction time test?",
    answer:
      "A reaction time test measures how long your brain takes to notice something, decide what to do, and start moving - the whole chain from stimulus to response, timed to the millisecond. It is one of the oldest measurements in psychology, going back to the astronomy labs of the 1800s, and it is still used today because reaction speed tracks closely with attention, alertness and processing efficiency. This test runs the classic two-step version: a simple round where you just wait for green and tap, then a choice round where you must tap the correct one of four quadrants.",
  },
  {
    question: "Why use the median instead of the average?",
    answer:
      "Reaction-time data is full of outliers: one moment of distraction produces a 900ms response that drags the average far away from how you actually performed. The median - the middle value of your valid trials - is robust, so a single lapse barely moves it. Psychologists studying reaction time overwhelmingly report medians for exactly this reason. Your variability (the spread of your simple-round times) is reported separately, so a jittery session is visible in the numbers rather than hiding inside an inflated mean.",
  },
  {
    question: "What counts as an anticipation or a lapse?",
    answer:
      "An anticipation is a response fired before your brain could genuinely have seen the cue - anything under 150ms in this test. Those taps reflect timing guesses, not reflexes, so they never score: the trial is retried up to twice and then skipped. A lapse is the opposite problem - a response slower than 1500ms, which usually means your attention drifted for a moment. The wait before each cue is randomised between 1.5 and 4.5 seconds precisely so you cannot anticipate by rhythm. If more than 30% of your trials end up invalid, the run is honestly flagged as low-validity and not scored.",
  },
  {
    question: "What is a typical reaction time by age?",
    answer:
      "For simple visual reaction time, healthy young adults average roughly 250-300ms, which is why this test anchors its population median at 300ms for casual mouse-and-touch users. Teenagers tend to be the fastest group; from the twenties onward, reaction time lengthens gradually - typically a few milliseconds per decade - though alertness and practice matter more than age in any single session. Choice reaction time, which adds a decision, typically lands around 450-550ms. Keep in mind that your device, input method and even screen refresh rate shift the numbers, so compare yourself against the built-in population curve rather than a single absolute figure.",
  },
  {
    question: "Simple vs choice reaction time - what is the difference?",
    answer:
      "Simple reaction time is one stimulus and one response: the stage turns green and you tap. It isolates raw sensorimotor speed - how quickly the signal travels from your eyes through your brain to your finger. Choice reaction time adds decision-making: any one of four quadrants can light up, so you must perceive WHICH one, select the matching response, and then move. The extra step typically costs 150-200ms and follows Hick's law: the more options, the slower the response. Seeing both numbers side by side shows you whether speed or decision-making is your stronger link.",
  },
  {
    question: "Can I retake the test?",
    answer:
      "Yes - retake it as often as you like, for free, with no sign-up. The randomised waits are re-drawn on every single trial and attempt, so there is no rhythm to memorise and no way to replay a fixed sequence. Most people are one tier quicker on their second or third run as the task stops feeling novel, so two or three attempts give the fairest picture of your true speed. Scores are calculated fresh on every run and nothing is stored between visits.",
  },
];
