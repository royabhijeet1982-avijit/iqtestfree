"use client";

/* ------------------------------------------------------------------ */
/*  Word Memory Test - interactive UI                                  */
/*  Classic old/new word recognition: words appear one at a time       */
/*  (STUDY, engine-paced), a short countdown clears the slate, then a  */
/*  shuffled stream of studied words + new foils must be judged with   */
/*  "I saw it" / "It's new". Scoring lives in word-memory-core.ts.     */
/*                                                                     */
/*  Testing hook: /test/word-memory?quick=1 shortens every engine      */
/*  timing (study holds + gaps + countdown + feedback) so automated    */
/*  flow tests run fast. Quick mode is a timing change only - never a  */
/*  scoring one.                                                       */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (study | interlude | recognize), the current word carries          */
/*  data-testid="wm-study-word" / "wm-word", and result numbers expose  */
/*  data-final so CountUp animation frames cannot fool assertions.     */
/*  Keyboard: A = "I saw it", L = "It's new" during recognize (a11y).  */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  BookOpen,
  Brain,
  Check,
  Eye,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Type,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  ROUND_LIST_LENS,
  buildWordMemorySession,
  scoreSession,
  type Judgement,
  type TestItem,
  type WordMemoryScore,
  type WordMemorySession,
} from "./word-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "study" | "interlude" | "recognize";

type Flash = "correct" | "wrong" | null;

/** Idle pause before the first study word of a round. */
const PRE_STUDY_MS = 450;
const PRE_STUDY_MS_QUICK = 150;
/** How long each study word stays on screen / its dark gap. */
const STUDY_ON_MS = 1250;
const STUDY_ON_MS_QUICK = 300;
const STUDY_GAP_MS = 350;
const STUDY_GAP_MS_QUICK = 80;
/** Countdown steps: global 3-2-1 and the between-phases interlude. */
const COUNTDOWN_STEP_MS = 750;
const COUNTDOWN_STEP_MS_QUICK = 180;
const INTERLUDE_STEP_MS = 750;
const INTERLUDE_STEP_MS_QUICK = 150;
/** Feedback flash + gap before the next test word. */
const FEEDBACK_MS = 260;
const FEEDBACK_MS_QUICK = 80;
const RESPONSE_GAP_MS = 120;
const RESPONSE_GAP_MS_QUICK = 40;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("word-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function WordMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("study");
  const [roundIndex, setRoundIndex] = useState(0);
  const [studyIdx, setStudyIdx] = useState(0);
  const [judged, setJudged] = useState(0);
  const [currentWord, setCurrentWord] = useState<string | null>(null);
  const [flash, setFlash] = useState<Flash>(null);
  const [score, setScore] = useState<WordMemoryScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);
  /** Mirrors sessionRef for RENDER-time reads (refs are off-limits in render). */
  const [session, setSession] = useState<WordMemorySession | null>(null);

  const sessionRef = useRef<WordMemorySession | null>(null);
  const roundRef = useRef(0);
  const studyIdxRef = useRef(0);
  const itemIdxRef = useRef(0);
  const judgedRef = useRef(0);
  const respondedRef = useRef(false);
  const shownAtRef = useRef(0);
  const judgementsRef = useRef<Judgement[]>([]);
  const activeStateRef = useRef<ActiveState>("study");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed =
      startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const result = scoreSession(judgementsRef.current);
    setScore(result);
    setPhase("results");
    // Bring the score into view - the user is scrolled mid-card.
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  const showItem = useCallback((round: number, index: number) => {
    const session = sessionRef.current;
    if (!session) return;
    const item: TestItem = session.rounds[round]!.testWords[index]!;
    itemIdxRef.current = index;
    respondedRef.current = false;
    setCurrentWord(item.word);
    shownAtRef.current = performance.now();
  }, []);

  const beginRecognize = useCallback(
    (round: number) => {
      activeStateRef.current = "recognize";
      setActiveState("recognize");
      itemIdxRef.current = 0;
      judgedRef.current = 0;
      respondedRef.current = false;
      setJudged(0);
      showItem(round, 0);
    },
    [showItem]
  );

  const beginInterlude = useCallback(
    (round: number) => {
      clearTimers();
      activeStateRef.current = "interlude";
      setActiveState("interlude");
      setCurrentWord(null);
      const stepMs = quickRef.current ? INTERLUDE_STEP_MS_QUICK : INTERLUDE_STEP_MS;
      let n = 3;
      const step = () => {
        setCountdownValue(n);
        n -= 1;
        if (n >= 0) {
          timersRef.current.push(setTimeout(step, stepMs));
        } else {
          beginRecognize(round);
        }
      };
      step();
    },
    [beginRecognize, clearTimers]
  );

  const scheduleStudy = useCallback(
    (round: number) => {
      clearTimers();
      const session = sessionRef.current;
      if (!session) return;
      const words = session.rounds[round]!.studyWords;
      const onMs = quickRef.current ? STUDY_ON_MS_QUICK : STUDY_ON_MS;
      const gapMs = quickRef.current ? STUDY_GAP_MS_QUICK : STUDY_GAP_MS;
      const preMs = quickRef.current ? PRE_STUDY_MS_QUICK : PRE_STUDY_MS;
      let t = preMs;
      words.forEach((word, i) => {
        timersRef.current.push(
          setTimeout(() => {
            studyIdxRef.current = i;
            setStudyIdx(i);
            setCurrentWord(word);
          }, t)
        );
        t += onMs;
        timersRef.current.push(setTimeout(() => setCurrentWord(null), t));
        t += gapMs;
      });
      timersRef.current.push(setTimeout(() => beginInterlude(round), t));
    },
    [beginInterlude, clearTimers]
  );

  const beginStudy = useCallback(
    (round: number) => {
      roundRef.current = round;
      setRoundIndex(round);
      activeStateRef.current = "study";
      setActiveState("study");
      studyIdxRef.current = 0;
      setStudyIdx(0);
      setCurrentWord(null);
      setPhase("active");
      scheduleStudy(round);
    },
    [scheduleStudy]
  );

  const start = useCallback(() => {
    clearTimers();
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const built = buildWordMemorySession(seed);
    sessionRef.current = built;
    setSession(built);
    judgementsRef.current = [];
    finishedRef.current = false;
    respondedRef.current = false;
    roundRef.current = 0;
    studyIdxRef.current = 0;
    itemIdxRef.current = 0;
    judgedRef.current = 0;
    setRoundIndex(0);
    setJudged(0);
    setScore(null);
    setRunSeconds(null);
    setFlash(null);
    setCurrentWord(null);
    setCountdownValue(3);
    setPhase("countdown");
    // Align the card immediately so the countdown is actually in view.
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Global 3-2-1 before the first study phase. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? COUNTDOWN_STEP_MS_QUICK : COUNTDOWN_STEP_MS;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        startedAtRef.current = performance.now();
        beginStudy(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginStudy]);

  /* Advance the recognition stream: next word, next round, or finish. */
  const advance = useCallback(() => {
    const session = sessionRef.current;
    if (!session) return;
    const r = roundRef.current;
    const i = itemIdxRef.current;
    const round = session.rounds[r]!;
    if (i < round.testWords.length) {
      showItem(r, i);
    } else if (r + 1 < session.rounds.length) {
      beginStudy(r + 1);
    } else {
      finish();
    }
  }, [showItem, beginStudy, finish]);

  /* --------------------------- judgements -------------------------- */

  const handleRespond = useCallback(
    (saidOld: boolean) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recognize") return;
      if (respondedRef.current) return;
      respondedRef.current = true;

      const r = roundRef.current;
      const session = sessionRef.current;
      if (!session) return;
      const item = session.rounds[r]!.testWords[itemIdxRef.current]!;
      const rt =
        shownAtRef.current > 0 ? performance.now() - shownAtRef.current : null;

      judgementsRef.current.push({
        word: item.word,
        isTarget: item.isTarget,
        round: r,
        saidOld,
        rtMs: rt,
      });

      const correct = saidOld === item.isTarget;
      setFlash(correct ? "correct" : "wrong");

      judgedRef.current += 1;
      setJudged(judgedRef.current);
      itemIdxRef.current += 1;

      clearTimers();
      const feedbackMs = quickRef.current ? FEEDBACK_MS_QUICK : FEEDBACK_MS;
      const gapMs = quickRef.current ? RESPONSE_GAP_MS_QUICK : RESPONSE_GAP_MS;
      timersRef.current.push(setTimeout(() => setFlash(null), feedbackMs));
      timersRef.current.push(setTimeout(() => advance(), feedbackMs + gapMs));
    },
    [advance, clearTimers]
  );

  /* Keyboard: A = "I saw it", L = "It's new" during recognize. */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "a") handleRespond(true);
      else if (k === "l") handleRespond(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, handleRespond]);

  /* ------------------------- derived data -------------------------- */

  // `session` is state (never read sessionRef during render).
  const round = session?.rounds[roundIndex];
  const statusText =
    activeState === "study"
      ? "Read each word - it will vanish quickly"
      : activeState === "interlude"
        ? "Clear your mind..."
        : flash === "correct"
          ? "Correct"
          : flash === "wrong"
            ? "Missed that one"
            : "Was it in the list?";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="word-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="wm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Type className="h-3.5 w-3.5" aria-hidden="true" />
                Verbal memory · old or new? · about 5 minutes
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Words drift by once - how many can you claim?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Three rounds, growing lists. Words appear one at a time -
                read them and hold on. Then judge a longer stream: some words
                you saw, some you never did. Your score is how cleanly you
                separate the two.
              </p>
            </div>

            {/* Static preview of the judgement card */}
            <div
              data-testid="wm-preview"
              aria-hidden="true"
              className="mx-auto mt-6 max-w-[300px] rounded-xl border border-border bg-muted/60 p-4"
            >
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                What a judgement looks like
              </p>
              <p className="mt-3 text-center text-2xl font-bold tracking-tight text-foreground">
                lantern
              </p>
              <div className="mt-3 flex items-center justify-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground">
                  <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                  I saw it
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-semibold text-foreground">
                  <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                  It&apos;s new
                </span>
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <BookOpen className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Study words appear one at a time at a fixed pace - the engine owns the timing, nothing can be slowed for extra reading.
              </li>
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                A brief countdown separates study from test - the same filled delay memory researchers use to block rehearsal.
              </li>
              <li className="flex gap-2.5">
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Every stream is half studied words, half new ones. Claiming a word you never saw costs exactly as much as missing one you did.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Mashing cannot win: guessing pins you at 50%, so only genuine recognition moves your score.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="wm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Type className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh words every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="wm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Round 1 · {ROUND_LIST_LENS[0]} words · eyes on the card
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="wm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Round header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="wm-round-chip"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Round {roundIndex + 1}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {activeState === "study"
                    ? "study phase · just read and remember"
                    : activeState === "interlude"
                      ? "get ready to judge"
                      : "old or new? trust your memory"}
                </p>
              </div>
              <span
                data-testid="wm-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {activeState === "recognize"
                  ? `${judged} / ${round?.testWords.length ?? 0}`
                  : `${Math.min(studyIdx + 1, round?.listLen ?? 0)} / ${round?.listLen ?? 0}`}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="wm-stage"
              data-phase={activeState}
              className={[
                "mx-auto mt-5 w-full max-w-[420px] rounded-2xl border-2 p-6 transition-[border-color,box-shadow] duration-200 sm:p-8",
                flash === "correct"
                  ? "border-emerald-500 shadow-[0_0_32px_rgba(16,185,129,0.25)]"
                  : flash === "wrong"
                    ? "border-red-400 shadow-[0_0_32px_rgba(239,68,68,0.18)]"
                    : "border-border",
              ].join(" ")}
            >
              {activeState === "interlude" ? (
                <div className="py-6 text-center">
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={countdownValue}
                      initial={{ scale: 0.6, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 1.4, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="inline-block text-6xl font-black tabular-nums text-primary sm:text-7xl"
                    >
                      {countdownValue === 0 ? "GO" : countdownValue}
                    </motion.span>
                  </AnimatePresence>
                  <p className="mt-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    Get ready - stream incoming
                  </p>
                </div>
              ) : (
                <div className="flex min-h-28 items-center justify-center">
                  <AnimatePresence mode="wait">
                    {currentWord ? (
                      <motion.p
                        key={currentWord}
                        data-testid={activeState === "study" ? "wm-study-word" : "wm-word"}
                        initial={{ opacity: 0, scale: 0.94 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.12 }}
                        className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
                      >
                        {currentWord}
                      </motion.p>
                    ) : (
                      <motion.span
                        key={`empty-${studyIdx}-${judged}`}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 0.25 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.1 }}
                        className="select-none text-3xl font-bold tracking-tight text-muted-foreground sm:text-4xl"
                      >
                        · · ·
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Response buttons - recognize phase only */}
            {activeState === "recognize" && (
              <div className="mx-auto mt-5 grid w-full max-w-[420px] grid-cols-2 gap-3">
                <button
                  type="button"
                  data-testid="wm-btn-old"
                  aria-keyshortcuts="A"
                  disabled={flash !== null}
                  onClick={() => handleRespond(true)}
                  className="inline-flex touch-manipulation items-center justify-center gap-2 rounded-xl bg-primary px-4 py-4 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:bg-emerald-700 active:translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 sm:text-lg"
                >
                  <Eye className="h-5 w-5" aria-hidden="true" />
                  I saw it
                  <kbd className="ml-1 hidden rounded border border-white/40 px-1.5 text-xs font-bold sm:inline">A</kbd>
                </button>
                <button
                  type="button"
                  data-testid="wm-btn-new"
                  aria-keyshortcuts="L"
                  disabled={flash !== null}
                  onClick={() => handleRespond(false)}
                  className="inline-flex touch-manipulation items-center justify-center gap-2 rounded-xl border-2 border-border bg-card px-4 py-4 text-base font-semibold text-foreground shadow-sm transition-[translate,border-color,background-color] hover:border-primary hover:text-primary active:translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 sm:text-lg"
                >
                  <Sparkles className="h-5 w-5" aria-hidden="true" />
                  It&apos;s new
                  <kbd className="ml-1 hidden rounded border border-border px-1.5 text-xs font-bold text-muted-foreground sm:inline">L</kbd>
                </button>
              </div>
            )}

            {/* Status */}
            <p
              data-testid="wm-status"
              aria-live="polite"
              className={[
                "mt-4 text-center text-sm font-semibold sm:text-base",
                flash === "wrong"
                  ? "text-red-600"
                  : flash === "correct"
                    ? "text-emerald-700"
                    : "text-muted-foreground",
              ].join(" ")}
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="wm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="wm-accuracy"
                    data-final={Math.round(score.accuracy * 100)}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={Math.round(score.accuracy * 100)} duration={1.2} />
                    <span className="text-3xl text-muted-foreground sm:text-4xl">%</span>
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  words judged correctly · {score.targets + score.foils} judgements
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="wm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Verbal memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="wm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <Type className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="wm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Per-round accuracy bars */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Round by round
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Longer lists are harder - watch where accuracy starts to slip
                </p>
                <div className="mt-3 space-y-2.5">
                  {score.rounds.map((rs) => {
                    const pct = Math.round(rs.accuracy * 100);
                    return (
                      <div key={rs.round} className="flex items-center gap-3">
                        <span className="w-20 shrink-0 text-xs font-semibold text-muted-foreground sm:w-24 sm:text-sm">
                          Round {rs.round + 1}
                        </span>
                        <div className="h-3 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className={[
                              "h-full rounded-full transition-[width] duration-700",
                              pct >= 80
                                ? "bg-emerald-500"
                                : pct >= 60
                                  ? "bg-emerald-400"
                                  : "bg-amber-400",
                            ].join(" ")}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span
                          data-testid={`wm-round-acc-${rs.round}`}
                          data-final={pct}
                          className="w-12 shrink-0 text-right text-sm font-bold tabular-nums text-foreground"
                        >
                          {pct}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="wm-stat-hits" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.hits}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">words recognised</p>
                </div>
                <div data-testid="wm-stat-cr" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.correctRejections}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">new words rejected</p>
                </div>
                <div data-testid="wm-stat-fa" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.falseAlarms}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">false alarms</p>
                </div>
                <div data-testid="wm-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.avgRtMs !== null ? `${(score.avgRtMs / 1000).toFixed(1)}s` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg response</p>
                </div>
              </div>

              <div className="mx-auto mt-5 max-w-md rounded-xl border border-border bg-muted/40 p-4 text-center">
                <p className="text-sm text-muted-foreground">
                  Signal sensitivity{" "}
                  <span
                    data-testid="wm-stat-dprime"
                    className="font-bold tabular-nums text-foreground"
                  >
                    d&apos; = {score.dPrime.toFixed(1)}
                  </span>{" "}
                  · 0 means pure guessing, higher means cleaner old/new separation
                </p>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="wm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - fresh words
                </button>
                <a
                  href="/test"
                  data-testid="wm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {score.hits} of {score.targets} studied words recognised ·{" "}
                {score.falseAlarms} false alarm{score.falseAlarms === 1 ? "" : "s"} ·{" "}
                {runSeconds !== null ? `${runSeconds.toFixed(0)}s total` : "memory-pure scoring"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
