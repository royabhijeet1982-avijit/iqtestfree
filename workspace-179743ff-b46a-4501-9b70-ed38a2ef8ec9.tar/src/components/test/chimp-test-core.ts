/* ------------------------------------------------------------------ */
/*  Chimp Test - pure engine                                           */
/*  Paradigm: the Ayumu / chimpanzee working-memory task from the      */
/*  landmark Kyoto University study (Inoue & Matsuzawa, 2007).         */
/*                                                                     */
/*  An 8x6 grid holds N numbered chips (N starts at 4). The player     */
/*  taps chip 1 first; ALL chips instantly mask into blank squares;    */
/*  the rest must then be tapped in ascending order from memory.       */
/*  Three consecutive cleared rounds advance the level (N + 1); a      */
/*  wrong tap consumes one of three lives.                             */
/*                                                                     */
/*  Scoring:                                                           */
/*   - levelReached  = the highest N the player unlocked and played    */
/*   - effectiveLevel = continuous mastery at the moment lives ran     */
/*     out: (N - 1) + consecutiveClears / 3, so clearing 2 of the 3    */
/*     rounds needed at N=6 counts as 5.67. This is the value the      */
/*     population anchor uses (untrained adults reach N~5-6, modelled  */
/*     as mean 5.4 / SD 1.2).                                          */
/*   - accuracy = correctFirstTaps / totalTaps. Every tap in this      */
/*     paradigm is a first attempt at recalling a hidden position      */
/*     (a wrong tap ends the round immediately - there are no          */
/*     retries), so correct taps are first-tap-correct by definition.  */
/*   - IQ = 100 + 15 * (0.7 * levelZ + 0.3 * accuracyZ), percentile    */
/*     via the erf normal CDF, clamped to 1..99.                       */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Positions are random every round, so nothing can be memorised   */
/*     across rounds or attempts.                                      */
/*   - Masking on the first tap removes the numbers from the DOM:      */
/*     screenshot-feeding or screen-reading cannot help, because the   */
/*     digits no longer exist on the page. Tapping chip 1 before       */
/*     memorising is the player's own choice - no exploit exists.      */
/*   - A run that completes a sequence of >= 5 chips with every gap    */
/*     between consecutive taps under 120 ms is flagged "bot-like"     */
/*     (humans need roughly 200 ms+ per directed tap). The flag is     */
/*     honest and informational: the score is not inflated.            */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Grid geometry: 8 columns x 6 rows = 48 cells. */
export const GRID_COLS = 8;
export const GRID_ROWS = 6;
export const GRID_CELLS = GRID_ROWS * GRID_COLS;

/** First level = first number of chips (default runs). */
export const START_N = 4;
/** Shortened mode used by automated flow tests via ?quick=1. */
export const QUICK_START_N = 3;
/** Lives: a wrong tap or wrong order consumes one. */
export const START_LIVES = 3;
export const QUICK_LIVES = 2;
/** Consecutive cleared rounds needed to advance the level. */
export const CLEARS_TO_ADVANCE = 3;
/** Level cap: 12 chips is far beyond trained-human span (Ayumu did 9). */
export const MAX_LEVEL = 12;

/** Placement preference: chips sit at least this Chebyshev distance
 *  apart when the grid allows it (soft constraint - placement never
 *  fails, it only relaxes). */
export const PREFERRED_MIN_CHEBYSHEV = 2;
/** Rejection-sampling tries per chip before relaxing the preference. */
export const PLACEMENT_TRIES = 40;

/** Bot-like threshold: gaps between consecutive taps below this are
 *  superhuman for directed tapping. */
export const BOT_GAP_MS = 120;
/** Bot detection needs a real sequence: at least this many chips. */
export const BOT_MIN_CHIPS = 5;

/** Population anchor for the level ladder (untrained adults). */
export const LEVEL_MEAN = 5.4;
export const LEVEL_SD = 1.2;

/** Population anchor for tap accuracy (see accuracy note above). */
export const ACC_MEAN = 0.91;
export const ACC_SD = 0.055;
/** Accuracy z is clamped so one sloppy run cannot dominate the blend. */
export const ACC_Z_CAP = 2.5;

/** Composite blend: mostly level, plus a smaller accuracy signal. */
export const LEVEL_WEIGHT = 0.7;
export const ACC_WEIGHT = 0.3;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type Chip = {
  /** Chip number, 1-based (1 is always tapped first). */
  n: number;
  /** Cell index 0..47 (row-major on the 8x6 grid). */
  cell: number;
  r: number;
  c: number;
};

/** One dealt round: N chips on distinct cells, sorted by number. */
export type Round = {
  n: number;
  chips: Chip[];
};

export type TapOutcome = {
  /** The tap hit the expected next chip. */
  correct: boolean;
  /** The tap was also the final chip (round cleared). */
  complete: boolean;
  /** Number on the tapped chip (null when the cell held no chip). */
  chipN: number | null;
};

/** Timing metadata the UI attaches to each tap. */
export type TapTiming = {
  /** ms since the previous tap (or since the round was dealt for the first tap). */
  sincePrevMs: number;
  /** ms since the round was dealt. */
  roundMs: number;
};

/** Permanent record of one finished round (cleared or failed). */
export type RoundRecord = {
  n: number;
  cleared: boolean;
  /** Total taps including the wrong one on a failed round. */
  taps: number;
  correctTaps: number;
  /** Gaps between consecutive taps (length taps - 1); bot detection. */
  intervals: number[];
  /** Round deal -> final tap. */
  durationMs: number;
};

export type RunPhase =
  | "show"             // numbers visible, waiting for the first tap
  | "recall"           // masked, tapping the remaining chips
  | "cleared-feedback" // round cleared, board frozen before the next deal
  | "failed-feedback"  // round failed, board frozen before the next deal
  | "done";            // out of lives

export type RunState = {
  phase: RunPhase;
  level: number;
  lives: number;
  maxLives: number;
  /** Consecutive cleared rounds at the current level (0..CLEARS_TO_ADVANCE). */
  streak: number;
  round: Round;
  /** True once the chips have masked (first tap happened). */
  masked: boolean;
  /** Correct taps made in the current round. */
  progress: number;
  records: RoundRecord[];
  /** Cell of the wrong tap (for the failure flash). */
  lastWrongCell: number | null;
  /** Interval gaps collected so far in the current round. */
  pendingIntervals: number[];
  rng: () => number;
};

export type TapResult = {
  next: RunState;
  outcome: TapOutcome;
  roundEnded: boolean;
  cleared: boolean;
  lifeLost: boolean;
  /** True when this clear completed CLEARS_TO_ADVANCE and levelled up. */
  advanced: boolean;
};

export type ChimpGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type ChimpScore = {
  /** Highest N unlocked and played (the level at which lives ran out). */
  levelReached: number;
  /** Continuous mastery: (levelReached - 1) + trailing clears / 3. */
  effectiveLevel: number;
  totalCleared: number;
  totalRounds: number;
  correctTaps: number;
  totalTaps: number;
  /** correctFirstTaps / totalTaps (see header note), 0..1. */
  accuracy: number;
  /** Mean round duration in ms (null with no rounds). */
  meanRoundMs: number | null;
  /** Trailing consecutive clears counted into effectiveLevel. */
  streakAtDeath: number;
  iq: number;
  percentile: number;
  grade: ChimpGrade;
  botLike: boolean;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */
/*  Chip placement                                                     */
/* ------------------------------------------------------------------ */

export function cellToRow(cell: number): number {
  return Math.floor(cell / GRID_COLS);
}

export function cellToCol(cell: number): number {
  return cell % GRID_COLS;
}

/** Chebyshev (chessboard) distance between two cells. */
export function chebyshevDistance(a: Cell, b: Cell): number {
  return Math.max(Math.abs(a.r - b.r), Math.abs(a.c - b.c));
}

type Cell = { r: number; c: number };

function cellOf(cell: number): Cell {
  return { r: cellToRow(cell), c: cellToCol(cell) };
}

/**
 * Place `n` chips on distinct random cells.
 *
 * Preference: every chip lands at Chebyshev distance >= 2 from the
 * others (at least one cell between them) so numbers never clump into
 * an unreadable cluster. When rejection sampling cannot satisfy the
 * preference (crowded grids at high N), it relaxes to "any distinct
 * cell" - overlap is impossible in every branch.
 */
export function placeChips(n: number, rng: () => number): Chip[] {
  const count = Math.max(1, Math.min(MAX_LEVEL, Math.round(n)));
  const used = new Set<number>();
  const chips: Chip[] = [];

  for (let i = 0; i < count; i++) {
    let picked = -1;
    // Pass 1: honour the spacing preference when possible.
    for (let tries = 0; tries < PLACEMENT_TRIES; tries++) {
      const cell = Math.floor(rng() * GRID_CELLS);
      if (used.has(cell)) continue;
      const cand = cellOf(cell);
      const okSpacing = chips.every(
        (chip) => chebyshevDistance(cand, { r: chip.r, c: chip.c }) >= PREFERRED_MIN_CHEBYSHEV
      );
      if (okSpacing) {
        picked = cell;
        break;
      }
    }
    // Pass 2: relax to any free cell (still never overlapping).
    if (picked < 0) {
      const free: number[] = [];
      for (let cell = 0; cell < GRID_CELLS; cell++) {
        if (!used.has(cell)) free.push(cell);
      }
      if (free.length === 0) break; // unreachable: n <= MAX_LEVEL < GRID_CELLS
      picked = free[Math.floor(rng() * free.length)]!;
    }
    used.add(picked);
    chips.push({ n: i + 1, cell: picked, r: cellToRow(picked), c: cellToCol(picked) });
  }

  return chips; // sorted by n by construction
}

/** Deal one round of `n` chips. */
export function makeRound(n: number, rng: () => number): Round {
  return { n: Math.max(1, Math.min(MAX_LEVEL, Math.round(n))), chips: placeChips(n, rng) };
}

/** Chip occupying a cell, or null when the cell is empty. */
export function chipAtCell(round: Round, cell: number): Chip | null {
  return round.chips.find((chip) => chip.cell === cell) ?? null;
}

/**
 * Grade one tap against the expected next chip (progress + 1).
 * Pure - the state machine wraps this in applyTap.
 */
export function gradeTap(round: Round, cell: number, progress: number): TapOutcome {
  const chip = chipAtCell(round, cell);
  const expected = progress + 1;
  const correct = chip !== null && chip.n === expected;
  return {
    correct,
    complete: correct && expected === round.n,
    chipN: chip ? chip.n : null,
  };
}

/* ------------------------------------------------------------------ */
/*  Run state machine (pure transitions)                               */
/* ------------------------------------------------------------------ */

/** Create a run and deal the first round. */
export function newRun(
  rng: () => number,
  startN: number = START_N,
  lives: number = START_LIVES
): RunState {
  const level = Math.max(1, Math.min(MAX_LEVEL, Math.round(startN)));
  return {
    phase: "show",
    level,
    lives: Math.max(1, Math.round(lives)),
    maxLives: Math.max(1, Math.round(lives)),
    streak: 0,
    round: makeRound(level, rng),
    masked: false,
    progress: 0,
    records: [],
    lastWrongCell: null,
    pendingIntervals: [],
    rng,
  };
}

/**
 * Apply one tap to the run. Pure: returns a new RunState (the input is
 * never mutated). Timing is optional so unit tests can drive the whole
 * machine without a clock.
 */
export function applyTap(state: RunState, cell: number, timing?: TapTiming): TapResult {
  const idle: TapResult = {
    next: state,
    outcome: { correct: false, complete: false, chipN: null },
    roundEnded: false,
    cleared: false,
    lifeLost: false,
    advanced: false,
  };
  if (state.phase !== "show" && state.phase !== "recall") return idle;

  const sincePrevMs = timing ? Math.max(0, timing.sincePrevMs) : 0;
  const roundMs = timing ? Math.max(0, timing.roundMs) : 0;
  const outcome = gradeTap(state.round, cell, state.progress);

  if (!outcome.correct) {
    // Wrong chip or wrong order: round over, one life gone.
    const intervals =
      state.progress >= 1 ? [...state.pendingIntervals, sincePrevMs] : state.pendingIntervals;
    const record: RoundRecord = {
      n: state.round.n,
      cleared: false,
      taps: state.progress + 1,
      correctTaps: state.progress,
      intervals: [...intervals],
      durationMs: roundMs,
    };
    const lives = state.lives - 1;
    return {
      next: {
        ...state,
        phase: lives <= 0 ? "done" : "failed-feedback",
        lives: Math.max(0, lives),
        streak: 0,
        records: [...state.records, record],
        lastWrongCell: cell,
        pendingIntervals: [],
      },
      outcome,
      roundEnded: true,
      cleared: false,
      lifeLost: true,
      advanced: false,
    };
  }

  const newProgress = state.progress + 1;
  const intervals =
    newProgress >= 2 ? [...state.pendingIntervals, sincePrevMs] : state.pendingIntervals;

  if (newProgress < state.round.n) {
    // First correct tap masks the board; every tap keeps it masked.
    return {
      next: {
        ...state,
        phase: "recall",
        masked: true,
        progress: newProgress,
        pendingIntervals: intervals,
      },
      outcome,
      roundEnded: false,
      cleared: false,
      lifeLost: false,
      advanced: false,
    };
  }

  // Final chip: round cleared.
  const record: RoundRecord = {
    n: state.round.n,
    cleared: true,
    taps: state.round.n,
    correctTaps: state.round.n,
    intervals: [...intervals],
    durationMs: roundMs,
  };
  let level = state.level;
  let streak = state.streak + 1;
  let advanced = false;
  if (streak >= CLEARS_TO_ADVANCE) {
    level = Math.min(MAX_LEVEL, level + 1);
    streak = 0;
    advanced = true;
  }
  return {
    next: {
      ...state,
      phase: "cleared-feedback",
      masked: true,
      progress: newProgress,
      level,
      streak,
      records: [...state.records, record],
      pendingIntervals: [],
    },
    outcome,
    roundEnded: true,
    cleared: true,
    lifeLost: false,
    advanced,
  };
}

/**
 * Deal the next round after a feedback beat. On "done" this is a no-op;
 * the UI finishes the run instead.
 */
export function dealNext(state: RunState): RunState {
  if (state.phase !== "cleared-feedback" && state.phase !== "failed-feedback") return state;
  return {
    ...state,
    phase: "show",
    round: makeRound(state.level, state.rng),
    masked: false,
    progress: 0,
    lastWrongCell: null,
    pendingIntervals: [],
  };
}

/* ------------------------------------------------------------------ */
/*  Bot-like detection                                                 */
/* ------------------------------------------------------------------ */

/**
 * A cleared round of >= BOT_MIN_CHIPS chips whose every consecutive-tap
 * gap is under BOT_GAP_MS is faster than humanly possible.
 */
export function roundIsBotLike(record: RoundRecord): boolean {
  if (!record.cleared) return false;
  if (record.n < BOT_MIN_CHIPS) return false;
  if (record.intervals.length !== record.n - 1) return false;
  return record.intervals.every((gap) => gap < BOT_GAP_MS);
}

export function runIsBotLike(records: readonly RoundRecord[]): boolean {
  return records.some(roundIsBotLike);
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/** Continuous mastery level -> z against the untrained-adult anchor. */
export function levelZOf(effectiveLevel: number): number {
  return (effectiveLevel - LEVEL_MEAN) / LEVEL_SD;
}

/** Tap accuracy -> clamped z against the accuracy anchor. */
export function accuracyZOf(accuracy: number): number {
  const z = (accuracy - ACC_MEAN) / ACC_SD;
  return Math.min(ACC_Z_CAP, Math.max(-ACC_Z_CAP, z));
}

/**
 * Blend the level signal (weight 0.7) with the accuracy signal
 * (weight 0.3) onto the IQ scale (mean 100, SD 15).
 */
export function compositeIq(effectiveLevel: number, accuracy: number): number {
  const z = LEVEL_WEIGHT * levelZOf(effectiveLevel) + ACC_WEIGHT * accuracyZOf(accuracy);
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the composite IQ. */
export function gradeForIq(iq: number): ChimpGrade {
  if (iq < 85) {
    return {
      label: "Warming up",
      blurb: "The masked board got the better of you this time - almost everyone adds a level or two once the rhythm clicks.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - a dependable grasp of number positions under masking.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - you hold number positions with little mental effort.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier span - the kind of working memory that shines in chess, coding and surgery.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite territory - Ayumu the chimpanzee would nod in respect.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Run scoring                                                        */
/* ------------------------------------------------------------------ */

/**
 * Score a complete run from its round records.
 *
 * The last record is always the round during which the final life was
 * lost, so:
 *   levelReached   = highest N played (monotone across the run)
 *   streakAtDeath  = trailing consecutive clears at that N (the clears
 *                    earned before the fatal round)
 *   effectiveLevel = (levelReached - 1) + streakAtDeath / 3
 */
export function scoreRun(records: readonly RoundRecord[]): ChimpScore {
  const totalRounds = records.length;

  if (totalRounds === 0) {
    const floorLevel = START_N - 1;
    const iq = compositeIq(floorLevel, 0);
    return {
      levelReached: floorLevel,
      effectiveLevel: floorLevel,
      totalCleared: 0,
      totalRounds: 0,
      correctTaps: 0,
      totalTaps: 0,
      accuracy: 0,
      meanRoundMs: null,
      streakAtDeath: 0,
      iq,
      percentile: iqToPercentile(iq),
      grade: gradeForIq(iq),
      botLike: false,
    };
  }

  let levelReached = 0;
  let totalCleared = 0;
  let correctTaps = 0;
  let totalTaps = 0;
  let durationSum = 0;
  for (const record of records) {
    levelReached = Math.max(levelReached, record.n);
    if (record.cleared) totalCleared += 1;
    correctTaps += record.correctTaps;
    totalTaps += record.taps;
    durationSum += record.durationMs;
  }

  let streakAtDeath = 0;
  // The final record is the fatal failed round (lives only run out on a
  // wrong tap), so the trailing-clear walk starts one record earlier.
  for (let i = totalRounds - 2; i >= 0; i--) {
    const record = records[i]!;
    if (record.cleared && record.n === levelReached) streakAtDeath += 1;
    else break;
  }

  const effectiveLevel = (levelReached - 1) + streakAtDeath / CLEARS_TO_ADVANCE;
  const accuracy = totalTaps > 0 ? correctTaps / totalTaps : 0;
  const meanRoundMs = durationSum / totalRounds;
  const iq = compositeIq(effectiveLevel, accuracy);

  return {
    levelReached,
    effectiveLevel,
    totalCleared,
    totalRounds,
    correctTaps,
    totalTaps,
    accuracy,
    meanRoundMs,
    streakAtDeath,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
    botLike: runIsBotLike(records),
  };
}

/* ------------------------------------------------------------------ */
/*  Formatting helper                                                  */
/* ------------------------------------------------------------------ */

/** 1840 -> "1.8s" (one decimal, stable for display and tests). */
export function formatRoundSeconds(ms: number): string {
  return `${(Math.max(0, ms) / 1000).toFixed(1)}s`;
}
