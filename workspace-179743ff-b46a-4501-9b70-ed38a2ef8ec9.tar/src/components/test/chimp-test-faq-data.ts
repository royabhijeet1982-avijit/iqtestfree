/* ------------------------------------------------------------------ */
/*  Chimp Test - FAQ (single source)                                   */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type ChimpFaqItem = { question: string; answer: string };

export const CHIMP_FAQ_ITEMS: ChimpFaqItem[] = [
  {
    question: "What does the Chimp Test measure?",
    answer:
      "It measures visuospatial working memory - your brain's sketchpad for holding locations in mind once the evidence is gone. The task is the same paradigm made famous by the Kyoto University study of the chimpanzee Ayumu (Inoue & Matsuzawa, 2007): numbered targets appear, then hide, and you must recall their positions in order. Young chimpanzees famously outperformed human adults on exactly this masked-number challenge.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Each round shows a number of chips equal to your current level; clearing three rounds in a row adds another chip, and a wrong tap costs one of three lives. Your 'effective level' is continuous mastery at the moment your lives ran out - for example, clearing two of the three rounds needed at level 6 counts as 5.67. That level, blended about 70/30 with your tap accuracy, is mapped onto an IQ-style scale (mean 100, SD 15) with a percentile against untrained adults.",
  },
  {
    question: "How long does the test take?",
    answer:
      "About five minutes. Individual rounds last only a few seconds - the numbers are visible for as long as you dare wait before tapping chip 1 - but a full run is a ladder of rounds across several levels, ending when your three lives are gone. There is no separate time limit, so you never have to rush the memorising itself.",
  },
  {
    question: "Can I retake the test?",
    answer:
      "Yes, as often as you like. Every round deals a freshly random board and every retake starts a brand-new run, so nothing can be memorised between attempts - the skill you are training is genuine spatial recall, not familiarity with the boards. A short warm-up effect is normal, so retaking once or twice to shake off the intro jitters is a fair way to see your true span.",
  },
  {
    question: "Any tips for a higher score?",
    answer:
      "Memorise before you tap: the instant you touch chip 1, every number disappears, so scan the whole board first and fix the positions in mind. Chunk the locations into shapes or clusters - corners, rows, a triangle - rather than memorising digits one by one. And stay calm at higher levels: a wrong tap costs a life but never ends the run, so a steady rhythm beats panicked speed.",
  },
  {
    question: "Is this comparable to professional memory tests?",
    answer:
      "It is an educational estimate built on a real research paradigm, not a clinical instrument. The masking procedure and span-ladder structure mirror the working-memory tasks used in cognitive science, and your score is anchored to a population model, but professionals use standardised, supervised assessments such as the WAIS working-memory index. Treat your result as a fun, honest benchmark - not a diagnosis.",
  },
];
