/* ------------------------------------------------------------------ */
/*  Digit Span Test - pure scoring engine                              */
/*  Paradigm: classic WAIS-style digit span with two phases.           */
/*                                                                     */
/*  FORWARD phase: sequences start at 3 digits and grow by one.        */
/*  Each digit is shown for DISPLAY_MS with a GAP_MS blank between.    */
/*  The user recalls the digits in the SAME order. Two attempts are    */
/*  allowed per length (the second only after a failed first); one     */
/*  correct attempt advances to the next length, failing both          */
/*  attempts at a length discontinues the phase.                       */
/*                                                                     */
/*  BACKWARD phase: identical rules, but the user recalls the digits   */
/*  in REVERSE order. It starts after the forward phase ends.          */
/*                                                                     */
/*  Span = the highest length with at least one correct attempt.       */
/*                                                                     */
/*  Scoring: the two spans are z-scored against adult population       */
/*  norms (forward ~7, SD 1.6; backward ~5.5, SD 1.5), combined into  */
/*  a weighted composite (backward weighted slightly higher because    */
/*  it is harder), renormalised for the known span correlation, and    */
/*  mapped onto the IQ scale (mean 100, SD 15) via an erf-based        */
/*  normal CDF. Percentiles are clamped to 1..99.                      */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Submitting before the sequence was shown, or submitting an      */
/*     empty input, records an INVALID attempt that can never count    */
/*     toward a span.                                                  */
/*   - Sequences are re-randomised for every attempt.                  */
/*   - After a failed attempt, the next attempt at the same length     */
/*     always uses a DIFFERENT sequence (no retry-and-memorise).       */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** The digit alphabet (0-9, adjacent repeats are the only constraint). */
export const DIGITS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] as const;

/* --------------------------- pacing/config -------------------------- */

/** First sequence length in a normal session. */
export const START_LENGTH = 3;
/** Attempts allowed per length in a normal session. */
export const ATTEMPTS_PER_LENGTH = 2;
/** First sequence length in quick (practice) mode. */
export const QUICK_START_LENGTH = 4;
/** Attempts allowed per length in quick mode. */
export const QUICK_ATTEMPTS_PER_LENGTH = 1;
/** Sequence lengths stop here; passing the top length ends the phase. */
export const MAX_LENGTH = 10;

/** Per-digit display time (normal mode). */
export const DISPLAY_MS = 1000;
/** Blank gap between digits (normal mode). */
export const GAP_MS = 250;
/** Per-digit display time in quick mode (shortened mode). */
export const QUICK_DISPLAY_MS = 500;
/** Blank gap between digits in quick mode. */
export const QUICK_GAP_MS = 120;

/* ------------------------- population model ------------------------- */

/** Typical adult forward digit span (digits, unchunked). */
export const FWD_MEAN = 7;
export const FWD_SD = 1.6;
/** Typical adult backward digit span. */
export const BWD_MEAN = 5.5;
export const BWD_SD = 1.5;
/** Composite weights - backward recall loads working memory harder. */
export const FWD_WEIGHT = 0.45;
export const BWD_WEIGHT = 0.55;
/** Population correlation between forward and backward spans. */
export const SPAN_CORRELATION = 0.55;

/** SD of the weighted composite of the two standardised spans. A
 *  weighted average of two correlated unit-variance scores has SD
 *  below 1, so the composite is renormalised by this constant to keep
 *  the IQ scale honestly calibrated (SD 15, not shrunk). */
export const COMPOSITE_SD = Math.sqrt(
  FWD_WEIGHT ** 2 + BWD_WEIGHT ** 2 + 2 * FWD_WEIGHT * BWD_WEIGHT * SPAN_CORRELATION
);

export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type SpanDirection = "forward" | "backward";

export type SpanAttempt = {
  direction: SpanDirection;
  /** Sequence length for this attempt. */
  length: number;
  /** 1-based attempt number within this length. */
  attemptIndex: number;
  /** The sequence that was displayed. */
  target: number[];
  /** The sequence the user submitted (empty for invalid attempts). */
  input: number[];
  /** Graded outcome (always false for invalid attempts). */
  correct: boolean;
  /** Anti-gaming validity: false = submit-before-show or empty input. */
  valid: boolean;
  invalidReason: string | null;
};

export type SessionConfig = {
  startLength: number;
  attemptsPerLength: number;
  displayMs: number;
  gapMs: number;
  quick: boolean;
};

export type SpanGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SpanSessionResult = {
  forwardSpan: number;
  backwardSpan: number;
  /** forwardSpan + backwardSpan. */
  totalSpan: number;
  /** IQ-scale composite (mean 100, SD 15), clamped to IQ_MIN..IQ_MAX. */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: SpanGrade;
  quick: boolean;
  /** Total attempts across both phases. */
  attempts: number;
  /** Correct (and valid) attempts across both phases. */
  correct: number;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

function sameSequence(a: readonly number[], b: readonly number[]): boolean {
  return a.length === b.length && a.every((d, i) => d === b[i]);
}

/* ------------------------------------------------------------------ */
/*  Sequence construction                                              */
/* ------------------------------------------------------------------ */

/**
 * Draw a random digit sequence of the given length. Digits come from
 * 0-9 and no two ADJACENT digits repeat (repeats further apart are
 * allowed - they make the task harder, not easier to game).
 */
export function buildSequence(length: number, rng: () => number): number[] {
  const out: number[] = [];
  let prev = -1;
  for (let i = 0; i < length; i++) {
    let d = Math.floor(rng() * 10);
    if (d === prev) {
      // Redraw uniformly from the 9 digits that differ from the previous.
      d = (d + 1 + Math.floor(rng() * 9)) % 10;
    }
    out.push(d);
    prev = d;
  }
  return out;
}

/**
 * Build a sequence that differs from every sequence in `exclude`.
 * Used after a failed attempt so the retry can never be the memorised
 * sequence. The exclusion space at length >= 2 is >= 90 sequences, so
 * rejection sampling terminates with certainty for all practical
 * session sizes.
 */
export function differentSequence(
  length: number,
  rng: () => number,
  exclude: readonly (readonly number[])[]
): number[] {
  for (let i = 0; i < 500; i++) {
    const candidate = buildSequence(length, rng);
    if (!exclude.some((e) => sameSequence(e, candidate))) return candidate;
  }
  // Statistically unreachable fallback; still returns a fresh sequence.
  return buildSequence(length, rng);
}

/** The reversed copy of a sequence (what backward recall expects). */
export function reverseOf(seq: readonly number[]): number[] {
  return seq.slice().reverse();
}

/* ------------------------------------------------------------------ */
/*  Grading                                                            */
/* ------------------------------------------------------------------ */

/**
 * Grade a recall attempt.
 *  - forward: input must equal the target exactly.
 *  - backward: input must equal the target reversed.
 * Both phases require the full length (partial input is incorrect).
 */
export function gradeRecall(
  target: readonly number[],
  input: readonly number[],
  direction: SpanDirection
): boolean {
  if (input.length !== target.length) return false;
  const expected = direction === "backward" ? reverseOf(target) : target;
  return expected.every((digit, i) => digit === input[i]);
}

/**
 * Record one attempt with anti-gaming validation.
 * An attempt is INVALID (and can never count toward a span) if it was
 * submitted before the sequence finished displaying, or if the input
 * was empty.
 */
export function submitAttempt(params: {
  direction: SpanDirection;
  length: number;
  attemptIndex: number;
  target: readonly number[];
  input: readonly number[];
  wasShown: boolean;
}): SpanAttempt {
  const { direction, length, attemptIndex, target, input, wasShown } = params;
  const base = {
    direction,
    length,
    attemptIndex,
    target: [...target],
    input: [...input],
  };
  if (!wasShown) {
    return {
      ...base,
      input: [],
      correct: false,
      valid: false,
      invalidReason: "Response was submitted before the sequence was shown.",
    };
  }
  if (input.length === 0) {
    return {
      ...base,
      correct: false,
      valid: false,
      invalidReason: "Empty response - no digits were submitted.",
    };
  }
  return {
    ...base,
    correct: gradeRecall(target, input, direction),
    valid: true,
    invalidReason: null,
  };
}

/* ------------------------------------------------------------------ */
/*  Span + session scoring                                             */
/* ------------------------------------------------------------------ */

/** Highest length with at least one correct, valid attempt (0 if none). */
export function spanOfPhase(attempts: readonly SpanAttempt[]): number {
  let span = 0;
  for (const attempt of attempts) {
    if (attempt.valid && attempt.correct && attempt.length > span) {
      span = attempt.length;
    }
  }
  return span;
}

/** Pacing + staircase parameters for normal or quick mode. */
export function sessionConfig(quick: boolean): SessionConfig {
  return quick
    ? {
        startLength: QUICK_START_LENGTH,
        attemptsPerLength: QUICK_ATTEMPTS_PER_LENGTH,
        displayMs: QUICK_DISPLAY_MS,
        gapMs: QUICK_GAP_MS,
        quick: true,
      }
    : {
        startLength: START_LENGTH,
        attemptsPerLength: ATTEMPTS_PER_LENGTH,
        displayMs: DISPLAY_MS,
        gapMs: GAP_MS,
        quick: false,
      };
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map (forwardSpan, backwardSpan) onto the IQ scale (mean 100, SD 15).
 * Each span is z-scored against its population norm, the two are
 * combined with fixed weights (backward weighted higher), and the
 * composite is renormalised by COMPOSITE_SD so the scale keeps its
 * full SD 15 spread. The result is clamped to IQ_MIN..IQ_MAX.
 */
export function spansToIq(forwardSpan: number, backwardSpan: number): number {
  const zf = (forwardSpan - FWD_MEAN) / FWD_SD;
  const zb = (backwardSpan - BWD_MEAN) / BWD_SD;
  const composite = (FWD_WEIGHT * zf + BWD_WEIGHT * zb) / COMPOSITE_SD;
  const iq = Math.round(100 + 15 * composite);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ-scale score -> population percentile (1..99), normal model. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ-scale composite. */
export function gradeForIq(iq: number): SpanGrade {
  if (iq < 85) {
    return {
      label: "Building",
      blurb: "Your spans came out short today - sleep, focus and task familiarity all move this number, so a warm-up retake often tells a fairer story.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in the everyday range - most adults hold about 7 digits forward and a little less backward, and that is exactly where you landed.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Above average",
      blurb: "Stronger than most - your working memory comfortably handles phone numbers, directions and multi-step instructions without notes.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Well above average",
      blurb: "Excellent span - long sequences stick together for you, which pays off in mental arithmetic, reading comprehension and following complex arguments.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite memory span - a level reached by only a few percent of adults. Your forward and backward recall both held up under serious load.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/**
 * Score a completed session (both phases).
 *
 * Span = highest length with at least one correct, valid attempt.
 * Invalid attempts (empty or submit-before-show) never contribute, so
 * a session of nothing but rejected attempts scores the honest floor:
 * spans 0/0 and the clamped minimum IQ - never an inflated number.
 */
export function scoreSession(
  forwardAttempts: readonly SpanAttempt[],
  backwardAttempts: readonly SpanAttempt[],
  quick: boolean
): SpanSessionResult {
  const forwardSpan = spanOfPhase(forwardAttempts);
  const backwardSpan = spanOfPhase(backwardAttempts);
  const all = [...forwardAttempts, ...backwardAttempts];
  const iq = spansToIq(forwardSpan, backwardSpan);
  return {
    forwardSpan,
    backwardSpan,
    totalSpan: forwardSpan + backwardSpan,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
    quick,
    attempts: all.length,
    correct: all.filter((a) => a.valid && a.correct).length,
  };
}
