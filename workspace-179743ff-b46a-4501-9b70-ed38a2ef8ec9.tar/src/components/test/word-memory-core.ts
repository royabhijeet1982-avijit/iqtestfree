/* ------------------------------------------------------------------ */
/*  Word Memory Test - pure scoring engine                             */
/*  Paradigm: the classic yes/no word-recognition task from verbal     */
/*  memory research (old/new paradigm). Each round has a STUDY phase   */
/*  (words appear one at a time, engine-paced) and a RECOGNIZE phase   */
/*  (a shuffled stream of studied words + equally many new foils -     */
/*  you judge each one "I saw it" or "It's new").                      */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - digit-span: recall of a numeric stream, you reproduce it.       */
/*     Here: RECOGNITION of a verbal stream - you never re-produce     */
/*     anything, you only judge familiarity.                           */
/*   - sequence-memory / visual-memory: spatial grids. Here: pure      */
/*     verbal material, no spatial component at all.                   */
/*   - working-memory: hold + manipulate. Here: recognition memory,    */
/*     zero manipulation.                                              */
/*                                                                     */
/*  Scoring honesty (anti-gaming by design):                           */
/*   - The primary metric is PROPORTION CORRECT (hits + correct        */
/*     rejections over all judgements). The lists are balanced         */
/*     (50% targets, 50% foils), so a degenerate strategy cannot      */
/*     win: mashing "I saw it" catches every target but false-alarms   */
/*     on every foil (50%); mashing "It's new" is symmetric (50%).     */
/*     Only genuine memory moves the number.                           */
/*   - d' (d-prime, signal-detection sensitivity, log-linear           */
/*     corrected) is reported as a science stat but is NOT the score - */
/*     d' alone would reward a liberal all-"old" bias.                 */
/*   - Response speed is not part of the score either: unlimited       */
/*     thinking time per word, so the index is memory-pure.            */
/*   - Every run reseeds the RNG and draws fresh words from a large    */
/*     pool, so there is nothing to memorise between attempts.         */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Study-list lengths per round (round 1 -> 8 words, ..., round 3 -> 16). */
export const ROUND_LIST_LENS: readonly number[] = [8, 12, 16];

/** Total number of studied (target) words across a session. */
export const TOTAL_TARGETS = ROUND_LIST_LENS.reduce((a, b) => a + b, 0);

/* -------------------- Engine-owned timing (ms) -------------------- */
/** How long each word stays on screen during STUDY. */
export const STUDY_ON_MS = 1250;
/** Dark gap between study words. */
export const STUDY_GAP_MS = 350;
/** Idle pause before the first study word of a round. */
export const PRE_STUDY_MS = 450;
/** Countdown step during the between-phases interlude (3-2-1). */
export const INTERLUDE_STEP_MS = 750;
/** Feedback flash after each judgement. */
export const FEEDBACK_MS = 260;
/** Gap between the feedback and the next test word. */
export const RESPONSE_GAP_MS = 120;

/** Shortened timings used by automated flow tests via ?quick=1. */
export const STUDY_ON_MS_QUICK = 300;
export const STUDY_GAP_MS_QUICK = 80;
export const PRE_STUDY_MS_QUICK = 150;
export const INTERLUDE_STEP_MS_QUICK = 150;
export const FEEDBACK_MS_QUICK = 80;
export const RESPONSE_GAP_MS_QUICK = 40;

/* -------------------- Population model -------------------- */
/**
 * Adult mean / SD for overall proportion correct on a balanced
 * old/new word-recognition task with lists growing 8 -> 12 -> 16.
 * 0.76 means the average adult recognises roughly three quarters of
 * the stream correctly. The score index is the standard IQ scale.
 */
export const ACC_MEAN = 0.76;
export const ACC_SD = 0.08;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** One item of a round's recognition stream. */
export type TestItem = {
  word: string;
  /** True when the word was in this round's study list. */
  isTarget: boolean;
  /** 0-based round the item belongs to. */
  round: number;
};

/** One round: a study list plus the shuffled recognition stream. */
export type WordRound = {
  /** 0-based round index. */
  round: number;
  /** Study-list length (also the number of foils). */
  listLen: number;
  /** The words shown during STUDY, in presentation order. */
  studyWords: string[];
  /** Study words + foils, shuffled - the stream to judge. */
  testWords: TestItem[];
};

export type WordMemorySession = {
  rounds: WordRound[];
};

/** One user judgement in the recognition stream. */
export type Judgement = {
  word: string;
  isTarget: boolean;
  round: number;
  /** True when the user answered "I saw it". */
  saidOld: boolean;
  /** Time from word onset to response in ms (null if unavailable). */
  rtMs: number | null;
};

export type RoundStat = {
  round: number;
  targets: number;
  foils: number;
  hits: number;
  falseAlarms: number;
  /** (hits + correct rejections) / items judged in this round. */
  accuracy: number;
};

export type MemoryGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type WordMemoryScore = {
  /** Said "old" to a studied word. */
  hits: number;
  /** Said "new" to a studied word. */
  misses: number;
  /** Said "old" to a foil. */
  falseAlarms: number;
  /** Said "new" to a foil. */
  correctRejections: number;
  targets: number;
  foils: number;
  /** Overall proportion correct (hits + CR) / total. */
  accuracy: number;
  /** Signal-detection sensitivity (log-linear corrected). */
  dPrime: number;
  /** Mean response time in ms (null when no timings recorded). */
  avgRtMs: number | null;
  /** Per-round breakdown, one entry per round with any judgements. */
  rounds: RoundStat[];
  /** IQ-scale verbal memory index (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: MemoryGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle of a copy - never mutates the input. */
export function shuffled<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i]!;
    out[i] = out[j]!;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Word pool                                                          */
/* ------------------------------------------------------------------ */

/**
 * ~200 common, concrete English nouns (3-10 letters). Deliberately
 * curated so that NO word is a prefix of another and no plural/singular
 * pairs exist ("wrench" yes, "wren" no; "teapot" yes, "tea" no) - a
 * stem-relative pair would make the old/new judgement ambiguous.
 * The unit-verify script re-checks all of these invariants.
 */
export const WORD_POOL: readonly string[] = [
  "almond", "amber", "anchor", "ankle", "apple", "apron", "arrow", "autumn", "avocado",
  "bagel", "balcony", "bamboo", "banner", "basin", "basket", "beacon", "beetle", "bell",
  "belt", "bicycle", "bird", "bishop", "blanket", "bottle", "bracelet", "bracket", "bread",
  "bridge", "broom", "bucket", "buffalo", "button",
  "cabin", "cable", "cactus", "camera", "candle", "canoe", "canvas", "captain", "carrot",
  "castle", "ceiling", "cellar", "chain", "chair", "chalk", "cheese", "cherry", "chimney",
  "circle", "cliff", "clock", "cloud", "clover", "coach", "coast", "comet", "compass",
  "copper", "corner", "cotton", "couch", "crayon", "cream", "crown", "crystal", "cupboard",
  "daisy", "dolphin", "donkey", "dragon", "drawer", "drum", "duck", "dust",
  "eagle", "earth", "engine", "envelope",
  "falcon", "feather", "fence", "fern", "fiddle", "finger", "firefly", "flag", "flamingo",
  "flute", "forest", "fountain", "fox", "frame", "frost", "funnel",
  "galaxy", "garden", "garlic", "gazelle", "gecko", "giant", "ginger", "giraffe", "glove",
  "grape", "gravel", "guitar",
  "hammer", "hammock", "handle", "harbor", "harvest", "hawk", "hazel", "helmet", "hinge",
  "honey", "horn", "horse", "hurdle",
  "iceberg", "igloo", "index", "ivory", "ivy",
  "jacket", "jaguar", "jasmine", "jelly", "jewel", "jigsaw", "jungle", "jury",
  "kayak", "kettle", "keyboard", "kingdom", "kitten", "kiwi", "knife", "knot",
  "ladder", "lantern", "lattice", "lavender", "ledger", "legend", "lemon", "leopard",
  "lever", "lily", "linen", "lion", "lizard", "lobster", "locket", "lumber",
  "magnet", "mailbox", "mammal", "mango", "maple", "marble", "meadow", "melody", "mercury",
  "meteor", "mirror", "mitten", "monkey", "moon", "moss", "moth", "mountain", "mouse", "muffin",
  "napkin", "nickel", "noodle", "north", "nurse", "nutmeg",
  "oak", "oasis", "ocean", "octopus", "olive", "onyx", "orange", "orchid", "otter", "owl",
  "oyster",
  "paddle", "pagoda", "palm", "pancake", "panther", "papaya", "paper", "parade", "parsley",
  "pastel", "peacock", "pebble", "pelican", "pencil", "pepper", "petal", "phantom", "piano",
  "pigment", "pillow", "pilot", "pine", "pizza", "planet", "plank", "plaza", "plum",
  "pocket", "poppy", "porch", "potato", "prism", "prize", "pumpkin", "puzzle",
  "quartz", "quill", "quilt",
  "rabbit", "raccoon", "radar", "raisin", "raven", "ribbon", "river", "rocket", "rooster",
  "rope", "rose", "rudder", "ruby", "ruin",
  "saddle", "sailor", "salmon", "sandal", "sapphire", "satchel", "scale", "scarf", "seal",
  "shadow", "shark", "sheep", "shelf", "shell", "shovel", "silk", "sketch", "skull", "slate",
  "smoke", "snake", "soap", "socket", "sofa", "spark", "sparrow", "spice", "spider", "spiral",
  "sponge", "spruce", "squirrel", "stable", "stair", "stem", "stone", "storm", "stump",
  "sugar", "sunflower", "syrup",
  "table", "tandem", "tavern", "teapot", "thicket", "thimble", "thistle", "thunder", "tiger",
  "timber", "tinsel", "toffee", "token", "tomato", "torch", "tortoise", "tower", "trail",
  "treasure", "tree", "triangle", "trumpet", "tulip", "tunnel", "turquoise", "turtle", "twig",
  "umbrella", "unicorn", "urchin",
  "valley", "vase", "velvet", "vessel", "violin", "violet", "vulture",
  "walnut", "walrus", "wardrobe", "weasel", "whale", "whisker", "willow", "window", "wolf",
  "wood", "wool", "wrench",
  "yacht", "yarn", "yolk",
  "zebra", "zipper",
];

/* ------------------------------------------------------------------ */
/*  Session building                                                   */
/* ------------------------------------------------------------------ */

/**
 * Build a full session (3 rounds) from a seed:
 *  1. Shuffle the pool, deal TOTAL_TARGETS distinct study words and
 *     slice them into rounds of ROUND_LIST_LENS.
 *  2. For each round draw listLen foils from the UNUSED remainder -
 *     a foil can never equal any word studied in ANY round, and foils
 *     never repeat across rounds. Every word in a session is unique.
 *  3. Shuffle targets + foils into the recognition stream.
 */
export function buildWordMemorySession(seed: number): WordMemorySession {
  const rng = mulberry32(seed);
  const pool = shuffled(WORD_POOL, rng);
  const needed = TOTAL_TARGETS + ROUND_LIST_LENS.reduce((a, b) => a + b, 0);
  if (pool.length < needed) {
    // Cannot happen with the shipped pool; guarded for future edits.
    throw new Error(`word pool too small: ${pool.length} < ${needed}`);
  }

  const rounds: WordRound[] = [];
  let cursor = 0;
  let foilCursor = TOTAL_TARGETS;

  for (let r = 0; r < ROUND_LIST_LENS.length; r++) {
    const listLen = ROUND_LIST_LENS[r]!;
    const studyWords = pool.slice(cursor, cursor + listLen);
    cursor += listLen;

    const foils = pool.slice(foilCursor, foilCursor + listLen);
    foilCursor += listLen;

    const items: TestItem[] = [
      ...studyWords.map((word) => ({ word, isTarget: true, round: r })),
      ...foils.map((word) => ({ word, isTarget: false, round: r })),
    ];

    rounds.push({
      round: r,
      listLen,
      studyWords,
      testWords: shuffled(items, rng),
    });
  }

  return { rounds };
}

/* ------------------------------------------------------------------ */
/*  Signal detection (d-prime)                                         */
/* ------------------------------------------------------------------ */

/**
 * Inverse standard normal CDF (probit) - Acklam's rational
 * approximation, |relative error| < 1.15e-9 over the open interval.
 */
export function probit(p: number): number {
  if (!Number.isFinite(p)) return NaN;
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;

  const a = [
    -3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
    1.38357751867269e2, -3.066479806614716e1, 2.506628277459239e0,
  ];
  const b = [
    -5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
    6.680131188771972e1, -1.328068155288572e1,
  ];
  const c = [
    -7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0,
    -2.549732539343734e0, 4.374664141464968e0, 2.938163982698783e0,
  ];
  const d = [
    7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0,
    3.754408661907416e0,
  ];

  const pLow = 0.02425;
  let q: number;
  let r: number;

  if (p < pLow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (
      (((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
      ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1)
    );
  }
  if (p <= 1 - pLow) {
    q = p - 0.5;
    r = q * q;
    return (
      (((((a[0]! * r + a[1]!) * r + a[2]!) * r + a[3]!) * r + a[4]!) * r + a[5]!) * q /
      (((((b[0]! * r + b[1]!) * r + b[2]!) * r + b[3]!) * r + b[4]!) * r + 1)
    );
  }
  q = Math.sqrt(-2 * Math.log(1 - p));
  return (
    -(((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
    ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1)
  );
}

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * d-prime with the log-linear correction (Hits + 0.5 / Targets + 1,
 * FA + 0.5 / Foils + 1), which keeps extreme rates finite. Equal hit
 * and false-alarm rates give exactly 0 - so a pure bias strategy
 * (mash "old" or mash "new") can never look sensitive.
 */
export function dPrime(
  hits: number,
  nTargets: number,
  falseAlarms: number,
  nFoils: number
): number {
  const hr = (hits + 0.5) / (nTargets + 1);
  const fr = (falseAlarms + 0.5) / (nFoils + 1);
  return probit(hr) - probit(fr);
}

/* ------------------------------------------------------------------ */
/*  Population model + grading                                         */
/* ------------------------------------------------------------------ */

/**
 * Map overall proportion correct onto the IQ scale (mean 100, SD 15).
 * Accuracy is the ONLY ingredient: no speed, no bias bonus. Balanced
 * lists mean chance-level mashing lands at 0.50 -> the index floor.
 */
export function memoryIndex(accuracy: number): number {
  const clamped = Math.min(1, Math.max(0, accuracy));
  const iq = Math.round(100 + (15 * (clamped - ACC_MEAN)) / ACC_SD);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): MemoryGrade {
  if (iq < 85) {
    return {
      label: "Building",
      blurb: "Your word recognition is still warming up - the streams shrink your advantage right now, but a second run with steadier attention usually lifts the number.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - you separate studied words from new ones about as well as the general population.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - studied words ring clearly familiar to you while new words stay convincingly new.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier verbal recognition - the kind of word memory that shines in reading, languages and exams.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite word memory - near-perfect separation of old from new across all three growing lists.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a complete session from the raw judgements. Aggregates are
 * item-weighted (every judged word counts once); per-round stats are
 * grouped by the round recorded on each judgement.
 */
export function scoreSession(judgements: readonly Judgement[]): WordMemoryScore {
  let hits = 0;
  let misses = 0;
  let falseAlarms = 0;
  let correctRejections = 0;
  let targets = 0;
  let foils = 0;
  let rtSum = 0;
  let rtCount = 0;

  const roundMap = new Map<number, { targets: number; foils: number; hits: number; falseAlarms: number }>();

  for (const j of judgements) {
    const bucket = roundMap.get(j.round) ?? { targets: 0, foils: 0, hits: 0, falseAlarms: 0 };
    if (j.isTarget) {
      targets++;
      bucket.targets++;
      if (j.saidOld) {
        hits++;
        bucket.hits++;
      } else {
        misses++;
      }
    } else {
      foils++;
      bucket.foils++;
      if (j.saidOld) {
        falseAlarms++;
        bucket.falseAlarms++;
      } else {
        correctRejections++;
      }
    }
    roundMap.set(j.round, bucket);
    if (j.rtMs !== null && Number.isFinite(j.rtMs)) {
      rtSum += j.rtMs;
      rtCount++;
    }
  }

  const total = targets + foils;
  const accuracy = total > 0 ? (hits + correctRejections) / total : 0;
  const dp = dPrime(hits, targets, falseAlarms, foils);
  const iq = memoryIndex(accuracy);

  const maxRound = judgements.reduce((m, j) => Math.max(m, j.round), -1);
  const rounds: RoundStat[] = [];
  for (let r = 0; r <= maxRound; r++) {
    const b = roundMap.get(r);
    if (!b) continue;
    const judged = b.targets + b.foils;
    rounds.push({
      round: r,
      targets: b.targets,
      foils: b.foils,
      hits: b.hits,
      falseAlarms: b.falseAlarms,
      accuracy: judged > 0 ? (b.hits + (b.foils - b.falseAlarms)) / judged : 0,
    });
  }

  return {
    hits,
    misses,
    falseAlarms,
    correctRejections,
    targets,
    foils,
    accuracy,
    dPrime: dp,
    avgRtMs: rtCount > 0 ? rtSum / rtCount : null,
    rounds,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
