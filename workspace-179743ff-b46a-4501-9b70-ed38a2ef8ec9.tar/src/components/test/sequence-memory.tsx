"use client";

/* ------------------------------------------------------------------ */
/*  Sequence Memory Test - interactive UI                              */
/*  The classic growing-sequence game on a 3x3 grid: one tile lights   */
/*  up, you tap it back; each cleared level appends exactly one tile   */
/*  and replays the WHOLE sequence from the start. One wrong tap ends  */
/*  the run - no lives, no retries. Scoring lives in                   */
/*  sequence-memory-core.ts.                                           */
/*                                                                     */
/*  Testing hook: /test/sequence-memory?quick=1 shortens every engine  */
/*  timing (playback + holds + countdown) so automated flow tests run  */
/*  fast. Quick mode is a timing change only - never a scoring one.    */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (playback | recall | feedback) and lit tiles carry the "is-lit"    */
/*  class plus data-lit="true" so playback can be observed.            */
/*  Keyboard: keys 1-9 tap tiles during recall (a11y + speed).         */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  Eye,
  Layers,
  ListOrdered,
  MousePointerClick,
  RotateCcw,
  ShieldCheck,
  X,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  SPAN_MEAN,
  START_LEVEL,
  appendTile,
  gradeClick,
  mulberry32,
  scoreRun,
  timingForLevel,
  type SequenceMemoryScore,
} from "./sequence-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "playback" | "recall" | "feedback";

type Flash = { tile: number; kind: "correct" | "wrong"; id: number } | null;

/** Idle pause before the first tile lights up. */
const PRE_PLAYBACK_MS = 500;
const PRE_PLAYBACK_MS_QUICK = 200;
/** Gap between the last tile going dark and the recall phase. */
const RECALL_DELAY_MS = 300;
const RECALL_DELAY_MS_QUICK = 150;
/** How long the success feedback holds before the next level. */
const SUCCESS_HOLD_MS = 850;
const SUCCESS_HOLD_MS_QUICK = 220;
/** How long the fail feedback holds before the results. */
const FAIL_HOLD_MS = 1400;
const FAIL_HOLD_MS_QUICK = 400;
/** Click feedback duration. */
const FLASH_MS = 200;
/** Countdown step (3-2-1-GO). */
const COUNTDOWN_STEP_MS = 750;
const COUNTDOWN_STEP_MS_QUICK = 180;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("sequence-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function SequenceMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("playback");
  const [level, setLevel] = useState(START_LEVEL);
  const [litTile, setLitTile] = useState<number | null>(null);
  const [revealTile, setRevealTile] = useState<number | null>(null);
  const [flash, setFlash] = useState<Flash>(null);
  const [placed, setPlaced] = useState(0);
  const [stageRing, setStageRing] = useState<"success" | "fail" | null>(null);
  const [score, setScore] = useState<SequenceMemoryScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);

  const rngRef = useRef<() => number>(() => 0.5);
  const runSeqRef = useRef<number[]>([]);
  const clickIndexRef = useRef(0);
  const attemptsRef = useRef<import("./sequence-memory-core").LevelAttempt[]>([]);
  const levelRef = useRef(START_LEVEL);
  const activeStateRef = useRef<ActiveState>("playback");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed = startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const result = scoreRun(attemptsRef.current);
    setScore(result);
    setPhase("results");
    // Bring the score into view - the user is scrolled mid-card.
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  const beginRecall = useCallback(() => {
    activeStateRef.current = "recall";
    setActiveState("recall");
    clickIndexRef.current = 0;
    setPlaced(0);
    setLitTile(null);
  }, []);

  const schedulePlayback = useCallback(
    (seq: number[], lv: number) => {
      clearTimers();
      activeStateRef.current = "playback";
      setActiveState("playback");
      setLitTile(null);
      setRevealTile(null);
      setStageRing(null);
      const { onMs, offMs } = timingForLevel(lv, quickRef.current);
      const preMs = quickRef.current ? PRE_PLAYBACK_MS_QUICK : PRE_PLAYBACK_MS;
      const recallDelay = quickRef.current ? RECALL_DELAY_MS_QUICK : RECALL_DELAY_MS;
      let t = preMs;
      seq.forEach((tile) => {
        timersRef.current.push(
          setTimeout(() => {
            setLitTile(tile);
          }, t)
        );
        t += onMs;
        timersRef.current.push(
          setTimeout(() => {
            setLitTile(null);
          }, t)
        );
        t += offMs;
      });
      timersRef.current.push(
        setTimeout(() => beginRecall(), t + recallDelay)
      );
    },
    [beginRecall, clearTimers]
  );

  const beginLevel = useCallback(
    (lv: number) => {
      levelRef.current = lv;
      setLevel(lv);
      setPhase("active");
      // Prefix-stable: level N always replays the first N tiles of the
      // one run sequence (which has already grown to at least N tiles).
      const seq = runSeqRef.current.slice(0, lv);
      clickIndexRef.current = 0;
      setPlaced(0);
      setRevealTile(null);
      setStageRing(null);
      schedulePlayback(seq, lv);
    },
    [schedulePlayback]
  );

  const start = useCallback(() => {
    clearTimers();
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rngRef.current = mulberry32(seed);
    runSeqRef.current = [];
    attemptsRef.current = [];
    finishedRef.current = false;
    levelRef.current = START_LEVEL;
    setLevel(START_LEVEL);
    setScore(null);
    setRunSeconds(null);
    setFlash(null);
    setLitTile(null);
    setRevealTile(null);
    setStageRing(null);
    setPlaced(0);
    setCountdownValue(3);
    setPhase("countdown");
    // Align the card immediately so the countdown is actually in view.
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Countdown 3-2-1, then the run sequence grows to level 1 and the
     first playback begins. The run clock starts with the first flash. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? COUNTDOWN_STEP_MS_QUICK : COUNTDOWN_STEP_MS;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        runSeqRef.current = appendTile(runSeqRef.current, rngRef.current);
        startedAtRef.current = performance.now();
        beginLevel(START_LEVEL);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginLevel]);

  /* --------------------------- recall clicks ------------------------ */

  const handleTileClick = useCallback(
    (tile: number) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recall") return;
      const lv = levelRef.current;
      const seq = runSeqRef.current.slice(0, lv);
      if (seq.length === 0) return;

      const idx = clickIndexRef.current;
      const now = performance.now();
      const outcome = gradeClick(seq, idx, tile);

      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
      setFlash({ tile, kind: outcome.correct ? "correct" : "wrong", id: now });
      flashTimerRef.current = setTimeout(() => setFlash(null), FLASH_MS);

      if (outcome.correct) {
        if (outcome.complete) {
          attemptsRef.current.push({
            level: lv,
            sequence: seq.slice(),
            correctClicks: lv,
            cleared: true,
          });
          activeStateRef.current = "feedback";
          setActiveState("feedback");
          setStageRing("success");
          setLitTile(null);
          clearTimers();
          // Grow the run sequence by exactly one tile for the next level.
          runSeqRef.current = appendTile(runSeqRef.current, rngRef.current);
          const hold = quickRef.current ? SUCCESS_HOLD_MS_QUICK : SUCCESS_HOLD_MS;
          timersRef.current.push(
            setTimeout(() => beginLevel(lv + 1), hold)
          );
        } else {
          clickIndexRef.current = idx + 1;
          setPlaced(idx + 1);
        }
      } else {
        // Wrong click ends the run immediately: single life, no retry.
        attemptsRef.current.push({
          level: lv,
          sequence: seq.slice(),
          correctClicks: idx,
          cleared: false,
        });
        setRevealTile(seq[idx] ?? null);
        activeStateRef.current = "feedback";
        setActiveState("feedback");
        setStageRing("fail");
        clearTimers();
        const hold = quickRef.current ? FAIL_HOLD_MS_QUICK : FAIL_HOLD_MS;
        timersRef.current.push(setTimeout(() => finish(), hold));
      }
    },
    [beginLevel, clearTimers, finish]
  );

  /* Keyboard 1-9 maps straight onto tiles during recall. */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      const n = Number(e.key);
      if (!Number.isInteger(n) || n < 1 || n > 9) return;
      handleTileClick(n - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, handleTileClick]);

  /* ------------------------- derived data -------------------------- */

  const demoSeq = useMemo(() => {
    let seq: number[] = [];
    for (let i = 0; i < 4; i++) seq = appendTile(seq, mulberry32(20240607 + i * 7919));
    return seq;
  }, []);
  const previewLit = useMemo(() => new Set(demoSeq), [demoSeq]);

  const clearedCount = score?.ladder.filter((r) => r.cleared).length ?? 0;
  const accuracyBasis = score ? score.tilesShown : 0;
  const statusText =
    activeState === "playback"
      ? "Watch the sequence..."
      : activeState === "recall"
        ? "Your turn - repeat the full sequence"
        : stageRing === "success"
          ? "Perfect - one more tile joins the run"
          : "Wrong tile - run over";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="sequence-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="sm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <ListOrdered className="h-3.5 w-3.5" aria-hidden="true" />
                Growing sequences · one miss ends the run
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                One tile becomes many - how far can you follow?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                The run starts with a single flashing tile. Clear a level and
                one more tile joins the sequence, which replays from the very
                beginning every time. One wrong tap ends the run - your score
                is simply how many levels you cleared.
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-[240px] rounded-xl border border-border bg-muted/60 p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                How it grows
              </p>
              <div
                data-testid="sm-preview"
                aria-hidden="true"
                className="mx-auto mt-2 grid w-fit grid-cols-3 gap-1.5"
              >
                {Array.from({ length: 9 }).map((_, i) => (
                  <span
                    key={i}
                    className={[
                      "h-9 w-9 rounded-lg border sm:h-10 sm:w-10",
                      previewLit.has(i)
                        ? "border-emerald-600 bg-emerald-500"
                        : "border-border bg-secondary",
                    ].join(" ")}
                  />
                ))}
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                Level 4 shown - every level replays all tiles in order.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Eye className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Playback is fixed by the engine and identical for everyone - nothing can be rushed or slowed.
              </li>
              <li className="flex gap-2.5">
                <Layers className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The sequence is yours for the whole run: it never changes, it only grows by one tile per level.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                One wrong tap ends the run instantly and reveals the tile you should have pressed.
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Pure span scoring: no speed bonus, no luck - only levels cleared move your number.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="sm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <ListOrdered className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="sm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Level 1 · a single tile · eyes on the grid
            </p>
            <div className="mx-auto mt-5 w-fit" aria-hidden="true">
              <div className="grid grid-cols-3 gap-2">
                {Array.from({ length: 9 }).map((_, i) => (
                  <span key={i} className="h-10 w-10 rounded-lg border border-border bg-secondary sm:h-12 sm:w-12" />
                ))}
              </div>
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="sm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Level header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="sm-level"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Level {level}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {level} {level === 1 ? "tile" : "tiles"} to remember
                </p>
              </div>
              <span
                data-testid="sm-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {placed} / {level}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="sm-stage"
              data-phase={activeState}
              className={[
                "mx-auto mt-5 w-full max-w-[340px] rounded-2xl border-2 p-3 transition-[border-color,box-shadow] duration-300 sm:max-w-md sm:p-4",
                stageRing === "success"
                  ? "border-emerald-500 shadow-[0_0_32px_rgba(16,185,129,0.25)]"
                  : stageRing === "fail"
                    ? "border-red-400 shadow-[0_0_32px_rgba(239,68,68,0.18)]"
                    : "border-border",
              ].join(" ")}
            >
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                {Array.from({ length: 9 }).map((_, i) => {
                  const isLit = litTile === i;
                  const isRevealed =
                    revealTile === i && activeState === "feedback";
                  const lit = isLit || isRevealed;
                  const isFlashing = flash?.tile === i;
                  return (
                    <button
                      key={i}
                      type="button"
                      data-testid={`sm-tile-${i}`}
                      aria-label={`Tile ${i + 1}, row ${Math.floor(i / 3) + 1}, column ${(i % 3) + 1}`}
                      aria-pressed={lit}
                      data-lit={lit ? "true" : "false"}
                      data-flash={isFlashing ? flash!.kind : undefined}
                      disabled={activeState !== "recall"}
                      onClick={() => handleTileClick(i)}
                      className={[
                        "sm-tile aspect-square select-none rounded-2xl border-2 touch-manipulation transition-[background-color,border-color,transform,box-shadow] duration-150",
                        isFlashing && flash!.kind === "wrong"
                          ? "sm-flash-wrong scale-95 border-red-500 bg-red-500"
                          : isFlashing
                            ? "sm-flash-correct scale-95 border-emerald-600 bg-emerald-500"
                            : lit
                              ? "is-lit scale-[1.03] border-emerald-600 bg-emerald-500 shadow-[0_0_24px_rgba(16,185,129,0.5)]"
                              : "border-border bg-secondary hover:border-primary/60 active:scale-95 disabled:hover:border-border",
                      ].join(" ")}
                    />
                  );
                })}
              </div>
            </div>

            {/* Status */}
            <p
              data-testid="sm-status"
              aria-live="polite"
              className={[
                "mt-4 text-center text-sm font-semibold sm:text-base",
                stageRing === "fail"
                  ? "text-red-600"
                  : stageRing === "success"
                    ? "text-emerald-700"
                    : "text-muted-foreground",
              ].join(" ")}
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="sm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="sm-span"
                    data-final={score.span}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.span} duration={1.2} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Sequence span · levels cleared · adult mean {SPAN_MEAN}
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="sm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="sm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <ListOrdered className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="sm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Level ladder */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Your level ladder
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Green levels were cleared, red is where the run ended
                </p>
                <div
                  data-testid="sm-ladder"
                  className="mt-3 flex flex-wrap items-center justify-center gap-2"
                >
                  {score.ladder.map((run) => (
                    <span
                      key={run.level}
                      data-testid={`sm-ladder-level-${run.level}`}
                      data-status={run.cleared ? "cleared" : "failed"}
                      className={[
                        "inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm font-bold tabular-nums",
                        run.cleared
                          ? "border-emerald-600 bg-emerald-600 text-white"
                          : "border-red-200 bg-red-50 text-red-600",
                      ].join(" ")}
                    >
                      {run.cleared ? (
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : (
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      L{run.level}
                    </span>
                  ))}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="sm-stat-recalled" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.tilesCorrect}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">tiles recalled</p>
                </div>
                <div data-testid="sm-stat-shown" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.tilesShown}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">tiles played</p>
                </div>
                <div data-testid="sm-stat-deepest" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.deepest}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">deepest level</p>
                </div>
                <div data-testid="sm-stat-time" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {runSeconds !== null ? `${runSeconds.toFixed(1)}s` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">run time</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="sm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random sequence
                </button>
                <a
                  href="/test"
                  data-testid="sm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                Cleared {clearedCount} level{clearedCount === 1 ? "" : "s"} this run ·{" "}
                {accuracyBasis > 0
                  ? `${Math.round((score.tilesCorrect / accuracyBasis) * 100)}% of played tiles recalled`
                  : "no tiles recalled"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
