/* ------------------------------------------------------------------ */
/*  Stroop Test - pure scoring engine                                  */
/*  Paradigm: the classic Stroop color-word interference task (1935).  */
/*                                                                     */
/*  A color word (RED / GREEN / BLUE / YELLOW) is rendered one at a     */
/*  time, printed in an ink colour that may or may not match the word.  */
/*  The user must respond to the INK colour as fast as possible.        */
/*  50% of trials are congruent (word == ink), 50% incongruent          */
/*  (word != ink). Incongruent trials reliably cost extra time - the    */
/*  Stroop interference - the canonical lab measure of selective        */
/*  attention and cognitive inhibition.                                 */
/*                                                                     */
/*  Scoring: median RT on congruent vs incongruent (correct trials      */
/*  only, anticipations under 200ms excluded), interference =           */
/*  medianIncongruent - medianCongruent. A composite Stroop Index is    */
/*  anchored to an IQ-scale mean 100 / SD 15 from two population        */
/*  anchors: overall median RT (~750ms, SD 160) and interference        */
/*  (~120ms, SD 55) for click-based adult web users.                    */
/*                                                                     */
/*  Anti-gaming:                                                        */
/*   - Random mashing (or spamming one button) lands near 25% accuracy  */
/*     on a 4-option task, far below the 70% floor -> the session is    */
/*     flagged invalid and not scored.                                  */
/*   - The word/ink sequence is randomised every attempt, so memorising */
/*     a previous run does not carry over.                              */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic   */
/*  under an injected RNG so it can be unit-tested exhaustively.        */
/* ------------------------------------------------------------------ */

/** The four stimulus colours. Blue here is the stimulus itself, not UI theme. */
export type StroopColorId = "red" | "green" | "blue" | "yellow";

export type StroopColorDef = {
  id: StroopColorId;
  label: string;
  hex: string;
  /** Keyboard shortcut (uppercase display). */
  key: string;
};

export const STROOP_COLORS: readonly StroopColorDef[] = [
  { id: "red", label: "Red", hex: "#dc2626", key: "R" },
  { id: "green", label: "Green", hex: "#16a34a", key: "G" },
  { id: "blue", label: "Blue", hex: "#2563eb", key: "B" },
  { id: "yellow", label: "Yellow", hex: "#ca8a04", key: "Y" },
] as const;

/** Fixed lookup by colour id (used for labels, hex and keyboard mapping). */
export const COLOR_BY_ID: Record<StroopColorId, StroopColorDef> = {
  red: STROOP_COLORS[0]!,
  green: STROOP_COLORS[1]!,
  blue: STROOP_COLORS[2]!,
  yellow: STROOP_COLORS[3]!,
};

const COLOR_IDS: readonly StroopColorId[] = STROOP_COLORS.map((c) => c.id);

/** Full session length (classic short-form Stroop block). */
export const TRIAL_COUNT = 60;

/** Shortened session used by automated flow tests via ?quick=1. */
export const QUICK_TRIAL_COUNT = 12;

/** Responses faster than this are anticipations and leave RT statistics. */
export const MIN_VALID_RT_MS = 200;

/** Accuracy floor - below this the session is flagged as too random. */
export const ACCURACY_FLOOR = 0.7;

/** Population anchors (adult casual web users, click/mouse responses). */
export const RT_POP_MEAN = 750; // overall median RT in ms
export const RT_POP_SD = 160;
export const INT_POP_MEAN = 120; // Stroop interference in ms
export const INT_POP_SD = 55;

/** Composite weights: 45% speed, 55% interference control. */
export const RT_WEIGHT = 0.45;
export const INT_WEIGHT = 0.55;
/** Normaliser so two independent unit-variance components yield IQ SD 15. */
export const Z_NORM = Math.sqrt(RT_WEIGHT * RT_WEIGHT + INT_WEIGHT * INT_WEIGHT);

export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** A presented stimulus: the word text and the ink colour it is printed in. */
export type StroopStimulus = {
  word: StroopColorId;
  ink: StroopColorId;
  congruent: boolean;
};

export type StroopTrial = {
  word: StroopColorId;
  ink: StroopColorId;
  congruent: boolean;
  response: StroopColorId;
  correct: boolean;
  /** Reaction time in ms from stimulus onset to response. */
  rtMs: number;
};

export type StroopGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SessionScore = {
  totalResponses: number;
  correct: number;
  errors: number;
  /** correct / totalResponses over ALL responses (anticipations included). */
  accuracy: number;
  /** Responses faster than MIN_VALID_RT_MS - excluded from RT statistics. */
  anticipationCount: number;
  /** How many congruent / incongruent stimuli were presented. */
  congruentTrials: number;
  incongruentTrials: number;
  /** Median RT of correct congruent trials with rt >= MIN_VALID_RT_MS. */
  medianCongruentMs: number | null;
  /** Median RT of correct incongruent trials with rt >= MIN_VALID_RT_MS. */
  medianIncongruentMs: number | null;
  /** medianIncongruent - medianCongruent (soft-clamped). Null if unknown. */
  interferenceMs: number | null;
  /** Overall median RT of correct trials with rt >= MIN_VALID_RT_MS. */
  medianRtMs: number | null;
  /** Composite Stroop Index (IQ-anchored, mean 100 / SD 15). 0 if invalid. */
  stroopIndex: number;
  /** Population percentile 1..99. 0 if invalid. */
  percentile: number;
  grade: StroopGrade;
  valid: boolean;
  invalidReason: string | null;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Stimulus generation                                                */
/* ------------------------------------------------------------------ */

/**
 * Next ink colour. Never allows three identical inks in a row: once the
 * last two inks match, the third draw is restricted to the other three
 * colours, so a broken-looking 3x streak is impossible by construction.
 */
function nextInk(
  rng: () => number,
  lastTwo: readonly [StroopColorId | null, StroopColorId | null]
): StroopColorId {
  const [twoAgo, oneAgo] = lastTwo;
  if (twoAgo !== null && oneAgo !== null && twoAgo === oneAgo) {
    const others = COLOR_IDS.filter((id) => id !== oneAgo);
    return others[Math.floor(rng() * others.length)]!;
  }
  return COLOR_IDS[Math.floor(rng() * COLOR_IDS.length)]!;
}

/** A colour guaranteed to differ from `not` (for incongruent words). */
function differentColor(rng: () => number, not: StroopColorId): StroopColorId {
  const others = COLOR_IDS.filter((id) => id !== not);
  return others[Math.floor(rng() * others.length)]!;
}

/**
 * Build the stimulus sequence for a session.
 *
 * - Exactly half congruent / half incongruent (for even counts; odd
 *   counts round the congruent half down), then shuffled into a random
 *   order so the trial type cannot be predicted.
 * - Congruent: word == ink.
 * - Incongruent: word != ink, always.
 * - The ink never repeats three times in a row.
 */
export function buildStimuli(rng: () => number, count: number = TRIAL_COUNT): StroopStimulus[] {
  const congruentCount = Math.floor(count / 2);
  const flags: boolean[] = [
    ...Array<boolean>(congruentCount).fill(true),
    ...Array<boolean>(count - congruentCount).fill(false),
  ];
  const order = shuffle(flags, rng);
  const stimuli: StroopStimulus[] = [];
  let lastTwoInk: [StroopColorId | null, StroopColorId | null] = [null, null];
  for (const congruent of order) {
    const ink = nextInk(rng, lastTwoInk);
    const word = congruent ? ink : differentColor(rng, ink);
    lastTwoInk = [lastTwoInk[1], ink];
    stimuli.push({ word, ink, congruent });
  }
  return stimuli;
}

/* ------------------------------------------------------------------ */
/*  Trial recording                                                    */
/* ------------------------------------------------------------------ */

/** Single trial step: evaluate a response against the stimulus ink. */
export function recordTrial(
  stimulus: StroopStimulus,
  response: StroopColorId,
  rtMs: number
): StroopTrial {
  return {
    word: stimulus.word,
    ink: stimulus.ink,
    congruent: stimulus.congruent,
    response,
    correct: response === stimulus.ink,
    rtMs,
  };
}

/* ------------------------------------------------------------------ */
/*  Statistics                                                         */
/* ------------------------------------------------------------------ */

/** Median of a numeric sample (mean of the two middle values if even). */
export function median(xs: readonly number[]): number | null {
  if (xs.length === 0) return null;
  const sorted = xs.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1
    ? sorted[mid]!
    : (sorted[mid - 1]! + sorted[mid]!) / 2;
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map (overall median RT, interference) to the composite Stroop Index.
 *
 *   rtZ  = (RT_POP_MEAN - medianRt) / RT_POP_SD   -> positive when faster
 *   intZ = (INT_POP_MEAN - interference) / INT_POP_SD -> positive when
 *           interference is smaller than the population's
 *   z    = (0.45 * rtZ + 0.55 * intZ) / Z_NORM
 *   IQ   = round(100 + 15 * z), clamped to [55, 145]
 *
 * Faster overall responding and a smaller congruency effect both raise
 * the index; the normaliser keeps the composite on a clean SD-15 scale
 * when the two components are independent unit-variance traits.
 * Inputs are soft-clamped first so absurd sessions cannot explode.
 */
export function stroopIndexFrom(medianRtMs: number, interferenceMs: number): number {
  const rt = Math.min(3000, Math.max(200, medianRtMs));
  const interference = Math.min(450, Math.max(-150, interferenceMs));
  const rtZ = (RT_POP_MEAN - rt) / RT_POP_SD;
  const intZ = (INT_POP_MEAN - interference) / INT_POP_SD;
  const z = (RT_WEIGHT * rtZ + INT_WEIGHT * intZ) / Z_NORM;
  const index = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, index));
}

/** Stroop Index -> population percentile (1..99), normal model SD 15. */
export function indexToPercentile(index: number): number {
  const pct = normalCdf(index, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the Stroop Index. */
export function gradeForIndex(index: number): StroopGrade {
  if (index < 85) {
    return {
      label: "Deliberate",
      blurb:
        "The word keeps grabbing your attention before the ink - the most common pattern there is. Accuracy first; inhibition typically sharpens quickly with practice.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (index < 100) {
    return {
      label: "Average",
      blurb:
        "A typical balance of reading and ink-naming - most people land in this band on their first run.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (index < 115) {
    return {
      label: "Focused",
      blurb:
        "You keep your attention on the ink despite what the word says - selective attention working as intended.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (index < 130) {
    return {
      label: "Highly focused",
      blurb:
        "Strong cognitive control - interference barely dents your response speed.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb:
      "Elite interference control - the top few percent of inhibitory performance.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a full session.
 *
 * Validity rules (anti-gaming):
 *  - zero responses -> invalid
 *  - accuracy < 70% -> invalid (random mashing or button spamming lands
 *    near the 25% chance level on four options)
 *  - if no valid reaction times survive (all anticipations) the session
 *    cannot produce interference -> invalid
 *
 * RT statistics use CORRECT trials only, with rt >= 200ms. If a
 * condition has no correct valid-RT samples (mathematically impossible
 * above the accuracy floor, but guarded anyway) the median falls back
 * to all valid-RT trials in that condition.
 */
export function scoreSession(trials: readonly StroopTrial[]): SessionScore {
  const totalResponses = trials.length;
  const correctTrials = trials.filter((t) => t.correct);
  const correct = correctTrials.length;
  const errors = totalResponses - correct;
  const accuracy = totalResponses > 0 ? correct / totalResponses : 0;
  const anticipationCount = trials.filter((t) => t.rtMs < MIN_VALID_RT_MS).length;
  const congruentTrials = trials.filter((t) => t.congruent).length;
  const incongruentTrials = totalResponses - congruentTrials;

  if (totalResponses === 0) {
    return invalidScore(trials, "No responses were recorded.");
  }
  if (accuracy < ACCURACY_FLOOR) {
    return invalidScore(
      trials,
      `Accuracy was ${Math.round(accuracy * 100)}% - below the ${Math.round(
        ACCURACY_FLOOR * 100
      )}% floor, so the responses look too random to score. Answer the INK colour of each word carefully - random tapping or mashing one button cannot pass.`
    );
  }

  const validRt = (t: StroopTrial) => t.rtMs >= MIN_VALID_RT_MS;

  const congCorrectRts = correctTrials.filter((t) => t.congruent && validRt(t)).map((t) => t.rtMs);
  const incongCorrectRts = correctTrials.filter((t) => !t.congruent && validRt(t)).map((t) => t.rtMs);
  const congAllRts = trials.filter((t) => t.congruent && validRt(t)).map((t) => t.rtMs);
  const incongAllRts = trials.filter((t) => !t.congruent && validRt(t)).map((t) => t.rtMs);
  const allCorrectRts = correctTrials.filter(validRt).map((t) => t.rtMs);
  const allValidRts = trials.filter(validRt).map((t) => t.rtMs);

  const medianCongruentMs = median(congCorrectRts) ?? median(congAllRts);
  const medianIncongruentMs = median(incongCorrectRts) ?? median(incongAllRts);
  const medianRtMs = median(allCorrectRts) ?? median(allValidRts);

  if (medianCongruentMs === null || medianIncongruentMs === null || medianRtMs === null) {
    return invalidScore(
      trials,
      "Too few valid reaction times were recorded to compute interference. Respond calmly - faster-than-human taps under 200ms are excluded as anticipations."
    );
  }

  const interferenceMs = medianIncongruentMs - medianCongruentMs;
  const stroopIndex = stroopIndexFrom(medianRtMs, interferenceMs);

  return {
    totalResponses,
    correct,
    errors,
    accuracy,
    anticipationCount,
    congruentTrials,
    incongruentTrials,
    medianCongruentMs,
    medianIncongruentMs,
    interferenceMs,
    medianRtMs,
    stroopIndex,
    percentile: indexToPercentile(stroopIndex),
    grade: gradeForIndex(stroopIndex),
    valid: true,
    invalidReason: null,
  };
}

function invalidScore(trials: readonly StroopTrial[], reason: string): SessionScore {
  const totalResponses = trials.length;
  const correct = trials.filter((t) => t.correct).length;
  const accuracy = totalResponses > 0 ? correct / totalResponses : 0;
  const congruentTrials = trials.filter((t) => t.congruent).length;
  return {
    totalResponses,
    correct,
    errors: totalResponses - correct,
    accuracy,
    anticipationCount: trials.filter((t) => t.rtMs < MIN_VALID_RT_MS).length,
    congruentTrials,
    incongruentTrials: totalResponses - congruentTrials,
    medianCongruentMs: null,
    medianIncongruentMs: null,
    interferenceMs: null,
    medianRtMs: null,
    stroopIndex: 0,
    percentile: 0,
    grade: {
      label: "Not scored",
      blurb: reason,
      className: "bg-amber-50 text-amber-800 border-amber-200",
    },
    valid: false,
    invalidReason: reason,
  };
}
