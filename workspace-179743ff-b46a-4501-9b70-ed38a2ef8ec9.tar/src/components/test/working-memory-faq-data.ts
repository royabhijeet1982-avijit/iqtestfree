/* ------------------------------------------------------------------ */
/*  Working Memory Test - FAQ (single source)                          */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type WmFaq = { question: string; answer: string };

export const WORKING_MEMORY_FAQS: WmFaq[] = [
  {
    question: "What is a working memory test?",
    answer:
      "A working memory test measures how well you can hold information in mind while also doing something with it. This test uses letter-number sequencing, the same paradigm that sits inside the working memory index of the WAIS: a stream of mixed digits and letters flashes by, and you recall the digits in ascending order first and the letters in alphabetical order second. Because the answer order is different from the display order, passive memory is not enough - your mind has to keep every element alive and actively reorganise it, which is exactly the juggling act working memory is named for.",
  },
  {
    question: "How is this different from the digit span test?",
    answer:
      "Forward digit span mostly taps passive storage: you repeat what you saw in the order you saw it. Letter-number sequencing adds a second job - before you respond, you must mentally re-sort the material into two streams (numbers up, letters A-to-Z). That reorganisation is handled by the central executive, the control system of working memory, so two people with the same storage span can score very differently here. If digit span is the size of your desk, this test measures how well you can keep using the desk while rearranging everything on it.",
  },
  {
    question: "Why numbers ascending and letters alphabetical?",
    answer:
      "Any fixed target order would do, but ascending numbers and alphabetical letters are the convention used in clinical batteries because both orders are over-learned - every adult knows them by heart. That matters for fairness: nobody has to invent their own sorting rule, so the score reflects juggling capacity rather than cleverness at choosing a strategy. It also makes feedback precise - your result shows whether the number stream, the letter stream, or both slipped.",
  },
  {
    question: "How does my score map to the IQ scale?",
    answer:
      "Your span - the longest sequence you fully reorganised - gets a half-step of partial credit when your final level sorted one of the two streams, or when you clear the whole ladder. That effective span is compared against an adult population model calibrated by simulation so the average adult lands at 100, and it is mapped onto the standard IQ scale where 100 is the population average and 15 points is one standard deviation. A percentile estimate sits alongside, and the calibration is checked against a 1000-person simulated population that averages 100.",
  },
  {
    question: "Can I improve my working memory?",
    answer:
      "Strategy helps immediately: encode the numbers as a sorted set as they appear, rehearse the first letters as a word-like chunk, and let the whole stream finish before you start rearranging. Over weeks, training on demanding span and updating tasks can lift measured performance further, and sleep, stress and practice with the format all move the number. Because every sequence here is drawn fresh at random - and a failed attempt is always followed by a different sequence at the same level - retaking the test measures the skill, not a memorised answer sheet.",
  },
  {
    question: "Are retakes fair? Why do my numbers change?",
    answer:
      "Every attempt uses a newly randomised sequence, so no run can be memorised, and the staircase follows the same rules every time: two attempts per level, one fully sorted recall advances you, two misses end the run. Spans are naturally noisy - attention, sleep and one lucky or unlucky element can move the result by a level. Take two or three runs and read the range rather than one number; the ladder view under your result shows every attempt so you can see exactly where each run broke.",
  },
];
