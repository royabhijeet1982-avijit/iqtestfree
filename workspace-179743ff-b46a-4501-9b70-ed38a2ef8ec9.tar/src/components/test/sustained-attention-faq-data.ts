/* ------------------------------------------------------------------ */
/*  Sustained Attention Test - FAQ (single source)                     */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type SaFaq = { question: string; answer: string };

export const SA_FAQS: SaFaq[] = [
  {
    question: "What is a sustained attention test and what does it measure?",
    answer:
      "This is the Sustained Attention to Response Task (SART), a famous vigilance measure introduced by Robertson and colleagues in 1997. Digits 1-9 stream past about a second apart and you respond to every single one - except the rare digit 3, where you must withhold. The task is deliberately monotonous, because that is exactly what it measures: how long your attention holds when nothing interesting is happening, and how badly it drifts once boredom sets in. It is the attentional equivalent of a long highway drive.",
  },
  {
    question: "Why is there no right-or-wrong feedback during the run?",
    answer:
      "Feedback is precisely what classic SART removes. If you saw a red flash after every mistake, your attention would snap back each time and the test would measure your reaction to corrections, not your endurance. Keeping you blind means the errors - pressing on a 3, missing an ordinary digit - accumulate naturally, painting an honest picture of how your attention behaves over four unbroken minutes.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Three ingredients make a weighted composite: your commission rate (how often you pressed on the digit 3, weighted 65%), your omission rate (how often you missed an ordinary digit, weighted 15%), and your RT consistency (how steady your tapping rhythm stayed, measured as coefficient of variation, weighted 20%). Each component is a z-score against adult anchors - commission mean 45%, omission 3%, rhythm variability 18% - clamped to +/-3, with hard participation gates: missing most digits or pressing on nearly every 3 floors the index at 55, because neither is real vigilance.",
  },
  {
    question: "Why does the 3 appear exactly 20 times?",
    answer:
      "The 180-digit stream is built from twenty shuffles of the digits 1-9, so every run contains exactly one 3 per shuffle - twenty no-go digits and 160 ordinary digits, no matter what. That exact balance is what makes scores comparable across people and across your own retakes: nobody gets a luckier stream than anyone else, and the maddening unpredictability of WHEN the 3 arrives is the same challenge for everyone.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "The average adult presses on roughly 45% of the 3s - yes, almost half - while missing only about 3% of ordinary digits and keeping a fairly steady rhythm. Perfect withholding across all 20 rare digits with zero misses maps to the index ceiling of 145. Watch the block-by-block chips on your results card: slips usually cluster late in the run, which is the classic signature of vigilance decrement rather than a general attention problem.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every run reshuffles the stream from a fresh seed, so the timing of the 3s is never the same twice. A small practice effect is normal: the second run usually improves because the respond-to-everything-but-3 rhythm is familiar. For tracking real change, run it two or three times in a sitting and compare weekly rather than hourly - sleep, caffeine and time of day all move vigilance by a few points, which is ordinary variation rather than genuine change.",
  },
];
