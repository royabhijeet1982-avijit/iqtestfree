/* ------------------------------------------------------------------ */
/*  Sequence Memory Test - pure scoring engine                         */
/*  Paradigm: the classic "growing sequence" game on a 3x3 grid. A     */
/*  run owns ONE random sequence that starts at a single tile and      */
/*  grows by exactly one tile per cleared level; every level replays   */
/*  the WHOLE sequence from the start, then adds the new tile at the   */
/*  end. One wrong click ends the run - there are no retries and no    */
/*  second lives, so the score (your sequence span) is fully honest.   */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - visual-memory (Corsi): NEW pattern every level, 2 lives,        */
/*     speed-weighted composite. Here: ONE growing sequence, 1 life,   */
/*     pure span - nothing but memory moves the number.                */
/*   - digit-span: verbal-numeric stream. Here: spatial grid.          */
/*   - working-memory: hold + mentally re-sort two streams. Here:      */
/*     pure forward retention, zero manipulation.                      */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Input is locked during playback by the UI; the engine owns the  */
/*     timing, so nothing a user does can speed up or slow down flash. */
/*   - A wrong click ends the run immediately: mashing produces floor  */
/*     scores, never high ones.                                        */
/*   - Every run reseeds the RNG, so retakes deal a fresh sequence.    */
/*   - Immediate triples are forbidden (two same tiles in a row may    */
/*     occur - that is a genuine memory event - but never three).       */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.        */
/* ------------------------------------------------------------------ */

/** Number of tiles on the board (3x3 grid, indices 0..8). */
export const GRID_TILES = 9;

/** First level of a run (and therefore first sequence length). */
export const START_LEVEL = 1;

/** Playback timing at the start level (engine-owned, UI cannot change). */
export const BASE_ON_MS = 620;
export const BASE_OFF_MS = 200;

/** On-time shrinks by this many ms per level above START_LEVEL... */
export const SPEED_STEP_MS = 22;
/** ...but never below this floor. */
export const MIN_ON_MS = 320;

/** Shortened playback used by automated flow tests via ?quick=1. */
export const QUICK_ON_MS = 220;
export const QUICK_OFF_MS = 80;

/** Span recorded when a run ends without clearing even level 1. */
export const SPAN_FLOOR = 0;

/** Population anchor for this task (growing-sequence span, adults). */
export const SPAN_MEAN = 7.4;
export const SPAN_SD = 1.5;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** Outcome of a single graded recall click. */
export type ClickOutcome = {
  /** Whether the clicked tile matched the expected tile. */
  correct: boolean;
  /** True when this click was also the final tile (level cleared). */
  complete: boolean;
};

/** Record of one level attempt (the failed level is always last). */
export type LevelAttempt = {
  /** Sequence length == level number. */
  level: number;
  /** The full prefix that was played back for this level. */
  sequence: number[];
  /** Correct clicks landed before the run ended. */
  correctClicks: number;
  /** Whether the full sequence was reproduced. */
  cleared: boolean;
};

export type LadderRun = { level: number; cleared: boolean };

export type MemoryGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SequenceMemoryScore = {
  /** Highest level cleared (SPAN_FLOOR when nothing was cleared). */
  span: number;
  /** Deepest level attempted (the failed level, or span when perfect). */
  deepest: number;
  /** Correct tile clicks across the whole run. */
  tilesCorrect: number;
  /** Total tiles played back across all levels (1+2+...+deepest). */
  tilesShown: number;
  /** Levels from START_LEVEL up to deepest, with status. */
  ladder: LadderRun[];
  /** IQ-scale span score (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: MemoryGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */
/*  The growing sequence                                               */
/* ------------------------------------------------------------------ */

/**
 * Append one tile to a run prefix. Doubles are allowed (a repeated tile
 * is a legitimate memory event) but triples are never generated: if the
 * last two tiles are identical, the new tile must differ from them.
 */
export function appendTile(prefix: readonly number[], rng: () => number): number[] {
  const next: number[] = prefix.slice();
  const n = prefix.length;
  const lastTwoEqual = n >= 2 && prefix[n - 1] === prefix[n - 2];
  let tile = Math.floor(rng() * GRID_TILES);
  if (lastTwoEqual) {
    const banned = prefix[n - 1]!;
    let guard = 0;
    while (tile === banned && guard < 50) {
      tile = Math.floor(rng() * GRID_TILES);
      guard++;
    }
    if (tile === banned) {
      // Deterministic fallback: any of the other 8 tiles.
      tile = (banned + 1 + Math.floor(rng() * (GRID_TILES - 1))) % GRID_TILES;
    }
  }
  next.push(tile);
  return next;
}

/**
 * Build a full run sequence of `targetLength` tiles by repeated
 * appendTile calls - the prefix-stable property guarantees that the
 * sequence shown at level N is exactly the first N tiles of this array.
 */
export function buildRunSequence(targetLength: number, rng: () => number): number[] {
  let seq: number[] = [];
  for (let i = 0; i < Math.max(1, Math.round(targetLength)); i++) {
    seq = appendTile(seq, rng);
  }
  return seq;
}

/* ------------------------------------------------------------------ */
/*  Playback timing                                                    */
/* ------------------------------------------------------------------ */

/**
 * Fixed playback speed for a level: 620 ms lit at level 1, easing down
 * 22 ms per level to a 320 ms floor. Off-gap is constant. The engine
 * owns this timing completely - the UI cannot alter it. Quick mode
 * (automated tests only) uses shortened timings via quickFor().
 */
export function speedForLevel(level: number): { onMs: number; offMs: number } {
  const onMs = Math.max(
    MIN_ON_MS,
    BASE_ON_MS - (Math.max(START_LEVEL, level) - START_LEVEL) * SPEED_STEP_MS
  );
  return { onMs, offMs: BASE_OFF_MS };
}

/** Quick-mode playback for automated flow tests. */
export function quickFor(): { onMs: number; offMs: number } {
  return { onMs: QUICK_ON_MS, offMs: QUICK_OFF_MS };
}

/** Playback timing for a level, honoring quick mode. */
export function timingForLevel(level: number, quick: boolean): { onMs: number; offMs: number } {
  return quick ? quickFor() : speedForLevel(level);
}

/* ------------------------------------------------------------------ */
/*  Grading                                                            */
/* ------------------------------------------------------------------ */

/**
 * Grade one recall click. `index` is the position the user is on
 * (0-based). A wrong click is always correct:false / complete:false -
 * the caller ends the run; the engine never lets a wrong click count
 * toward the score.
 */
export function gradeClick(
  sequence: readonly number[],
  index: number,
  tile: number
): ClickOutcome {
  const expected = sequence[index];
  const correct = expected !== undefined && tile === expected;
  return { correct, complete: correct && index === sequence.length - 1 };
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map a sequence span onto the IQ scale (mean 100, SD 15). Pure span:
 * there is deliberately no speed or luck component - the only thing
 * that moves this number is how many levels you actually cleared.
 */
export function spanIq(span: number): number {
  const z = (span - SPAN_MEAN) / SPAN_SD;
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): MemoryGrade {
  if (iq < 85) {
    return {
      label: "Building",
      blurb: "Your sequence span is still warming up - one more run usually settles the rhythm and adds a level or two.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - a dependable grip on growing sequences.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - you track each new tile without letting earlier ones slip.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier span - the kind of retention that shines in music, code and games.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite sequence span - rarer than one person in fifty.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Run scoring                                                        */
/* ------------------------------------------------------------------ */

/**
 * Score a complete run (one attempt per level, single life).
 *
 *  - span = highest level cleared, floored at SPAN_FLOOR when the run
 *    died on level 1 (an honest "below one tile" outcome).
 *  - deepest = the level where the run ended (the failed level).
 *  - tilesShown = 1+2+...+deepest (the staircase replays everything).
 *  - tilesCorrect = every correct recall click, including clicks inside
 *    the final failed level - effort is recorded even in defeat.
 */
export function scoreRun(attempts: readonly LevelAttempt[]): SequenceMemoryScore {
  let maxCleared = 0;
  let maxReached = 0;
  let tilesCorrect = 0;
  const clearedLevels = new Set<number>();

  for (const attempt of attempts) {
    maxReached = Math.max(maxReached, attempt.level);
    if (attempt.cleared) {
      maxCleared = Math.max(maxCleared, attempt.level);
      clearedLevels.add(attempt.level);
    }
    tilesCorrect += attempt.correctClicks;
  }

  const span = maxCleared > 0 ? maxCleared : SPAN_FLOOR;
  const deepest = Math.max(maxReached, span);

  const ladder: LadderRun[] = [];
  for (let level = START_LEVEL; level <= deepest; level++) {
    ladder.push({ level, cleared: clearedLevels.has(level) });
  }

  const tilesShown = (deepest * (deepest + 1)) / 2;
  const iq = spanIq(span);

  return {
    span,
    deepest,
    tilesCorrect,
    tilesShown,
    ladder,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
