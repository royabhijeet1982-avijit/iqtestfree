/* ------------------------------------------------------------------ */
/*  Matrix Reasoning Test - pure engine (no React, no DOM)             */
/*  Paradigm: Raven-style progressive matrices, the classic marker     */
/*  task for fluid intelligence (Gf) and the model for the WAIS        */
/*  Matrix Reasoning subtest.                                          */
/*                                                                     */
/*  Every item is a 3x3 grid (2x2 for the easiest warm-ups) in which   */
/*  the last cell is missing. The user picks the completing tile       */
/*  from 6 options (1 correct + 5 plausible distractors that share     */
/*  features with the correct answer).                                 */
/*                                                                     */
/*  Rules the generator draws from (5 scored categories):              */
/*    quantity      - element count or size progresses across a row    */
/*    shape         - shape alternates across the row (A,B,A)          */
/*    rotation      - rotation advances by a fixed delta per step      */
/*    fill          - shading alternates (A,B,A) or follows XOR        */
/*    superposition - cell3 = cell1 combined with cell2                */
/*                                                                     */
/*  Difficulty ramp: items 0-5 are 2x2 single-rule warm-ups, items     */
/*  6-13 are 3x3 single-rule matrices, items 14-19 combine TWO rules   */
/*  (one across the columns, one down the rows).                       */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - Every session generates fresh random matrices from a new seed,  */
/*     so retakes measure reasoning, not memory.                       */
/*   - Distractors are single-feature mutations of the correct tile,   */
/*     so pattern matching alone is not enough.                        */
/*   - Per-item response times are recorded; a median under 2s flags   */
/*     the session as rushed (honesty panel, score kept but caveated). */
/*   - Chance performance (1-in-6 guessing) lands near 3/20, which     */
/*     maps far below the population mean on the IQ scale.             */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.      */
/* ------------------------------------------------------------------ */

/** Items in a full session. */
export const ITEM_COUNT = 20;

/** Shortened session used by automated flow tests via ?quick=1. */
export const QUICK_ITEM_COUNT = 8;

/** IQ-scale clamp (same 55-145 band used across BrainMetrics). */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/** Median answer time under this many ms flags the session as rushed. */
export const RUSHED_MEDIAN_MS = 2000;

/** At least this many answered items are required before rushing applies. */
export const MIN_RUSHED_N = 6;

/**
 * Population calibration for raw correct answers (0-20 items).
 * Derived from a 500-user simulation with normally distributed ability
 * (see scripts/verify-matrix-reasoning-core.ts) so that the resulting
 * IQ-scale scores average 100 with SD 15.
 */
export const POPULATION_RAW_MEAN = 10.37;
export const POPULATION_RAW_SD = 3.22;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export const RULE_ORDER = ["quantity", "shape", "rotation", "fill", "superposition"] as const;
export type RuleId = (typeof RULE_ORDER)[number];

export const RULE_LABELS: Record<RuleId, string> = {
  quantity: "Quantity & size",
  shape: "Shape logic",
  rotation: "Rotation",
  fill: "Shading logic",
  superposition: "Superposition",
};

export const SHAPES = [
  "circle",
  "square",
  "triangle",
  "diamond",
  "star",
  "hexagon",
  "pentagon",
  "cross",
] as const;
export type ShapeKind = (typeof SHAPES)[number];

export const FILLS = ["solid", "tinted", "outline", "dashed"] as const;
export type FillKind = (typeof FILLS)[number];

const ROT_DELTAS = [30, 45, 90] as const;

/** One drawable element inside a matrix cell. */
export type ElementSpec = {
  shape: ShapeKind;
  /** Degrees, always normalised to [0, 360). */
  rotation: number;
  fill: FillKind;
  /** Relative size multiplier (size-progression rule). */
  scale: number;
  /** 1-4 copies drawn in a row (quantity rule). */
  count: number;
};

/** A matrix cell: one primary element plus an optional corner element. */
export type Cell = { elements: ElementSpec[] };

export type FillMode = "alt" | "xor";

/** Declared generation recipe - lets the verifier re-solve every item. */
export type ItemSpec =
  | { kind: "diag"; rule: RuleId; variant?: "count" | "scale" }
  | { kind: "across"; rule: RuleId; fillMode?: FillMode; variant?: "count" | "scale" }
  | { kind: "rotXY" }
  | { kind: "super" }
  | { kind: "dual"; across: "rotation" | "quantity"; down: "shape" | "fill"; variant?: "count" | "scale" };

export type MatrixItem = {
  /** Position within the session (0-based). */
  index: number;
  /** Grid dimension: 2 -> 2x2 warm-up, 3 -> full 3x3 matrix. */
  size: 2 | 3;
  /** size*size cells; the LAST one is always null (the missing tile). */
  cells: (Cell | null)[];
  /** 6 answer tiles; options[correctIndex] completes the matrix. */
  options: Cell[];
  correctIndex: number;
  /** Declared rule categories (1 for single-rule items, 2 for duals). */
  rules: RuleId[];
  /** Primary category used for the per-rule accuracy breakdown. */
  category: RuleId;
  /** 0 = 2x2 warm-up, 1 = 3x3 single rule, 2 = 3x3 two rules. */
  tier: 0 | 1 | 2;
  spec: ItemSpec;
};

export type RuleAccuracy = {
  category: RuleId;
  label: string;
  correct: number;
  total: number;
};

export type MatrixGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type MatrixScore = {
  total: number;
  answered: number;
  correct: number;
  /** Alias of `correct` - raw score on the 0..20 scale. */
  raw: number;
  /** IQ-scale score (mean 100, SD 15), clamped to 55..145. */
  iq: number;
  /** Population percentile, clamped to 1..99. */
  percentile: number;
  grade: MatrixGrade;
  medianRtMs: number;
  meanRtMs: number;
  /** Answers quicker than RUSHED_MEDIAN_MS. */
  fastCount: number;
  /** True when the median answer time suggests under-engagement. */
  rushed: boolean;
  ruleAccuracy: RuleAccuracy[];
  valid: boolean;
  invalidReason: string | null;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Small numeric + structural helpers                                 */
/* ------------------------------------------------------------------ */

function round2(x: number): number {
  return Math.round(x * 100) / 100;
}

function mod360(x: number): number {
  return ((x % 360) + 360) % 360;
}

function clampCount(n: number): number {
  return Math.min(4, Math.max(1, n));
}

/** Canonical string form of an element (used for dedupe and equality). */
export function elementKey(e: ElementSpec): string {
  return `${e.shape}|${e.rotation}|${e.fill}|${e.scale.toFixed(2)}|${e.count}`;
}

/** Canonical string form of a cell. */
export function cellKey(c: Cell): string {
  return c.elements.map(elementKey).join(";");
}

function cloneEl(e: ElementSpec): ElementSpec {
  return { ...e };
}

function cloneCell(c: Cell): Cell {
  return { elements: c.elements.map(cloneEl) };
}

function primaryOf(c: Cell): ElementSpec {
  return c.elements[0] as ElementSpec;
}

/** Patch the primary element, leaving any corner element untouched. */
function withPrimary(c: Cell, patch: Partial<ElementSpec>): Cell {
  return {
    elements: c.elements.map((e, i) => (i === 0 ? { ...e, ...patch } : e)),
  };
}

/** Set union over element lists, preserving a's order then b's extras. */
function unionElements(a: readonly ElementSpec[], b: readonly ElementSpec[]): ElementSpec[] {
  const out = a.map(cloneEl);
  for (const e of b) {
    if (!out.some((x) => elementKey(x) === elementKey(e))) out.push(cloneEl(e));
  }
  return out;
}

function toggleFill(f: FillKind): FillKind {
  switch (f) {
    case "solid":
      return "outline";
    case "outline":
      return "solid";
    case "tinted":
      return "dashed";
    case "dashed":
      return "tinted";
  }
}

/** XOR shading: equal fills -> outline (absent), different -> solid. */
function xorFill(a: FillKind, b: FillKind): FillKind {
  return a === b ? "outline" : "solid";
}

function nextShape(s: ShapeKind, steps: number): ShapeKind {
  const idx = SHAPES.indexOf(s);
  return SHAPES[(idx + steps + SHAPES.length * 8) % SHAPES.length] as ShapeKind;
}

/* ------------------------------------------------------------------ */
/*  Rule application (used by the solver AND the generator)            */
/* ------------------------------------------------------------------ */

/**
 * Predict the 3rd cell of a 3x3 row from its first two cells, given the
 * declared rule. Works for every single-rule kind ("across", and as the
 * across-half of "dual" items). Numeric rules infer the step from the
 * observed pair; shape/fill alternation repeats the first cell.
 */
function predictNextInRow(rule: RuleId, fillMode: FillMode, c1: Cell, c2: Cell): Cell {
  if (rule === "shape") {
    // Alternation A,B,A -> the third cell repeats the first.
    return cloneCell(c1);
  }
  if (rule === "fill") {
    if (fillMode === "xor") {
      const f1 = primaryOf(c1).fill;
      const f2 = primaryOf(c2).fill;
      return withPrimary(cloneCell(c2), { fill: xorFill(f1, f2) });
    }
    return cloneCell(c1);
  }
  const p = primaryOf(c1);
  const q = primaryOf(c2);
  if (rule === "quantity") {
    if (q.count !== p.count) {
      return withPrimary(cloneCell(c2), { count: clampCount(q.count + (q.count - p.count)) });
    }
    return withPrimary(cloneCell(c2), { scale: round2(q.scale + (q.scale - p.scale)) });
  }
  if (rule === "rotation") {
    return withPrimary(cloneCell(c2), { rotation: mod360(q.rotation + (q.rotation - p.rotation)) });
  }
  // superposition rows are solved directly in solveItem, never here.
  return cloneCell(c2);
}

/**
 * One diagonal step for 2x2 warm-up items: infer the delta from the
 * c0 -> c1 transition and apply it to `target`.
 */
function advanceDiagStep(rule: RuleId, prev: Cell, cur: Cell, target: Cell): Cell {
  if (rule === "shape") {
    return withPrimary(cloneCell(target), {
      shape: nextShape(primaryOf(target).shape, 1),
    });
  }
  if (rule === "fill") {
    return withPrimary(cloneCell(target), { fill: toggleFill(primaryOf(target).fill) });
  }
  const p = primaryOf(prev);
  const q = primaryOf(cur);
  const t = primaryOf(target);
  if (q.count !== p.count) {
    return withPrimary(cloneCell(target), { count: clampCount(t.count + (q.count - p.count)) });
  }
  if (Math.abs(q.scale - p.scale) > 1e-9) {
    return withPrimary(cloneCell(target), { scale: round2(t.scale + (q.scale - p.scale)) });
  }
  return withPrimary(cloneCell(target), { rotation: mod360(t.rotation + (q.rotation - p.rotation)) });
}

/**
 * Re-derive the correct answer from an item's GIVEN cells and declared
 * spec, ignoring the stored correctIndex. The verifier uses this to
 * prove every matrix is genuinely solvable per its declared rule.
 */
export function solveItem(item: MatrixItem): Cell | null {
  const cells = item.cells;
  const spec = item.spec;
  if (spec.kind === "diag") {
    const c0 = cells[0];
    const c1 = cells[1];
    const c2 = cells[2];
    if (!c0 || !c1 || !c2) return null;
    // Grid is [A, adv(A), adv(A), ?] -> answer = adv(c2) == adv^2(c0).
    return advanceDiagStep(spec.rule, c0, c1, c2);
  }
  if (spec.kind === "across") {
    const c6 = cells[6];
    const c7 = cells[7];
    if (!c6 || !c7) return null;
    return predictNextInRow(spec.rule, spec.fillMode ?? "alt", c6, c7);
  }
  if (spec.kind === "rotXY") {
    const c6 = cells[6];
    const c7 = cells[7];
    if (!c6 || !c7) return null;
    const delta = primaryOf(c7).rotation - primaryOf(c6).rotation;
    return withPrimary(cloneCell(c7), { rotation: mod360(primaryOf(c7).rotation + delta) });
  }
  if (spec.kind === "super") {
    const c6 = cells[6];
    const c7 = cells[7];
    if (!c6 || !c7) return null;
    return { elements: unionElements(c6.elements, c7.elements) };
  }
  // dual: across rule on the numeric attribute + down rule on shape/fill.
  const c5 = cells[5];
  const c6 = cells[6];
  const c7 = cells[7];
  if (!c5 || !c6 || !c7) return null;
  const base = predictNextInRow(spec.across, "alt", c6, c7);
  if (spec.down === "shape") {
    return withPrimary(cloneCell(base), {
      shape: nextShape(primaryOf(c5).shape, 1),
    });
  }
  return withPrimary(cloneCell(base), { fill: toggleFill(primaryOf(c5).fill) });
}

/* ------------------------------------------------------------------ */
/*  Item plan                                                          */
/* ------------------------------------------------------------------ */

type PlanEntry =
  | { tier: 0; kind: "diag"; rule: RuleId; variant?: "count" | "scale" }
  | { tier: 1; kind: "across"; rule: RuleId; variant?: "count" | "scale" }
  | { tier: 1; kind: "rotXY" }
  | { tier: 1; kind: "super" }
  | { tier: 2; kind: "dual"; across: "rotation" | "quantity"; down: "shape" | "fill"; variant?: "count" | "scale" };

/**
 * Fixed 20-item plan. Tiers never go backwards (difficulty ramp), every
 * scored category appears at least twice over a full session, and the
 * first 8 items (quick mode) already cover all five categories.
 */
const PLAN: PlanEntry[] = [
  { tier: 0, kind: "diag", rule: "quantity", variant: "count" },
  { tier: 0, kind: "diag", rule: "shape" },
  { tier: 0, kind: "diag", rule: "rotation" },
  { tier: 0, kind: "diag", rule: "fill" },
  { tier: 0, kind: "diag", rule: "shape" },
  { tier: 0, kind: "diag", rule: "quantity", variant: "scale" },
  { tier: 1, kind: "super" },
  { tier: 1, kind: "across", rule: "quantity", variant: "count" },
  { tier: 1, kind: "across", rule: "fill" },
  { tier: 1, kind: "across", rule: "shape" },
  { tier: 1, kind: "rotXY" },
  { tier: 1, kind: "super" },
  { tier: 1, kind: "across", rule: "fill" },
  { tier: 1, kind: "across", rule: "rotation" },
  { tier: 2, kind: "dual", across: "rotation", down: "shape" },
  { tier: 2, kind: "dual", across: "quantity", down: "fill", variant: "count" },
  { tier: 2, kind: "dual", across: "quantity", down: "shape", variant: "scale" },
  { tier: 2, kind: "dual", across: "rotation", down: "fill" },
  { tier: 2, kind: "dual", across: "quantity", down: "shape", variant: "count" },
  { tier: 2, kind: "dual", across: "rotation", down: "fill" },
];

/* ------------------------------------------------------------------ */
/*  Grid generators                                                    */
/* ------------------------------------------------------------------ */

function pickShape(rng: () => number): ShapeKind {
  return SHAPES[Math.floor(rng() * SHAPES.length)] as ShapeKind;
}

function pickFill(rng: () => number): FillKind {
  return FILLS[Math.floor(rng() * FILLS.length)] as FillKind;
}

function makeBaseFactory(shape: ShapeKind, fill: FillKind) {
  return (patch: Partial<ElementSpec>): Cell =>
    cell([{ shape, fill, rotation: 0, scale: 1, count: 1, ...patch }]);
}

function cell(elements: ElementSpec[]): Cell {
  return { elements };
}

/** Alternation fill pair: never both from {solid, outline}, so an alt
 *  grid can never be confused with an xor grid. */
function pickAltFillPair(rng: () => number): [FillKind, FillKind] {
  const a = pickFill(rng);
  const allowed = FILLS.filter(
    (f) => f !== a && (a === "tinted" || a === "dashed" || f === "tinted" || f === "dashed")
  );
  const b = allowed[Math.floor(rng() * allowed.length)] as FillKind;
  return [a, b];
}

function buildGrid(
  spec: ItemSpec,
  rng: () => number
): { grid: Cell[]; rules: RuleId[]; category: RuleId } {
  if (spec.kind === "diag") {
    const base = makeBaseFactory(pickShape(rng), pickFill(rng));
    if (spec.rule === "quantity") {
      if (spec.variant === "scale") {
        const s = rng() < 0.5 ? 0.6 : 0.85;
        return {
          grid: [
            base({ scale: s }),
            base({ scale: round2(s + 0.25) }),
            base({ scale: round2(s + 0.25) }),
            base({ scale: round2(s + 0.5) }),
          ],
          rules: ["quantity"],
          category: "quantity",
        };
      }
      const k = 1 + Math.floor(rng() * 2);
      return {
        grid: [
          base({ count: k }),
          base({ count: k + 1 }),
          base({ count: k + 1 }),
          base({ count: k + 2 }),
        ],
        rules: ["quantity"],
        category: "quantity",
      };
    }
    if (spec.rule === "shape") {
      const a = Math.floor(rng() * (SHAPES.length - 2));
      return {
        grid: [
          base({ shape: SHAPES[a] as ShapeKind }),
          base({ shape: SHAPES[a + 1] as ShapeKind }),
          base({ shape: SHAPES[a + 1] as ShapeKind }),
          base({ shape: SHAPES[a + 2] as ShapeKind }),
        ],
        rules: ["shape"],
        category: "shape",
      };
    }
    if (spec.rule === "rotation") {
      const delta = ROT_DELTAS[Math.floor(rng() * ROT_DELTAS.length)] as number;
      const b = Math.floor(rng() * (331 - 2 * delta));
      return {
        grid: [
          base({ rotation: b }),
          base({ rotation: b + delta }),
          base({ rotation: b + delta }),
          base({ rotation: b + 2 * delta }),
        ],
        rules: ["rotation"],
        category: "rotation",
      };
    }
    // fill (toggle design on 2x2)
    const x = pickFill(rng);
    const t = toggleFill(x);
    return {
      grid: [base({ fill: x }), base({ fill: t }), base({ fill: t }), base({ fill: x })],
      rules: ["fill"],
      category: "fill",
    };
  }

  if (spec.kind === "across") {
    const base = makeBaseFactory(pickShape(rng), pickFill(rng));
    let triple: [Partial<ElementSpec>, Partial<ElementSpec>, Partial<ElementSpec>];
    if (spec.rule === "quantity") {
      if (spec.variant === "scale" || (spec.variant === undefined && rng() < 0.4)) {
        const s = rng() < 0.5 ? 0.6 : 0.85;
        triple = [{ scale: s }, { scale: round2(s + 0.25) }, { scale: round2(s + 0.5) }];
      } else {
        const k = 1 + Math.floor(rng() * 2);
        triple = [{ count: k }, { count: k + 1 }, { count: k + 2 }];
      }
    } else if (spec.rule === "rotation") {
      const delta = ROT_DELTAS[Math.floor(rng() * ROT_DELTAS.length)] as number;
      const b = Math.floor(rng() * (331 - 2 * delta));
      triple = [{ rotation: b }, { rotation: b + delta }, { rotation: b + 2 * delta }];
    } else if (spec.rule === "shape") {
      const a = Math.floor(rng() * SHAPES.length);
      const b = (a + 1 + Math.floor(rng() * 7)) % SHAPES.length;
      triple = [
        { shape: SHAPES[a] as ShapeKind },
        { shape: SHAPES[b] as ShapeKind },
        { shape: SHAPES[a] as ShapeKind },
      ];
    } else {
      // fill: alternation or xor
      if (spec.fillMode === "xor") {
        const a = rng() < 0.5 ? "solid" : "outline";
        const b = a === "solid" ? "outline" : "solid";
        triple = [
          { fill: a as FillKind },
          { fill: b as FillKind },
          { fill: xorFill(a as FillKind, b as FillKind) },
        ];
      } else {
        const [a, b] = pickAltFillPair(rng);
        triple = [{ fill: a }, { fill: b }, { fill: a }];
      }
    }
    const row = triple.map((patch) => base(patch));
    return { grid: [...row, ...row, ...row], rules: [spec.rule], category: spec.rule };
  }

  if (spec.kind === "rotXY") {
    const base = makeBaseFactory(pickShape(rng), pickFill(rng));
    const delta = rng() < 0.5 ? 30 : 45;
    const b = Math.floor(rng() * (331 - 4 * delta));
    const grid: Cell[] = [];
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        grid.push(base({ rotation: b + (r + c) * delta }));
      }
    }
    return { grid, rules: ["rotation"], category: "rotation" };
  }

  if (spec.kind === "super") {
    const a0 = Math.floor(rng() * SHAPES.length);
    const gap = 1 + Math.floor(rng() * 7);
    const grid: Cell[] = [];
    for (let r = 0; r < 3; r++) {
      const shapeA = SHAPES[(a0 + r) % SHAPES.length] as ShapeKind;
      const shapeB = SHAPES[(a0 + r + gap) % SHAPES.length] as ShapeKind;
      const elA: ElementSpec = { shape: shapeA, rotation: 0, fill: "solid", scale: 1, count: 1 };
      const elB: ElementSpec = { shape: shapeB, rotation: 0, fill: "outline", scale: 1, count: 1 };
      grid.push(cell([elA]), cell([elB]), cell([elA, elB]));
    }
    return { grid, rules: ["superposition"], category: "superposition" };
  }

  // dual: one rule across the columns + one rule down the rows.
  const downShapeBase = Math.floor(rng() * (SHAPES.length - 2));
  const downFillPair: [FillKind, FillKind] = rng() < 0.5 ? ["solid", "outline"] : ["tinted", "dashed"];
  const constShape = pickShape(rng);
  const constFill = pickFill(rng);

  let acrossOf: (c: number) => Partial<ElementSpec>;
  if (spec.across === "rotation") {
    const delta = ROT_DELTAS[Math.floor(rng() * ROT_DELTAS.length)] as number;
    const b = Math.floor(rng() * (331 - 2 * delta));
    acrossOf = (c) => ({ rotation: b + c * delta });
  } else if (spec.variant === "scale" || (spec.variant === undefined && rng() < 0.4)) {
    const s = rng() < 0.5 ? 0.6 : 0.85;
    acrossOf = (c) => ({ scale: round2(s + 0.25 * c) });
  } else {
    const k = 1 + Math.floor(rng() * 2);
    acrossOf = (c) => ({ count: k + c });
  }

  const grid: Cell[] = [];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const patch: Partial<ElementSpec> = { ...acrossOf(c) };
      if (spec.down === "shape") {
        patch.shape = SHAPES[downShapeBase + r] as ShapeKind;
        patch.fill = constFill;
      } else {
        patch.shape = constShape;
        patch.fill = downFillPair[r % 2];
      }
      grid.push(cell([{ shape: constShape, fill: constFill, rotation: 0, scale: 1, count: 1, ...patch }]));
    }
  }
  const downRule: RuleId = spec.down === "shape" ? "shape" : "fill";
  return { grid, rules: [spec.across, downRule], category: spec.across };
}

/* ------------------------------------------------------------------ */
/*  Distractor construction                                            */
/* ------------------------------------------------------------------ */

/**
 * Build 5 plausible distractors: single-feature mutations of the
 * correct tile, prioritised toward the item's declared rule, plus
 * classic "existing tile" lures. Falls back to random double
 * mutations (deterministic under rng) if the priority list runs dry.
 */
function makeDistractors(
  correct: Cell,
  grid: readonly Cell[],
  spec: ItemSpec,
  rng: () => number
): Cell[] {
  const correctKey = cellKey(correct);
  const p = primaryOf(correct);
  const chosen: Cell[] = [];
  const seen = new Set<string>([correctKey]);

  const consider = (c: Cell | null): void => {
    if (!c) return;
    const k = cellKey(c);
    if (seen.has(k)) return;
    seen.add(k);
    chosen.push(c);
  };

  const mutCount = (d: number): Cell | null => {
    const n = clampCount(p.count + d);
    return n === p.count ? null : withPrimary(cloneCell(correct), { count: n });
  };
  const mutScale = (d: number): Cell | null => {
    const s = round2(Math.min(1.6, Math.max(0.35, p.scale + d)));
    return Math.abs(s - p.scale) < 1e-9 ? null : withPrimary(cloneCell(correct), { scale: s });
  };
  const mutRot = (d: number): Cell | null => {
    const r = mod360(p.rotation + d);
    return r === p.rotation ? null : withPrimary(cloneCell(correct), { rotation: r });
  };
  const mutFill = (steps: number): Cell | null => {
    const f = FILLS[(FILLS.indexOf(p.fill) + steps + FILLS.length * 4) % FILLS.length] as FillKind;
    return f === p.fill ? null : withPrimary(cloneCell(correct), { fill: f });
  };
  const mutShape = (steps: number): Cell | null => {
    const s = nextShape(p.shape, steps);
    return s === p.shape ? null : withPrimary(cloneCell(correct), { shape: s });
  };
  const mutDrop = (): Cell | null =>
    correct.elements.length > 1 ? cell([cloneEl(correct.elements[0] as ElementSpec)]) : null;
  const mutCornerShape = (): Cell | null =>
    correct.elements.length === 2
      ? cell([
          cloneEl(correct.elements[0] as ElementSpec),
          { ...cloneEl(correct.elements[1] as ElementSpec), shape: nextShape(correct.elements[1]!.shape, 1) },
        ])
      : null;
  const mutCornerRot = (): Cell | null =>
    correct.elements.length === 2
      ? cell([
          cloneEl(correct.elements[0] as ElementSpec),
          { ...cloneEl(correct.elements[1] as ElementSpec), rotation: mod360(correct.elements[1]!.rotation + 45) },
        ])
      : null;
  const gridCell = (): Cell | null => {
    const given = grid.slice(0, grid.length - 1);
    const idxs = shuffle(given.map((_, i) => i), rng);
    for (const i of idxs) {
      const g = given[i] as Cell;
      if (!seen.has(cellKey(g))) return cloneCell(g);
    }
    return null;
  };

  const category: RuleId =
    spec.kind === "super"
      ? "superposition"
      : spec.kind === "dual"
        ? (spec.across as RuleId)
        : spec.kind === "rotXY"
          ? "rotation"
          : spec.rule;

  const cands: Array<() => Cell | null> = [];
  if (spec.kind === "super") {
    cands.push(mutDrop, mutCornerShape, mutCornerRot, () => mutFill(1), () => mutShape(1), gridCell);
  } else if (category === "quantity") {
    cands.push(
      () => mutCount(1),
      () => mutCount(-1),
      () => mutScale(0.25),
      () => mutScale(-0.25),
      gridCell,
      () => mutFill(1),
      () => mutShape(1)
    );
  } else if (category === "rotation") {
    cands.push(
      () => mutRot(45),
      () => mutRot(-45),
      () => mutRot(90),
      () => mutFill(1),
      gridCell,
      () => mutShape(1),
      () => mutCount(1)
    );
  } else if (category === "shape") {
    cands.push(
      () => mutShape(1),
      () => mutShape(2),
      () => mutShape(-1),
      () => mutFill(1),
      gridCell,
      () => mutRot(45),
      () => mutCount(1)
    );
  } else if (category === "fill") {
    cands.push(
      () => mutFill(1),
      () => mutFill(2),
      () => mutFill(-1),
      () => mutShape(1),
      gridCell,
      () => mutRot(45),
      () => mutCount(1)
    );
  } else {
    cands.push(
      () => mutScale(0.25),
      () => mutScale(-0.25),
      () => mutCount(1),
      () => mutCount(-1),
      gridCell,
      () => mutFill(1)
    );
  }

  for (const fn of cands) {
    if (chosen.length >= 5) break;
    consider(fn());
  }

  // Filler: random double mutations until we have exactly 5.
  let guard = 0;
  while (chosen.length < 5 && guard < 80) {
    guard += 1;
    let c = cloneCell(correct);
    const mutators: Array<(x: Cell) => Cell | null> = [
      (x) => withPrimary(x, { shape: nextShape(primaryOf(x).shape, 1 + Math.floor(rng() * 7)) }),
      (x) => withPrimary(x, { fill: pickFill(rng) }),
      (x) =>
        withPrimary(x, {
          rotation: mod360(primaryOf(x).rotation + [30, 45, 90, 135][Math.floor(rng() * 4)]!),
        }),
      (x) =>
        withPrimary(x, { count: clampCount(primaryOf(x).count + (rng() < 0.5 ? -1 : 1)) }),
      (x) =>
        withPrimary(x, {
          scale: round2(
            Math.min(1.6, Math.max(0.35, primaryOf(x).scale + (rng() < 0.5 ? -0.25 : 0.25)))
          ),
        }),
      (x) => mutFill(1),
      (x) => mutShape(1),
    ];
    const m1 = mutators[Math.floor(rng() * mutators.length)]!;
    const m2 = mutators[Math.floor(rng() * mutators.length)]!;
    const a = m1(c);
    if (a) c = a;
    const b = m2(c);
    if (b) c = b;
    consider(c);
  }

  // Absolute fallback (never expected): walk the shape list.
  for (let s = 1; chosen.length < 5 && s < SHAPES.length; s++) {
    consider(withPrimary(cloneCell(correct), { shape: nextShape(p.shape, s) }));
  }

  return chosen.slice(0, 5);
}

/* ------------------------------------------------------------------ */
/*  Item + session generation                                          */
/* ------------------------------------------------------------------ */

function buildItem(index: number, plan: PlanEntry, rng: () => number): MatrixItem {
  const spec: ItemSpec = plan as ItemSpec;
  const { grid, rules, category } = buildGrid(spec, rng);
  const size: 2 | 3 = plan.tier === 0 ? 2 : 3;
  const correct = grid[grid.length - 1] as Cell;
  const distractors = makeDistractors(correct, grid, spec, rng);
  const options = shuffle([correct, ...distractors], rng);
  const correctKey = cellKey(correct);
  const correctIndex = options.findIndex((o) => cellKey(o) === correctKey);
  const cells: (Cell | null)[] = [
    ...grid.slice(0, grid.length - 1).map((c) => cloneCell(c)),
    null,
  ];
  return {
    index,
    size,
    cells,
    options,
    correctIndex,
    rules,
    category,
    tier: plan.tier,
    spec,
  };
}

/**
 * Generate a full matrix-reasoning session from a seed. Every seed
 * produces a different set of grids, patterns and option orders, so
 * retakes always present fresh material.
 */
export function generateItems(seed: number, count: number = ITEM_COUNT): MatrixItem[] {
  const rng = mulberry32(seed);
  return PLAN.slice(0, Math.min(count, PLAN.length)).map((plan, i) => buildItem(i, plan, rng));
}

/** Grade a user's option choice for an item. */
export function gradeAnswer(item: MatrixItem, answerIndex: number | null): boolean {
  return answerIndex !== null && answerIndex === item.correctIndex;
}

/** Stable content fingerprint (cells + options) for anti-repetition checks. */
export function itemFingerprint(item: MatrixItem): string {
  const payload = JSON.stringify({
    size: item.size,
    cells: item.cells.map((c) => (c ? cellKey(c) : "?")),
    options: item.options.map(cellKey),
  });
  let h = 5381;
  for (let i = 0; i < payload.length; i++) {
    h = ((h << 5) + h + payload.charCodeAt(i)) | 0;
  }
  return (h >>> 0).toString(36);
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map raw correct answers (0..20) onto the IQ scale (mean 100, SD 15)
 * using the calibrated population parameters, clamped to 55..145.
 */
export function rawToIq(raw: number): number {
  const z = (raw - POPULATION_RAW_MEAN) / POPULATION_RAW_SD;
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ-scale score -> population percentile (1..99), normal model. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ-scale score. */
export function gradeForIq(iq: number): MatrixGrade {
  if (iq < 85) {
    return {
      label: "Developing",
      blurb: "You spotted some of the easier patterns - slower, deliberate work on a retake usually lifts this noticeably.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most people - you extracted the common rules and avoided the obvious traps.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - you combined several features per item and rarely fell for single-feature lures.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier abstract reasoning - the two-rule matrices barely slowed you down.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite pattern deduction - the kind of performance seen in the top few percent of test takers.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/** Median of a numeric sample (average of the two middles when even). */
export function medianOf(xs: readonly number[]): number {
  if (xs.length === 0) return 0;
  const sorted = xs.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid] as number;
  return ((sorted[mid - 1] as number) + (sorted[mid] as number)) / 2;
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a full session.
 *
 * answers[i] = chosen option index (or null if the item was skipped -
 * the UI never allows this, but the API stays defensive).
 * rtsMs[i]   = response time for item i in ms (or null).
 *
 * Validity: a session with zero answered items is not scored. Sessions
 * with a median answer time under RUSHED_MEDIAN_MS are still scored
 * but flagged as rushed so results can carry an honesty panel.
 */
export function scoreMatrixSession(
  items: readonly MatrixItem[],
  answers: readonly (number | null)[],
  rtsMs: readonly (number | null)[]
): MatrixScore {
  const total = items.length;
  const answeredIdx: number[] = [];
  for (let i = 0; i < total; i++) {
    const a = answers[i];
    if (typeof a === "number" && a >= 0) answeredIdx.push(i);
  }
  const answered = answeredIdx.length;
  const correct = answeredIdx.filter((i) =>
    gradeAnswer(items[i] as MatrixItem, answers[i] as number)
  ).length;

  const rts = answeredIdx
    .map((i) => rtsMs[i])
    .filter((r): r is number => typeof r === "number" && Number.isFinite(r) && r >= 0);
  const medianRtMs = medianOf(rts);
  const meanRtMs = rts.length > 0 ? rts.reduce((a, b) => a + b, 0) / rts.length : 0;
  const fastCount = rts.filter((r) => r < RUSHED_MEDIAN_MS).length;
  const rushed = answered >= MIN_RUSHED_N && rts.length >= MIN_RUSHED_N && medianRtMs < RUSHED_MEDIAN_MS;

  const ruleAccuracy: RuleAccuracy[] = RULE_ORDER.map((cat) => {
    const idxs = items
      .map((it, i) => (it.category === cat ? i : -1))
      .filter((i) => i >= 0);
    const c = idxs.filter((i) => gradeAnswer(items[i] as MatrixItem, answers[i] ?? null)).length;
    return { category: cat, label: RULE_LABELS[cat], correct: c, total: idxs.length };
  });

  if (answered === 0) {
    return {
      total,
      answered: 0,
      correct: 0,
      raw: 0,
      iq: 0,
      percentile: 0,
      grade: {
        label: "Not scored",
        blurb: "No answers were recorded, so there is nothing to score.",
        className: "bg-amber-50 text-amber-800 border-amber-200",
      },
      medianRtMs: 0,
      meanRtMs: 0,
      fastCount: 0,
      rushed: false,
      ruleAccuracy: ruleAccuracy.map((r) => ({ ...r, correct: 0 })),
      valid: false,
      invalidReason: "No answers were recorded.",
    };
  }

  const iq = rawToIq(correct);
  return {
    total,
    answered,
    correct,
    raw: correct,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
    medianRtMs,
    meanRtMs,
    fastCount,
    rushed,
    ruleAccuracy,
    valid: true,
    invalidReason: null,
  };
}
