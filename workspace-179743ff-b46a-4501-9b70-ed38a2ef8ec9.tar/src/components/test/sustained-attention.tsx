"use client";

/* ------------------------------------------------------------------ */
/*  Sustained Attention Test - interactive UI                          */
/*  SART (Robertson et al., 1997): digits 1-9 stream past (250ms on,   */
/*  900ms gap, engine-owned); respond to EVERY digit, WITHHOLD on the  */
/*  rare 3. Six blocks of thirty, no live feedback (classic SART),     */
/*  short breaks between blocks. Scoring in sustained-attention-core.  */
/*                                                                     */
/*  Testing hook: /test/sustained-attention?quick=1 shortens every     */
/*  engine timing (digit on + gap + breaks) so automated flow tests    */
/*  run fast. Quick mode is a timing change only - never a scoring     */
/*  one.                                                               */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (digit | gap | break) plus data-trial / data-block; the digit      */
/*  element carries data-digit ONLY while shown (cleared in the gap -  */
/*  anti-cheat); result numbers expose data-final so CountUp frames    */
/*  cannot fool assertions. First press per trial wins; key auto-      */
/*  repeat is guarded.                                                 */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  Brain,
  Hand,
  RotateCcw,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  BLOCK_COUNT,
  BREAK_MS,
  BREAK_MS_QUICK,
  DIGIT_ON_MS,
  DIGIT_ON_MS_QUICK,
  ISI_MS,
  ISI_MS_QUICK,
  NO_GO_DIGIT,
  TRIALS_PER_BLOCK,
  TOTAL_TRIALS,
  buildSaSession,
  scoreSession,
  type SaResponse,
  type SaScore,
  type SaSession,
} from "./sustained-attention-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "digit" | "gap" | "break";

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("sa-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function SustainedAttentionTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("digit");
  const [currentDigit, setCurrentDigit] = useState<number | null>(null);
  const [blockIndex, setBlockIndex] = useState(0);
  const [trialInBlock, setTrialInBlock] = useState(0);
  const [globalTrial, setGlobalTrial] = useState(0);
  const [score, setScore] = useState<SaScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);
  /** Mirrors sessionRef for RENDER-time reads (refs are off-limits in render). */
  const [session, setSession] = useState<SaSession | null>(null);

  const sessionRef = useRef<SaSession | null>(null);
  const responsesRef = useRef<SaResponse[]>([]);
  const respondedTrialsRef = useRef<Set<number>>(new Set());
  const shownAtRef = useRef(0);
  const trialRef = useRef(0);
  const activeStateRef = useRef<ActiveState>("digit");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  /** Self-recursion hook: scheduleTrial re-schedules itself via this ref. */
  const scheduleTrialRef = useRef<(trial: number) => void>(() => {});

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed =
      startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const result = scoreSession(responsesRef.current, sessionRef.current);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  /** Schedule one trial: digit on -> gap -> next digit / break / finish. */
  const scheduleTrial = useCallback(
    (trial: number) => {
      const sess = sessionRef.current;
      if (!sess) return;
      const flat = sess.blocks.flat();
      if (trial >= flat.length) {
        finish();
        return;
      }
      const block = Math.floor(trial / TRIALS_PER_BLOCK);
      const digit = flat[trial]!;
      const onMs = quickRef.current ? DIGIT_ON_MS_QUICK : DIGIT_ON_MS;
      const isiMs = quickRef.current ? ISI_MS_QUICK : ISI_MS;
      const breakMs = quickRef.current ? BREAK_MS_QUICK : BREAK_MS;

      trialRef.current = trial;
      const isBlockStart = trial % TRIALS_PER_BLOCK === 0;

      const showDigit = () => {
        // Enter the active render (the countdown screen hands over here).
        setPhase("active");
        // Block break just ended (or very first trial).
        if (isBlockStart) {
          setBlockIndex(block);
          setTrialInBlock(0);
        } else {
          setTrialInBlock(trial % TRIALS_PER_BLOCK);
        }
        setGlobalTrial(trial);
        activeStateRef.current = "digit";
        setActiveState("digit");
        setCurrentDigit(digit);
        shownAtRef.current = performance.now();
        timersRef.current.push(
          setTimeout(() => {
            // Gap: clear the digit (anti-cheat hook removed here).
            setCurrentDigit(null);
            activeStateRef.current = "gap";
            setActiveState("gap");
          }, onMs)
        );
        const nextTrial = trial + 1;
        const nextIsBlockStart =
          nextTrial < flat.length && nextTrial % TRIALS_PER_BLOCK === 0;
        timersRef.current.push(
          setTimeout(() => {
            if (nextTrial >= flat.length) {
              finish();
            } else if (nextIsBlockStart) {
              activeStateRef.current = "break";
              setActiveState("break");
              timersRef.current.push(
                setTimeout(() => scheduleTrialRef.current(nextTrial), breakMs)
              );
            } else {
              scheduleTrialRef.current(nextTrial);
            }
          }, onMs + isiMs)
        );
      };

      // NOTE: for block starts (trial > 0) the break has ALREADY been
      // displayed by the previous trial's tail transition - land
      // straight into the digit here.
      showDigit();
    },
    [finish]
  );

  /* Keep the self-recursion ref pointed at the latest callback. */
  useEffect(() => {
    scheduleTrialRef.current = scheduleTrial;
  }, [scheduleTrial]);

  const start = useCallback(() => {
    clearTimers();
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const built = buildSaSession(seed);
    sessionRef.current = built;
    setSession(built);
    responsesRef.current = [];
    respondedTrialsRef.current = new Set();
    finishedRef.current = false;
    trialRef.current = 0;
    setBlockIndex(0);
    setTrialInBlock(0);
    setGlobalTrial(0);
    setScore(null);
    setRunSeconds(null);
    setCurrentDigit(null);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Global 3-2-1 before block 1. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? 180 : 750;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        startedAtRef.current = performance.now();
        scheduleTrial(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, scheduleTrial]);

  /* --------------------------- interaction -------------------------- */

  const respond = useCallback(() => {
    if (finishedRef.current) return;
    if (activeStateRef.current !== "digit" && activeStateRef.current !== "gap") return;
    const trial = trialRef.current;
    // First press per trial wins; auto-repeat guarded by the Set.
    if (respondedTrialsRef.current.has(trial)) return;
    respondedTrialsRef.current.add(trial);
    const rt = shownAtRef.current > 0 ? performance.now() - shownAtRef.current : null;
    responsesRef.current.push({ trial, pressed: true, rtMs: rt });
  }, []);

  /* Keyboard: SPACE responds (auto-repeat guarded). */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Space" && e.key !== " ") return;
      e.preventDefault();
      if (e.repeat) return; // key auto-repeat guard
      respond();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, respond]);

  /* ------------------------- derived data -------------------------- */

  const statusText =
    activeState === "digit"
      ? currentDigit === NO_GO_DIGIT
        ? ""
        : ""
      : activeState === "break"
        ? `Block ${blockIndex + 1} of ${BLOCK_COUNT} done - breathe`
        : "";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="sa-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="sa-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Activity className="h-3.5 w-3.5" aria-hidden="true" />
                Sustained attention · SART · about 4 minutes
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Respond to every digit. Except one.
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Digits 1-9 stream past, roughly a second apart. Tap for each
                one - but when the rare 3 appears, do nothing. Six blocks,
                180 digits, zero feedback. Drift is the enemy.
              </p>
            </div>

            {/* Static stream preview */}
            <div
              data-testid="sa-preview"
              aria-hidden="true"
              className="mx-auto mt-6 max-w-[340px] rounded-xl border border-border bg-muted/60 p-4"
            >
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                The stream looks like this
              </p>
              <div className="mt-3 flex items-center justify-center gap-2">
                {["7", "2", "9", "3", "5"].map((d, i) => (
                  <span
                    key={i}
                    className={[
                      "flex h-12 w-10 items-center justify-center rounded-lg border text-2xl font-black tabular-nums",
                      d === "3"
                        ? "border-red-300 bg-red-50 text-red-500"
                        : i === 0
                          ? "border-emerald-500 bg-emerald-500/10 text-foreground"
                          : "border-border bg-background text-muted-foreground/60",
                    ].join(" ")}
                  >
                    {d}
                  </span>
                ))}
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                tap · tap · tap · <span className="font-semibold text-red-500">withhold</span> · tap
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Hand className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Press SPACE (or the GO button) for every digit - the rhythm is the point, even when it feels mindless.
              </li>
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The 3 appears exactly 20 times, scattered unpredictably. Withholding on it is the whole test.
              </li>
              <li className="flex gap-2.5">
                <Activity className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                No right-or-wrong flashes during the run - classic SART keeps you blind, so boredom can genuinely bite.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Mashing everything or nothing both floor the score; only steady, selective responding climbs.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="sa-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Activity className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh stream every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="sa-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Block 1 · 30 digits · hands ready
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="sa-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Block header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="sa-block-chip"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Block {blockIndex + 1}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {activeState === "break" ? "short break" : "tap every digit · withhold on 3"}
                </p>
              </div>
              <span
                data-testid="sa-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {Math.min(globalTrial + 1, TOTAL_TRIALS)} / {TOTAL_TRIALS}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="sa-stage"
              data-phase={activeState}
              data-trial={globalTrial}
              data-block={blockIndex}
              className={[
                "mx-auto mt-5 flex w-full max-w-[420px] min-h-44 items-center justify-center rounded-2xl border-2 transition-[border-color,box-shadow] duration-150",
                activeState === "break"
                  ? "border-emerald-400/60 bg-emerald-50/40"
                  : "border-border",
              ].join(" ")}
            >
              {activeState === "break" ? (
                <div className="py-8 text-center">
                  <p className="text-2xl font-black text-emerald-700">Break</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Next block incoming - keep the rhythm in mind
                  </p>
                </div>
              ) : (
                <div className="flex min-h-28 items-center justify-center">
                  {/* No AnimatePresence here on purpose: an exit animation
                      would keep data-digit in the DOM after the gap starts
                      (frozen props) - the machine hook must clear the instant
                      the gap begins. */}
                  {currentDigit !== null ? (
                    <motion.span
                      key={`${globalTrial}-${currentDigit}`}
                      data-testid="sa-digit"
                      data-digit={currentDigit}
                      initial={{ opacity: 0, scale: 0.92 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.08 }}
                      className="text-7xl font-black tabular-nums text-foreground sm:text-8xl"
                    >
                      {currentDigit}
                    </motion.span>
                  ) : (
                    <motion.span
                      key={`gap-${globalTrial}`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 0.15 }}
                      transition={{ duration: 0.08 }}
                      className="select-none text-7xl font-black text-muted-foreground"
                    >
                      ·
                    </motion.span>
                  )}
                </div>
              )}
            </div>

            {/* GO button */}
            {activeState !== "break" && (
              <div className="mx-auto mt-5 w-full max-w-[420px]">
                <button
                  type="button"
                  data-testid="sa-go"
                  aria-keyshortcuts="Space"
                  onClick={respond}
                  className="w-full touch-manipulation rounded-2xl bg-primary py-5 text-lg font-bold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:bg-emerald-700 active:translate-y-0.5 sm:text-xl"
                >
                  GO
                  <kbd className="ml-2 hidden rounded border border-white/40 px-2 py-0.5 text-xs font-bold sm:inline">SPACE</kbd>
                </button>
              </div>
            )}

            {/* Status */}
            <p
              data-testid="sa-status"
              aria-live="polite"
              className="mt-4 min-h-5 text-center text-sm font-semibold text-muted-foreground sm:text-base"
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="sa-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="sa-iq"
                    data-final={score.iq}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Sustained attention index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="sa-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <Activity className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="sa-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
                {score.gated && (
                  <p className="mx-auto mt-2 max-w-md rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-700">
                    Participation gate: too many missed digits for a reliable index - the score is floored. Try again with the rhythm ready.
                  </p>
                )}
              </div>

              {/* 4-stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="sa-stat-commissions" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.commissions}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">slips on the 3 (of 20)</p>
                </div>
                <div data-testid="sa-stat-omissions" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.omissions}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">missed digits (of 160)</p>
                </div>
                <div data-testid="sa-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.meanRtMs !== null ? `${Math.round(score.meanRtMs)}` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg response (ms)</p>
                </div>
                <div data-testid="sa-stat-rtcv" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.rtCv !== null ? `${Math.round(score.rtCv * 100)}%` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">rhythm variability</p>
                </div>
              </div>

              {/* Per-block drift chips */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Block by block
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Slips + misses per block - drift usually grows late in long runs
                </p>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                  {score.blocks.map((bs) => {
                    const load = bs.commissions + bs.omissions;
                    const cls =
                      load === 0
                        ? "border-emerald-500 bg-emerald-500/15 text-emerald-700"
                        : load <= 2
                          ? "border-emerald-300 bg-emerald-50 text-emerald-600"
                          : load <= 5
                            ? "border-amber-300 bg-amber-50 text-amber-600"
                            : "border-red-300 bg-red-50 text-red-500";
                    return (
                      <span
                        key={bs.block}
                        data-testid={`sa-block-stat-${bs.block}`}
                        className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-bold tabular-nums ${cls}`}
                      >
                        B{bs.block + 1}
                        <span className="text-xs font-semibold text-muted-foreground">
                          {bs.commissions}S·{bs.omissions}M
                        </span>
                      </span>
                    );
                  })}
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="sa-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - fresh stream
                </button>
                <a
                  href="/test"
                  data-testid="sa-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {score.commissions} slip{score.commissions === 1 ? "" : "s"} on the rare digit ·{" "}
                {score.omissions} missed ·{" "}
                {runSeconds !== null ? `${runSeconds.toFixed(0)}s total` : "composite-z scoring"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
