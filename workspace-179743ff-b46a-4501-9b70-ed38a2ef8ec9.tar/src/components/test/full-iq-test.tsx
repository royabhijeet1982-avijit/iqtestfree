"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Baby,
  Check,
  CircleAlert,
  GraduationCap,
  RotateCcw,
  Shapes,
  Timer,
  TrendingUp,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  AGE_GROUPS,
  AGE_SETS,
  CATEGORY_LABELS,
  SET_SIZE,
  estimateIq,
  estimatePercentile,
  pickSetFor,
  scoreLabel,
  type AgeGroup,
  type IqQuestion,
  type QuestionCategory,
} from "./iq-questions";

type Phase = "intro" | "active" | "results";

const GROUP_ICONS = { kids: Baby, teens: GraduationCap, adults: Users } as const;

const fmtTime = (s: number) =>
  `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

function setFootnote(group: AgeGroup): string {
  const pool = AGE_SETS[group];
  return pool.length > 0
    ? `${pool.length} question sets ready`
    : "Fresh mixed set every time";
}

export function FullIqTest() {
  const [phase, setPhase] = useState<Phase>("intro");
  const [group, setGroup] = useState<AgeGroup | null>(null);
  const [setName, setSetName] = useState("Mixed Draw");
  const [idx, setIdx] = useState(0);
  const [questions, setQuestions] = useState<IqQuestion[]>([]);
  const [answers, setAnswers] = useState<(number | null)[]>(
    () => Array(SET_SIZE).fill(null)
  );
  const [elapsed, setElapsed] = useState(0);
  const lastSetIdRef = useRef<number | undefined>(undefined);

  const total = questions.length;
  const question = questions[idx];
  const selected = answers[idx];
  const answeredCount = answers.filter((a) => a !== null).length;
  const isLast = idx === total - 1;

  /* Elapsed timer while the test is active. */
  useEffect(() => {
    if (phase !== "active") return;
    const t = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(t);
  }, [phase]);

  /* Results maths, recomputed only when answers change. */
  const results = useMemo(() => {
    const correct = answers.reduce(
      (n, a, i) => (a === questions[i]?.answer ? n + 1 : n),
      0
    );
    const byCategory = new Map<
      QuestionCategory,
      { right: number; total: number }
    >();
    questions.forEach((q, i) => {
      const entry = byCategory.get(q.category) ?? { right: 0, total: 0 };
      entry.total += 1;
      if (answers[i] === q.answer) entry.right += 1;
      byCategory.set(q.category, entry);
    });
    return {
      correct,
      iq: estimateIq(correct, questions.length),
      percentile: estimatePercentile(correct, questions.length),
      breakdown: [...byCategory.entries()].map(([category, v]) => ({
        category,
        ...v,
        pct: Math.round((v.right / v.total) * 100),
      })),
    };
  }, [answers, questions]);

  /* Every attempt draws a fresh set for the chosen age group. */
  function startFor(g: AgeGroup) {
    const set = pickSetFor(g, lastSetIdRef.current);
    lastSetIdRef.current = set.id;
    setGroup(g);
    setSetName(set.name);
    setQuestions(set.questions);
    setAnswers(Array(set.questions.length).fill(null));
    setIdx(0);
    setElapsed(0);
    setPhase("active");
  }

  function choose(optionIndex: number) {
    setAnswers((prev) => {
      const next = [...prev];
      next[idx] = optionIndex;
      return next;
    });
  }

  function advance() {
    if (selected === null) return;
    if (isLast) setPhase("results");
    else setIdx((i) => i + 1);
  }

  function back() {
    if (idx > 0) setIdx((i) => i - 1);
  }

  /* ------------------------------ INTRO ------------------------------ */
  if (phase === "intro") {
    return (
      <div className="rounded-3xl border border-border bg-card p-6 shadow-[0_24px_60px_-20px_rgba(10,12,11,0.18)] sm:p-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-700/20 bg-emerald-600/10 px-3.5 py-1.5 text-xs font-semibold text-emerald-800">
            <Timer className="size-3.5" aria-hidden="true" />
            {SET_SIZE} questions per set · a new set every time · free
          </span>
          <h2 className="mt-5 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Who is taking the test today?
          </h2>
          <p className="mt-3 text-base leading-relaxed text-muted-foreground">
            Pick an age group — the moment you choose, a fresh set of{" "}
            {SET_SIZE} questions is dealt from that group&apos;s bank. Every
            visit serves a different set.
          </p>

          <div className="mt-7 grid gap-3 text-left sm:grid-cols-3">
            {AGE_GROUPS.map((g) => {
              const Icon = GROUP_ICONS[g.id];
              return (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => startFor(g.id)}
                  aria-label={`Start the ${g.label} IQ test, ${g.ages}`}
                  className="group flex h-full flex-col rounded-2xl border border-border bg-background/60 p-5 text-left transition-[translate,box-shadow,border-color] duration-200 hover:-translate-y-1 hover:border-primary/50 hover:shadow-[0_14px_34px_rgba(4,120,87,0.16)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="flex size-11 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[scale,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <span className="mt-3 flex items-baseline gap-2">
                    <span className="text-base font-bold text-foreground transition-colors duration-200 group-hover:text-primary">
                      {g.label}
                    </span>
                    <span className="text-xs font-medium text-muted-foreground">
                      {g.ages}
                    </span>
                  </span>
                  <span className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {g.blurb}
                  </span>
                  <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                    <Shapes className="size-3.5" aria-hidden="true" />
                    {setFootnote(g.id)}
                  </span>
                </button>
              );
            })}
          </div>

          <ul className="mx-auto mt-7 grid max-w-md gap-2 text-left text-sm text-muted-foreground">
            {[
              "No signup — your result appears instantly",
              "One question at a time, change answers freely",
              "Domain-by-domain breakdown at the end",
            ].map((line) => (
              <li key={line} className="flex items-start gap-2">
                <Check
                  className="mt-0.5 size-4 shrink-0 text-emerald-600"
                  aria-hidden="true"
                />
                {line}
              </li>
            ))}
          </ul>

          <p className="mt-5 text-xs text-muted-foreground/80">
            Educational estimate for self-exploration — not a clinical
            assessment.
          </p>
        </div>
      </div>
    );
  }

  /* ----------------------------- RESULTS ----------------------------- */
  if (phase === "results") {
    return (
      <div className="rounded-3xl border border-border bg-card p-6 shadow-[0_24px_60px_-20px_rgba(10,12,11,0.18)] sm:p-10">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">
            Your result
          </p>
          <p className="mt-4 text-6xl font-extrabold leading-none tracking-tight text-foreground sm:text-7xl">
            <CountUp to={results.iq} duration={1.4} />
          </p>
          <p className="mt-3 text-base font-semibold text-foreground">
            {scoreLabel(results.iq)}
          </p>
          <p className="mt-1 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
            <TrendingUp className="size-4 text-emerald-600" aria-hidden="true" />
            Higher than about {results.percentile}% of test takers
          </p>
          <p className="mt-2 text-xs text-muted-foreground/80">
            {results.correct} of {total} correct · time {fmtTime(elapsed)} ·
            educational estimate, not a clinical score
          </p>
          <p className="mt-1 text-xs text-muted-foreground/80">
            {group ? `${group.charAt(0).toUpperCase()}${group.slice(1)}` : ""}{" "}
            set “{setName}” · your questions were dealt randomly — the next
            attempt gets a new set
          </p>
        </div>

        {/* Domain breakdown */}
        <div className="mx-auto mt-10 max-w-2xl">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Skill breakdown
          </h3>
          <ul className="mt-4 space-y-3.5">
            {results.breakdown.map((row) => (
              <li key={row.category}>
                <div className="flex items-center justify-between gap-3 text-sm">
                  <span className="font-medium text-foreground">
                    {CATEGORY_LABELS[row.category]}
                  </span>
                  <span className="tabular-nums text-muted-foreground">
                    {row.right}/{row.total}
                  </span>
                </div>
                <div
                  className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted"
                  role="img"
                  aria-label={`${CATEGORY_LABELS[row.category]}: ${row.pct}% correct`}
                >
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${row.pct}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                    className="h-full rounded-full bg-gradient-to-r from-emerald-600 to-emerald-400"
                  />
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Per-question review */}
        <div className="mx-auto mt-10 max-w-2xl">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Question review
          </h3>
          <ul className="mt-4 space-y-2.5">
            {questions.map((q, i) => {
              const picked = answers[i];
              const right = picked === q.answer;
              return (
                <li key={q.id}>
                  <details className="group rounded-xl border border-border bg-background/60 px-4 py-3 transition-[border-color] duration-200 open:border-primary/30">
                    <summary className="flex cursor-pointer list-none items-center gap-2.5 text-sm font-medium text-foreground [&::-webkit-details-marker]:hidden">
                      {right ? (
                        <Check
                          className="size-4 shrink-0 text-emerald-600"
                          aria-hidden="true"
                        />
                      ) : (
                        <CircleAlert
                          className="size-4 shrink-0 text-red-500"
                          aria-hidden="true"
                        />
                      )}
                      <span className="flex-1">
                        Q{i + 1}. {q.prompt.length > 64 ? `${q.prompt.slice(0, 64)}…` : q.prompt}
                      </span>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                          right
                            ? "bg-emerald-600/10 text-emerald-700"
                            : "bg-red-500/10 text-red-600"
                        }`}
                      >
                        {right ? "Correct" : "Review"}
                      </span>
                    </summary>
                    <div className="mt-3 space-y-1.5 border-t border-border/70 pt-3 text-sm">
                      <p className="text-muted-foreground">
                        Your answer:{" "}
                        <span className={right ? "font-semibold text-emerald-700" : "font-semibold text-foreground"}>
                          {picked !== null ? q.options[picked] : "Skipped"}
                        </span>
                        {!right && (
                          <>
                            {" "}· Correct answer:{" "}
                            <span className="font-semibold text-emerald-700">
                              {q.options[q.answer]}
                            </span>
                          </>
                        )}
                      </p>
                      <p className="leading-relaxed text-muted-foreground">
                        {q.explanation}
                      </p>
                    </div>
                  </details>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button
            size="lg"
            onClick={() => group && startFor(group)}
            className="h-12 w-full px-7 text-base shadow-[0_8px_24px_rgba(4,120,87,0.35)] transition-[translate,box-shadow] duration-300 hover:-translate-y-0.5 hover:shadow-[0_10px_30px_rgba(4,120,87,0.45)] active:translate-y-0 sm:w-auto bm-shine"
          >
            <RotateCcw className="size-4" aria-hidden="true" />
            Retake — new {SET_SIZE} questions
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => setPhase("intro")}
            className="h-12 w-full border-border bg-card px-7 text-base shadow-sm transition-[translate,box-shadow,border-color] duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md active:translate-y-0 sm:w-auto"
          >
            <Users className="size-4" aria-hidden="true" />
            Change age group
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="h-12 w-full border-border bg-card px-7 text-base shadow-sm transition-[translate,box-shadow,border-color] duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md active:translate-y-0 sm:w-auto"
          >
            <Link href="/#all-tests">Explore all cognitive tests</Link>
          </Button>
        </div>
      </div>
    );
  }

  /* ------------------------------ ACTIVE ----------------------------- */
  return (
    <div className="rounded-3xl border border-border bg-card p-6 shadow-[0_24px_60px_-20px_rgba(10,12,11,0.18)] sm:p-10">
      {/* Status row */}
      <div className="flex items-center justify-between gap-3">
        <span className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-primary">
          {CATEGORY_LABELS[question.category]}
        </span>
        <span className="inline-flex items-center gap-1.5 text-sm font-medium tabular-nums text-muted-foreground">
          <Timer className="size-4" aria-hidden="true" />
          {fmtTime(elapsed)}
        </span>
      </div>

      {/* Progress */}
      <div className="mt-5">
        <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
          <span>
            Question {idx + 1} of {total}
          </span>
          <span>{answeredCount} answered</span>
        </div>
        <div
          className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted"
          role="progressbar"
          aria-valuenow={idx + 1}
          aria-valuemin={1}
          aria-valuemax={total}
          aria-label="Test progress"
        >
          <motion.div
            initial={false}
            animate={{ width: `${((idx + 1) / total) * 100}%` }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="h-full rounded-full bg-gradient-to-r from-emerald-600 to-emerald-400"
          />
        </div>
      </div>

      {/* Question */}
      <div aria-live="polite">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={question.id}
            initial={{ opacity: 0, x: 28 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -28 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
          >
            <h3 className="mt-7 text-xl font-bold leading-snug tracking-tight text-foreground sm:text-2xl">
              {question.prompt}
            </h3>

            <div className="mt-6 grid gap-2.5" role="group" aria-label="Answer options">
              {question.options.map((option, i) => {
                const active = selected === i;
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => choose(i)}
                    aria-pressed={active}
                    className={`flex items-center gap-3 rounded-xl border px-4 py-3.5 text-left text-base font-medium transition-[border-color,background-color,translate] duration-200 hover:-translate-y-px hover:border-primary/40 ${
                      active
                        ? "border-primary bg-primary/5 text-foreground shadow-[0_6px_18px_rgba(4,120,87,0.12)]"
                        : "border-border bg-background/60 text-foreground"
                    }`}
                  >
                    <span
                      className={`flex size-7 shrink-0 items-center justify-center rounded-full border text-xs font-bold transition-colors duration-200 ${
                        active
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-muted text-muted-foreground"
                      }`}
                      aria-hidden="true"
                    >
                      {String.fromCharCode(65 + i)}
                    </span>
                    {option}
                  </button>
                );
              })}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Controls */}
      <div className="mt-8 flex items-center justify-between gap-3">
        <Button
          variant="outline"
          onClick={back}
          disabled={idx === 0}
          className="h-11 border-border bg-card px-5 text-sm font-semibold transition-[border-color,translate] duration-200 hover:border-primary/40 disabled:pointer-events-none disabled:opacity-40"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Back
        </Button>
        <Button
          onClick={advance}
          disabled={selected === null}
          className="h-11 px-6 text-sm font-semibold shadow-[0_6px_18px_rgba(4,120,87,0.3)] transition-[translate,box-shadow] duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(4,120,87,0.4)] active:translate-y-0 disabled:pointer-events-none disabled:opacity-40 bm-shine"
        >
          {isLast ? "See my results" : "Next question"}
          <ArrowRight className="size-4" aria-hidden="true" />
        </Button>
      </div>
    </div>
  );
}
