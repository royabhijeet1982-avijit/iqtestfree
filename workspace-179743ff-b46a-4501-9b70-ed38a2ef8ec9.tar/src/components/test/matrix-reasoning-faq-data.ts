/* ------------------------------------------------------------------ */
/*  Matrix Reasoning Test - FAQ (single source)                        */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type MrFaq = { question: string; answer: string };

export const MATRIX_REASONING_FAQS: MrFaq[] = [
  {
    question: "What does the Matrix Reasoning Test measure?",
    answer:
      "Matrix reasoning measures fluid intelligence: your ability to reason through novel problems that do not depend on learned facts or vocabulary. Each item shows a grid of shapes governed by hidden rules, and you must infer those rules and apply them to find the one tile that completes the pattern. Early items rely on a single rule such as a quantity progression, while later items combine two independent rules at once, such as a rotation across the columns plus a shading change down the rows. This infer-and-apply loop is the same core skill behind abstract thinking, problem solving and learning speed.",
  },
  {
    question: "Is the test timed?",
    answer:
      "No. There is no per-item countdown and no session time limit, which matches how standard matrix reasoning assessments are administered. Most people finish the twenty matrices in ten to twenty minutes, and taking your time genuinely helps because accuracy is the only thing that raises your score. That said, every answer is timed to the millisecond, and if your median answer time drops under two seconds the results page shows an honesty panel - the score is still computed from your answers, but it likely understates your real reasoning ability.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Your raw score is simply the number of matrices you solved correctly out of twenty, and only correct answers count - there is no penalty for wrong picks beyond the missed item. The raw score is then mapped onto an IQ-style scale with a population mean of 100 and a standard deviation of 15, using reference values calibrated against a simulated population of five hundred users with realistically spread abilities. You also get a percentile estimate and a per-rule accuracy breakdown covering the five rule categories: quantity and size, shape logic, rotation, shading logic and superposition, so you can see exactly which kind of pattern gave you trouble.",
  },
  {
    question: "What is the retake policy?",
    answer:
      "You can retake the test as many times as you like, for free and without signing up. Every session generates a completely fresh set of random matrices from a new seed, so the grids, the patterns and the order of the answer tiles all change between attempts - retaking measures your reasoning, never your memory of last time. One or two warm-up attempts are a fair way to reach your ceiling, since a first run includes the cost of learning the interface. If your score varies a lot between careful runs, the single-session estimate is simply noisy rather than a real change in ability.",
  },
  {
    question: "How does this relate to Raven's Progressive Matrices?",
    answer:
      "This test is a procedural cousin of Raven's Progressive Matrices, the multiple-choice visual task published by John Raven in 1938 and still regarded as one of the purest single measures of fluid intelligence, or Gf in Cattell's theory of cognitive abilities. The Matrix Reasoning subtest of the WAIS IQ battery uses the same format for the same purpose. Our generator builds items from the same rule families - quantity progressions, shape alternation, rotation, shading logic and element superposition - with a difficulty ramp from single-rule warm-ups to two-rule matrices. It is an educational estimate rather than a clinical instrument, but the skill it samples is the real one.",
  },
  {
    question: "How accurate is the IQ estimate?",
    answer:
      "Treat the score as a screening-level estimate with a meaningful margin of error, not a clinical measurement. Twenty items is a short form, so the estimate typically carries an uncertainty of roughly plus or minus half a standard deviation compared with a full professional assessment, and conditions matter: noise, interruptions, fatigue or rushing can all push the number down. Confidence grows with consistency - if careful retakes and other cognitive tests land in the same range, the estimate is more trustworthy. For any formal purpose, such as diagnosis or assessment documentation, you need a qualified professional and standardised testing conditions.",
  },
];
