/* ------------------------------------------------------------------ */
/*  Reaction Time Test - pure scoring engine                           */
/*  Paradigm: classic psychomotor reaction time, in two rounds.        */
/*   Round 1 (simple RT): a stage sits red for a RANDOM 1.5-4.5s       */
/*     foreperiod, then flashes green; one tap is measured in ms.      */
/*   Round 2 (choice RT): one of four quadrant pads lights up after    */
/*     the same random foreperiod; the user must tap the lit pad.      */
/*                                                                     */
/*  Scoring: median simple RT, median choice RT, RT variability        */
/*  (SD of valid simple RTs) and choice accuracy are combined into     */
/*  a single "RT Index" on the IQ scale (mean 100 / SD 15), anchored   */
/*  on population norms: simple RT median ~300ms (SD 55), choice RT    */
/*  ~500ms (SD 80). Faster => higher. Percentile via erf normal CDF.  */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - The foreperiod is randomised every trial, so a fixed rhythm     */
/*     never aligns with the cue.                                      */
/*   - Responses under 150ms are ANTICIPATIONS: they fired before the  */
/*     cue could be processed, so they never score; the trial is       */
/*     retried up to 2 times, then skipped.                            */
/*   - Responses over 1500ms are LAPSES (attention drop): invalid.     */
/*   - If more than 30% of trials end invalid, the run is flagged      */
/*     low-validity and is NOT scored - no IQ inflation.               */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Round sizes for the default session. */
export const SIMPLE_TRIALS = 5;
export const CHOICE_TRIALS = 10;

/** Shortened session used by automated flow tests via ?quick=1. */
export const QUICK_SIMPLE_TRIALS = 3;
export const QUICK_CHOICE_TRIALS = 6;

/** Random wait before the cue, per trial (uniform, ms). */
export const FOREPERIOD_MIN_MS = 1500;
export const FOREPERIOD_MAX_MS = 4500;

/** Response faster than this fired before the cue could register. */
export const ANTICIPATION_MS = 150;

/** Response slower than this is an attention lapse (invalid). */
export const LAPSE_MS = 1500;

/** No response at all by this point is auto-scored as a lapse. */
export const LAPSE_TIMEOUT_MS = 4000;

/** A trial retried this many times after anticipations is skipped. */
export const MAX_ANTICIPATION_RETRIES = 2;

/** Share of invalid trials above which the run is flagged. */
export const INVALID_RATE_THRESHOLD = 0.3;

/** Valid rounds required per phase before medians can be computed. */
export const MIN_VALID_PER_KIND = 2;

/** Number of quadrant pads in the choice round. */
export const PAD_COUNT = 4;

/* Composite weights (spec): 0.55 simple + 0.35 choice - 0.10 variability
 * plus a bounded accuracy adjustment. */
export const WEIGHT_SIMPLE = 0.55;
export const WEIGHT_CHOICE = 0.35;
export const WEIGHT_VARIABILITY = 0.1;
export const WEIGHT_ACCURACY = 0.1;

/** Accuracy z-score clamp (chance is 25% with 4 pads; bounded effect). */
export const ACCURACY_Z_CLAMP_MIN = -3;
export const ACCURACY_Z_CLAMP_MAX = 1.5;

/* Population anchors for the OBSERVED test statistics (adult casual
 * web users, mouse/touch input). Faster-than-median maps to positive
 * z, so quicker users score higher on the index. */
export const SIMPLE_RT_MEDIAN = 300;
export const SIMPLE_RT_SD = 55;
export const CHOICE_RT_MEDIAN = 500;
export const CHOICE_RT_SD = 80;
export const VARIABILITY_MEDIAN = 45;
export const VARIABILITY_SD = 20;
export const ACCURACY_MEAN = 0.94;
export const ACCURACY_SD = 0.06;

export const INDEX_MIN = 55;
export const INDEX_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type TrialKind = "simple" | "choice";

/** Final outcome of one trial SLOT (anticipation attempts live inside). */
export type TrialOutcome = "valid" | "lapse" | "skipped";

export type RtTrial = {
  kind: TrialKind;
  outcome: TrialOutcome;
  /** Final response time in ms (0 when the slot was skipped). */
  rtMs: number;
  /** Choice round: tapped pad matched the lit pad. Simple: true. */
  correct: boolean;
  /** Lit quadrant 0..3 (-1 for the simple round). */
  litPad: number;
  /** Quadrant the user tapped (-1 for simple / keyboard-less). */
  responsePad: number;
  /** How many times this slot fired before the cue (0..3). */
  anticipationAttempts: number;
};

export type RtGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SessionScore = {
  totalTrials: number;
  validTrials: number;
  /** Total early responses across all slots (including retries). */
  anticipationCount: number;
  lapseCount: number;
  skippedCount: number;
  /** (lapses + skipped) / totalTrials, 0..1. */
  invalidRate: number;
  validSimpleCount: number;
  validChoiceCount: number;
  medianSimpleMs: number;
  medianChoiceMs: number;
  /** SD of valid simple RTs (ms) - lower is steadier. */
  variabilityMs: number;
  /** Correct / valid choice trials, 0..1. */
  choiceAccuracy: number;
  lowValidity: boolean;
  /** RT Index (IQ-anchored, mean 100 / SD 15). 0 when not scored. */
  rtIndex: number;
  /** Population percentile 1..99. 0 when not scored. */
  percentile: number;
  grade: RtGrade;
  valid: boolean;
  invalidReason: string | null;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/**
 * Random foreperiod for one trial: uniform integer in
 * [FOREPERIOD_MIN_MS, FOREPERIOD_MAX_MS). Randomised waits destroy any
 * fixed tapping rhythm, which is the core anti-gaming defence.
 */
export function randomForeperiod(rng: () => number): number {
  const span = FOREPERIOD_MAX_MS - FOREPERIOD_MIN_MS;
  return FOREPERIOD_MIN_MS + Math.floor(rng() * span);
}

/* ------------------------------------------------------------------ */
/*  Classification                                                     */
/* ------------------------------------------------------------------ */

export type RtClassification = "valid" | "anticipation" | "lapse";

/**
 * Classify a raw response time:
 *  - < 150ms  -> anticipation (fired before the cue could register)
 *  - 150..1500ms inclusive -> valid
 *  - > 1500ms -> lapse (attention dropped)
 */
export function classifyRt(rtMs: number): RtClassification {
  if (rtMs < ANTICIPATION_MS) return "anticipation";
  if (rtMs <= LAPSE_MS) return "valid";
  return "lapse";
}

/* ------------------------------------------------------------------ */
/*  Statistics                                                         */
/* ------------------------------------------------------------------ */

/** Median of a numeric sample (0 for empty input). */
export function median(xs: readonly number[]): number {
  if (xs.length === 0) return 0;
  const sorted = xs.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid] as number;
  return ((sorted[mid - 1] as number) + (sorted[mid] as number)) / 2;
}

/** Sample standard deviation (0 for fewer than 2 values). */
export function sampleSd(xs: readonly number[]): number {
  if (xs.length < 2) return 0;
  const m = xs.reduce((a, b) => a + b, 0) / xs.length;
  const variance =
    xs.reduce((acc, x) => acc + (x - m) ** 2, 0) / (xs.length - 1);
  return Math.sqrt(variance);
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Combine the component z-scores into the RT Index (mean 100, SD 15).
 * Faster RTs give HIGHER z (the median is subtracted from the norm),
 * higher variability gives LOWER z, accuracy nudges either way.
 */
export function compositeToIndex(compositeZ: number): number {
  const raw = 100 + 15 * compositeZ;
  const rounded = Math.round(raw);
  return Math.min(INDEX_MAX, Math.max(INDEX_MIN, rounded));
}

/** RT Index -> population percentile (1..99), normal model SD 15. */
export function indexToPercentile(rtIndex: number): number {
  const pct = normalCdf(rtIndex, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the RT Index (black accent for Elite). */
export function gradeForIndex(rtIndex: number): RtGrade {
  if (rtIndex < 85) {
    return {
      label: "Steady",
      blurb:
        "Deliberate and measured - your responses favour composure over raw speed, and they will sharpen with a little practice.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (rtIndex < 100) {
    return {
      label: "Average",
      blurb: "Right in the normal band - a dependable, everyday response speed.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (rtIndex < 115) {
    return {
      label: "Quick",
      blurb: "Faster than most - your eyes, brain and finger work well together.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (rtIndex < 130) {
    return {
      label: "Very quick",
      blurb: "Excellent tempo - you notice the cue and commit to a response almost instantly.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Elite",
    blurb: "Elite reflexes - responses this fast put you among the top few percent of people.",
    className: "bg-neutral-900 text-white border-neutral-900",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a full session (both rounds) from its trial records.
 *
 * Validity rules (anti-gaming):
 *  - no trials at all -> invalid
 *  - more than INVALID_RATE_THRESHOLD of trials invalid (lapses +
 *    skipped-after-anticipation) -> flagged low validity, NOT scored
 *  - fewer than MIN_VALID_PER_KIND valid trials in either round ->
 *    invalid (medians too unstable)
 *
 * Scoring model: medians of valid trials, SD of valid simple RTs and
 * choice accuracy combine with fixed weights into the RT Index.
 */
export function scoreSession(trials: readonly RtTrial[]): SessionScore {
  const totalTrials = trials.length;
  const anticipationCount = trials.reduce(
    (a, t) => a + t.anticipationAttempts,
    0
  );
  const lapseCount = trials.filter((t) => t.outcome === "lapse").length;
  const skippedCount = trials.filter((t) => t.outcome === "skipped").length;
  const invalidCount = lapseCount + skippedCount;
  const invalidRate = totalTrials > 0 ? invalidCount / totalTrials : 1;

  const validTrials = trials.filter((t) => t.outcome === "valid");
  const validSimple = validTrials.filter((t) => t.kind === "simple");
  const validChoice = validTrials.filter((t) => t.kind === "choice");
  const simpleRts = validSimple.map((t) => t.rtMs);
  const choiceRts = validChoice.map((t) => t.rtMs);
  const choiceCorrect = validChoice.filter((t) => t.correct).length;

  const medianSimpleMs = median(simpleRts);
  const medianChoiceMs = median(choiceRts);
  const variabilityMs = sampleSd(simpleRts);
  const choiceAccuracy =
    validChoice.length > 0 ? choiceCorrect / validChoice.length : 0;

  const base = {
    totalTrials,
    validTrials: validTrials.length,
    anticipationCount,
    lapseCount,
    skippedCount,
    invalidRate,
    validSimpleCount: validSimple.length,
    validChoiceCount: validChoice.length,
    medianSimpleMs,
    medianChoiceMs,
    variabilityMs,
    choiceAccuracy,
  };

  if (totalTrials === 0) {
    return invalidScore(base, "No responses were recorded.", false);
  }

  if (invalidRate > INVALID_RATE_THRESHOLD) {
    const validCount = validTrials.length;
    return invalidScore(
      base,
      `Only ${validCount} of ${totalTrials} trials were valid - ${anticipationCount} tap(s) landed before the green cue (anticipations) and ${lapseCount} came too late (lapses). Keep your eyes on the red screen and respond only when it turns green.`,
      true
    );
  }

  if (
    validSimple.length < MIN_VALID_PER_KIND ||
    validChoice.length < MIN_VALID_PER_KIND
  ) {
    return invalidScore(
      base,
      `Not enough valid trials to compute stable medians - at least ${MIN_VALID_PER_KIND} valid rounds of each type are required. You completed ${validSimple.length} simple and ${validChoice.length} choice rounds. Take your time and run it again.`,
      false
    );
  }

  // Faster than the population median -> positive z.
  const zSimple = (SIMPLE_RT_MEDIAN - medianSimpleMs) / SIMPLE_RT_SD;
  const zChoice = (CHOICE_RT_MEDIAN - medianChoiceMs) / CHOICE_RT_SD;
  // More variable than typical -> positive z, which is subtracted.
  const zVariability = (variabilityMs - VARIABILITY_MEDIAN) / VARIABILITY_SD;
  const zAccuracy = Math.min(
    ACCURACY_Z_CLAMP_MAX,
    Math.max(ACCURACY_Z_CLAMP_MIN, (choiceAccuracy - ACCURACY_MEAN) / ACCURACY_SD)
  );

  const compositeZ =
    WEIGHT_SIMPLE * zSimple +
    WEIGHT_CHOICE * zChoice -
    WEIGHT_VARIABILITY * zVariability +
    WEIGHT_ACCURACY * zAccuracy;

  const rtIndex = compositeToIndex(compositeZ);

  return {
    ...base,
    lowValidity: false,
    rtIndex,
    percentile: indexToPercentile(rtIndex),
    grade: gradeForIndex(rtIndex),
    valid: true,
    invalidReason: null,
  };
}

function invalidScore(
  base: Omit<SessionScore, "rtIndex" | "percentile" | "grade" | "valid" | "invalidReason" | "lowValidity">,
  reason: string,
  flaggedLowValidity: boolean
): SessionScore {
  return {
    ...base,
    lowValidity: flaggedLowValidity,
    rtIndex: 0,
    percentile: 0,
    grade: {
      label: "Not scored",
      blurb: reason,
      className: "bg-amber-50 text-amber-800 border-amber-200",
    },
    valid: false,
    invalidReason: reason,
  };
}
