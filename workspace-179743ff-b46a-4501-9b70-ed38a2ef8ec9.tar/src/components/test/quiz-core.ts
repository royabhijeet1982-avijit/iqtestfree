export type QuestionCategory =
  | "logic"
  | "verbal"
  | "numeric"
  | "pattern"
  | "attention"
  | "memory"
  | "spatial";

export type AgeGroup = "kids" | "teens" | "adults";

export type IqQuestion = {
  id: number;
  category: QuestionCategory;
  /** 1 = easy, 2 = medium, 3 = hard. */
  difficulty: 1 | 2 | 3;
  prompt: string;
  options: string[];
  /** Index of the correct option (in bank order; the served set reshuffles). */
  answer: number;
  explanation: string;
};

/** Compact authoring format: [category, difficulty, prompt, "a|b|c|d", answerIdx, explanation]. */
export type RawQuestion = [
  QuestionCategory,
  1 | 2 | 3,
  string,
  string,
  number,
  string
];

export type RawSet = {
  name: string;
  qs: RawQuestion[];
};

export type IqSet = {
  id: number;
  name: string;
  ageGroup: AgeGroup;
  questions: IqQuestion[];
};

/** Questions served per attempt. */
export const SET_SIZE = 12;

export const CATEGORY_LABELS: Record<QuestionCategory, string> = {
  logic: "Logical Reasoning",
  verbal: "Verbal",
  numeric: "Numerical",
  pattern: "Pattern Recognition",
  attention: "Attention to Detail",
  memory: "Working Memory",
  spatial: "Spatial Thinking",
};

export const AGE_GROUPS: {
  id: AgeGroup;
  label: string;
  ages: string;
  blurb: string;
}[] = [
  {
    id: "kids",
    label: "Kids",
    ages: "Ages 7–12",
    blurb: "Playful puzzles with easy words, friendly numbers and fun logic.",
  },
  {
    id: "teens",
    label: "Teens",
    ages: "Ages 13–17",
    blurb: "School-smart brainteasers across words, numbers and reasoning.",
  },
  {
    id: "adults",
    label: "Adults",
    ages: "Ages 18+",
    blurb: "Classic IQ-style items with trickier logic and 3D thinking.",
  },
];

export function shuffle<T>(input: T[]): T[] {
  const a = [...input];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Shuffles an option list and remaps the answer index to match. */
export function withShuffledOptions(q: IqQuestion): IqQuestion {
  const order = shuffle(q.options.map((_, i) => i));
  return {
    ...q,
    options: order.map((i) => q.options[i]),
    answer: order.indexOf(q.answer),
  };
}

/** Expands one authored set; idBase keeps ids unique per age group. */
export function expandRawSet(raw: RawSet, setNo: number, idBase: number, ageGroup: AgeGroup): IqSet {
  return {
    id: idBase + setNo + 1,
    name: raw.name,
    ageGroup,
    questions: raw.qs.map((r, qi) => ({
      id: (idBase + setNo + 1) * 100 + qi + 1,
      category: r[0],
      difficulty: r[1],
      prompt: r[2],
      options: r[3].split("|"),
      answer: r[4],
      explanation: r[5],
    })),
  };
}

/** Expands a flat bank of raw questions with sequential ids. */
export function expandRawQuestions(raws: RawQuestion[], idStart: number): IqQuestion[] {
  return raws.map((r, i) => ({
    id: idStart + i,
    category: r[0],
    difficulty: r[1],
    prompt: r[2],
    options: r[3].split("|"),
    answer: r[4],
    explanation: r[5],
  }));
}

/** Maps correct answers to an estimated IQ-style score (78–135). */
export function estimateIq(correct: number, total: number): number {
  const ratio = total > 0 ? correct / total : 0;
  return Math.round(78 + ratio * 57);
}

/** Rough percentile band for the estimated score. */
export function estimatePercentile(correct: number, total: number): number {
  const ratio = total > 0 ? correct / total : 0;
  return Math.min(99, Math.max(2, Math.round(4 + ratio * 92)));
}

export function scoreLabel(iq: number): string {
  if (iq < 90) return "Developing range";
  if (iq < 110) return "Average range";
  if (iq < 125) return "Above average";
  return "Very high range";
}
