/* ------------------------------------------------------------------ */
/*  Pattern Memory Test - pure scoring engine                          */
/*  Paradigm: tile-pattern reproduction with a shrinking hint budget.  */
/*  Each round shows a pattern of lit cells on a 5x5 grid for a fixed  */
/*  engine-owned flash, then the board goes dark and you reproduce it  */
/*  by clicking. Rounds grow the pattern while the peek budget (extra  */
/*  re-flashes) shrinks to zero.                                       */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - visual-memory: ONE cumulative pattern that grows level by       */
/*     level and speeds up forever - a survival ladder. Here: six      */
/*     INDEPENDENT patterns, each scored on its own, with a peek       */
/*     budget that decays instead of a timer that accelerates.         */
/*   - spatial-memory: symbol-location PAIRS you must bind and later   */
/*     re-place (what went where). Here: pure pattern FORM - what      */
/*     was lit, no symbols involved.                                   */
/*                                                                     */
/*  Scoring honesty (anti-gaming by design):                           */
/*   - Round score = (correct cells - wrong cells) / pattern size,     */
/*     floored at 0. Spraying every tile on the board "catches" the    */
/*     pattern but pays for every miss, so mashing pins the round at   */
/*     0 - only genuine recall moves the number.                       */
/*   - Flash duration and pattern are engine-owned; the board carries  */
/*     machine hooks ONLY while the flash is up (anti-cheat).          */
/*   - Every run reseeds the RNG and draws fresh patterns, so there is */
/*     nothing to memorise between attempts.                           */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Pattern sizes per round (round 1 -> 3 cells, ..., round 6 -> 8). */
export const ROUND_PATTERN_SIZES: readonly number[] = [3, 4, 5, 6, 7, 8];

/** Total pattern cells shown across a full session. */
export const TOTAL_SESSION_CELLS = ROUND_PATTERN_SIZES.reduce((a, b) => a + b, 0);

/** Board geometry: 5x5 = 25 cells, indexed row-major 0..24. */
export const GRID_SIZE = 5;
export const CELL_COUNT = GRID_SIZE * GRID_SIZE;

/** Peek budget per round - extra re-flashes the user may spend. */
export const ROUND_PEEKS: readonly number[] = [2, 2, 1, 1, 0, 0];

/* -------------------- Engine-owned timing (ms) -------------------- */
/** How long the pattern flash stays lit in each round. */
export const SHOW_MS: readonly number[] = [1400, 1250, 1100, 950, 820, 700];
/** Dark pause after the flash before clicking opens. */
export const AFTER_SHOW_GAP_MS = 350;
/** Feedback reveal length after a round's submission. */
export const FEEDBACK_MS = 900;
/** Idle pause before the flash of a round. */
export const PRE_SHOW_MS = 450;

/** Shortened timings used by automated flow tests via ?quick=1. */
export const SHOW_MS_QUICK: readonly number[] = [350, 320, 300, 280, 260, 240];
export const AFTER_SHOW_GAP_MS_QUICK = 80;
export const FEEDBACK_MS_QUICK = 200;
export const PRE_SHOW_MS_QUICK = 150;

/* -------------------- Population model -------------------- */
/**
 * Adult mean / SD for mean round score on a 5x5 tile-pattern task with
 * patterns growing 3 -> 8 cells and flashes shrinking 1400 -> 700 ms.
 * The score index is the standard IQ scale.
 */
export const SCORE_MEAN = 0.6;
export const SCORE_SD = 0.13;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** One round's generated pattern plus its independent parameters. */
export type PatternRound = {
  /** 0-based round index. */
  round: number;
  /** Number of lit cells in the pattern. */
  size: number;
  /** Sorted cell indices (0..24) that form the pattern. */
  cells: number[];
  /** Extra re-flashes the user may spend this round. */
  peeks: number;
  /** Flash duration for this round in ms. */
  showMs: number;
};

export type PatternMemorySession = {
  rounds: PatternRound[];
};

/** One user submission for a round: the cell set they clicked. */
export type Recall = {
  round: number;
  /** Cell indices the user clicked, in click order (may contain any cells). */
  clicked: number[];
  /** How many peeks the user actually spent this round. */
  peeksUsed: number;
  /** Time from recall opening to submission in ms (null if unavailable). */
  rtMs: number | null;
};

export type RoundStat = {
  round: number;
  size: number;
  /** Cells the user got right. */
  hits: number;
  /** Cells the user clicked that were NOT in the pattern. */
  wrong: number;
  /** max(0, hits - wrong) / size for this round. */
  score: number;
};

export type PatternGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type PatternMemoryScore = {
  /** Total pattern cells reproduced across the session. */
  hits: number;
  /** Total wrong tiles clicked across the session. */
  wrong: number;
  /** Total pattern cells shown across the session. */
  totalCells: number;
  /** Mean of the six per-round scores (each floored at 0). */
  accuracy: number;
  /** Mean response time from recall open to submit (null when absent). */
  avgRtMs: number | null;
  /** Peeks spent vs available across the session. */
  peeksUsed: number;
  peeksAvailable: number;
  /** Per-round breakdown, one entry per round with a submission. */
  rounds: RoundStat[];
  /** IQ-scale pattern memory index (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: PatternGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle of a copy - never mutates the input. */
export function shuffled<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i]!;
    out[i] = out[j]!;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Session building                                                   */
/* ------------------------------------------------------------------ */

/** Row (0..4) of a cell index. */
export function rowOf(cell: number): number {
  return Math.floor(cell / GRID_SIZE);
}

/** Column (0..4) of a cell index. */
export function colOf(cell: number): number {
  return cell % GRID_SIZE;
}

/** Chebyshev distance between two cells (max of row and column deltas). */
export function chebyshev(a: number, b: number): number {
  return Math.max(Math.abs(rowOf(a) - rowOf(b)), Math.abs(colOf(a) - colOf(b)));
}

/**
 * Draw one pattern of `size` distinct cells. Two quality rules keep the
 * patterns fair and memorable:
 *  1. No two pattern cells sit DIRECTLY adjacent (chebyshev distance 1
 *     creates blobby chunks that collapse into one gestalt and make
 *     size irrelevant); the minimum spacing is 2.
 *  2. The pattern is not confined to a single row or column - a line
 *     of cells is trivially encoded as "row 2" and scores for free.
 *
 * Rejection sampling cannot find size-8 patterns (they are astronomically
 * rare at random), so this uses randomized BACKTRACKING: a complete
 * search over cell subsets in a seed-shuffled order, which terminates
 * quickly because the board's independence number is 9 and size <= 8.
 * The fallback is the 3x3 anchor grid {0,2,4}x{0,2,4} - every pair of
 * anchors is at least 2 apart by construction.
 */
export function drawPattern(size: number, rng: () => number): number[] {
  if (size < 1 || size > CELL_COUNT) {
    throw new Error(`pattern size out of range: ${size}`);
  }

  const needsSpread = size >= 2;
  const isSpread = (cells: readonly number[]): boolean => {
    if (!needsSpread) return true;
    const rows = new Set(cells.map(rowOf));
    const cols = new Set(cells.map(colOf));
    return rows.size > 1 && cols.size > 1;
  };

  const order = shuffled(
    Array.from({ length: CELL_COUNT }, (_, i) => i),
    rng
  );
  const chosen: number[] = [];
  let visits = 0;

  const backtrack = (startIdx: number): boolean => {
    if (chosen.length === size) return isSpread(chosen);
    for (let idx = startIdx; idx < order.length; idx++) {
      if (++visits > 50000) return false; // hard cap; fallback below
      const cand = order[idx]!;
      let adjacent = false;
      for (const c of chosen) {
        if (chebyshev(c, cand) < 2) {
          adjacent = true;
          break;
        }
      }
      if (adjacent) continue;
      chosen.push(cand);
      if (backtrack(idx + 1)) return true;
      chosen.pop();
    }
    return false;
  };

  if (backtrack(0)) {
    return [...chosen].sort((a, b) => a - b);
  }

  // Fallback (practically unreachable): 3x3 anchor grid, shuffled pick.
  const anchors = [0, 2, 4, 10, 12, 14, 20, 22, 24];
  for (let attempt = 0; attempt < 500; attempt++) {
    const pick = shuffled(anchors, rng)
      .slice(0, size)
      .sort((a, b) => a - b);
    if (isSpread(pick)) return pick;
  }
  return anchors.slice(0, size).sort((a, b) => a - b);
}

/** Build a full session (6 rounds) from a seed. */
export function buildPatternMemorySession(seed: number): PatternMemorySession {
  const rng = mulberry32(seed);
  const rounds: PatternRound[] = ROUND_PATTERN_SIZES.map((size, r) => ({
    round: r,
    size,
    cells: drawPattern(size, rng),
    peeks: ROUND_PEEKS[r]!,
    showMs: SHOW_MS[r]!,
  }));
  return { rounds };
}

/* ------------------------------------------------------------------ */
/*  Population model + grading                                         */
/* ------------------------------------------------------------------ */

/**
 * Map the mean round score onto the IQ scale (mean 100, SD 15).
 * Each round's (hits - wrong) / size is floored at 0 BEFORE averaging,
 * so a spray-everything strategy earns exactly the floor, not a boost.
 */
export function patternIndex(accuracy: number): number {
  const clamped = Math.min(1, Math.max(0, accuracy));
  const iq = Math.round(100 + (15 * (clamped - SCORE_MEAN)) / SCORE_SD);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  // Normal CDF via erf approximation (Abramowitz & Stegun 7.1.26).
  const erf = (x: number): number => {
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * ax);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-ax * ax);
    return sign * y;
  };
  const z = (iq - 100) / 15;
  const pct = 0.5 * (1 + erf(z / Math.SQRT2)) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): PatternGrade {
  if (iq < 85) {
    return {
      label: "Fading",
      blurb: "The shorter flashes are wiping your patterns right now - a second run usually settles the rhythm of the task and lifts the number.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - you hold tile patterns about as well as the general population as the hints disappear.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Sharp",
      blurb: "Better than most - you chunk lit tiles into shapes and rebuild them cleanly even with the peek budget gone.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier pattern memory - the kind of visual precision that shines in design, engineering and map reading.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Photographic",
    blurb: "Elite recall - near-perfect reproduction of every pattern from three tiles to eight, with almost nothing wasted.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a complete session from the raw recalls. Every round is scored
 * independently: hits minus wrong clicks over the pattern size, floored
 * at zero, then averaged. Wrong clicks NEVER feed the next round, and
 * spending a peek costs nothing but the safety net it provides.
 *
 * This overload is the degenerate entry (no session -> floor score);
 * production always calls scoreSessionWithSession with the session.
 */
export function scoreSession(recalls: readonly Recall[]): PatternMemoryScore {
  return scoreSessionWithSession(recalls, null);
}

/**
 * Session-aware scorer. `session` supplies the true pattern cells; when
 * null (should not happen in production) every recall scores 0 so a
 * malformed run can never inflate the index.
 */
export function scoreSessionWithSession(
  recalls: readonly Recall[],
  session: PatternMemorySession | null
): PatternMemoryScore {
  let hits = 0;
  let wrong = 0;
  let totalCells = 0;
  let rtSum = 0;
  let rtCount = 0;
  let peeksUsed = 0;
  let peeksAvailable = 0;

  const stats: RoundStat[] = [];

  if (!session) {
    // Degenerate guard: zero data in, floor out.
    const iq = patternIndex(0);
    return {
      hits: 0,
      wrong: 0,
      totalCells: 0,
      accuracy: 0,
      avgRtMs: null,
      peeksUsed: 0,
      peeksAvailable: ROUND_PEEKS.reduce((a, b) => a + b, 0),
      rounds: [],
      iq,
      percentile: iqToPercentile(iq),
      grade: gradeForIq(iq),
    };
  }

  for (const round of session.rounds) {
    const rc = recalls.find((r) => r.round === round.round);
    totalCells += round.size;
    peeksAvailable += round.peeks;
    if (!rc) {
      stats.push({ round: round.round, size: round.size, hits: 0, wrong: 0, score: 0 });
      continue;
    }
    peeksUsed += Math.min(rc.peeksUsed, round.peeks);
    const truth = new Set(round.cells);
    const clickedUnique = [...new Set(rc.clicked)].filter(
      (c) => Number.isInteger(c) && c >= 0 && c < CELL_COUNT
    );
    let roundHits = 0;
    let roundWrong = 0;
    for (const cell of clickedUnique) {
      if (truth.has(cell)) roundHits++;
      else roundWrong++;
    }
    const score = Math.max(0, (roundHits - roundWrong) / round.size);
    hits += roundHits;
    wrong += roundWrong;
    if (rc.rtMs !== null && Number.isFinite(rc.rtMs)) {
      rtSum += rc.rtMs;
      rtCount++;
    }
    stats.push({
      round: round.round,
      size: round.size,
      hits: roundHits,
      wrong: roundWrong,
      score,
    });
  }

  const accuracy =
    stats.length > 0 ? stats.reduce((a, s) => a + s.score, 0) / stats.length : 0;
  const iq = patternIndex(accuracy);

  return {
    hits,
    wrong,
    totalCells,
    accuracy,
    avgRtMs: rtCount > 0 ? rtSum / rtCount : null,
    peeksUsed,
    peeksAvailable,
    rounds: stats,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
