"use client";

/* ------------------------------------------------------------------ */
/*  Processing Speed Test - interactive UI                             */
/*  Symbol-Digit Coding sprint: study the key, then match symbols to   */
/*  digits as fast as possible for 90 seconds. Tap the pad or press    */
/*  the digit keys. Scoring lives in processing-speed-core.ts.         */
/*                                                                     */
/*  Testing hook: /test/processing-speed?quick=1 shortens the sprint   */
/*  to 15s so automated flow tests can run two full sessions quickly.  */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Gauge, Keyboard, MousePointerClick, RotateCcw, Timer, TrendingDown, TrendingUp, Zap } from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  DURATION_MS,
  EPOCH_COUNT,
  QUICK_DURATION_MS,
  buildCodingKey,
  formatClock,
  mulberry32,
  nextSymbol,
  recordTrial,
  scoreSession,
  type CodingKey,
  type SessionScore,
} from "./processing-speed-core";

type Phase = "intro" | "countdown" | "active" | "results";

type Flash = { digit: number; correct: boolean; id: number } | null;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("processing-speed-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function ProcessingSpeedTest() {
  const searchParams = useSearchParams();
  const duration = useMemo(
    () => (searchParams.get("quick") === "1" ? QUICK_DURATION_MS : DURATION_MS),
    [searchParams]
  );

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [sessionKey, setSessionKey] = useState<CodingKey | null>(null);
  const [currentSymbol, setCurrentSymbol] = useState("");
  const [remainingMs, setRemainingMs] = useState(duration);
  const [correctCount, setCorrectCount] = useState(0);
  const [errorCount, setErrorCount] = useState(0);
  const [flash, setFlash] = useState<Flash>(null);
  const [score, setScore] = useState<SessionScore | null>(null);

  const trialsRef = useRef<import("./processing-speed-core").TrialRecord[]>([]);
  const rngRef = useRef<() => number>(() => 0.5);
  const keyRef = useRef<CodingKey | null>(null);
  const symbolRef = useRef("");
  const lastTwoRef = useRef<[string | null, string | null]>([null, null]);
  const sessionStartRef = useRef(0);
  const trialStartRef = useRef(0);
  const phaseRef = useRef<Phase>("intro");
  const finishedRef = useRef(false);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  /* ------------------------- session flow ------------------------- */

  const start = useCallback(() => {
    const seed =
      (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const rng = mulberry32(seed);
    const key = buildCodingKey(rng);
    rngRef.current = rng;
    keyRef.current = key;
    trialsRef.current = [];
    lastTwoRef.current = [null, null];
    finishedRef.current = false;
    setSessionKey(key);
    setCorrectCount(0);
    setErrorCount(0);
    setScore(null);
    setFlash(null);
    setRemainingMs(duration);
    setCountdownValue(3);
    setPhase("countdown");
    // Align the card immediately so the countdown key is actually in view.
    requestAnimationFrame(() => scrollToApp(false));
  }, [duration]);

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    const result = scoreSession(trialsRef.current, duration);
    setScore(result);
    setPhase("results");
    // Bring the score into view - the user is scrolled mid-card after the sprint.
    requestAnimationFrame(() => scrollToApp(true));
  }, [duration]);

  const beginSprint = useCallback(() => {
    const key = keyRef.current;
    const rng = rngRef.current;
    if (!key) return;
    const first = nextSymbol(key, rng, [null, null]);
    lastTwoRef.current = [null, first];
    symbolRef.current = first;
    setCurrentSymbol(first);
    const now = performance.now();
    sessionStartRef.current = now;
    trialStartRef.current = now;
    setRemainingMs(duration);
    setPhase("active");
    // Safety re-align in case the user scrolled during the countdown.
    requestAnimationFrame(() => scrollToApp(false));
  }, [duration]);

  /* Countdown 3-2-1, key visible so users can study the mapping. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginSprint();
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginSprint]);

  /* --------------------------- responding -------------------------- */

  const respond = useCallback((digit: number) => {
    if (phaseRef.current !== "active") return;
    const key = keyRef.current;
    const symbol = symbolRef.current;
    if (!key || !symbol) return;

    const now = performance.now();
    const trial = recordTrial(
      key,
      symbol,
      digit,
      now - trialStartRef.current,
      now - sessionStartRef.current
    );
    trialsRef.current.push(trial);

    if (trial.correct) setCorrectCount((c) => c + 1);
    else setErrorCount((e) => e + 1);

    setFlash({ digit, correct: trial.correct, id: now });
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    flashTimerRef.current = setTimeout(() => setFlash(null), 180);

    // Advance on every response - errors cost time, correctness is what counts.
    const next = nextSymbol(key, rngRef.current, lastTwoRef.current);
    lastTwoRef.current = [lastTwoRef.current[1], next];
    symbolRef.current = next;
    setCurrentSymbol(next);
    trialStartRef.current = performance.now();
  }, []);

  /* Keyboard input: the mapped digit keys respond, others ignored. */
  useEffect(() => {
    if (phase !== "active") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      const digit = Number(event.key);
      if (!Number.isInteger(digit) || digit < 1 || digit > 9) return;
      const key = keyRef.current;
      if (!key || !key.padDigits.includes(digit)) return;
      event.preventDefault();
      respond(digit);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, respond]);

  /* Sprint timer. */
  useEffect(() => {
    if (phase !== "active") return;
    const started = sessionStartRef.current;
    const interval = setInterval(() => {
      const remaining = duration - (performance.now() - started);
      if (remaining <= 0) {
        setRemainingMs(0);
        finish();
      } else {
        setRemainingMs(remaining);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [phase, duration, finish]);

  useEffect(() => {
    return () => {
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- derived data -------------------------- */

  const progressPct = Math.max(0, Math.min(100, (remainingMs / duration) * 100));
  const maxEpochCorrect = score?.epochs.reduce((m, e) => Math.max(m, e.correct), 1) ?? 1;
  const paceInsight = useMemo(() => {
    if (!score || score.epochs.length < 4) return null;
    const half = Math.ceil(score.epochs.length / 2);
    const firstHalf =
      score.epochs.slice(0, half).reduce((a, e) => a + e.correct, 0) / half;
    const secondHalf =
      score.epochs.slice(half).reduce((a, e) => a + e.correct, 0) /
      (score.epochs.length - half);
    if (secondHalf > firstHalf * 1.15) {
      return {
        icon: TrendingUp,
        text: "You warmed up as you went - your second half was faster than your first. A second attempt often starts stronger.",
      };
    }
    if (secondHalf < firstHalf * 0.85) {
      return {
        icon: TrendingDown,
        text: "Your pace dipped in the second half - classic mental fatigue. Short breaks and practice runs help stamina.",
      };
    }
    return {
      icon: Zap,
      text: "Remarkably steady pacing - you held the same tempo from start to finish.",
    };
  }, [score]);

  const demoKey = useMemo(() => buildCodingKey(mulberry32(20240607)), []);

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="processing-speed-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="ps-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Gauge className="h-3.5 w-3.5" aria-hidden="true" />
                Symbol-Digit Coding · {duration === QUICK_DURATION_MS ? "15-second" : "90-second"} sprint
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Match every symbol to its digit
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                A key pairs six symbols with six digits. Symbols appear one at a
                time - find the symbol in the key and tap its digit as fast as
                you can. How many can you land in{" "}
                {duration === QUICK_DURATION_MS ? "15 seconds" : "90 seconds"}?
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-md rounded-xl border border-border bg-muted/60 p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Example key
              </p>
              <div className="mt-2 grid grid-cols-6 gap-2">
                {demoKey.pairs.map((pair) => (
                  <div key={pair.symbol} className="text-center">
                    <div className="text-2xl text-foreground" aria-hidden="true">
                      {pair.symbol}
                    </div>
                    <div className="mt-0.5 text-sm font-bold text-primary">{pair.digit}</div>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                Your real key is randomised every attempt.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                One continuous {duration === QUICK_DURATION_MS ? "15-second" : "90-second"} sprint - the clock does not stop.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Tap the digit pad, or use your keyboard number keys for max speed.
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Accuracy matters: only correct matches count, and random tapping (under 60% accuracy) is not scored.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="ps-start"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Gauge className="h-5 w-5" aria-hidden="true" />
                Start the sprint
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && sessionKey && (
          <motion.div
            key="countdown"
            data-testid="ps-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Study the key
            </p>
            <div className="mt-4 grid grid-cols-6 gap-2 rounded-xl border border-border bg-muted/60 p-4">
              {sessionKey.pairs.map((pair, i) => (
                <div
                  key={pair.symbol}
                  data-testid={`ps-key-pair-${i}`}
                  className="text-center"
                >
                  <div className="text-2xl text-foreground sm:text-3xl" aria-hidden="true">
                    {pair.symbol}
                  </div>
                  <div className="mt-1 text-base font-bold text-primary sm:text-lg">{pair.digit}</div>
                </div>
              ))}
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && sessionKey && (
          <motion.div
            key="active"
            data-testid="ps-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Timer + live counters */}
            <div className="flex items-center justify-between gap-3">
              <span
                data-testid="ps-timer"
                className="text-2xl font-black tabular-nums text-foreground sm:text-3xl"
              >
                {formatClock(remainingMs)}
              </span>
              <div className="flex items-center gap-2 text-sm">
                <span
                  data-testid="ps-correct"
                  className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 font-semibold text-emerald-700 tabular-nums"
                >
                  {correctCount} correct
                </span>
                <span
                  data-testid="ps-errors"
                  className="rounded-full border border-red-200 bg-red-50 px-3 py-1 font-semibold text-red-600 tabular-nums"
                >
                  {errorCount} wrong
                </span>
              </div>
            </div>
            <div
              className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Time remaining"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(progressPct)}
            >
              <div
                data-testid="ps-timer-bar"
                className="h-full rounded-full bg-primary transition-[width] duration-100 ease-linear"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            {/* Coding key */}
            <div
              data-testid="ps-key"
              className="mt-4 grid grid-cols-6 gap-1.5 rounded-xl border border-border bg-muted/60 p-2 sm:gap-3 sm:p-3"
            >
              {sessionKey.pairs.map((pair, i) => (
                <div
                  key={pair.symbol}
                  data-testid={`ps-key-pair-${i}`}
                  data-symbol={pair.symbol}
                  data-digit={pair.digit}
                  className="text-center"
                >
                  <div className="text-lg text-foreground sm:text-2xl" aria-hidden="true">
                    {pair.symbol}
                  </div>
                  <div className="text-xs font-bold text-primary sm:text-sm">{pair.digit}</div>
                </div>
              ))}
            </div>

            {/* Current symbol */}
            <div className="mt-5 flex min-h-28 items-center justify-center rounded-xl border border-border bg-secondary/70 py-4 sm:min-h-32">
              <span
                key={currentSymbol}
                data-testid="ps-symbol"
                aria-label={`Symbol ${currentSymbol}`}
                className="select-none text-6xl leading-none text-foreground sm:text-7xl"
              >
                {currentSymbol}
              </span>
            </div>

            {/* Response pad */}
            <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-6 sm:gap-3">
              {sessionKey.padDigits.map((digit) => {
                const isFlashing = flash?.digit === digit;
                return (
                  <button
                    key={digit}
                    type="button"
                    data-testid={`ps-pad-${digit}`}
                    aria-label={`Digit ${digit}`}
                    onClick={() => respond(digit)}
                    className={[
                      "h-14 rounded-xl border text-xl font-bold tabular-nums transition-[background-color,border-color,color,translate] duration-100 sm:h-16",
                      isFlashing
                        ? flash!.correct
                          ? "border-emerald-600 bg-emerald-600 text-white"
                          : "border-red-500 bg-red-500 text-white"
                        : "border-border bg-card text-foreground hover:-translate-y-0.5 hover:border-primary hover:text-primary active:translate-y-0",
                    ].join(" ")}
                  >
                    {digit}
                  </button>
                );
              })}
            </div>

            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
              <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
              Tip: number keys work too - {sessionKey.padDigits.join(", ")}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="ps-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            {score.valid ? (
              <div className="mx-auto max-w-2xl">
                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                    Your result
                  </p>
                  <div className="mt-2 flex items-end justify-center gap-2">
                    <span
                      data-testid="ps-psi"
                      className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                    >
                      <CountUp to={score.psi} duration={1.4} />
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Processing Speed Index · mean 100, SD 15
                  </p>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                    <span
                      data-testid="ps-grade"
                      className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                    >
                      <Gauge className="h-4 w-4" aria-hidden="true" />
                      {score.grade.label}
                    </span>
                    <span
                      data-testid="ps-percentile"
                      className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                    >
                      Faster than {score.percentile} in 100 adults
                    </span>
                  </div>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    {score.grade.blurb}
                  </p>
                </div>

                {/* Stat grid */}
                <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  <div data-testid="ps-stat-rate" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.ratePerMin.toFixed(1)}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">correct per minute</p>
                  </div>
                  <div data-testid="ps-stat-accuracy" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round(score.accuracy * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">accuracy</p>
                  </div>
                  <div data-testid="ps-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {(score.meanRtMs / 1000).toFixed(2)}s
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">avg time per correct item</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">{score.correct}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">correct · {score.errors} wrong</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">{score.bestStreak}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">best streak</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round(score.cv * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">pace consistency (lower is steadier)</p>
                  </div>
                </div>

                {/* Throughput profile */}
                <div className="mt-8">
                  <p className="text-sm font-semibold text-foreground">
                    Throughput across the sprint
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Correct answers in each {Math.round(duration / 1000 / EPOCH_COUNT)}-second slice
                  </p>
                  <div className="mt-3 flex h-28 items-end gap-2" data-testid="ps-epochs">
                    {score.epochs.map((epoch, i) => (
                      <div key={i} className="flex flex-1 flex-col items-center justify-end gap-1">
                        <motion.div
                          data-testid={`ps-epoch-${i}`}
                          initial={{ height: 4 }}
                          animate={{ height: Math.max(6, (epoch.correct / maxEpochCorrect) * 84) }}
                          transition={{ duration: 0.6, delay: 0.15 + i * 0.08, ease: "easeOut" }}
                          className="w-full rounded-t-md bg-primary/85"
                        />
                        <span className="text-xs font-semibold tabular-nums text-foreground">
                          {epoch.correct}
                        </span>
                      </div>
                    ))}
                  </div>
                  {paceInsight && (
                    <p className="mt-3 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm leading-relaxed text-emerald-800">
                      <paceInsight.icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                      {paceInsight.text}
                    </p>
                  )}
                </div>

                <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button
                    type="button"
                    data-testid="ps-retake"
                    onClick={start}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    Retake - new random key
                  </button>
                  <a
                    href="/test"
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                  >
                    Try the Full IQ Test
                  </a>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-xl text-center" data-testid="ps-invalid">
                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-amber-200 bg-amber-50 text-2xl" aria-hidden="true">
                  ⚠️
                </span>
                <h3 className="mt-4 text-xl font-bold text-foreground">
                  This sprint was not scored
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {score.invalidReason}
                </p>
                <div className="mx-auto mt-5 grid max-w-sm grid-cols-3 gap-3 text-sm">
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums">{score.attempts}</p>
                    <p className="text-xs text-muted-foreground">responses</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-emerald-700">{score.correct}</p>
                    <p className="text-xs text-muted-foreground">correct</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-red-600">{score.errors}</p>
                    <p className="text-xs text-muted-foreground">wrong</p>
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="ps-retake"
                  onClick={start}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color] hover:-translate-y-0.5 hover:bg-emerald-700"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Try again - carefully this time
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
