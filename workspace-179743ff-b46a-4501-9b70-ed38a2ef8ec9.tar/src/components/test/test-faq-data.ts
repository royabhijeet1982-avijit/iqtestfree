export type TestFaqItem = {
  question: string;
  answer: string;
};

/**
 * FAQ content specific to the Full IQ Test page.
 * Single source of truth: imported by both the visible FAQ section and
 * the FAQPage JSON-LD on /test so they can never drift apart.
 */
export const TEST_FAQ_ITEMS: TestFaqItem[] = [
  {
    question: "How do the three age groups work?",
    answer:
      "Before the test starts you pick one of three groups: Kids (ages 7-12), Teens (13-17) or Adults (18+). Each group has its own completely separate bank of 10 hand-built question sets - kids get playful puzzles with easy words and friendly numbers, teens get school-smart brainteasers, and adults get classic IQ-style items with trickier logic. Kids' questions never appear in the teen or adult tests, and no two groups share a single question.",
  },
  {
    question: "Will I see the same questions every time I visit?",
    answer:
      "No. Every visit and every attempt deals a fresh set of 12 questions from your age group's bank of 10 hand-built sets - a different set each time, with question options reshuffled so answers never sit in the same position twice. With 30 sets across the three age groups plus reshuffling, you can take the test again and again without seeing the same paper.",
  },
  {
    question: "How is the estimated IQ score calculated?",
    answer:
      "Your score is estimated from the number of correctly answered questions across logic, verbal, numerical, pattern, memory and spatial items, mapped onto a standard IQ-style scale where 100 is the population average. Each set keeps a similar mix of easier and harder questions so scores stay comparable between attempts. It is an educational estimate for self-exploration - not a clinically administered assessment.",
  },
  {
    question: "How long does the test take?",
    answer:
      "A set has 12 questions and most people finish in 5 to 10 minutes. There is no enforced time limit - a timer only tracks your elapsed time, so you can think each question through at your own pace.",
  },
  {
    question: "Can I retake the test or switch age groups?",
    answer:
      "Yes, as often as you like - every attempt is free and needs no account. Each retake draws a brand-new set of 12 questions (never the same set twice in a row), and the 'Change age group' button on the results screen takes you straight back to the picker so a younger sibling or parent can try their own level.",
  },
  {
    question: "What does the Full IQ Test measure?",
    answer:
      "It samples several cognitive domains in one short sitting: logical reasoning, verbal understanding, numerical thinking, pattern recognition, attention to detail, working memory and spatial thinking. Every set covers all of these areas, and your results screen shows a breakdown for each, so you can see where you are strongest.",
  },
  {
    question: "Is my result comparable to a professional IQ test?",
    answer:
      "No. Professional assessments such as WISC and WAIS are individually administered, timed and normed under controlled conditions for a specific age range. This test is a fun, free approximation designed for education and self-exploration - treat the score as a starting point, not a label.",
  },
];
