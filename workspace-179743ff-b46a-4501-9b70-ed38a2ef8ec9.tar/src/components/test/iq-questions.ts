import {
  type AgeGroup,
  type IqSet,
  SET_SIZE,
  expandRawSet,
  withShuffledOptions,
} from "./quiz-core";
import { KIDS_RAW_SETS } from "./age-sets-kids";
import { TEENS_RAW_SETS } from "./age-sets-teens";
import { ADULTS_RAW_SETS } from "./age-sets-adults";

/* Re-export the shared quiz vocabulary so components import from here. */
export * from "./quiz-core";

/* ------------------------------------------------------------------ */
/*  Age-group set serving                                             */
/* ------------------------------------------------------------------ */

/**
 * Authored sets per age group. Every group owns a completely separate
 * bank of 10 hand-built sets — kids' questions never appear in the teen
 * or adult tracks, and vice versa.
 */
const AUTHORED_SETS: Record<AgeGroup, IqSet[]> = {
  kids: KIDS_RAW_SETS.map((raw, i) => expandRawSet(raw, i, 0, "kids")),
  teens: TEENS_RAW_SETS.map((raw, i) => expandRawSet(raw, i, 100, "teens")),
  adults: ADULTS_RAW_SETS.map((raw, i) => expandRawSet(raw, i, 200, "adults")),
};

export const AGE_SETS = AUTHORED_SETS;

export const KIDS_QUESTION_COUNT = AUTHORED_SETS.kids.reduce(
  (n, s) => n + s.questions.length,
  0
);

/** Total authored sets across all age groups (30). */
export const TOTAL_SET_COUNT = Object.values(AUTHORED_SETS).reduce(
  (n, pool) => n + pool.length,
  0
);

/** Total authored questions across all age groups (360). */
export const TOTAL_QUESTION_COUNT = Object.values(AUTHORED_SETS).reduce(
  (n, pool) => n + pool.reduce((m, set) => m + set.questions.length, 0),
  0
);

/**
 * Serves the set for one attempt: picks a random hand-built set from the
 * chosen group's own bank — never the same one as the previous attempt
 * when an alternative exists — and reshuffles every question's options so
 * answers never sit in the same position twice.
 */
export function pickSetFor(group: AgeGroup, excludeId?: number): IqSet {
  const pool = AUTHORED_SETS[group];
  const candidates =
    excludeId == null || pool.length <= 1
      ? pool
      : pool.filter((s) => s.id !== excludeId);
  const from = candidates.length > 0 ? candidates : pool;
  const set = from[Math.floor(Math.random() * from.length)];
  return { ...set, questions: set.questions.map(withShuffledOptions) };
}
