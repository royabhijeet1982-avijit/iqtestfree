/* ------------------------------------------------------------------ */
/*  Sequence Memory Test - FAQ (single source)                         */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type SmFaq = { question: string; answer: string };

export const SEQUENCE_MEMORY_FAQS: SmFaq[] = [
  {
    question: "What is sequence memory and what does the span score mean?",
    answer:
      "Sequence memory is your ability to hold an ordered stream of information in mind and extend it one step at a time. This test expresses that ability as a span: the number of levels you cleared before a wrong tap ended the run. A span of six means you reproduced a six-tile sequence perfectly, in order, after watching it flash once. Every extra level forces your brain to keep every earlier tile alive while attaching one more position to the end, which is why spans feel dramatically harder near your personal ceiling.",
  },
  {
    question: "How is this different from the Visual Memory (Corsi) test?",
    answer:
      "Both tests use a grid of flashing tiles, but the mechanics are deliberately different. Visual Memory deals a brand-new random pattern at every level, gives you two lives with retries, and adds a small speed component to the score. Sequence Memory gives you ONE sequence for the whole run that grows by a single tile per level and replays from the start each time; there are no retries, no speed bonus, and one wrong tap ends everything. It is a purer, harsher measure of forward retention versus the Corsi task's broader sampling.",
  },
  {
    question: "What strategies actually help me remember longer sequences?",
    answer:
      "Chunking is the big one: instead of nine separate tiles, see them as shapes - a diagonal line, a corner sweep, an L, a repeated pair. Because the same sequence replays every level, you can also build a rhythm or a silent story: 'top-left, middle, middle again, bottom-right'. Verbal rehearsal (quietly naming positions as they light) anchors spatial memory through a second channel. Finally, keep your tapping pace steady; confident clicking protects the trace better than hesitant second-guessing.",
  },
  {
    question: "How does my score map to an IQ-scale number?",
    answer:
      "Your span is compared against an adult population model with a mean of about 7.4 levels and a standard deviation of 1.5. That z-score is mapped straight onto the standard IQ scale (mean 100, SD 15) with no other ingredients: sequence memory is deliberately a pure-span test, so a fast player and a slow player with the same span get the same index. A percentile estimate comes from the same normal model, and scores are clamped to the 55-145 range that all BrainMetrics tests use.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "Most adults land between five and nine levels, with around seven being typical. Clearing ten or eleven puts you well inside the top few percent, and anything beyond twelve is exceptional - that is expert memory-athlete territory on this kind of task. Because a single mistake ends the run, scores wobble by a level or two between attempts even for the same person; treat your best run as your peak and your average of two or three runs as your honest baseline.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free and every run reseeds a brand-new random sequence, so there is nothing to memorise between attempts. Expect a small warm-up effect: the second run is often your best because the mechanics feel automatic. For tracking real change, run the test two or three times in a sitting and compare weekly, not hourly. Sleep, attention and caffeine all move sequence span by a level or so, which is normal variation rather than genuine cognitive change.",
  },
];
