/* ------------------------------------------------------------------ */
/*  Processing Speed Test - pure scoring engine                        */
/*  Paradigm: Symbol-Digit Coding (digit-symbol substitution), the     */
/*  same family of tasks behind the WAIS Processing Speed Index.       */
/*                                                                     */
/*  A key maps 6 symbols to 6 digits. Symbols flash one at a time;     */
/*  the user taps/keys the matching digit as fast as possible for a    */
/*  fixed 90-second sprint. Score = accuracy-safe throughput:          */
/*  correct items per minute, anchored to a normal population model.   */
/*                                                                     */
/*  Anti-gaming:                                                       */
/*   - The symbol->digit mapping is re-randomised every attempt, so    */
/*     practising one key does not carry over.                         */
/*   - Random mashing lands near 1/6 accuracy (~17%), far below the    */
/*     60% floor -> the session is flagged invalid and not scored.     */
/*   - Only CORRECT items count; errors cost time and never add.       */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** The six glyphs used in the coding key (all widely supported). */
export const CODE_SYMBOLS = ["\u25C6", "\u25CF", "\u25B2", "\u25A0", "\u25CB", "\u271A"] as const;

/** Sprint length. 90s matches the classic paper coding blocks. */
export const DURATION_MS = 90_000;

/** Shortened sprint used by automated flow tests via ?quick=1. */
export const QUICK_DURATION_MS = 15_000;

/** Throughput profile buckets (default 6 x 15s for the 90s sprint). */
export const EPOCH_COUNT = 6;

/** Sessions below this many responses cannot be scored. */
export const MIN_ATTEMPTS = 10;

/** Accuracy floor - below this the session is flagged as too random. */
export const ACCURACY_FLOOR = 0.6;

/** Population model for correct-items-per-minute (adult casual web users).
 *  A median click-based user matches one 6-pair item roughly every
 *  2.4s (~25 correct/min in a 90s sprint); skilled keyboard users
 *  reach 35+/min and elite sprinters 45+/min. */
export const RATE_MEAN = 25;
export const RATE_SD = 6;

export const PSI_MIN = 55;
export const PSI_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type KeyPair = { symbol: string; digit: number };

/** A full session key: 6 pairs plus a shuffled response-pad order. */
export type CodingKey = {
  /** 6 pairs in fixed key-display order (stable for the whole sprint). */
  pairs: KeyPair[];
  /** Response-pad display order (shuffled digits, stable all session). */
  padDigits: number[];
  /** digit -> symbol lookup for scoring keyboard/pad responses. */
  byDigit: Record<number, string>;
};

export type TrialRecord = {
  symbol: string;
  response: number;
  correct: boolean;
  /** Reaction time of this trial in ms (pad click or key press). */
  rtMs: number;
  /** Elapsed time since sprint start in ms (for epoch bucketing). */
  timeMs: number;
};

export type EpochStat = { correct: number; attempts: number; ratePerMin: number };

export type SpeedGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SessionScore = {
  attempts: number;
  correct: number;
  errors: number;
  /** correct / attempts, 0..1 */
  accuracy: number;
  /** Correct items per minute. */
  ratePerMin: number;
  /** RT stats over CORRECT trials only. */
  meanRtMs: number;
  sdRtMs: number;
  /** Coefficient of variation (sd/mean) - lower = more consistent. */
  cv: number;
  /** Longest run of consecutive correct responses. */
  bestStreak: number;
  epochs: EpochStat[];
  /** Processing Speed Index (IQ-anchored, mean 100 / SD 15). */
  psi: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: SpeedGrade;
  valid: boolean;
  invalidReason: string | null;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Key construction                                                   */
/* ------------------------------------------------------------------ */

/**
 * Build a fresh coding key. 6 distinct digits are drawn from 1..9 and
 * paired with the 6 glyphs in shuffled order, so both the mapping and
 * the key's visual order change every attempt. The response-pad order
 * is shuffled independently of the key order.
 */
export function buildCodingKey(rng: () => number): CodingKey {
  const allDigits = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  const digits = shuffle(allDigits, rng).slice(0, CODE_SYMBOLS.length);
  const symbols = shuffle(CODE_SYMBOLS, rng);
  const pairs: KeyPair[] = symbols.map((symbol, i) => ({
    symbol,
    digit: digits[i] as number,
  }));
  const byDigit: Record<number, string> = {};
  for (const pair of pairs) byDigit[pair.digit] = pair.symbol;
  const padDigits = shuffle(pairs.map((p) => p.digit), rng);
  return { pairs, padDigits, byDigit };
}

/** Digits that exist in the key (for wiring keyboard input). */
export function keyDigits(key: CodingKey): number[] {
  return key.pairs.map((p) => p.digit).sort((a, b) => a - b);
}

/** Digit to press for a given symbol (null if the symbol is unknown). */
export function digitForSymbol(key: CodingKey, symbol: string): number | null {
  const pair = key.pairs.find((p) => p.symbol === symbol);
  return pair ? pair.digit : null;
}

/* ------------------------------------------------------------------ */
/*  Symbol stream                                                      */
/* ------------------------------------------------------------------ */

/**
 * Pick the next symbol. Uniformly random, but a symbol never appears
 * three times in a row (looks broken to users) - pass the last two
 * shown symbols to enforce that.
 */
export function nextSymbol(
  key: CodingKey,
  rng: () => number,
  lastTwo: readonly [string | null, string | null]
): string {
  const [twoAgo, oneAgo] = lastTwo;
  const candidate = key.pairs[Math.floor(rng() * key.pairs.length)]!.symbol;
  if (oneAgo !== null && twoAgo !== null && oneAgo === twoAgo && candidate === oneAgo) {
    // Would be a third consecutive repeat - redraw once, then accept.
    const redraw = key.pairs[Math.floor(rng() * key.pairs.length)]!.symbol;
    if (redraw !== oneAgo) return redraw;
    const others = key.pairs.map((p) => p.symbol).filter((s) => s !== oneAgo);
    return others[Math.floor(rng() * others.length)]!;
  }
  return candidate;
}

/* ------------------------------------------------------------------ */
/*  Trial recording                                                    */
/* ------------------------------------------------------------------ */

/** Immutable-ish single trial step: evaluate a response against the key. */
export function recordTrial(
  key: CodingKey,
  symbol: string,
  response: number,
  rtMs: number,
  timeMs: number
): TrialRecord {
  const expected = digitForSymbol(key, symbol);
  return {
    symbol,
    response,
    correct: expected !== null && response === expected,
    rtMs,
    timeMs,
  };
}

/* ------------------------------------------------------------------ */
/*  Statistics                                                         */
/* ------------------------------------------------------------------ */

/** Bucket trials into EPOCH_COUNT equal time slices of durationMs. */
export function computeEpochs(
  trials: readonly TrialRecord[],
  durationMs: number,
  epochCount: number = EPOCH_COUNT
): EpochStat[] {
  const epochMs = durationMs / epochCount;
  const epochs: EpochStat[] = Array.from({ length: epochCount }, () => ({
    correct: 0,
    attempts: 0,
    ratePerMin: 0,
  }));
  for (const trial of trials) {
    const idx = Math.min(epochCount - 1, Math.floor(trial.timeMs / epochMs));
    const epoch = epochs[idx]!;
    epoch.attempts += 1;
    if (trial.correct) epoch.correct += 1;
  }
  const minutesPerEpoch = epochMs / 60_000;
  for (const epoch of epochs) {
    epoch.ratePerMin = minutesPerEpoch > 0 ? epoch.correct / minutesPerEpoch : 0;
  }
  return epochs;
}

/** Longest run of consecutive correct trials. */
export function bestStreakOf(trials: readonly TrialRecord[]): number {
  let best = 0;
  let run = 0;
  for (const trial of trials) {
    if (trial.correct) {
      run += 1;
      if (run > best) best = run;
    } else {
      run = 0;
    }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/**
 * Map correct-per-minute to a Processing Speed Index (mean 100, SD 15).
 * Rate is soft-clamped into [0, 60] first so absurd values cannot push
 * the index out of range.
 */
export function rateToPsi(ratePerMin: number): number {
  const clamped = Math.min(60, Math.max(0, ratePerMin));
  const z = (clamped - RATE_MEAN) / RATE_SD;
  const psi = Math.round(100 + 15 * z);
  return Math.min(PSI_MAX, Math.max(PSI_MIN, psi));
}

/** PSI -> population percentile (1..99), normal model with SD 15. */
export function psiToPercentile(psi: number): number {
  const pct = normalCdf(psi, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the PSI. */
export function gradeForPsi(psi: number): SpeedGrade {
  if (psi < 85) {
    return {
      label: "Deliberate",
      blurb: "Careful and steady - accuracy first, speed will follow with practice.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (psi < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most people - a solid, dependable pace.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (psi < 115) {
    return {
      label: "Quick",
      blurb: "Faster than most - you scan, decide and respond with ease.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (psi < 130) {
    return {
      label: "Very quick",
      blurb: "Top-tier tempo - visual search and decisions come rapidly.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite processing speed - the top few percent of sprinters.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a full sprint.
 *
 * Validity rules (anti-gaming):
 *  - fewer than MIN_ATTEMPTS responses -> invalid (not enough data)
 *  - accuracy < ACCURACY_FLOOR -> invalid (responses look random;
 *    chance level with 6 pad buttons is ~17%)
 *
 * Scoring model: only correct items count. ratePerMin is correct per
 * minute of sprint time, mapped to the population model above.
 */
export function scoreSession(
  trials: readonly TrialRecord[],
  durationMs: number
): SessionScore {
  const attempts = trials.length;
  const correctTrials = trials.filter((t) => t.correct);
  const correct = correctTrials.length;
  const errors = attempts - correct;
  const accuracy = attempts > 0 ? correct / attempts : 0;
  const ratePerMin = durationMs > 0 ? (correct * 60_000) / durationMs : 0;

  const rts = correctTrials.map((t) => t.rtMs).filter((rt) => rt >= 0);
  const meanRtMs = rts.length > 0 ? rts.reduce((a, b) => a + b, 0) / rts.length : 0;
  const variance =
    rts.length > 1
      ? rts.reduce((acc, rt) => acc + (rt - meanRtMs) ** 2, 0) / (rts.length - 1)
      : 0;
  const sdRtMs = Math.sqrt(variance);
  const cv = meanRtMs > 0 ? sdRtMs / meanRtMs : 0;

  if (attempts === 0) {
    return invalidScore(trials, durationMs, "No responses were recorded.");
  }
  if (attempts < MIN_ATTEMPTS) {
    return invalidScore(
      trials,
      durationMs,
      `Only ${attempts} response${attempts === 1 ? "" : "s"} recorded - at least ${MIN_ATTEMPTS} are needed to score a sprint.`
    );
  }
  if (accuracy < ACCURACY_FLOOR) {
    return invalidScore(
      trials,
      durationMs,
      `Accuracy was ${Math.round(accuracy * 100)}% - below the ${Math.round(
        ACCURACY_FLOOR * 100
      )}% floor, so the responses look too random to score. Take your time and match carefully.`
    );
  }

  const psi = rateToPsi(ratePerMin);

  return {
    attempts,
    correct,
    errors,
    accuracy,
    ratePerMin,
    meanRtMs,
    sdRtMs,
    cv,
    bestStreak: bestStreakOf(trials),
    epochs: computeEpochs(trials, durationMs),
    psi,
    percentile: psiToPercentile(psi),
    grade: gradeForPsi(psi),
    valid: true,
    invalidReason: null,
  };
}

function invalidScore(
  trials: readonly TrialRecord[],
  durationMs: number,
  reason: string
): SessionScore {
  const attempts = trials.length;
  const correct = trials.filter((t) => t.correct).length;
  void durationMs;
  return {
    attempts,
    correct,
    errors: attempts - correct,
    accuracy: attempts > 0 ? correct / attempts : 0,
    ratePerMin: 0,
    meanRtMs: 0,
    sdRtMs: 0,
    cv: 0,
    bestStreak: bestStreakOf(trials),
    epochs: [],
    psi: 0,
    percentile: 0,
    grade: {
      label: "Not scored",
      blurb: reason,
      className: "bg-amber-50 text-amber-800 border-amber-200",
    },
    valid: false,
    invalidReason: reason,
  };
}

/* ------------------------------------------------------------------ */
/*  Formatting helpers (used by the UI, tested for stability)          */
/* ------------------------------------------------------------------ */

/** 83450 -> "1:23". */
export function formatClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}
