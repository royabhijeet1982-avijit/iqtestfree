"use client";

/* ------------------------------------------------------------------ */
/*  Stroop Test - interactive UI                                       */
/*  Classic color-word interference: a colour word is printed in a     */
/*  possibly different ink colour and the user responds to the INK     */
/*  with four colour buttons or the R / G / B / Y keys.                */
/*  Scoring lives in stroop-test-core.ts.                              */
/*                                                                     */
/*  Testing hook: /test/stroop-test?quick=1 runs 12 trials instead of  */
/*  60 so automated flow tests can complete full sessions quickly.     */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Keyboard,
  MousePointerClick,
  Palette,
  RotateCcw,
  Timer,
  TriangleAlert,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  COLOR_BY_ID,
  QUICK_TRIAL_COUNT,
  STROOP_COLORS,
  TRIAL_COUNT,
  buildStimuli,
  mulberry32,
  recordTrial,
  scoreSession,
  type SessionScore,
  type StroopColorId,
  type StroopStimulus,
  type StroopTrial,
} from "./stroop-test-core";

type Phase = "intro" | "countdown" | "active" | "results";

type Flash = { id: StroopColorId; correct: boolean; serial: number } | null;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("stroop-test-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

/** Static intro example: the word RED printed in blue ink. */
const DEMO_STIMULUS: StroopStimulus = { word: "red", ink: "blue", congruent: false };

/** "+37" for positive interference, "-12" for a reversal. */
function formatInterference(ms: number): string {
  const rounded = Math.round(ms);
  return rounded >= 0 ? `+${rounded}` : `${rounded}`;
}

export function StroopTest() {
  const searchParams = useSearchParams();
  const trialCount = useMemo(
    () => (searchParams.get("quick") === "1" ? QUICK_TRIAL_COUNT : TRIAL_COUNT),
    [searchParams]
  );

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [current, setCurrent] = useState<StroopStimulus | null>(null);
  const [answered, setAnswered] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [errorCount, setErrorCount] = useState(0);
  const [flash, setFlash] = useState<Flash>(null);
  const [feedback, setFeedback] = useState<{ correct: boolean; text: string } | null>(null);
  const [score, setScore] = useState<SessionScore | null>(null);

  const trialsRef = useRef<StroopTrial[]>([]);
  const stimuliRef = useRef<StroopStimulus[]>([]);
  const indexRef = useRef(0);
  const rngRef = useRef<() => number>(() => 0.5);
  const trialStartRef = useRef(0);
  const phaseRef = useRef<Phase>("intro");
  const finishedRef = useRef(false);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    phaseRef.current = "results";
    const result = scoreSession(trialsRef.current);
    setScore(result);
    setPhase("results");
    // Bring the score into view - the user is scrolled mid-card after the run.
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  const beginTrials = useCallback(() => {
    const first = stimuliRef.current[0];
    if (!first) return;
    indexRef.current = 0;
    setCurrent(first);
    trialStartRef.current = performance.now();
    phaseRef.current = "active";
    setPhase("active");
    // Safety re-align in case the user scrolled during the countdown.
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const rng = mulberry32(seed);
    rngRef.current = rng;
    stimuliRef.current = buildStimuli(rng, trialCount);
    trialsRef.current = [];
    indexRef.current = 0;
    finishedRef.current = false;
    setAnswered(0);
    setCorrectCount(0);
    setErrorCount(0);
    setScore(null);
    setFlash(null);
    setFeedback(null);
    setCurrent(null);
    setCountdownValue(3);
    phaseRef.current = "countdown";
    setPhase("countdown");
    // Align the card immediately so the countdown legend is in view.
    requestAnimationFrame(() => scrollToApp(false));
  }, [trialCount]);

  /* Countdown 3-2-1, colour legend visible so users can plan their fingers. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginTrials();
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginTrials]);

  /* --------------------------- responding -------------------------- */

  const respond = useCallback(
    (colorId: StroopColorId) => {
      if (phaseRef.current !== "active") return;
      const stimulus = stimuliRef.current[indexRef.current];
      if (!stimulus) return;

      const now = performance.now();
      const trial = recordTrial(stimulus, colorId, now - trialStartRef.current);
      trialsRef.current.push(trial);

      if (trial.correct) setCorrectCount((c) => c + 1);
      else setErrorCount((e) => e + 1);
      setAnswered((a) => a + 1);

      setFlash({ id: colorId, correct: trial.correct, serial: now });
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
      flashTimerRef.current = setTimeout(() => setFlash(null), 180);
      setFeedback({
        correct: trial.correct,
        text: trial.correct
          ? "Correct"
          : `Wrong - the ink was ${COLOR_BY_ID[stimulus.ink].label}`,
      });

      // Advance on every response - errors cost accuracy, never a re-trial.
      const nextIndex = indexRef.current + 1;
      if (nextIndex >= stimuliRef.current.length) {
        finish();
        return;
      }
      indexRef.current = nextIndex;
      const next = stimuliRef.current[nextIndex];
      if (next) setCurrent(next);
      trialStartRef.current = performance.now();
    },
    [finish]
  );

  /* Keyboard input: R / G / B / Y respond, everything else is ignored. */
  useEffect(() => {
    if (phase !== "active") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      const pressed = event.key.toUpperCase();
      const color = STROOP_COLORS.find((c) => c.key === pressed);
      if (!color) return;
      event.preventDefault();
      respond(color.id);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, respond]);

  useEffect(() => {
    return () => {
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- derived data -------------------------- */

  const progressPct = trialCount > 0 ? Math.min(100, (answered / trialCount) * 100) : 0;
  const maxBarMs =
    score?.medianCongruentMs != null && score?.medianIncongruentMs != null
      ? Math.max(score.medianCongruentMs, score.medianIncongruentMs, 1)
      : 1;
  const congWidthPct =
    score?.medianCongruentMs != null ? (score.medianCongruentMs / maxBarMs) * 100 : 0;
  const incongWidthPct =
    score?.medianIncongruentMs != null ? (score.medianIncongruentMs / maxBarMs) * 100 : 0;

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="stroop-test-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="st-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Palette className="h-3.5 w-3.5" aria-hidden="true" />
                Color-Word Interference · {trialCount} trials
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Name the ink, not the word
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                A colour word appears on screen - RED, GREEN, BLUE or YELLOW - but
                the ink it is printed in may be a completely different colour.
                Ignore what the word says and respond to the colour of the ink as
                fast as you can.
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-md rounded-xl border border-border bg-muted/60 p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Example - the ink wins
              </p>
              <div className="mt-3 flex min-h-24 items-center justify-center rounded-lg border border-border bg-card">
                <span
                  aria-label="The word Red written in Blue ink"
                  className="select-none text-5xl font-black uppercase tracking-wide"
                  style={{ color: COLOR_BY_ID[DEMO_STIMULUS.ink].hex }}
                >
                  {COLOR_BY_ID[DEMO_STIMULUS.word].label}
                </span>
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                The word reads RED, but the ink is BLUE - the correct answer is
                Blue. Words and inks are randomised on every trial.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {trialCount} words, one after another - answer each one at full speed.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Tap the colour buttons, or press R, G, B, Y on the keyboard.
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Accuracy matters: random tapping scores about 25%, and runs under the 70% floor are not scored.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="st-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Palette className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="st-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Answer with the ink colour
            </p>
            <div className="mx-auto mt-4 grid max-w-md grid-cols-2 gap-2 sm:grid-cols-4">
              {STROOP_COLORS.map((color) => (
                <div
                  key={color.id}
                  className="flex items-center justify-center gap-2 rounded-lg border border-border bg-muted/60 px-2 py-2"
                >
                  <span
                    aria-hidden="true"
                    className="size-4 shrink-0 rounded-full border border-black/10"
                    style={{ backgroundColor: color.hex }}
                  />
                  <span className="text-sm font-bold text-foreground">{color.label}</span>
                  <span className="rounded border border-border bg-card px-1 text-[11px] font-semibold text-muted-foreground">
                    {color.key}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="st-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Trial counter + live score */}
            <div className="flex items-center justify-between gap-3">
              <span
                data-testid="st-trial-count"
                className="text-sm font-semibold tabular-nums text-foreground sm:text-base"
              >
                Trial {Math.min(answered + 1, trialCount)} of {trialCount}
              </span>
              <div className="flex items-center gap-2 text-xs sm:text-sm">
                <span
                  data-testid="st-correct"
                  className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 font-semibold text-emerald-700 tabular-nums"
                >
                  {correctCount} right
                </span>
                <span
                  data-testid="st-wrong"
                  className="rounded-full border border-red-200 bg-red-50 px-3 py-1 font-semibold text-red-600 tabular-nums"
                >
                  {errorCount} wrong
                </span>
              </div>
            </div>
            <div
              className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Trials completed"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(progressPct)}
            >
              <div
                data-testid="st-progress"
                className="h-full rounded-full bg-primary transition-[width] duration-150 ease-linear"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            {/* The stimulus word */}
            <div className="mt-5 flex min-h-36 items-center justify-center rounded-2xl border border-border bg-secondary/70 py-6 sm:min-h-44">
              {current && (
                <motion.span
                  key={`${answered}-${current.word}-${current.ink}`}
                  initial={{ opacity: 0, scale: 0.94 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.12 }}
                  className="select-none"
                >
                  <span
                    data-testid="st-word"
                    data-word={current.word}
                    data-ink={current.ink}
                    aria-label={`The word ${COLOR_BY_ID[current.word].label} written in ${COLOR_BY_ID[current.ink].label} ink`}
                    className="block text-6xl font-black uppercase leading-none sm:text-7xl"
                    style={{ color: COLOR_BY_ID[current.ink].hex }}
                  >
                    {COLOR_BY_ID[current.word].label}
                  </span>
                </motion.span>
              )}
            </div>

            {/* Response feedback (height reserved to avoid layout shift) */}
            <p
              data-testid="st-feedback"
              aria-live="polite"
              className={[
                "mt-3 h-5 text-center text-sm font-semibold",
                feedback
                  ? feedback.correct
                    ? "text-emerald-700"
                    : "text-red-600"
                  : "text-muted-foreground font-normal",
              ].join(" ")}
            >
              {feedback ? feedback.text : "Tap the colour of the ink - not the word."}
            </p>

            {/* Answer pad */}
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4 sm:gap-3">
              {STROOP_COLORS.map((color, i) => {
                const isFlashing = flash?.id === color.id;
                return (
                  <button
                    key={color.id}
                    type="button"
                    data-testid={`st-btn-${i}`}
                    data-color={color.id}
                    aria-label={`${color.label} (key ${color.key})`}
                    onClick={() => respond(color.id)}
                    className={[
                      "flex h-16 items-center gap-2.5 rounded-xl border px-3 transition-[background-color,border-color,translate] duration-100 sm:h-20 sm:px-4",
                      isFlashing
                        ? flash!.correct
                          ? "border-emerald-600 bg-emerald-600 text-white"
                          : "border-red-500 bg-red-500 text-white"
                        : "border-border bg-card text-foreground hover:-translate-y-0.5 hover:border-primary active:translate-y-0",
                    ].join(" ")}
                  >
                    <span
                      aria-hidden="true"
                      className="size-6 shrink-0 rounded-full border border-black/10 sm:size-7"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="min-w-0 text-left">
                      <span className="block truncate text-sm font-bold sm:text-base">
                        {color.label}
                      </span>
                      <span
                        className={[
                          "block text-[11px] font-medium",
                          isFlashing ? "text-white/80" : "text-muted-foreground",
                        ].join(" ")}
                      >
                        Key {color.key}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>

            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
              <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
              Tip: the R, G, B and Y keys work too - use them for maximum speed.
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="st-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            {score.valid ? (
              <div className="mx-auto max-w-2xl">
                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                    Your result
                  </p>
                  <div className="mt-2 flex items-end justify-center gap-2">
                    <span
                      data-testid="st-iq"
                      className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                    >
                      <CountUp to={score.stroopIndex} duration={1.4} />
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Stroop Index · mean 100, SD 15
                  </p>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                    <span
                      data-testid="st-grade"
                      className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                    >
                      <Palette className="h-4 w-4" aria-hidden="true" />
                      {score.grade.label}
                    </span>
                    <span
                      data-testid="st-percentile"
                      className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                    >
                      Higher than {score.percentile} in 100 adults
                    </span>
                  </div>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    {score.grade.blurb}
                  </p>
                </div>

                {/* Interference + congruent vs incongruent RT bars */}
                <div className="mt-8 rounded-2xl border border-border bg-muted/40 p-4 sm:p-6">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        Stroop interference
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Extra time when the word fights the ink (incongruent minus congruent)
                      </p>
                    </div>
                    <span
                      data-testid="st-interference"
                      className="text-3xl font-black tabular-nums text-primary sm:text-4xl"
                    >
                      {score.interferenceMs != null
                        ? `${formatInterference(score.interferenceMs)} ms`
                        : "--"}
                    </span>
                  </div>

                  <div className="mt-4 space-y-3">
                    <div>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-medium text-foreground">
                          Congruent median RT
                        </span>
                        <span
                          data-testid="st-congruent-ms"
                          className="font-semibold tabular-nums text-foreground"
                        >
                          {score.medianCongruentMs != null
                            ? Math.round(score.medianCongruentMs)
                            : "--"}{" "}
                          ms
                        </span>
                      </div>
                      <div className="h-3 w-full overflow-hidden rounded-full bg-muted">
                        <motion.div
                          data-testid="st-congruent-bar"
                          initial={{ width: 4 }}
                          animate={{ width: `${Math.max(4, congWidthPct)}%` }}
                          transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
                          className="h-full rounded-full bg-emerald-400"
                        />
                      </div>
                    </div>
                    <div>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-medium text-foreground">
                          Incongruent median RT
                        </span>
                        <span
                          data-testid="st-incongruent-ms"
                          className="font-semibold tabular-nums text-foreground"
                        >
                          {score.medianIncongruentMs != null
                            ? Math.round(score.medianIncongruentMs)
                            : "--"}{" "}
                          ms
                        </span>
                      </div>
                      <div className="h-3 w-full overflow-hidden rounded-full bg-muted">
                        <motion.div
                          data-testid="st-incongruent-bar"
                          initial={{ width: 4 }}
                          animate={{ width: `${Math.max(4, incongWidthPct)}%` }}
                          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
                          className="h-full rounded-full bg-emerald-700"
                        />
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">
                    Positive interference is normal - reading is automatic, so
                    naming the ink takes a moment longer when the word disagrees.
                  </p>
                </div>

                {/* Stat grid */}
                <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  <div
                    data-testid="st-accuracy"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round(score.accuracy * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">accuracy</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.medianRtMs != null ? Math.round(score.medianRtMs) : "--"}
                      <span className="text-sm font-semibold text-muted-foreground"> ms</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">overall median RT</p>
                  </div>
                  <div
                    data-testid="st-anticipations"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.anticipationCount}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      taps under 200ms excluded
                    </p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-emerald-700">
                      {score.correct}
                      <span className="text-sm font-semibold text-muted-foreground">
                        {" "}
                        / {score.totalResponses}
                      </span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      correct · {score.errors} wrong
                    </p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.congruentTrials}
                      <span className="text-sm font-semibold text-muted-foreground">
                        {" "}
                        / {score.incongruentTrials}
                      </span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      congruent / incongruent words
                    </p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.percentile}
                      <span className="text-sm font-semibold text-muted-foreground">th</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      population percentile
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button
                    type="button"
                    data-testid="st-retake"
                    onClick={start}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    Retake - new random words
                  </button>
                  <a
                    href="/test"
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                  >
                    Try the Full IQ Test
                  </a>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-xl text-center" data-testid="st-invalid">
                <span
                  className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-amber-200 bg-amber-50"
                  aria-hidden="true"
                >
                  <TriangleAlert className="h-6 w-6 text-amber-600" />
                </span>
                <h3 className="mt-4 text-xl font-bold text-foreground">
                  This run was not scored
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {score.invalidReason}
                </p>
                <div className="mx-auto mt-5 grid max-w-sm grid-cols-3 gap-3 text-sm">
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums">
                      {Math.round(score.accuracy * 100)}%
                    </p>
                    <p className="text-xs text-muted-foreground">accuracy</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-emerald-700">
                      {score.correct}
                    </p>
                    <p className="text-xs text-muted-foreground">correct</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-red-600">
                      {score.errors}
                    </p>
                    <p className="text-xs text-muted-foreground">wrong</p>
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="st-retake"
                  onClick={start}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color] hover:-translate-y-0.5 hover:bg-emerald-700"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Try again - answer the ink carefully
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
