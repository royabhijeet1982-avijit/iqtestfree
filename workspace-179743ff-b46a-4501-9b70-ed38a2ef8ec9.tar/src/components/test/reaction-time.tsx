"use client";

/* ------------------------------------------------------------------ */
/*  Reaction Time Test - interactive UI                                */
/*  Round 1 (simple RT): red stage waits a random 1.5-4.5s, flashes    */
/*  green, user taps anywhere on the stage or presses SPACE.           */
/*  Round 2 (choice RT): one of four quadrant pads lights up emerald;  */
/*  user taps the lit pad (or arrow / Q W A S keys).                   */
/*  Scoring lives in reaction-time-core.ts.                            */
/*                                                                     */
/*  Testing hook: /test/reaction-time?quick=1 runs 3 simple + 6        */
/*  choice trials instead of 5 + 10, so automated flow tests can       */
/*  complete full sessions quickly.                                    */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  Keyboard,
  MousePointerClick,
  RotateCcw,
  Timer,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  CHOICE_TRIALS,
  LAPSE_MS,
  MAX_ANTICIPATION_RETRIES,
  PAD_COUNT,
  QUICK_CHOICE_TRIALS,
  QUICK_SIMPLE_TRIALS,
  SIMPLE_TRIALS,
  classifyRt,
  mulberry32,
  randomForeperiod,
  scoreSession,
  type RtTrial,
  type SessionScore,
  type TrialKind,
} from "./reaction-time-core";

type Phase = "intro" | "countdown" | "simple" | "choice" | "results";

type StageState = "wait" | "go" | "early" | "late";

type PadFeedback = { kind: "hit" | "miss"; pad: number } | null;

const PAD_LABELS = [
  "Top-left quadrant",
  "Top-right quadrant",
  "Bottom-left quadrant",
  "Bottom-right quadrant",
];

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("reaction-time-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

/** Precomputed bell-curve path for the distribution strip (index 55-145). */
const DIST_PATH = (() => {
  const points: string[] = [];
  for (let i = 0; i <= 80; i++) {
    const index = 55 + (90 * i) / 80;
    const z = (index - 100) / 15;
    const density = Math.exp(-0.5 * z * z);
    const x = (i / 80) * 400;
    const y = 74 - density * 60;
    points.push(`${x.toFixed(2)},${y.toFixed(2)}`);
  }
  return `M0,74 L${points.join(" L")} L400,74 Z`;
})();

function DistributionStrip({ rtIndex }: { rtIndex: number }) {
  const clamped = Math.min(145, Math.max(55, rtIndex));
  const x = Math.min(386, Math.max(14, ((clamped - 55) / 90) * 400));
  return (
    <svg
      viewBox="0 0 400 96"
      className="mt-2 h-auto w-full"
      role="img"
      aria-label={`Population distribution of RT Index scores with your score of ${rtIndex} marked`}
    >
      <path d={DIST_PATH} className="fill-emerald-100 stroke-emerald-300" strokeWidth="1.5" />
      <line
        x1={200}
        y1={30}
        x2={200}
        y2={74}
        strokeDasharray="3 3"
        className="stroke-neutral-300"
        strokeWidth="1"
      />
      <text x={200} y={22} textAnchor="middle" className="fill-neutral-500 text-[11px]">
        average 100
      </text>
      <line x1={x} y1={34} x2={x} y2={74} className="stroke-emerald-700" strokeWidth="3" />
      <circle cx={x} cy={34} r={4} className="fill-emerald-700" />
      <text x={x} y={92} textAnchor="middle" className="fill-emerald-800 text-[11px] font-bold">
        You: {rtIndex}
      </text>
    </svg>
  );
}

export function ReactionTimeTest() {
  const searchParams = useSearchParams();
  const quick = useMemo(() => searchParams.get("quick") === "1", [searchParams]);
  const planSimple = quick ? QUICK_SIMPLE_TRIALS : SIMPLE_TRIALS;
  const planChoice = quick ? QUICK_CHOICE_TRIALS : CHOICE_TRIALS;

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [stageState, setStageState] = useState<StageState>("wait");
  const [litPad, setLitPad] = useState<number | null>(null);
  const [padFeedback, setPadFeedback] = useState<PadFeedback>(null);
  const [choiceIntro, setChoiceIntro] = useState<number | null>(null);
  const [simpleDone, setSimpleDone] = useState(0);
  const [choiceDone, setChoiceDone] = useState(0);
  const [score, setScore] = useState<SessionScore | null>(null);

  const phaseRef = useRef<Phase>("intro");
  /** A trial slot is in progress (responses accepted). */
  const activeRef = useRef(false);
  /** The cue is currently visible (response time is running). */
  const armedRef = useRef(false);
  const goAtRef = useRef(0);
  const litPadRef = useRef(-1);
  const anticipationAttemptsRef = useRef(0);
  const trialsRef = useRef<RtTrial[]>([]);
  const rngRef = useRef<() => number>(() => 0.5);
  const lastTwoPadsRef = useRef<[number | null, number | null]>([null, null]);
  const finishedRef = useRef(false);
  const cueTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lapseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const feedbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    return () => {
      [cueTimerRef, lapseTimerRef, feedbackTimerRef].forEach((ref) => {
        if (ref.current) clearTimeout(ref.current);
      });
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    activeRef.current = false;
    armedRef.current = false;
    const result = scoreSession(trialsRef.current);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  const recordTrial = useCallback((trial: RtTrial) => {
    trialsRef.current.push(trial);
    if (trial.kind === "simple") setSimpleDone((d) => d + 1);
    else setChoiceDone((d) => d + 1);
  }, []);

  /** Pick the next lit quadrant; avoid the same pad 3x in a row. */
  const pickPad = useCallback((): number => {
    const rng = rngRef.current;
    let pad = Math.floor(rng() * PAD_COUNT);
    const [twoAgo, oneAgo] = lastTwoPadsRef.current;
    if (twoAgo !== null && oneAgo !== null && twoAgo === oneAgo && pad === oneAgo) {
      pad = (pad + 1 + Math.floor(rng() * (PAD_COUNT - 1))) % PAD_COUNT;
    }
    lastTwoPadsRef.current = [oneAgo, pad];
    return pad;
  }, []);

  function startTrial(kind: TrialKind, isRetry: boolean) {
      if (!isRetry) anticipationAttemptsRef.current = 0;
      activeRef.current = true;
      armedRef.current = false;
      goAtRef.current = 0;
      if (kind === "simple") {
        setStageState("wait");
      } else {
        setLitPad(null);
        setPadFeedback(null);
      }
      cueTimerRef.current = setTimeout(() => {
        goAtRef.current = performance.now();
        armedRef.current = true;
        if (kind === "simple") {
          setStageState("go");
        } else {
          const pad = pickPad();
          litPadRef.current = pad;
          setLitPad(pad);
        }
        lapseTimerRef.current = setTimeout(() => {
          // No response at all within the grace window -> lapse.
          if (!armedRef.current || !activeRef.current) return;
          armedRef.current = false;
          activeRef.current = false;
          recordTrial({
            kind,
            outcome: "lapse",
            rtMs: 4000,
            correct: false,
            litPad: kind === "choice" ? litPadRef.current : -1,
            responsePad: -1,
            anticipationAttempts: anticipationAttemptsRef.current,
          });
          if (kind === "simple") setStageState("late");
          else setPadFeedback({ kind: "miss", pad: litPadRef.current });
          feedbackTimerRef.current = setTimeout(() => advance(kind), 900);
        }, 4000);
      }, randomForeperiod(rngRef.current));
  }

  function advance(kind: TrialKind) {
      const done = trialsRef.current.filter((t) => t.kind === kind).length;
      if (kind === "simple") {
        if (done < planSimple) startTrial("simple", false);
        else {
          phaseRef.current = "choice";
          setPhase("choice");
        }
      } else {
        if (done < planChoice) startTrial("choice", false);
        else finish();
      }
  }

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rngRef.current = mulberry32(seed);
    trialsRef.current = [];
    lastTwoPadsRef.current = [null, null];
    litPadRef.current = -1;
    anticipationAttemptsRef.current = 0;
    finishedRef.current = false;
    activeRef.current = false;
    armedRef.current = false;
    setSimpleDone(0);
    setChoiceDone(0);
    setScore(null);
    setLitPad(null);
    setPadFeedback(null);
    setChoiceIntro(null);
    setStageState("wait");
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  const beginSimple = useCallback(() => {
    phaseRef.current = "simple";
    setPhase("simple");
    startTrial("simple", false);
  }, []);

  /* Countdown 3-2-1 before the simple round. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginSimple();
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginSimple]);

  /* Round-2 intro countdown, then the choice trials begin. */
  useEffect(() => {
    if (phase !== "choice") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setChoiceIntro(n);
      if (n === 0) {
        setChoiceIntro(null);
        startTrial("choice", false);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase]);

  /* --------------------------- responding -------------------------- */

  const handleAnticipation = useCallback(
    (kind: TrialKind, responsePad: number) => {
      activeRef.current = false;
      anticipationAttemptsRef.current += 1;
      if (kind === "simple") setStageState("early");
      else setPadFeedback({ kind: "miss", pad: responsePad });
      if (anticipationAttemptsRef.current <= MAX_ANTICIPATION_RETRIES) {
        feedbackTimerRef.current = setTimeout(
          () => startTrial(kind, true),
          700
        );
      } else {
        recordTrial({
          kind,
          outcome: "skipped",
          rtMs: 0,
          correct: false,
          litPad: kind === "choice" ? litPadRef.current : -1,
          responsePad,
          anticipationAttempts: anticipationAttemptsRef.current,
        });
        feedbackTimerRef.current = setTimeout(() => advance(kind), 700);
      }
    },
    [recordTrial]
  );

  const respond = useCallback(
    (pad: number) => {
      if (phaseRef.current !== "simple" && phaseRef.current !== "choice") return;
      if (!activeRef.current) return;
      const kind: TrialKind = phaseRef.current === "simple" ? "simple" : "choice";

      if (!armedRef.current) {
        // Fired while the stage/pads were still waiting -> anticipation.
        handleAnticipation(kind, pad);
        return;
      }

      armedRef.current = false;
      activeRef.current = false;
      if (lapseTimerRef.current) clearTimeout(lapseTimerRef.current);

      const rt = performance.now() - goAtRef.current;
      const classification = classifyRt(rt);

      if (classification === "anticipation") {
        // Beat the cue by a hair even after it appeared - never scores.
        handleAnticipation(kind, pad);
        return;
      }

      const correct = kind === "simple" ? true : pad === litPadRef.current;
      recordTrial({
        kind,
        outcome: classification === "valid" ? "valid" : "lapse",
        rtMs: rt,
        correct,
        litPad: kind === "choice" ? litPadRef.current : -1,
        responsePad: pad,
        anticipationAttempts: anticipationAttemptsRef.current,
      });

      if (classification === "lapse") {
        if (kind === "simple") setStageState("late");
        else setPadFeedback({ kind: "miss", pad });
        feedbackTimerRef.current = setTimeout(() => advance(kind), 900);
      } else {
        if (kind === "choice") setPadFeedback({ kind: correct ? "hit" : "miss", pad });
        feedbackTimerRef.current = setTimeout(
          () => advance(kind),
          kind === "simple" ? 250 : 420
        );
      }
    },
    [handleAnticipation, recordTrial]
  );

  /* Keyboard input: SPACE taps the simple stage; arrows / Q W A S tap quadrants. */
  useEffect(() => {
    if (phase !== "simple" && phase !== "choice") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      if (phaseRef.current === "simple") {
        if (event.code === "Space" || event.key === " ") {
          event.preventDefault();
          respond(-1);
        }
        return;
      }
      if (phaseRef.current === "choice") {
        const keyMap: Record<string, number> = {
          ArrowUp: 0,
          ArrowRight: 1,
          ArrowLeft: 2,
          ArrowDown: 3,
          q: 0,
          w: 1,
          a: 2,
          s: 3,
          Q: 0,
          W: 1,
          A: 2,
          S: 3,
        };
        const pad = keyMap[event.key];
        if (pad !== undefined) {
          event.preventDefault();
          respond(pad);
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, respond]);

  /* ------------------------- derived data -------------------------- */

  const padState = (index: number): "idle" | "lit" | "hit" | "miss" => {
    if (padFeedback) return index === padFeedback.pad ? padFeedback.kind : "idle";
    if (litPad === index) return "lit";
    return "idle";
  };

  const insight = useMemo(() => {
    if (!score || !score.valid) return null;
    if (score.variabilityMs > 75) {
      return {
        icon: Activity,
        text: "Your simple-round times varied a lot - that usually means attention wandered between cues. A quiet room steadies the numbers more than raw effort does.",
      };
    }
    if (score.medianSimpleMs > 0 && score.medianChoiceMs > 0) {
      const decisionCost = score.medianChoiceMs - score.medianSimpleMs;
      if (decisionCost < 120) {
        return {
          icon: Zap,
          text: "Your decision cost - the gap between choice and simple reactions - is remarkably small. You select the right response almost as fast as you react.",
        };
      }
      return {
        icon: Activity,
        text: `Your decision cost is about ${Math.round(decisionCost)}ms - the extra time your brain needs to pick the right response among four options.`,
      };
    }
    return null;
  }, [score]);

  const stageCopy: Record<StageState, { title: string; sub: string; className: string }> = {
    wait: {
      title: "Wait for green",
      sub: "Do not tap yet",
      className: "bg-red-600 text-white",
    },
    go: {
      title: "TAP NOW",
      sub: "",
      className: "bg-emerald-500 text-white",
    },
    early: {
      title: "Too soon!",
      sub: "Wait for GREEN, then tap",
      className: "bg-amber-400 text-neutral-900",
    },
    late: {
      title: "Too slow",
      sub: `Respond within ${(LAPSE_MS / 1000).toFixed(1)} seconds`,
      className: "bg-neutral-900 text-white",
    },
  };

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="reaction-time-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="rt-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Zap className="h-3.5 w-3.5" aria-hidden="true" />
                Simple + choice RT · {planSimple} + {planChoice} trials
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Wait for green - then tap as fast as you can
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Two rounds, millisecond timing. First a classic reflex sprint:
                the screen sits red, then flashes green - tap the instant it
                does. Then four quadrants: tap whichever one lights up.
              </p>
            </div>

            <div className="mx-auto mt-6 flex max-w-md items-center justify-center gap-3">
              <div className="flex-1 rounded-xl border border-border bg-red-600 px-3 py-3 text-center text-xs font-bold text-white">
                RED = wait
              </div>
              <div className="flex-1 rounded-xl border border-border bg-emerald-500 px-3 py-3 text-center text-xs font-bold text-white">
                GREEN = tap
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The wait before each cue is random (1.5-4.5s) - never tap on a rhythm.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Round 1: click the stage or press SPACE. Round 2: tap the lit quadrant (arrow keys work too).
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Faster than 150ms counts as a guess and never scores; slower than 1.5s is a lapse. Too many invalid trials and the run is honestly not scored.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="rt-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Zap className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="rt-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Get ready - eyes on the stage
            </p>
            <div className="mx-auto mt-4 flex max-w-md items-center justify-center gap-3">
              <div className="flex-1 rounded-xl bg-red-600 px-3 py-2.5 text-center text-xs font-bold text-white">
                RED = wait
              </div>
              <div className="flex-1 rounded-xl bg-emerald-500 px-3 py-2.5 text-center text-xs font-bold text-white">
                GREEN = tap
              </div>
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* --------------------------- SIMPLE ROUND --------------------------- */}
        {phase === "simple" && (
          <motion.div
            key="simple"
            data-testid="rt-phase-simple"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="cursor-pointer p-4 select-none sm:p-8"
            onClick={() => respond(-1)}
          >
            <div className="flex items-center justify-between gap-3">
              <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                Round 1 · Simple RT
              </span>
              <span
                data-testid="rt-trial-counter"
                className="text-sm font-semibold tabular-nums text-muted-foreground"
              >
                Trial {Math.min(simpleDone + 1, planSimple)} of {planSimple}
              </span>
            </div>

            <motion.div
              key={stageState}
              data-testid="rt-stage"
              data-state={stageState}
              initial={{ scale: 0.98, opacity: 0.85 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.15 }}
              className={`mt-4 flex min-h-56 flex-col items-center justify-center rounded-2xl sm:min-h-64 ${stageCopy[stageState].className}`}
            >
              {stageState === "go" ? (
                <motion.span
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 0.6, repeat: Infinity, ease: "easeInOut" }}
                  className="text-4xl font-black tracking-tight sm:text-5xl"
                >
                  {stageCopy[stageState].title}
                </motion.span>
              ) : (
                <span className="text-3xl font-black tracking-tight sm:text-4xl">
                  {stageCopy[stageState].title}
                </span>
              )}
              {stageCopy[stageState].sub && (
                <span className="mt-2 text-sm font-medium opacity-90">
                  {stageCopy[stageState].sub}
                </span>
              )}
            </motion.div>

            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
              <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
              Click the big box or press SPACE · the wait is random every trial
            </p>
          </motion.div>
        )}

        {/* --------------------------- CHOICE ROUND --------------------------- */}
        {phase === "choice" && (
          <motion.div
            key="choice"
            data-testid="rt-phase-choice"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 select-none sm:p-8"
          >
            {choiceIntro !== null ? (
              <div data-testid="rt-choice-intro" className="py-6 text-center">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                  <MousePointerClick className="h-3.5 w-3.5" aria-hidden="true" />
                  Round 2 · Choice RT
                </span>
                <h3 className="mt-3 text-xl font-bold text-foreground sm:text-2xl">
                  Tap whichever quadrant lights up
                </h3>
                <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
                  Any one of the four boxes can flash emerald after a random
                  wait. Hit the lit one as fast as you can - wrong taps still
                  count against you.
                </p>
                <AnimatePresence mode="wait">
                  <motion.span
                    key={choiceIntro}
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.6, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-6 inline-block text-7xl font-black tabular-nums text-primary"
                  >
                    {choiceIntro === 0 ? "GO" : choiceIntro}
                  </motion.span>
                </AnimatePresence>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between gap-3">
                  <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                    Round 2 · Choice RT
                  </span>
                  <span
                    data-testid="rt-trial-counter"
                    className="text-sm font-semibold tabular-nums text-muted-foreground"
                  >
                    Trial {Math.min(choiceDone + 1, planChoice)} of {planChoice}
                  </span>
                </div>

                <p
                  data-testid="rt-choice-status"
                  className={`mt-3 text-center text-sm font-semibold ${
                    litPad !== null ? "text-emerald-700" : "text-muted-foreground"
                  }`}
                >
                  {padFeedback
                    ? padFeedback.kind === "hit"
                      ? "Hit - nice reflex"
                      : "Wrong box - the lit one was highlighted"
                    : litPad !== null
                      ? "Tap the lit quadrant now"
                      : "Wait for a quadrant to light up"}
                </p>

                <div className="mx-auto mt-3 grid max-w-md grid-cols-2 gap-3">
                  {Array.from({ length: PAD_COUNT }, (_, i) => {
                    const state = padState(i);
                    return (
                      <motion.button
                        key={i}
                        type="button"
                        data-testid={`rt-pad-${i}`}
                        data-state={state}
                        aria-label={PAD_LABELS[i]}
                        onClick={() => respond(i)}
                        whileTap={{ scale: 0.96 }}
                        className={[
                          "h-24 rounded-2xl border-2 transition-[background-color,border-color,box-shadow] duration-100 sm:h-32",
                          state === "lit" &&
                            "border-emerald-600 bg-emerald-500 shadow-[0_0_24px_rgba(16,185,129,0.45)]",
                          state === "hit" &&
                            "border-emerald-700 bg-emerald-600 text-white",
                          state === "miss" && "border-red-600 bg-red-500 text-white",
                          state === "idle" && "border-border bg-muted/40",
                        ]
                          .filter(Boolean)
                          .join(" ")}
                      >
                        <span
                          aria-hidden="true"
                          className={`text-2xl font-black ${
                            state === "idle" ? "text-muted-foreground/40" : "text-current"
                          }`}
                        >
                          {i + 1}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>

                <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
                  <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
                  Arrow keys or Q W A S also work
                </p>
              </>
            )}
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="rt-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            {score.valid ? (
              <div className="mx-auto max-w-2xl">
                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                    Your result
                  </p>
                  <div className="mt-2 flex items-end justify-center gap-2">
                    <span
                      data-testid="rt-index"
                      className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                    >
                      <CountUp to={score.rtIndex} duration={1.4} />
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    RT Index · mean 100, SD 15 · higher is faster
                  </p>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                    <span
                      data-testid="rt-grade"
                      className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                    >
                      <Zap className="h-4 w-4" aria-hidden="true" />
                      {score.grade.label}
                    </span>
                    <span
                      data-testid="rt-percentile"
                      className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                    >
                      Faster than {score.percentile}% of adults
                    </span>
                  </div>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    {score.grade.blurb}
                  </p>
                </div>

                {/* Stat grid */}
                <div className="mt-8 grid grid-cols-2 gap-3">
                  <div
                    data-testid="rt-stat-simple"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-3xl font-bold tabular-nums text-foreground">
                      <CountUp to={Math.round(score.medianSimpleMs)} duration={1.2} />
                      <span className="ml-1 text-base font-semibold text-muted-foreground">ms</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">median simple RT</p>
                  </div>
                  <div
                    data-testid="rt-stat-choice"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-3xl font-bold tabular-nums text-foreground">
                      <CountUp to={Math.round(score.medianChoiceMs)} duration={1.2} />
                      <span className="ml-1 text-base font-semibold text-muted-foreground">ms</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">median choice RT</p>
                  </div>
                  <div
                    data-testid="rt-stat-variability"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round(score.variabilityMs)}
                      <span className="ml-1 text-sm font-semibold text-muted-foreground">ms</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">variability (SD, lower is steadier)</p>
                  </div>
                  <div
                    data-testid="rt-stat-accuracy"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round(score.choiceAccuracy * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">choice accuracy</p>
                  </div>
                </div>

                <p
                  data-testid="rt-validity-line"
                  className="mt-4 text-center text-xs text-muted-foreground"
                >
                  {score.validTrials} of {score.totalTrials} trials valid ·{" "}
                  {score.anticipationCount} anticipation
                  {score.anticipationCount === 1 ? "" : "s"} · {score.lapseCount} lapse
                  {score.lapseCount === 1 ? "" : "s"}
                </p>

                {/* Population distribution */}
                <div className="mt-8" data-testid="rt-distribution">
                  <p className="text-sm font-semibold text-foreground">
                    Where you sit in the population
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    RT Index scale (55-145) · the curve is the adult population
                  </p>
                  <DistributionStrip rtIndex={score.rtIndex} />
                </div>

                {insight && (
                  <p className="mt-6 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm leading-relaxed text-emerald-800">
                    <insight.icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                    {insight.text}
                  </p>
                )}

                <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button
                    type="button"
                    data-testid="rt-retake"
                    onClick={start}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    Retake - new random waits
                  </button>
                  <a
                    href="/test"
                    data-testid="rt-cta-all-tests"
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                  >
                    Explore all tests
                  </a>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-xl text-center" data-testid="rt-invalid">
                <span
                  className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-amber-200 bg-amber-50"
                  aria-hidden="true"
                >
                  <Timer className="h-7 w-7 text-amber-600" />
                </span>
                <h3 className="mt-4 text-xl font-bold text-foreground">
                  Low validity - this run was not scored
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {score.invalidReason}
                </p>
                <div className="mx-auto mt-5 grid max-w-sm grid-cols-2 gap-3 text-sm">
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-emerald-700">
                      {score.validTrials}/{score.totalTrials}
                    </p>
                    <p className="text-xs text-muted-foreground">valid trials</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-amber-700">
                      {score.anticipationCount}
                    </p>
                    <p className="text-xs text-muted-foreground">anticipations (too soon)</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums text-neutral-900">
                      {score.lapseCount}
                    </p>
                    <p className="text-xs text-muted-foreground">lapses (too slow)</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-3">
                    <p className="text-lg font-bold tabular-nums">
                      {score.medianSimpleMs > 0 ? `${Math.round(score.medianSimpleMs)}ms` : "-"}
                    </p>
                    <p className="text-xs text-muted-foreground">raw median simple RT</p>
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="rt-retake"
                  onClick={start}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color] hover:-translate-y-0.5 hover:bg-emerald-700"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Try again - wait for green
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
