/* ------------------------------------------------------------------ */
/*  Digit Span Test - FAQ (single source)                              */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type DsFaq = { question: string; answer: string };

export const DIGIT_SPAN_FAQS: DsFaq[] = [
  {
    question: "What is a digit span test?",
    answer:
      "A digit span test measures how many digits you can hold in mind and reproduce immediately after seeing them. Digits appear on screen one at a time, and you type back what you saw; the sequences then grow by one digit until recall breaks down. Your longest reliably remembered sequence is called your span. It is one of the oldest and most widely used measures of short-term and working memory, and a version of it appears in virtually every major clinical battery, including the WAIS.",
  },
  {
    question: "Forward or backward - what is the difference?",
    answer:
      "The forward phase asks you to repeat the digits in the order they appeared, which mostly taps passive storage: the phonological loop that holds sound-based information for a couple of seconds. The backward phase asks for the sequence in reverse, which additionally loads the central executive - you must hold the digits in mind AND actively re-order them at the same time. Almost everyone scores lower backward; typical adults manage about 7 digits forward and 5 to 6 backward, and the gap between your two spans is itself a useful signal.",
  },
  {
    question: "Is 7 plus or minus 2 really the limit?",
    answer:
      "In 1956 George Miller famously argued that immediate memory holds about seven items, plus or minus two, and the phrase stuck. Modern research refines the picture: for raw unchunked digits the typical adult forward span sits somewhere between 5 and 9, and measured capacity depends heavily on strategy - grouping 419 555 0132 into three chunks makes it feel effortless. This test keeps every sequence random and unchunked, so it estimates your raw span rather than your talent for memorising phone numbers.",
  },
  {
    question: "How does my score map to the IQ scale?",
    answer:
      "Your forward and backward spans are each compared against adult population norms - a typical forward span is about 7 with a standard deviation of 1.6, and backward about 5.5 with a standard deviation of 1.5. The two are combined into a weighted composite (backward weighted slightly higher because it is harder), renormalised for the known correlation between the spans, and mapped onto the standard IQ scale where 100 is the population average and 15 points is one standard deviation. A percentile estimate sits alongside, and the calibration is checked against a 500-person simulated population that averages 100.",
  },
  {
    question: "Can I improve my digit span?",
    answer:
      "Yes, although the gains come mostly from strategy rather than new neurons. Chunking digits into small groups, rehearsing with a steady rhythm, and keeping your eyes in one place all reliably add a digit or two. Weeks of consistent working-memory practice can lift your measured span further. Because every sequence here is drawn fresh at random - and a failed attempt is always followed by a different sequence at the same length - retaking the test measures the skill, not a memorised answer sheet.",
  },
  {
    question: "Are retakes fair? Why do my numbers change?",
    answer:
      "Every attempt uses a newly randomised sequence, so no run can be memorised, and both phases follow the same staircase rules every time. Spans are naturally noisy: attention, sleep, and a single lucky or unlucky one-digit draw can move the result by a point. That is why the scoring needs both phases - the composite is steadier than either span alone. Take two or three runs and read the range rather than one number; that spread is the most honest picture of your working memory.",
  },
];
