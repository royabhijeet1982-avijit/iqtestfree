/* ------------------------------------------------------------------ */
/*  Sustained Attention Test - pure scoring engine                     */
/*  Paradigm: the Sustained Attention to Response Task (SART;          */
/*  Robertson et al., 1997). Digits 1-9 stream past one at a time;     */
/*  respond to EVERY digit, but WITHHOLD on the rare digit 3. The      */
/*  task is deliberately monotonous - attention drifts, and the rare   */
/*  no-go digit catches the drift.                                     */
/*                                                                     */
/*  Structure: 6 blocks x 30 trials = 180 trials. The full sequence    */
/*  is 20 SEEDED SHUFFLES of [1..9] cut into 6 blocks of 30, so every  */
/*  run contains EXACTLY 20 no-go digits (20 threes) and 160 go        */
/*  digits - perfectly balanced, impossible to farm or starve.         */
/*                                                                     */
/*  Timing (engine-owned): each digit shows 250ms, then a 900ms        */
/*  inter-stimulus gap with the screen cleared. A response registers   */
/*  once per trial (first press wins) from digit onset until the next  */
/*  digit onset.                                                       */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - go-no-go: SHORT fast inhibition with two shapes and d'          */
/*     scoring. Here: a LONG 4-minute monotone vigil with digits,      */
/*     scored on commission rate + RT consistency - classic SART.       */
/*                                                                     */
/*  Scoring honesty (anti-gaming by design):                           */
/*   - Composite z = 0.65*z(commission) + 0.15*z(omission)             */
/*                   + 0.20*z(RT-CV), each z clamped to +/-3.          */
/*     Pressing EVERYTHING: commission 1.0 -> z -3 -> floor.           */
/*     Pressing NOTHING: omission gate (omissionRate > 0.4 -> IQ 55).  */
/*     Random 50/50 mashing: commission ~0.5 with huge RT-CV ->        */
/*     nowhere near the anchor. Only steady, selective responding      */
/*     moves the number.                                               */
/*   - Responses faster than 100ms are excluded from RT statistics     */
/*     (impossible reflexes cannot fake consistency).                  */
/*   - Every run reseeds the RNG and reshuffles the digit sequence.    */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Digits streamed to the participant. */
export const SART_DIGITS: readonly number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];

/** The only no-go digit (withhold response). */
export const NO_GO_DIGIT = 3;

/** Blocks per session. */
export const BLOCK_COUNT = 6;

/** Trials per block (block = 30 trials = 10/3 shuffles... see below). */
export const TRIALS_PER_BLOCK = 30;

/** Total trials (180) and exact no-go count per run. */
export const TOTAL_TRIALS = BLOCK_COUNT * TRIALS_PER_BLOCK;
export const TOTAL_NO_GO = TOTAL_TRIALS / SART_DIGITS.length; // 20

/* -------------------- Engine-owned timing (ms) -------------------- */
/** How long each digit stays visible. */
export const DIGIT_ON_MS = 250;
/** Inter-stimulus gap with the screen cleared. */
export const ISI_MS = 900;
/** Block-break length between blocks. */
export const BREAK_MS = 2000;

/** Shortened timings used by automated flow tests via ?quick=1. */
export const DIGIT_ON_MS_QUICK = 90;
export const ISI_MS_QUICK = 220;
export const BREAK_MS_QUICK = 400;

/* -------------------- Response validity -------------------- */
/** RTs below this are impossible reflexes - excluded from RT stats. */
export const MIN_VALID_RT_MS = 100;

/* -------------------- Population model -------------------- */
/** Adult commission anchor: mean rate of responding to the digit 3. */
export const COMM_MEAN = 0.45;
export const COMM_SD = 0.15;

/** Adult omission anchor: mean rate of missing go digits. */
export const OMIT_MEAN = 0.03;
export const OMIT_SD = 0.05;

/** Adult anchor for RT coefficient of variation on go trials. */
export const RTCV_MEAN = 0.18;
export const RTCV_SD = 0.06;

/** Composite weights (commission-heavy, per SART tradition). */
export const W_COMMISSION = 0.65;
export const W_OMISSION = 0.15;
export const W_RTCV = 0.2;

/** Participation gate: more than this omission rate floors the IQ. */
export const OMIT_GATE = 0.4;

/**
 * Commission gate: responding to more than this share of the rare
 * digit means withholding has been abandoned entirely (gaming or
 * total drift) - the index floors. Honest SART commission rates sit
 * far below this; 15+ slips out of 20 is not vigilance.
 */
export const COMMISSION_GATE = 0.75;

/** z-clamp and IQ bounds. */
export const Z_CLAMP = 3;
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/**
 * The maximum raw composite a run can achieve: perfect commission
 * (z +3), perfect omission (z = OMIT_MEAN/OMIT_SD) and perfect RT
 * consistency (z +3). The raw composite is scaled by Z_CLAMP / this
 * so a flawless run lands exactly on the 145 ceiling.
 */
export const COMPOSITE_MAX =
  W_COMMISSION * Z_CLAMP + W_OMISSION * (OMIT_MEAN / OMIT_SD) + W_RTCV * Z_CLAMP;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type SaSession = {
  /** 180 digits, 6 blocks x 30. */
  blocks: number[][];
};

/** One recorded response (or non-response) for a trial. */
export type SaResponse = {
  /** 0-based trial index across the whole session (0..179). */
  trial: number;
  /** True when the participant pressed (SPACE / GO button). */
  pressed: boolean;
  /** Time from digit onset to press in ms (null when not pressed). */
  rtMs: number | null;
};

export type BlockStat = {
  block: number;
  /** Commissions (presses on 3) in this block. */
  commissions: number;
  /** Omissions (missed go digits) in this block. */
  omissions: number;
  /** Mean RT on valid go responses (null when none). */
  meanRtMs: number | null;
};

export type SaGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SaScore = {
  /** Presses on the digit 3 (errors of commission). */
  commissions: number;
  /** commission rate over 20 no-go trials. */
  commissionRate: number;
  /** Missed go digits (errors of omission). */
  omissions: number;
  /** omission rate over 160 go trials. */
  omissionRate: number;
  /** Mean RT on valid go responses (null when none). */
  meanRtMs: number | null;
  /** RT coefficient of variation (SD/mean) on valid go responses. */
  rtCv: number | null;
  /** Valid go-response count feeding the RT stats. */
  validGoResponses: number;
  /** Per-block breakdown. */
  blocks: BlockStat[];
  /** Participation gate triggered (omissionRate > 0.4). */
  gated: boolean;
  /** IQ-scale sustained attention index (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: SaGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle of a copy - never mutates the input. */
export function shuffled<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i]!;
    out[i] = out[j]!;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Session building                                                   */
/* ------------------------------------------------------------------ */

/**
 * Build the full 180-trial digit sequence from a seed: 20 seeded
 * shuffles of [1..9] concatenated, then cut into 6 blocks of 30.
 * Guarantees EXACTLY 20 no-go digits (threes) and 160 go digits every
 * run, with a different order each seed.
 */
export function buildSaSession(seed: number): SaSession {
  const rng = mulberry32(seed);
  const flat: number[] = [];
  for (let s = 0; s < TOTAL_NO_GO; s++) {
    flat.push(...shuffled(SART_DIGITS, rng));
  }
  const blocks: number[][] = [];
  for (let b = 0; b < BLOCK_COUNT; b++) {
    blocks.push(flat.slice(b * TRIALS_PER_BLOCK, (b + 1) * TRIALS_PER_BLOCK));
  }
  return { blocks };
}

/* ------------------------------------------------------------------ */
/*  Statistics helpers                                                 */
/* ------------------------------------------------------------------ */

/** Mean of a numeric array (null when empty). */
export function mean(values: readonly number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

/** Sample standard deviation (null when fewer than 2 values). */
export function sampleSd(values: readonly number[]): number | null {
  if (values.length < 2) return null;
  const m = mean(values)!;
  const variance =
    values.reduce((acc, v) => acc + (v - m) * (v - m), 0) / (values.length - 1);
  return Math.sqrt(variance);
}

/**
 * RT coefficient of variation (SD / mean) - the vigilance literature's
 * standard consistency metric. Null when fewer than 2 valid RTs.
 */
export function rtCv(rts: readonly number[]): number | null {
  const m = mean(rts);
  const sd = sampleSd(rts);
  if (m === null || sd === null || m <= 0) return null;
  return sd / m;
}

/* ------------------------------------------------------------------ */
/*  Population model + grading                                         */
/* ------------------------------------------------------------------ */

/** Clamp a z-score to +/- Z_CLAMP. */
export function clampZ(z: number): number {
  return Math.min(Z_CLAMP, Math.max(-Z_CLAMP, z));
}

/**
 * Composite sustained-attention index. Commission z is INVERTED
 * (lower commission is better); omission z likewise; RT-CV z is also
 * inverted (lower variability is better). Weights 0.65/0.15/0.20,
 * each component clamped to +/-3, the raw weighted sum stretched so a
 * flawless run reaches the 145 ceiling, then clamped again.
 *
 * Hard participation gates: omission above OMIT_GATE (not actually
 * playing) or commission above COMMISSION_GATE (withholding
 * abandoned) floor the index at 55 - mashing cannot win.
 */
export function saIndex(
  commissionRate: number,
  omissionRate: number,
  rtCvValue: number | null
): number {
  if (omissionRate > OMIT_GATE) return IQ_MIN;
  if (commissionRate > COMMISSION_GATE) return IQ_MIN;
  const zComm = clampZ((COMM_MEAN - commissionRate) / COMM_SD);
  const zOmit = clampZ((OMIT_MEAN - omissionRate) / OMIT_SD);
  const zCv = rtCvValue === null ? 0 : clampZ((RTCV_MEAN - rtCvValue) / RTCV_SD);
  const raw = W_COMMISSION * zComm + W_OMISSION * zOmit + W_RTCV * zCv;
  const scaled = clampZ(raw * (Z_CLAMP / COMPOSITE_MAX));
  return Math.min(IQ_MAX, Math.max(IQ_MIN, Math.round(100 + 15 * scaled)));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const erf = (x: number): number => {
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * ax);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-ax * ax);
    return sign * y;
  };
  const z = (iq - 100) / 15;
  const pct = 0.5 * (1 + erf(z / Math.SQRT2)) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): SaGrade {
  if (iq < 85) {
    return {
      label: "Drifting",
      blurb: "The stream pulled your attention under more than once - classic SART drift. A second run usually steadies the rhythm of respond-to-everything-but-3.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - you caught the stream about as well as the general population across four monotonous minutes.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Steady",
      blurb: "Better than most - few slips, few misses, and your tapping rhythm stayed remarkably even across all six blocks.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Locked-in",
      blurb: "Top-tier vigilance - the rare 3 barely caught you and your response rhythm barely wavered. This is sustained attention that shines in long study sessions and monitoring work.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Laser",
    blurb: "Elite vigilance - near-zero slips on the rare digit, almost no missed targets, and machine-like consistency for four straight minutes.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a complete session from the raw responses. Response record is
 * keyed by absolute trial index (0..179); presses within MIN_VALID_RT
 * still count as responses for commission/omission but are excluded
 * from RT statistics.
 */
export function scoreSession(
  responses: readonly SaResponse[],
  session: SaSession | null
): SaScore {
  if (!session) {
    const iq = 55;
    return {
      commissions: 0,
      commissionRate: 0,
      omissions: 0,
      omissionRate: 1,
      meanRtMs: null,
      rtCv: null,
      validGoResponses: 0,
      blocks: [],
      gated: true,
      iq,
      percentile: iqToPercentile(iq),
      grade: gradeForIq(iq),
    };
  }

  const flat: number[] = session.blocks.flat();
  const responseByTrial = new Map<number, SaResponse>();
  for (const r of responses) responseByTrial.set(r.trial, r);

  let commissions = 0;
  let omissions = 0;
  let goTrials = 0;
  let noGoTrials = 0;
  const goRts: number[] = [];

  const blockStats: BlockStat[] = [];
  let trialCursor = 0;

  for (let b = 0; b < session.blocks.length; b++) {
    const blockDigits = session.blocks[b]!;
    let bComm = 0;
    let bOmit = 0;
    const bRts: number[] = [];

    for (const digit of blockDigits) {
      const trialIdx = trialCursor++;
      const r = responseByTrial.get(trialIdx);
      if (digit === NO_GO_DIGIT) {
        noGoTrials++;
        if (r && r.pressed) {
          commissions++;
          bComm++;
        }
      } else {
        goTrials++;
        if (!r || !r.pressed) {
          omissions++;
          bOmit++;
        } else if (r.rtMs !== null && r.rtMs >= MIN_VALID_RT_MS) {
          goRts.push(r.rtMs);
          bRts.push(r.rtMs);
        }
      }
    }

    blockStats.push({
      block: b,
      commissions: bComm,
      omissions: bOmit,
      meanRtMs: mean(bRts),
    });
  }

  void flat;
  const commissionRate = noGoTrials > 0 ? commissions / noGoTrials : 0;
  const omissionRate = goTrials > 0 ? omissions / goTrials : 1;
  const cv = rtCv(goRts);
  const gated = omissionRate > OMIT_GATE;
  const iq = gated ? 55 : saIndex(commissionRate, omissionRate, cv);

  return {
    commissions,
    commissionRate,
    omissions,
    omissionRate,
    meanRtMs: mean(goRts),
    rtCv: cv,
    validGoResponses: goRts.length,
    blocks: blockStats,
    gated,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
