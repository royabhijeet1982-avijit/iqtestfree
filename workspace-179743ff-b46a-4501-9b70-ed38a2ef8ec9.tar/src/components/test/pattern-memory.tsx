"use client";

/* ------------------------------------------------------------------ */
/*  Pattern Memory Test - interactive UI                               */
/*  Six independent rounds: a lit tile pattern flashes on a 5x5 grid   */
/*  (engine-owned duration), the board goes dark, you reproduce it by  */
/*  clicking and Submit. A shrinking peek budget re-flashes the pat-   */
/*  tern; scoring lives in pattern-memory-core.ts.                     */
/*                                                                     */
/*  Testing hook: /test/pattern-memory?quick=1 shortens every engine   */
/*  timing (flash + gaps + countdown + feedback) so automated flow     */
/*  tests run fast. Quick mode is a timing change only - never a       */
/*  scoring one.                                                       */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (show | recall | feedback), each board cell exposes                 */
/*  data-testid="pm-cell-{i}" with data-on="1" ONLY while the flash is */
/*  up (cleared on recall - anti-cheat), and result numbers expose     */
/*  data-final so CountUp animation frames cannot fool assertions.     */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Brain,
  Eye,
  EyeOff,
  LayoutGrid,
  MousePointerClick,
  RotateCcw,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  AFTER_SHOW_GAP_MS,
  AFTER_SHOW_GAP_MS_QUICK,
  CELL_COUNT,
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  GRID_SIZE,
  PRE_SHOW_MS,
  PRE_SHOW_MS_QUICK,
  ROUND_PATTERN_SIZES,
  SHOW_MS,
  SHOW_MS_QUICK,
  buildPatternMemorySession,
  scoreSessionWithSession,
  type PatternMemoryScore,
  type PatternMemorySession,
  type Recall,
} from "./pattern-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "show" | "recall" | "feedback";

/** Idle pause before a round's flash. */
const PRE_SHOW_MS_FALLBACK = PRE_SHOW_MS;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("pattern-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function PatternMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("show");
  const [roundIndex, setRoundIndex] = useState(0);
  /** Lit cells right now (flash rendering ONLY - never during recall). */
  const [litCells, setLitCells] = useState<number[]>([]);
  /** Cells the user has clicked in the current recall. */
  const [picked, setPicked] = useState<number[]>([]);
  /** Cells revealed as the truth during feedback (correct + missed). */
  const [revealCells, setRevealCells] = useState<number[]>([]);
  const [peeksLeft, setPeeksLeft] = useState(0);
  const [peeksSpentRound, setPeeksSpentRound] = useState(0);
  const [peeking, setPeeking] = useState(false);
  const [score, setScore] = useState<PatternMemoryScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);
  /** Mirrors sessionRef for RENDER-time reads (refs are off-limits in render). */
  const [session, setSession] = useState<PatternMemorySession | null>(null);

  const sessionRef = useRef<PatternMemorySession | null>(null);
  const roundRef = useRef(0);
  const recallsRef = useRef<Recall[]>([]);
  const pickedRef = useRef<number[]>([]);
  const peeksSpentRef = useRef(0);
  const recallOpenedAtRef = useRef(0);
  const activeStateRef = useRef<ActiveState>("show");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed =
      startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const result = scoreSessionWithSession(recallsRef.current, sessionRef.current);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  /** Flash a set of cells for `ms`, then run `after`. */
  const flash = useCallback(
    (cells: number[], ms: number, after: () => void) => {
      clearTimers();
      setLitCells(cells);
      timersRef.current.push(
        setTimeout(() => {
          setLitCells([]);
          after();
        }, ms)
      );
    },
    [clearTimers]
  );

  const openRecall = useCallback(
    (round: number) => {
      activeStateRef.current = "recall";
      setActiveState("recall");
      const sess = sessionRef.current;
      if (!sess) return;
      setPicked([]);
      pickedRef.current = [];
      setPeeksSpentRound(0);
      peeksSpentRef.current = 0;
      setPeeksLeft(sess.rounds[round]!.peeks);
      recallOpenedAtRef.current = performance.now();
    },
    []
  );

  const beginShow = useCallback(
    (round: number) => {
      roundRef.current = round;
      setRoundIndex(round);
      activeStateRef.current = "show";
      setActiveState("show");
      setPhase("active");
      setPicked([]);
      pickedRef.current = [];
      setRevealCells([]);
      const sess = sessionRef.current;
      if (!sess) return;
      const r = sess.rounds[round]!;
      const preMs = quickRef.current ? PRE_SHOW_MS_QUICK : PRE_SHOW_MS_FALLBACK;
      const showMs = quickRef.current ? SHOW_MS_QUICK[round]! : r.showMs;
      const gapMs = quickRef.current ? AFTER_SHOW_GAP_MS_QUICK : AFTER_SHOW_GAP_MS;
      clearTimers();
      timersRef.current.push(
        setTimeout(() => {
          flash(
            [...r.cells],
            showMs,
            () => timersRef.current.push(setTimeout(() => openRecall(round), gapMs))
          );
        }, preMs)
      );
    },
    [clearTimers, flash, openRecall]
  );

  const beginFeedback = useCallback(
    (round: number) => {
      activeStateRef.current = "feedback";
      setActiveState("feedback");
      // Kill any in-flight peek re-flash: board clears, peeking unblocks.
      clearTimers();
      setLitCells([]);
      setPeeking(false);
      const sess = sessionRef.current;
      if (!sess) return;
      const r = sess.rounds[round]!;
      setRevealCells([...r.cells]);
      const feedbackMs = quickRef.current ? FEEDBACK_MS_QUICK : FEEDBACK_MS;
      timersRef.current.push(
        setTimeout(() => {
          setRevealCells([]);
          if (round + 1 < sess.rounds.length) {
            beginShow(round + 1);
          } else {
            finish();
          }
        }, feedbackMs)
      );
    },
    [beginShow, clearTimers, finish]
  );

  const start = useCallback(() => {
    clearTimers();
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const built = buildPatternMemorySession(seed);
    sessionRef.current = built;
    setSession(built);
    recallsRef.current = [];
    finishedRef.current = false;
    pickedRef.current = [];
    peeksSpentRef.current = 0;
    setPicked([]);
    setRevealCells([]);
    setLitCells([]);
    setRoundIndex(0);
    setScore(null);
    setRunSeconds(null);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Global 3-2-1 before round 1. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? 180 : 750;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        startedAtRef.current = performance.now();
        beginShow(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginShow]);

  /* --------------------------- interaction -------------------------- */

  const toggleCell = useCallback(
    (cell: number) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recall") return;
      if (peeking) return;
      setPicked((prev) => {
        if (prev.includes(cell)) {
          pickedRef.current = prev.filter((c) => c !== cell);
          return pickedRef.current;
        }
        pickedRef.current = [...prev, cell];
        return pickedRef.current;
      });
    },
    [peeking]
  );

  const spendPeek = useCallback(() => {
    const sess = sessionRef.current;
    if (!sess) return;
    if (activeStateRef.current !== "recall" || peeking) return;
    if (peeksSpentRef.current >= sess.rounds[roundRef.current]!.peeks) return;
    peeksSpentRef.current += 1;
    setPeeksSpentRound(peeksSpentRef.current);
    setPeeksLeft(sess.rounds[roundRef.current]!.peeks - peeksSpentRef.current);
    setPeeking(true);
    const showMs = quickRef.current ? SHOW_MS_QUICK[roundRef.current]! : SHOW_MS[roundRef.current]!;
    const r = sess.rounds[roundRef.current]!;
    // Re-flash the pattern briefly; picked cells stay counted.
    setLitCells([...r.cells]);
    timersRef.current.push(
      setTimeout(() => {
        setLitCells([]);
        setPeeking(false);
      }, Math.max(240, Math.round(showMs * 0.45)))
    );
  }, [peeking]);

  const submitRound = useCallback(() => {
    const sess = sessionRef.current;
    if (!sess) return;
    if (activeStateRef.current !== "recall") return;
    recallsRef.current.push({
      round: roundRef.current,
      clicked: [...pickedRef.current],
      peeksUsed: peeksSpentRef.current,
      rtMs: recallOpenedAtRef.current > 0 ? performance.now() - recallOpenedAtRef.current : null,
    });
    beginFeedback(roundRef.current);
  }, [beginFeedback]);

  /* Keyboard: P = peek, Enter = submit during recall. */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      if (activeStateRef.current !== "recall") return;
      const k = e.key.toLowerCase();
      if (k === "p") spendPeek();
      else if (k === "enter") submitRound();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, spendPeek, submitRound]);

  /* ------------------------- derived data -------------------------- */

  const round = session?.rounds[roundIndex];
  const size = ROUND_PATTERN_SIZES[roundIndex] ?? 0;
  const statusText =
    activeState === "show"
      ? peeking
        ? "Peek - memorise fast!"
        : "Memorise the lit tiles"
      : activeState === "recall"
        ? "Click the tiles that were lit"
        : "Green = correct · dim = you missed it";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="pattern-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="pm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <LayoutGrid className="h-3.5 w-3.5" aria-hidden="true" />
                Visual memory · tile patterns · about 4 minutes
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                A pattern flashes once - can you rebuild it?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Six rounds on a 5×5 board. Patterns grow from 3 to 8 tiles
                while the flash shrinks - and your peek budget drains to
                zero. Rebuild each pattern from memory.
              </p>
            </div>

            {/* Static preview of the board */}
            <div
              data-testid="pm-preview"
              aria-hidden="true"
              className="mx-auto mt-6 w-fit rounded-xl border border-border bg-muted/60 p-4"
            >
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                What a flash looks like
              </p>
              <div className="mt-3 grid grid-cols-5 gap-1.5">
                {Array.from({ length: CELL_COUNT }, (_, i) => (
                  <span
                    key={i}
                    className={[
                      "h-6 w-6 rounded-md sm:h-7 sm:w-7",
                      [2, 8, 14].includes(i)
                        ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                        : "bg-background border border-border",
                    ].join(" ")}
                  />
                ))}
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Eye className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The flash duration is engine-owned - nobody can slow it down for extra studying.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Click the tiles you remember, then Submit. Early rounds hand you peeks - the last two give none.
              </li>
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Wrong tiles cancel right ones: spraying the board earns exactly zero.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Fresh patterns every run - chunk tiles into shapes instead of memorising positions one by one.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="pm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <LayoutGrid className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh patterns every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="pm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Round 1 · {ROUND_PATTERN_SIZES[0]} tiles · eyes on the board
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="pm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Round header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="pm-round-chip"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Round {roundIndex + 1}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {activeState === "show"
                    ? "flash · memorise the lit tiles"
                    : activeState === "recall"
                      ? "rebuild the pattern"
                      : "round result"}
                </p>
              </div>
              <span
                data-testid="pm-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {activeState === "recall"
                  ? `${picked.length} / ${size}`
                  : `${size} tiles`}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="pm-stage"
              data-phase={activeState}
              className="mx-auto mt-5 w-full max-w-[420px]"
            >
              <div
                data-testid="pm-board"
                className={[
                  "grid grid-cols-5 gap-1.5 rounded-2xl border-2 p-3 transition-[border-color,box-shadow] duration-200 sm:gap-2 sm:p-4",
                  activeState === "show" || activeState === "feedback"
                    ? "border-emerald-400/70 shadow-[0_0_28px_rgba(16,185,129,0.18)]"
                    : "border-border",
                ].join(" ")}
              >
                {Array.from({ length: CELL_COUNT }, (_, i) => {
                  const lit = litCells.includes(i);
                  const revealed = revealCells.includes(i);
                  const pickedCell = picked.includes(i);
                  const showLit = activeState === "show" || peeking ? lit : false;
                  const feedbackState =
                    activeState === "feedback"
                      ? revealed
                        ? pickedCell
                          ? "hit"
                          : "missed"
                        : pickedCell
                          ? "wrong"
                          : "idle"
                      : null;
                  return (
                    <button
                      key={i}
                      type="button"
                      data-testid={`pm-cell-${i}`}
                      data-on={showLit ? "1" : "0"}
                      disabled={activeState !== "recall" || peeking}
                      onClick={() => toggleCell(i)}
                      aria-label={`tile row ${Math.floor(i / GRID_SIZE) + 1} column ${(i % GRID_SIZE) + 1}`}
                      className={[
                        "aspect-square rounded-md transition-[background-color,transform,box-shadow] duration-100 sm:rounded-lg",
                        showLit
                          ? "bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.55)]"
                          : feedbackState === "hit"
                            ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.45)]"
                            : feedbackState === "missed"
                              ? "bg-emerald-300/60"
                              : feedbackState === "wrong"
                                ? "bg-red-400"
                                : pickedCell
                                  ? "bg-emerald-600"
                                  : "border border-border bg-background hover:border-primary/50",
                      ].join(" ")}
                    />
                  );
                })}
              </div>
            </div>

            {/* Recall controls */}
            {activeState === "recall" && (
              <div className="mx-auto mt-5 flex w-full max-w-[420px] items-center justify-center gap-3">
                <button
                  type="button"
                  data-testid="pm-peek-btn"
                  aria-keyshortcuts="P"
                  disabled={peeksLeft <= 0 || peeking}
                  onClick={spendPeek}
                  className="inline-flex flex-1 touch-manipulation items-center justify-center gap-2 rounded-xl border-2 border-border bg-card px-4 py-3.5 text-base font-semibold text-foreground shadow-sm transition-[translate,border-color,color] hover:border-primary hover:text-primary active:translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {peeksLeft > 0 ? (
                    <Eye className="h-5 w-5" aria-hidden="true" />
                  ) : (
                    <EyeOff className="h-5 w-5" aria-hidden="true" />
                  )}
                  Peek ({peeksLeft})
                  <kbd className="ml-1 hidden rounded border border-border px-1.5 text-xs font-bold text-muted-foreground sm:inline">P</kbd>
                </button>
                <button
                  type="button"
                  data-testid="pm-submit"
                  aria-keyshortcuts="Enter"
                  onClick={submitRound}
                  className="inline-flex flex-1 touch-manipulation items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:bg-emerald-700 active:translate-y-0.5"
                >
                  Submit
                  <kbd className="ml-1 hidden rounded border border-white/40 px-1.5 text-xs font-bold sm:inline">↵</kbd>
                </button>
              </div>
            )}

            {/* Status */}
            <p
              data-testid="pm-status"
              aria-live="polite"
              className="mt-4 text-center text-sm font-semibold text-muted-foreground sm:text-base"
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="pm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="pm-accuracy"
                    data-final={Math.round(score.accuracy * 100)}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={Math.round(score.accuracy * 100)} duration={1.2} />
                    <span className="text-3xl text-muted-foreground sm:text-4xl">%</span>
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  pattern content rebuilt · {score.totalCells} tiles shown
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="pm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Pattern memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="pm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <LayoutGrid className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="pm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Per-round score bars */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Round by round
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Bigger patterns, shorter flashes, fewer peeks - watch where it gets hard
                </p>
                <div className="mt-3 space-y-2.5">
                  {score.rounds.map((rs) => {
                    const pct = Math.round(rs.score * 100);
                    return (
                      <div key={rs.round} className="flex items-center gap-3">
                        <span className="w-20 shrink-0 text-xs font-semibold text-muted-foreground sm:w-24 sm:text-sm">
                          Round {rs.round + 1}
                        </span>
                        <div className="h-3 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className={[
                              "h-full rounded-full transition-[width] duration-700",
                              pct >= 80
                                ? "bg-emerald-500"
                                : pct >= 50
                                  ? "bg-emerald-400"
                                  : "bg-amber-400",
                            ].join(" ")}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span
                          data-testid={`pm-round-score-${rs.round}`}
                          data-final={pct}
                          className="w-12 shrink-0 text-right text-sm font-bold tabular-nums text-foreground"
                        >
                          {pct}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="pm-stat-hits" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.hits}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">tiles rebuilt</p>
                </div>
                <div data-testid="pm-stat-wrong" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.wrong}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">wrong tiles</p>
                </div>
                <div data-testid="pm-stat-peeks" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.peeksUsed}/{score.peeksAvailable}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">peeks spent</p>
                </div>
                <div data-testid="pm-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.avgRtMs !== null ? `${(score.avgRtMs / 1000).toFixed(1)}s` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg recall time</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="pm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - fresh patterns
                </button>
                <a
                  href="/test"
                  data-testid="pm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {score.hits} of {score.totalCells} tiles rebuilt ·{" "}
                {score.wrong} wrong tile{score.wrong === 1 ? "" : "s"} ·{" "}
                {runSeconds !== null ? `${runSeconds.toFixed(0)}s total` : "pattern-pure scoring"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
