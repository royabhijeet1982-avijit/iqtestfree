/* ------------------------------------------------------------------ */
/*  Mental Rotation Test - pure engine (no React, no DOM)              */
/*  Paradigm: Shepard-Metzler-style cube figures, the classic marker   */
/*  task for spatial ability and mental imagery (Shepard & Metzler,    */
/*  1971; Cooper & Shepard, 1973).                                     */
/*                                                                     */
/*  A figure is a set of unit cells on an NxN grid forming a           */
/*  connected arm-like polyline (a self-avoiding random walk of        */
/*  6-8 cells, normalised to its bounding box). Each item shows a      */
/*  TARGET figure and a CANDIDATE figure rotated by 0/90/180/270       */
/*  degrees. Half the items are "same" (candidate = target rotated);   */
/*  half are "different" (candidate = MIRRORED target, then rotated).  */
/*  The user answers with two buttons: "Same figure" / "Mirrored       */
/*  figure". Random guessing therefore floors at ~50% accuracy.        */
/*                                                                     */
/*  Scoring model (population-anchored, IQ mean 100 / SD 15):          */
/*   - accuracy z-score, anchored at 78% (SD 12 percentage points)     */
/*   - rotation-cost z-score: RT slope in ms per degree of rotation,   */
/*     anchored at 6 ms/deg (SD 4); lower is better. The slope          */
/*     component is reliability-gated: as accuracy approaches the      */
/*     50% guessing floor, the slope can no longer add credit, so      */
/*     fast random clicking cannot farm a low-slope bonus.             */
/*   - composite z = 0.6 * accuracyZ + 0.4 * slopeComponent            */
/*   - IQ = 100 + 15z, clamped to 55..145; percentile via erf CDF,     */
/*     clamped to 1..99.                                               */
/*                                                                     */
/*  Anti-gaming:                                                        */
/*   - Fresh random figures on every attempt (retakes cannot be        */
/*     memorised).                                                     */
/*   - Individual answers under 800ms are counted as rushed and the    */
/*     percentage is shown; a median under 1500ms COMBINED with        */
/*     accuracy below 85% flags the session as rushed (score still     */
/*     shown, with an honesty panel).                                  */
/*   - Random guessing floors at ~50% accuracy and the honesty panel   */
/*     says so.                                                        */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Session length: 24 figure pairs (8 when ?quick=1). */
export const ITEM_COUNT = 24;
export const QUICK_ITEM_COUNT = 8;

/** The four rotation angles used to build candidates. */
export const ANGLES = [0, 90, 180, 270] as const;
export type MrotAngle = (typeof ANGLES)[number];

/** Figure size: 6-8 connected cells per random walk. */
export const MIN_CELLS = 6;
export const MAX_CELLS = 8;

/** Angles sort ascending (difficulty ramp) with this much jitter. */
export const RAMP_JITTER_DEG = 135;

/** IQ scale bounds. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/** Individual answers faster than this are "rushed" (counted + shown). */
export const FAST_RT_MS = 800;

/** Median under this, WITH accuracy below the max below, flags a rushed session. */
export const RUSHED_MEDIAN_MS = 1500;
export const RUSHED_ACCURACY_MAX = 0.85;
/** Minimum answered items before the rushed flag can fire. */
export const MIN_RUSHED_N = 6;

/** Two-option item: random guessing floors at ~50% accuracy. */
export const CHANCE_ACCURACY = 0.5;
/** Accuracy at or below this shows the "looks like guessing" honesty note. */
export const NEAR_CHANCE_ACCURACY = 0.6;

/** Population anchors (adult casual web users, compact 2D-grid task). */
export const ACC_MEAN = 0.78;
export const ACC_SD = 0.12;
export const SLOPE_MEAN = 6; // ms per degree of rotation
export const SLOPE_SD = 4; // ms per degree, population spread
/** Composite weights: accuracy carries 60%, rotation cost 40%. */
export const ACC_WEIGHT = 0.6;
export const SLOPE_WEIGHT = 0.4;
/** Cap on the credit the (inverted) slope z can contribute. */
export const SLOPE_CREDIT_MAX = 1.5;
/** Slope component reliability ramps from 0 at chance to 1 here above it. */
export const REL_SPAN = 0.28;
/** Hard sanity clamp for the estimated RT slope (ms per degree). */
export const SLOPE_CLAMP_MAX = 30;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type Cell = { x: number; y: number };

/** A figure: normalised cells on a size x size grid (bounding box). */
export type Figure = {
  cells: Cell[];
  /** max(width, height) of the bounding box - invariant under rotation/mirror. */
  size: number;
};

export type MrotAnswer = "same" | "different";

export type MrotItem = {
  index: number;
  target: Figure;
  candidate: Figure;
  /** Rotation applied to the target (or its mirror) to build the candidate. */
  angleDeg: MrotAngle;
  /** true = candidate is the target rotated; false = mirrored then rotated. */
  isSame: boolean;
  correctAnswer: MrotAnswer;
};

export type AngleStat = { angle: MrotAngle; correct: number; total: number };

export type MrotGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type SlopePair = { angleDeg: number; rtMs: number };

export type MrotScore = {
  total: number;
  answered: number;
  correct: number;
  /** correct / answered, 0..1 */
  accuracy: number;
  medianRtMs: number;
  meanRtMs: number;
  /** Answers faster than FAST_RT_MS. */
  fastCount: number;
  /** fastCount / answered, 0..1 */
  fastPct: number;
  /** RT slope over CORRECT trials, ms per degree of rotation (null if unestimable). */
  slopeMsPerDeg: number | null;
  angleStats: AngleStat[];
  rushed: boolean;
  /** Accuracy at/below NEAR_CHANCE_ACCURACY - the honesty panel explains the 50% floor. */
  nearChance: boolean;
  iq: number;
  percentile: number;
  grade: MrotGrade;
  valid: boolean;
  invalidReason: string | null;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Figure algebra                                                     */
/* ------------------------------------------------------------------ */

/** Shift cells so the bounding box starts at (0, 0). */
export function normalizeCells(cells: readonly Cell[]): Cell[] {
  if (cells.length === 0) return [];
  const minX = Math.min(...cells.map((c) => c.x));
  const minY = Math.min(...cells.map((c) => c.y));
  return cells.map((c) => ({ x: c.x - minX, y: c.y - minY }));
}

/** max(width, height) of the bounding box. */
export function bboxSize(cells: readonly Cell[]): number {
  const w = Math.max(...cells.map((c) => c.x)) + 1;
  const h = Math.max(...cells.map((c) => c.y)) + 1;
  return Math.max(w, h);
}

/**
 * Rotate cells by a multiple of 90 degrees (clockwise in screen
 * coordinates where y grows downward) and re-normalise. Angles are
 * reduced modulo 360, so any integer degree value is accepted.
 */
export function rotateFigure(cells: readonly Cell[], deg: number): Cell[] {
  const norm = ((Math.round(deg) % 360) + 360) % 360;
  const quarterTurns = Math.round(norm / 90) % 4;
  let pts = cells.map((c) => ({ x: c.x, y: c.y }));
  for (let i = 0; i < quarterTurns; i++) {
    pts = pts.map((p) => ({ x: -p.y, y: p.x }));
  }
  return normalizeCells(pts);
}

/** Mirror horizontally (flip the x axis) and re-normalise. */
export function mirrorFigure(cells: readonly Cell[]): Cell[] {
  return normalizeCells(cells.map((c) => ({ x: -c.x, y: c.y })));
}

/** Stable, order-independent key for a cell set. */
export function figureKey(cells: readonly Cell[]): string {
  return cells.map((c) => `${c.x},${c.y}`).sort().join(";");
}

/** True when both arguments contain exactly the same cells. */
export function figuresEqual(a: readonly Cell[], b: readonly Cell[]): boolean {
  return a.length === b.length && figureKey(a) === figureKey(b);
}

/**
 * A chiral figure is NOT equal to any rotated copy of its own mirror
 * image. Only chiral figures may be used for "different" items - for
 * achiral ones the mirrored candidate could coincide with a plain
 * rotation of the target, making both answers arguably correct.
 */
export function isChiralFigure(cells: readonly Cell[]): boolean {
  const mirrored = mirrorFigure(cells);
  for (const deg of ANGLES) {
    if (figuresEqual(mirrored, rotateFigure(cells, deg))) return false;
  }
  return true;
}

const DIRS: readonly (readonly [number, number])[] = [
  [1, 0],
  [0, 1],
  [-1, 0],
  [0, -1],
];

/**
 * One self-avoiding random-walk attempt: 6-8 cells, moving in short
 * straight runs (1-3 cells per arm) so figures read as arm-like
 * polylines rather than noisy snakes. Returns null when boxed in.
 */
function tryGrowFigure(rng: () => number): Cell[] | null {
  const target = MIN_CELLS + Math.floor(rng() * (MAX_CELLS - MIN_CELLS + 1));
  const cells: Cell[] = [{ x: 0, y: 0 }];
  const visited = new Set<string>(["0,0"]);
  let dir = Math.floor(rng() * 4);
  let runLeft = 1 + Math.floor(rng() * 3);
  for (let guard = 0; cells.length < target && guard < 300; guard++) {
    const head = cells[cells.length - 1]!;
    const order: number[] = [];
    if (runLeft > 0) order.push(dir);
    for (const d of shuffle([0, 1, 2, 3], rng)) {
      if (!order.includes(d)) order.push(d);
    }
    let moved = false;
    for (const d of order) {
      const [dx, dy] = DIRS[d]!;
      const next = { x: head.x + dx, y: head.y + dy };
      const key = `${next.x},${next.y}`;
      if (visited.has(key)) continue;
      cells.push(next);
      visited.add(key);
      if (d === dir) {
        runLeft -= 1;
      } else {
        dir = d;
        runLeft = Math.floor(rng() * 3);
      }
      moved = true;
      break;
    }
    if (!moved) return null;
  }
  return cells.length === target ? cells : null;
}

/** Deterministic chiral fallback (diagonal staircase, 6 cells). */
const FALLBACK_CELLS: readonly Cell[] = [
  { x: 0, y: 0 },
  { x: 1, y: 0 },
  { x: 1, y: 1 },
  { x: 2, y: 1 },
  { x: 2, y: 2 },
  { x: 3, y: 2 },
];

/**
 * Generate a random Shepard-Metzler-style figure: a connected,
 * self-avoiding polyline of 6-8 unit cells, normalised to its
 * bounding box and guaranteed chiral (safe for "different" items).
 */
export function generateFigure(rng: () => number): Figure {
  for (let attempt = 0; attempt < 400; attempt++) {
    const walked = tryGrowFigure(rng);
    if (!walked) continue;
    const cells = normalizeCells(walked);
    if (cells.length < MIN_CELLS || cells.length > MAX_CELLS) continue;
    if (!isChiralFigure(cells)) continue;
    return { cells, size: bboxSize(cells) };
  }
  return {
    cells: FALLBACK_CELLS.map((c) => ({ ...c })),
    size: bboxSize(FALLBACK_CELLS),
  };
}

/* ------------------------------------------------------------------ */
/*  Item construction                                                  */
/* ------------------------------------------------------------------ */

/**
 * Generate a full session from a seed.
 *
 * Balance: items are split evenly across the four angles and, within
 * each angle, evenly between "same" and "different". Ordering ramps
 * with angle (0/90 easy first, 180/270 hard later) while jitter keeps
 * the exact angle of each trial unpredictable.
 *
 * Every seed produces a different set of figures, so retakes always
 * present fresh material.
 */
export function generateItems(seed: number, count: number = ITEM_COUNT): MrotItem[] {
  const rng = mulberry32(seed);
  const base = Math.floor(count / ANGLES.length);
  const remainder = count % ANGLES.length;
  const staged: Omit<MrotItem, "index">[] = [];
  ANGLES.forEach((angle, ai) => {
    const n = base + (ai < remainder ? 1 : 0);
    const sameCount = Math.ceil(n / 2);
    for (let k = 0; k < n; k++) {
      const isSame = k < sameCount;
      const target = generateFigure(rng);
      const baseCells = isSame ? target.cells : mirrorFigure(target.cells);
      const candidate: Figure = {
        cells: rotateFigure(baseCells, angle),
        size: target.size,
      };
      staged.push({
        target,
        candidate,
        angleDeg: angle,
        isSame,
        correctAnswer: isSame ? "same" : "different",
      });
    }
  });
  const ordered = staged
    .map((item) => ({ item, key: item.angleDeg + rng() * RAMP_JITTER_DEG }))
    .sort((a, b) => a.key - b.key)
    .map((entry) => entry.item);
  return ordered.map((item, i) => ({ ...item, index: i }));
}

/** Grade a user's same/mirrored choice for an item. */
export function gradeAnswer(item: MrotItem, answer: MrotAnswer | null): boolean {
  return answer !== null && answer === item.correctAnswer;
}

/** Stable content fingerprint (figures + angle + polarity) for anti-repetition checks. */
export function itemFingerprint(item: MrotItem): string {
  const payload = JSON.stringify({
    t: figureKey(item.target.cells),
    c: figureKey(item.candidate.cells),
    a: item.angleDeg,
    s: item.isSame,
  });
  let h = 5381;
  for (let i = 0; i < payload.length; i++) {
    h = ((h << 5) + h + payload.charCodeAt(i)) | 0;
  }
  return (h >>> 0).toString(36);
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}

/** IQ-scale score -> population percentile (1..99), normal model. */
export function iqToPercentile(iq: number): number {
  const pct = normalCdf(iq, 100, 15) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/**
 * Composite IQ from accuracy and rotation cost.
 *
 * accuracyZ is anchored at 78% (SD 12). The rotation-cost component is
 * the inverted slope z (fewer ms per degree = better), capped at
 * SLOPE_CREDIT_MAX and gated by a reliability factor that falls to
 * zero at the 50% guessing floor - so low-accuracy sessions cannot
 * profit from a meaningless flat slope. A null slope (too few correct
 * trials to estimate) contributes nothing.
 */
export function computeIq(accuracy: number, slopeMsPerDeg: number | null): number {
  const accZ = (accuracy - ACC_MEAN) / ACC_SD;
  let slopeComponent = 0;
  if (slopeMsPerDeg !== null) {
    const reliability = Math.min(1, Math.max(0, (accuracy - CHANCE_ACCURACY) / REL_SPAN));
    const invertedSlopeZ = -((slopeMsPerDeg - SLOPE_MEAN) / SLOPE_SD);
    slopeComponent = reliability * Math.min(SLOPE_CREDIT_MAX, invertedSlopeZ);
  }
  const z = ACC_WEIGHT * accZ + SLOPE_WEIGHT * slopeComponent;
  const iq = Math.round(100 + 15 * z);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** Five-tier grade anchored to the IQ-scale score. */
export function gradeForIq(iq: number): MrotGrade {
  if (iq < 85) {
    return {
      label: "Developing",
      blurb: "You matched several pairs correctly - mental rotation responds fast to practice, so a slower, more deliberate retake usually lifts this score.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most people - you told rotations from mirrors on the easier angles and held your own on the hard ones.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Strong",
      blurb: "Better than most - you rotated figures quickly without letting mirror joints trip you up.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very strong",
      blurb: "Top-tier spatial skill - large rotations barely slowed you down and your accuracy stayed high.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb: "Elite mental rotation - the kind of performance seen in the top few percent of test takers.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Statistics                                                         */
/* ------------------------------------------------------------------ */

/** Median of a numeric sample (average of the two middles when even). */
export function medianOf(xs: readonly number[]): number {
  if (xs.length === 0) return 0;
  const sorted = xs.slice().sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid] as number;
  return ((sorted[mid - 1] as number) + (sorted[mid] as number)) / 2;
}

/**
 * Ordinary least-squares slope of RT on rotation angle, in ms per
 * degree. Returns null when there are fewer than 3 pairs or no angle
 * variance (the slope is then unestimable). The result is clamped to
 * [0, SLOPE_CLAMP_MAX]: a negative estimate is RT noise, not a real
 * "faster at larger angles" effect.
 */
export function slopeMsPerDegOf(pairs: readonly SlopePair[]): number | null {
  if (pairs.length < 3) return null;
  const meanA = pairs.reduce((a, p) => a + p.angleDeg, 0) / pairs.length;
  const meanR = pairs.reduce((a, p) => a + p.rtMs, 0) / pairs.length;
  let cov = 0;
  let varA = 0;
  for (const p of pairs) {
    const da = p.angleDeg - meanA;
    cov += da * (p.rtMs - meanR);
    varA += da * da;
  }
  if (varA < 1e-6) return null;
  const slope = cov / varA;
  return Math.min(SLOPE_CLAMP_MAX, Math.max(0, slope));
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Score a full session.
 *
 * answers[i] = "same" | "different" | null (null only if the item was
 * somehow skipped - the UI always records an answer).
 * rtsMs[i]   = response time for item i in ms (or null).
 *
 * Validity: a session with zero answered items is not scored. Sessions
 * are ALWAYS scored otherwise (score still shown), but flagged rushed
 * when the median answer time is under RUSHED_MEDIAN_MS while accuracy
 * sits below RUSHED_ACCURACY_MAX - too fast to have really rotated the
 * figures. Per-answer speed under FAST_RT_MS is reported separately.
 */
export function scoreMentalRotationSession(
  items: readonly MrotItem[],
  answers: readonly (MrotAnswer | null)[],
  rtsMs: readonly (number | null)[]
): MrotScore {
  const total = items.length;
  const answeredIdx: number[] = [];
  for (let i = 0; i < total; i++) {
    const a = answers[i];
    if (a === "same" || a === "different") answeredIdx.push(i);
  }
  const answered = answeredIdx.length;
  const correct = answeredIdx.filter((i) =>
    gradeAnswer(items[i] as MrotItem, answers[i] as MrotAnswer)
  ).length;
  const accuracy = answered > 0 ? correct / answered : 0;

  const rts = answeredIdx
    .map((i) => rtsMs[i])
    .filter((r): r is number => typeof r === "number" && Number.isFinite(r) && r >= 0);
  const medianRtMs = medianOf(rts);
  const meanRtMs = rts.length > 0 ? rts.reduce((a, b) => a + b, 0) / rts.length : 0;
  const fastCount = rts.filter((r) => r < FAST_RT_MS).length;
  const fastPct = rts.length > 0 ? fastCount / rts.length : 0;

  // RT-vs-angle regression over CORRECT trials only: errors carry no
  // meaningful rotation signal.
  const slopePairs: SlopePair[] = answeredIdx
    .filter((i) => gradeAnswer(items[i] as MrotItem, answers[i] as MrotAnswer))
    .map((i) => ({
      angleDeg: (items[i] as MrotItem).angleDeg,
      rtMs: rtsMs[i] as number,
    }))
    .filter((p) => typeof p.rtMs === "number" && Number.isFinite(p.rtMs) && p.rtMs >= 0);
  const slope = slopeMsPerDegOf(slopePairs);

  const angleStats: AngleStat[] = ANGLES.map((angle) => {
    const idxs = items
      .map((it, i) => (it.angleDeg === angle ? i : -1))
      .filter((i) => i >= 0);
    const c = idxs.filter((i) => gradeAnswer(items[i] as MrotItem, answers[i] ?? null)).length;
    return { angle, correct: c, total: idxs.length };
  });

  const rushed =
    answered >= MIN_RUSHED_N &&
    rts.length >= MIN_RUSHED_N &&
    medianRtMs < RUSHED_MEDIAN_MS &&
    accuracy < RUSHED_ACCURACY_MAX;
  const nearChance = answered > 0 && accuracy <= NEAR_CHANCE_ACCURACY;

  if (answered === 0) {
    return {
      total,
      answered: 0,
      correct: 0,
      accuracy: 0,
      medianRtMs: 0,
      meanRtMs: 0,
      fastCount: 0,
      fastPct: 0,
      slopeMsPerDeg: null,
      angleStats: angleStats.map((s) => ({ ...s, correct: 0 })),
      rushed: false,
      nearChance: false,
      iq: 0,
      percentile: 0,
      grade: {
        label: "Not scored",
        blurb: "No answers were recorded, so there is nothing to score.",
        className: "bg-amber-50 text-amber-800 border-amber-200",
      },
      valid: false,
      invalidReason: "No answers were recorded.",
    };
  }

  const iq = computeIq(accuracy, slope);
  return {
    total,
    answered,
    correct,
    accuracy,
    medianRtMs,
    meanRtMs,
    fastCount,
    fastPct,
    slopeMsPerDeg: slope,
    angleStats,
    rushed,
    nearChance,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
    valid: true,
    invalidReason: null,
  };
}
