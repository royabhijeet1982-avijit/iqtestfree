/* ------------------------------------------------------------------ */
/*  N-Back Test - pure scoring engine                                  */
/*  Paradigm: the classic letter N-back working-memory task            */
/*  (Kirchner 1958 and successors). A run is 5 sequential blocks with  */
/*  N = 1, 2, 3, 4, 5. Each block presents 20 + N letters, one every   */
/*  2800 ms (visible ~1500 ms, then a gap). The user responds whenever */
/*  the current letter matches the one exactly N steps earlier.        */
/*                                                                     */
/*  Sequence construction guarantees (per block):                      */
/*   - EXACTLY round(0.3 * trials) lag-N targets                       */
/*   - the first N trials are warm-up and can never be targets         */
/*   - lag-(N-1) LURES on some non-target trials: the letter matches   */
/*     one step back but not N steps back - these punish near-misses   */
/*   - no letter ever appears 3 times in a row                         */
/*   - a position is a target if and only if its letter equals the     */
/*     letter N steps back (so the displayed data is always honest)    */
/*                                                                     */
/*  Scoring is signal detection: every trial lands in exactly one of   */
/*  hit / miss / false alarm / correct rejection. balancedScore =      */
/*  mean(hitRate, correctRejectionRate), which defeats BOTH mashing    */
/*  the button on every trial (100% FA, 0% CR -> 0.5) and never        */
/*  responding (0% hits, 100% CR -> 0.5).                              */
/*                                                                     */
/*  effectiveSpan = highest N with balancedScore >= 0.70. Composite =  */
/*  mean of the five balanced scores. IQ is anchored through           */
/*  SPAN_IQ_ANCHORS, interpolated by effective span and nudged a few   */
/*  points by how strongly the run was held within its level.          */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected RNG so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** The eight letters letters are drawn from (visually distinct capitals). */
export const NBACK_LETTERS = ["C", "F", "H", "K", "L", "Q", "R", "S"] as const;

/** Full rhythm of one trial: stimulus visible + inter-stimulus gap. */
export const TRIAL_MS = 2800;

/** How long each letter stays on screen before the gap. */
export const STIMULUS_VISIBLE_MS = 1500;

/** Target share of trials in a block (exactly round(0.3 * trials)). */
export const TARGET_RATE = 0.3;

/** A block passes (counts toward span) at this balanced score. */
export const PASS_THRESHOLD = 0.7;

/** Share of eligible non-target trials deliberately turned into lures. */
export const LURE_RATE = 0.28;

/** Full run: five sequential blocks, N = 1..5. */
export const BLOCK_N_VALUES = [1, 2, 3, 4, 5] as const;

/** Quick run (flow tests): two blocks, N = 1..2. */
export const QUICK_BLOCK_N_VALUES = [1, 2] as const;

/** Block N runs BASE_TRIALS_PER_BLOCK + N trials. */
export const BASE_TRIALS_PER_BLOCK = 20;

/** Quick-mode blocks run a fixed 12 trials. */
export const QUICK_TRIALS_PER_BLOCK = 12;

/** IQ anchor points by effective span (interpolated between levels). */
export const SPAN_IQ_ANCHORS: Record<number, number> = {
  0: 64,
  1: 77,
  2: 90,
  3: 102,
  4: 116,
  5: 130,
};

/** Population model for effective span (adult casual web users). */
export const SPAN_MEAN = 2.3;
export const SPAN_SD = 1.05;

export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type NBackTrial = {
  /** Position of the trial inside its block (0-based). */
  index: number;
  letter: string;
  /** True when the letter matches the one exactly N steps back. */
  isTarget: boolean;
  /** True when the letter matches N-1 back but NOT N back (N >= 2). */
  isLure: boolean;
};

export type NBackBlock = {
  n: number;
  trials: NBackTrial[];
  targetCount: number;
  lureCount: number;
};

/** What the user did on one trial. One response per trial, at most. */
export type TrialResponse = {
  responded: boolean;
  rtMs: number | null;
};

export type TrialOutcome = "hit" | "miss" | "false-alarm" | "correct-rejection";

export type BlockScore = {
  n: number;
  trialCount: number;
  targetCount: number;
  nonTargetCount: number;
  lureCount: number;
  /** False alarms on lure trials specifically (near-miss slips). */
  lureErrors: number;
  hits: number;
  misses: number;
  falseAlarms: number;
  correctRejections: number;
  hitRate: number;
  correctRejectionRate: number;
  balancedScore: number;
  passed: boolean;
  /** Mean response time over hits (null when there were none). */
  meanHitRtMs: number | null;
};

export type NBackGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type NBackResults = {
  blocks: BlockScore[];
  /** Highest N whose block scored >= PASS_THRESHOLD (0 if none did). */
  effectiveSpan: number;
  /** Mean of every block's balanced score (0..1). */
  composite: number;
  /** IQ-anchored working-memory index (IQ_MIN..IQ_MAX). */
  iq: number;
  /** Population percentile 1..99 for the effective span. */
  percentile: number;
  grade: NBackGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG + helpers (deterministic under injected seed)                  */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle (returns a new array; rng in [0,1)). */
export function shuffle<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i] as T;
    out[i] = out[j] as T;
    out[j] = tmp;
  }
  return out;
}

function clamp01(x: number): number {
  return Math.min(1, Math.max(0, x));
}

/* ------------------------------------------------------------------ */
/*  Block construction                                                 */
/* ------------------------------------------------------------------ */

/** Exact number of lag-N targets for a block of the given length. */
export function targetCountFor(totalTrials: number): number {
  return Math.round(TARGET_RATE * totalTrials);
}

/** Random letter avoiding everything in `exclude` (pool never empties:
 *  callers exclude at most 2 of the 8 letters). */
function pickLetterExcluding(rng: () => number, exclude: readonly string[]): string {
  const pool = NBACK_LETTERS.filter((l) => !exclude.includes(l));
  return pool[Math.floor(rng() * pool.length)]!;
}

function tryBuildBlock(
  n: number,
  total: number,
  targetCount: number,
  rng: () => number
): NBackBlock | null {
  // 1. Choose target positions: distinct indices in [n, total), so the
  //    first N trials stay warm-up.
  const eligible: number[] = [];
  for (let i = n; i < total; i++) eligible.push(i);
  const targetPos = new Set(shuffle(eligible, rng).slice(0, targetCount));
  if (targetPos.size !== targetCount) return null;

  // 2. Pre-select lure intent positions among the remaining trials.
  const free = shuffle(
    eligible.filter((i) => !targetPos.has(i)),
    rng
  );
  const lureIntents = new Set(free.slice(0, Math.max(2, Math.round(targetCount / 2))));

  // 3. Fill letters left to right honouring every constraint.
  const letters: string[] = [];
  for (let i = 0; i < total; i++) {
    const formsTriple = (candidate: string) =>
      i >= 2 && letters[i - 1] === candidate && letters[i - 2] === candidate;

    if (i < n) {
      // Warm-up: free choice, only the anti-repeat rule applies.
      const exclude: string[] = [];
      if (i >= 2 && letters[i - 1] === letters[i - 2]) exclude.push(letters[i - 1]!);
      letters.push(pickLetterExcluding(rng, exclude));
      continue;
    }

    if (targetPos.has(i)) {
      // Forced: must equal the letter N steps back.
      const forced = letters[i - n]!;
      if (formsTriple(forced)) return null; // restart with new layout
      letters.push(forced);
      continue;
    }

    // Non-target: must NOT equal the letter N steps back.
    const exclude = [letters[i - n]!];
    if (i >= 2 && letters[i - 1] === letters[i - 2]) exclude.push(letters[i - 1]!);

    if (n >= 2 && lureIntents.has(i)) {
      const lureCandidate = letters[i - (n - 1)]!;
      // A lure matches N-1 back but not N back, and must not form a triple.
      if (lureCandidate !== letters[i - n] && !exclude.includes(lureCandidate)) {
        letters.push(lureCandidate);
        continue;
      }
    }
    letters.push(pickLetterExcluding(rng, exclude));
  }

  // 4. Validate + count the lures that actually materialised.
  let lureCount = 0;
  for (let i = n; i < total; i++) {
    const isTarget = letters[i] === letters[i - n];
    if (isTarget !== targetPos.has(i)) return null; // safety net
    if (n >= 2 && !isTarget && letters[i] === letters[i - (n - 1)]) lureCount++;
  }
  if (n >= 2 && lureCount === 0) return null; // every N>=2 block carries lures

  const trials: NBackTrial[] = letters.map((letter, index) => ({
    index,
    letter,
    isTarget: index >= n && letter === letters[index - n]!,
    isLure:
      n >= 2 &&
      index >= n &&
      letter !== letters[index - n]! &&
      letter === letters[index - (n - 1)]!,
  }));

  return { n, trials, targetCount, lureCount };
}

/**
 * Build one block of lag-N trials honouring every construction
 * guarantee. Randomised layouts are retried until all invariants hold;
 * the constraints are loose enough that a valid layout appears within
 * a handful of attempts, and the fallback retries deterministically.
 */
export function buildBlock(
  n: number,
  rng: () => number,
  opts?: { trials?: number }
): NBackBlock {
  const total = Math.max(n + 2, opts?.trials ?? BASE_TRIALS_PER_BLOCK + n);
  const targetCount = Math.min(targetCountFor(total), total - n);

  for (let attempt = 0; attempt < 400; attempt++) {
    const built = tryBuildBlock(n, total, targetCount, rng);
    if (built) return built;
  }
  // Deterministic last resort (never expected in practice): fresh
  // fixed-seed stream, many more attempts, then give up loudly.
  const fallbackRng = mulberry32(0x5eed ^ (n * 7919) ^ (total * 104729));
  for (let attempt = 0; attempt < 20_000; attempt++) {
    const built = tryBuildBlock(n, total, targetCount, fallbackRng);
    if (built) return built;
  }
  throw new Error(`buildBlock: could not satisfy constraints for N=${n}, trials=${total}`);
}

/**
 * Build a full run: five blocks (N = 1..5) of 20 + N trials, or two
 * 12-trial blocks (N = 1..2) in quick mode.
 */
export function buildBlocks(rng: () => number, opts: { quick?: boolean } = {}): NBackBlock[] {
  const ns = opts.quick ? QUICK_BLOCK_N_VALUES : BLOCK_N_VALUES;
  return ns.map((n) =>
    buildBlock(n, rng, opts.quick ? { trials: QUICK_TRIALS_PER_BLOCK } : undefined)
  );
}

/* ------------------------------------------------------------------ */
/*  Scoring                                                            */
/* ------------------------------------------------------------------ */

/** Signal-detection classification of a single trial. */
export function scoreTrial(trial: NBackTrial, responded: boolean): TrialOutcome {
  if (trial.isTarget) return responded ? "hit" : "miss";
  return responded ? "false-alarm" : "correct-rejection";
}

/**
 * Partition one block's trials into hits / misses / false alarms /
 * correct rejections and derive its balanced score.
 * hits + misses + falseAlarms + correctRejections === trials.length.
 */
export function scoreBlock(
  block: NBackBlock,
  responses: readonly TrialResponse[]
): BlockScore {
  let hits = 0;
  let misses = 0;
  let falseAlarms = 0;
  let correctRejections = 0;
  let lureErrors = 0;
  const hitRts: number[] = [];

  block.trials.forEach((trial, i) => {
    const responded = responses[i]?.responded ?? false;
    const outcome = scoreTrial(trial, responded);
    if (outcome === "hit") {
      hits += 1;
      const rt = responses[i]?.rtMs;
      if (rt != null && rt >= 0) hitRts.push(rt);
    } else if (outcome === "miss") {
      misses += 1;
    } else if (outcome === "false-alarm") {
      falseAlarms += 1;
      if (trial.isLure) lureErrors += 1;
    } else {
      correctRejections += 1;
    }
  });

  const trialCount = block.trials.length;
  const targetCount = block.trials.filter((t) => t.isTarget).length;
  const nonTargetCount = trialCount - targetCount;
  const hitRate = targetCount > 0 ? hits / targetCount : 0;
  const correctRejectionRate = nonTargetCount > 0 ? correctRejections / nonTargetCount : 0;
  const balancedScore = (hitRate + correctRejectionRate) / 2;
  const meanHitRtMs =
    hitRts.length > 0 ? hitRts.reduce((a, b) => a + b, 0) / hitRts.length : null;

  return {
    n: block.n,
    trialCount,
    targetCount,
    nonTargetCount,
    lureCount: block.lureCount,
    lureErrors,
    hits,
    misses,
    falseAlarms,
    correctRejections,
    hitRate,
    correctRejectionRate,
    balancedScore,
    passed: balancedScore >= PASS_THRESHOLD,
    meanHitRtMs,
  };
}

/**
 * Map a span + within-level strength to an IQ-anchored index.
 *
 * - The anchor table SPAN_IQ_ANCHORS is interpolated linearly by
 *   effective span.
 * - Within the level, `levelBalance` (the balanced score of the
 *   block that defined the span) adds up to half a level of progress,
 *   worth roughly +/-7 points.
 * - `composite` nudges the final value by up to +/-3 points so a
 *   consistently strong (or weak) whole run shows through.
 * - Result clamped to IQ_MIN..IQ_MAX.
 */
export function spanToIq(effectiveSpan: number, levelBalance: number, composite: number): number {
  const span = Math.min(5, Math.max(0, Math.round(effectiveSpan)));
  const within = span >= 1
    ? clamp01((levelBalance - PASS_THRESHOLD) / (1 - PASS_THRESHOLD))
    : clamp01(levelBalance / PASS_THRESHOLD);
  const continuous = span + within * 0.5;

  let raw: number;
  if (continuous >= 5) {
    // Extrapolate beyond the last anchor with the final segment's slope.
    const slope = SPAN_IQ_ANCHORS[5]! - SPAN_IQ_ANCHORS[4]!;
    raw = SPAN_IQ_ANCHORS[5]! + slope * (continuous - 5);
  } else {
    const lo = Math.floor(continuous);
    const hi = lo + 1;
    const anchorLo = SPAN_IQ_ANCHORS[lo] ?? SPAN_IQ_ANCHORS[0]!;
    const anchorHi = SPAN_IQ_ANCHORS[hi] ?? anchorLo;
    raw = anchorLo + (anchorHi - anchorLo) * (continuous - lo);
  }
  const nudge = Math.round((composite - 0.72) * 10);
  const clampedNudge = Math.min(3, Math.max(-3, nudge));
  const iq = Math.round(raw) + clampedNudge;
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** Effective span -> population percentile (1..99) under N(2.3, 1.05). */
export function percentileForSpan(span: number): number {
  const pct = normalCdf(span, SPAN_MEAN, SPAN_SD) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Six-tier grade anchored to the effective span. */
export function gradeForSpan(span: number): NBackGrade {
  if (span <= 0) {
    return {
      label: "Warming up",
      blurb:
        "The matches did not line up this run. That is normal on a first attempt - the rhythm of N-back takes a block or two to click.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (span === 1) {
    return {
      label: "Emerging",
      blurb:
        "You held a one-letter window reliably. Most people find N = 2 within reach once the task feels familiar, so a retake is worth it.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (span === 2) {
    return {
      label: "Solid",
      blurb:
        "N = 2 is right in the heart of the adult range - you tracked two streams of 'what was it two letters ago' without dropping the thread.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (span === 3) {
    return {
      label: "Strong",
      blurb:
        "Above the typical adult span. Holding three items while filtering lures takes real executive control.",
      className: "bg-emerald-500 text-white border-emerald-500",
    };
  }
  if (span === 4) {
    return {
      label: "Very strong",
      blurb:
        "Rare territory. Four-back means continuously updating a four-item window while the lures keep pulling at one step back.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Exceptional",
    blurb:
      "Five-back with a clean detection record - the top sliver of a bell curve. Very few people can hold this pace for a full block.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Run scoring                                                        */
/* ------------------------------------------------------------------ */

/**
 * Score a whole run: signal-detection partition per block, effective
 * span, composite, IQ anchor and percentile.
 */
export function computeResults(
  blocks: readonly NBackBlock[],
  responsesPerBlock: readonly (readonly TrialResponse[])[]
): NBackResults {
  const scores = blocks.map((block, i) => scoreBlock(block, responsesPerBlock[i] ?? []));
  return summarizeResults(scores);
}

/** Core result assembly (also usable with hand-built BlockScores). */
export function summarizeResults(scores: readonly BlockScore[]): NBackResults {
  let effectiveSpan = 0;
  for (const score of scores) {
    if (score.passed && score.n > effectiveSpan) effectiveSpan = score.n;
  }
  const composite =
    scores.length > 0
      ? scores.reduce((acc, s) => acc + s.balancedScore, 0) / scores.length
      : 0;

  // The block that defined the span drives the within-level nudge; for
  // span 0 the N = 1 block shows how close the run came.
  const levelBalance =
    effectiveSpan >= 1
      ? (scores.find((s) => s.n === effectiveSpan)?.balancedScore ?? 0)
      : (scores[0]?.balancedScore ?? 0);

  const iq = spanToIq(effectiveSpan, levelBalance, composite);
  return {
    blocks: scores.slice(),
    effectiveSpan,
    composite,
    iq,
    percentile: percentileForSpan(effectiveSpan),
    grade: gradeForSpan(effectiveSpan),
  };
}

/* ------------------------------------------------------------------ */
/*  Population model (normal CDF via erf approximation)                */
/* ------------------------------------------------------------------ */

/** Abramowitz & Stegun 7.1.26 erf approximation (|err| < 1.5e-7). */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-ax * ax);
  return sign * y;
}

export function normalCdf(x: number, mean: number, sd: number): number {
  const z = (x - mean) / (sd * Math.SQRT2);
  return 0.5 * (1 + erf(z));
}
