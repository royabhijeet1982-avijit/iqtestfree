/* ------------------------------------------------------------------ */
/*  Short-Term Memory Test - pure scoring engine                       */
/*  Paradigm: the classic Brown-Peterson filled-delay recall task.     */
/*  Each trial shows a consonant trigram ("CHJ") for a brief engine-   */
/*  owned flash, then a COUNTING-BACKWARDS task fills the retention    */
/*  interval (subtract 3 aloud from a start number - rehearsal made    */
/*  impossible), and finally the trigram must be typed back. Delays    */
/*  cycle 3s -> 9s -> 15s across nine trials, tracing the decay curve  */
/*  of short-term retention.                                           */
/*                                                                     */
/*  How this differs from the sibling tests on purpose:                */
/*   - word-memory: recognition (old/new judgements, lists of words).  */
/*     Here: pure RECALL of ordered letters after an interfering      */
/*     task - the raw capacity of the short-term buffer itself.        */
/*   - digit-span: recall WITHOUT interference, span grows until       */
/*     failure. Here: fixed 3-letter load, interference DURATION       */
/*     grows instead - we measure survival over time, not span.        */
/*                                                                     */
/*  Scoring honesty (anti-gaming by design):                           */
/*   - The score is position-wise letters correct across all 27        */
/*     letters. Random mashing nets ~0: Q is excluded from the pool    */
/*     so a fixed "QQQ" strategy can never farm a lucky match.         */
/*   - The delay is engine-owned: recall cannot open early, and the    */
/*     subtraction chain cannot pause the clock.                       */
/*   - Every run reseeds the RNG: fresh trigrams, fresh numbers.       */
/*                                                                     */
/*  This file is intentionally framework-free and fully deterministic  */
/*  under an injected seed so it can be unit-tested exhaustively.       */
/* ------------------------------------------------------------------ */

/** Consonants used for trigrams (Q excluded - see anti-gaming note). */
export const LETTER_POOL: readonly string[] = [
  "B", "C", "D", "F", "G", "H", "J", "K", "L", "M",
  "N", "P", "R", "S", "T", "V", "X", "Z",
];

/** Trials per session. */
export const TRIAL_COUNT = 9;

/** Retention intervals per trial, cycling 3s -> 9s -> 15s (x3 each). */
export const DELAY_MS: readonly number[] = [
  3000, 9000, 15000, 3000, 9000, 15000, 3000, 9000, 15000,
];

/** Unique delay levels, ascending (for the decay-curve report). */
export const DELAY_LEVELS: readonly number[] = [3000, 9000, 15000];

/* -------------------- Engine-owned timing (ms) -------------------- */
/** How long the trigram stays on screen. */
export const SHOW_MS = 900;
/** Gap between the trigram flash and the delay task opening. */
export const AFTER_SHOW_GAP_MS = 350;
/** Feedback reveal after each recall submission. */
export const FEEDBACK_MS = 850;

/** Shortened timings used by automated flow tests via ?quick=1. */
export const SHOW_MS_QUICK = 250;
export const AFTER_SHOW_GAP_MS_QUICK = 80;
export const FEEDBACK_MS_QUICK = 150;
/** Quick-mode delay per level (engine still owns the clock). */
export const DELAY_MS_QUICK: readonly number[] = [500, 900, 1400];

/* -------------------- Population model -------------------- */
/**
 * Adult mean / SD for position-wise letters correct across nine
 * Brown-Peterson trials with delays cycling 3/9/15 seconds. Perfect
 * recall (27/27) maps to the 145 ceiling; chance typing floors out.
 */
export const ACC_MEAN = 0.52;
export const ACC_SD = 0.13;

/** IQ-scale bounds (mean 100, SD 15), same clamps as the other tests. */
export const IQ_MIN = 55;
export const IQ_MAX = 145;

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

/** One trial: the to-remember trigram plus its filled-delay setup. */
export type StmTrial = {
  /** 0-based trial index. */
  trial: number;
  /** Three distinct consonants, e.g. "CHJ". */
  letters: string;
  /** Number to start counting backwards from, by 3. */
  startNumber: number;
  /** Retention interval in ms (engine-owned). */
  delayMs: number;
};

export type StmSession = {
  trials: StmTrial[];
};

/** One user recall submission. */
export type Recall = {
  trial: number;
  /** Raw typed answer, uppercased and stripped of non-letters. */
  answer: string;
  /** Time from recall opening to submission in ms (null if absent). */
  rtMs: number | null;
};

export type DurationStat = {
  delayMs: number;
  correct: number;
  total: number;
  accuracy: number;
};

export type StmGrade = {
  label: string;
  blurb: string;
  className: string;
};

export type StmScore = {
  /** Position-wise letters correct across the session. */
  correct: number;
  /** Total letters shown (trials x 3). */
  totalLetters: number;
  /** correct / totalLetters. */
  accuracy: number;
  /** Decay curve: one stat per unique delay level, ascending. */
  byDuration: DurationStat[];
  /** Mean recall submission time in ms (null when absent). */
  avgRtMs: number | null;
  /** Per-trial correct counts (0..3), length = trials recalled. */
  perTrial: number[];
  /** IQ-scale short-term memory index (mean 100, SD 15). */
  iq: number;
  /** Population percentile 1..99. */
  percentile: number;
  grade: StmGrade;
};

/* ------------------------------------------------------------------ */
/*  RNG (deterministic under injected seed)                            */
/* ------------------------------------------------------------------ */

/** Mulberry32 - tiny, fast, seedable PRNG returning floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Fisher-Yates shuffle of a copy - never mutates the input. */
export function shuffled<T>(items: readonly T[], rng: () => number): T[] {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i]!;
    out[i] = out[j]!;
    out[j] = tmp;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/*  Session building                                                   */
/* ------------------------------------------------------------------ */

/**
 * Draw the next trigram: three DISTINCT letters. A working bag is
 * reshuffled whenever it runs low, so consecutive trigrams avoid
 * immediate repetition where the bag allows it.
 */
export function drawTrigrams(count: number, rng: () => number): string[] {
  const out: string[] = [];
  let bag: string[] = [];
  for (let t = 0; t < count; t++) {
    if (bag.length < 3) bag = shuffled(LETTER_POOL, rng);
    const pick = bag.slice(0, 3);
    bag = bag.slice(3);
    out.push(pick.join(""));
  }
  return out;
}

/** Build a full session (9 trials) from a seed. */
export function buildStmSession(seed: number): StmSession {
  const rng = mulberry32(seed);
  const trigrams = drawTrigrams(TRIAL_COUNT, rng);
  const trials: StmTrial[] = [];
  for (let t = 0; t < TRIAL_COUNT; t++) {
    // Start numbers 101..989, never containing a 0 digit (cleaner to
    // read while counting backwards under load).
    let startNumber = 0;
    do {
      startNumber = 101 + Math.floor(rng() * 889);
    } while (String(startNumber).includes("0"));
    trials.push({
      trial: t,
      letters: trigrams[t]!,
      startNumber,
      delayMs: DELAY_MS[t]!,
    });
  }
  return { trials };
}

/* ------------------------------------------------------------------ */
/*  Counting chain (delay task helper)                                 */
/* ------------------------------------------------------------------ */

/**
 * The expected k-th subtraction answer for a trial: start - 3k.
 * The UI feeds this to validate the chain without ever affecting the
 * clock or the score.
 */
export function expectedCount(startNumber: number, step: number): number {
  return startNumber - 3 * step;
}

/* ------------------------------------------------------------------ */
/*  Population model + grading                                         */
/* ------------------------------------------------------------------ */

/**
 * Map position-wise letters-correct accuracy onto the IQ scale
 * (mean 100, SD 15), clamped to 55..145.
 */
export function stmIndex(accuracy: number): number {
  const clamped = Math.min(1, Math.max(0, accuracy));
  const iq = Math.round(100 + (15 * (clamped - ACC_MEAN)) / ACC_SD);
  return Math.min(IQ_MAX, Math.max(IQ_MIN, iq));
}

/** IQ -> population percentile (1..99), normal model with SD 15. */
export function iqToPercentile(iq: number): number {
  const erf = (x: number): number => {
    const sign = x < 0 ? -1 : 1;
    const ax = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * ax);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-ax * ax);
    return sign * y;
  };
  const z = (iq - 100) / 15;
  const pct = 0.5 * (1 + erf(z / Math.SQRT2)) * 100;
  return Math.min(99, Math.max(1, Math.round(pct)));
}

/** Five-tier grade anchored to the IQ number. */
export function gradeForIq(iq: number): StmGrade {
  if (iq < 85) {
    return {
      label: "Evaporated",
      blurb: "The counting task is wiping your trigrams almost immediately right now - one more run usually settles the rhythm of count-then-recall and lifts the number.",
      className: "bg-slate-100 text-slate-700 border-slate-200",
    };
  }
  if (iq < 100) {
    return {
      label: "Average",
      blurb: "Right in line with most adults - your letters survive the filled delay about as well as the general population's do.",
      className: "bg-emerald-50 text-emerald-700 border-emerald-200",
    };
  }
  if (iq < 115) {
    return {
      label: "Holding",
      blurb: "Better than most - a solid share of your trigrams survives even the fifteen-second interference interval.",
      className: "bg-emerald-100 text-emerald-800 border-emerald-300",
    };
  }
  if (iq < 130) {
    return {
      label: "Very sharp",
      blurb: "Top-tier short-term retention - the kind of interference resistance that shines in note-taking, languages and exams.",
      className: "bg-emerald-600 text-white border-emerald-600",
    };
  }
  return {
    label: "Steel trap",
    blurb: "Elite recall - most trigrams come back intact even after fifteen seconds of nonstop backwards counting.",
    className: "bg-emerald-700 text-white border-emerald-700",
  };
}

/* ------------------------------------------------------------------ */
/*  Session scoring                                                    */
/* ------------------------------------------------------------------ */

/**
 * Normalise a typed answer: uppercase, letters only, truncated to 3.
 * Returns "" when nothing usable was typed.
 */
export function normaliseAnswer(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^A-Z]/g, "")
    .slice(0, 3);
}

/**
 * Score a complete session. Primary metric: position-wise letters
 * correct (answer[i] === trigram[i]) across all 27 letters. Also
 * reports the decay curve per delay level. Trials without a recall
 * score 0.
 */
export function scoreSession(recalls: readonly Recall[], session: StmSession | null): StmScore {
  if (!session) {
    const iq = stmIndex(0);
    return {
      correct: 0,
      totalLetters: 0,
      accuracy: 0,
      byDuration: DELAY_LEVELS.map((d) => ({ delayMs: d, correct: 0, total: 0, accuracy: 0 })),
      avgRtMs: null,
      perTrial: [],
      iq,
      percentile: iqToPercentile(iq),
      grade: gradeForIq(iq),
    };
  }

  let correct = 0;
  let rtSum = 0;
  let rtCount = 0;
  const perTrial: number[] = [];
  const durMap = new Map<number, { correct: number; total: number }>();
  for (const d of DELAY_LEVELS) durMap.set(d, { correct: 0, total: 0 });

  for (const trial of session.trials) {
    const rc = recalls.find((r) => r.trial === trial.trial);
    let trialCorrect = 0;
    for (let d of durMap.values()) void d;
    if (rc) {
      const answer = normaliseAnswer(rc.answer);
      for (let i = 0; i < 3; i++) {
        if (answer[i] !== undefined && answer[i] === trial.letters[i]) {
          trialCorrect++;
        }
      }
      if (rc.rtMs !== null && Number.isFinite(rc.rtMs)) {
        rtSum += rc.rtMs;
        rtCount++;
      }
    }
    const bucket = durMap.get(trial.delayMs);
    if (bucket) {
      bucket.correct += trialCorrect;
      bucket.total += 3;
    }
    correct += trialCorrect;
    perTrial.push(trialCorrect);
  }

  const totalLetters = session.trials.length * 3;
  const accuracy = totalLetters > 0 ? correct / totalLetters : 0;
  const iq = stmIndex(accuracy);

  return {
    correct,
    totalLetters,
    accuracy,
    byDuration: DELAY_LEVELS.map((d) => {
      const b = durMap.get(d)!;
      return {
        delayMs: d,
        correct: b.correct,
        total: b.total,
        accuracy: b.total > 0 ? b.correct / b.total : 0,
      };
    }),
    avgRtMs: rtCount > 0 ? rtSum / rtCount : null,
    perTrial,
    iq,
    percentile: iqToPercentile(iq),
    grade: gradeForIq(iq),
  };
}
