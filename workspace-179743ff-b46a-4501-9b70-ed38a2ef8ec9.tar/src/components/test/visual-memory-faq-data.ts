/* ------------------------------------------------------------------ */
/*  Visual Memory Test - FAQ (single source)                           */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type VmFaq = { question: string; answer: string };

export const VISUAL_MEMORY_FAQS: VmFaq[] = [
  {
    question: "What is visual memory and what does the span score mean?",
    answer:
      "Visual memory is your ability to hold what you have just seen - shapes, positions and order - in mind after the stimulus is gone. Psychologists call the capacity part of this system the visual-spatial sketchpad. This test expresses your capacity as a span: the longest sequence of tiles you can reproduce perfectly. A span of four means you reliably held four positions in order; every extra tile is another chunk of spatial information your brain must maintain without letting it decay.",
  },
  {
    question: "What are Corsi blocks and why does this test use them?",
    answer:
      "The task is a digital version of the Corsi block-tapping test, introduced by Philip Corsi in 1972. In the original, an examiner taps a series of wooden blocks on a board and the participant taps them back in the same order. The format has survived for more than fifty years because it is quick, almost language-free, and remarkably sensitive to visuospatial working memory. Our version uses a 3x3 grid of lit tiles and grows the sequence automatically, so the staircase finds your true span without an examiner.",
  },
  {
    question: "Can chunking help me remember longer sequences?",
    answer:
      "Yes, and it is completely fair play. Chunking means grouping separate items into one meaningful unit - for example, seeing tiles 1, 3 and 5 as a diagonal line instead of three separate positions. Spatial patterns, clockwise sweeps and familiar shapes such as an L or a Z are all chunks. Studies of memory experts show that chunking, not raw capacity, explains most of the difference between average and exceptional performance, so look for geometry in the pattern before the recall phase starts.",
  },
  {
    question: "How does my score map to an IQ-scale number?",
    answer:
      "Your visual span is compared against an adult population model with a mean span of about 5.3 tiles and a standard deviation of 1.4. That z-score carries most of the weight (80%) in a composite, while a small speed bonus (20%) rewards quick, confident recall - capped so that clicking fast can never outweigh remembering more. The composite is mapped onto the standard IQ scale, which has a mean of 100 and a standard deviation of 15, and a percentile estimate is derived from the same normal model.",
  },
  {
    question: "Do age and age-related norms matter here?",
    answer:
      "They do. Raw Corsi span climbs through childhood, peaks in your twenties and thirties, and declines gradually from the fifties onward, so a nine-year-old and a seventy-year-old should not expect the same number. This test scores adults against adult norms to keep one clean, honest scale; if you are testing a child or an older adult, treat the result as a comparison against young-adult performance rather than against your own peer group. Trends across repeated runs matter more than any single score.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - the test is free and every run deals fresh random sequences, so retaking never lets you memorise the patterns. A sensible routine is two or three runs in one sitting, then a break: most people add about half a tile once the task mechanics feel automatic, and that warm-up effect is normal rather than cheating. Use your best or your average run as your personal baseline and track it over weeks, not minutes, to see real change.",
  },
];
