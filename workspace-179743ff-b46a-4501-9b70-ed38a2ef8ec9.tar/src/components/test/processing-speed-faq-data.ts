/* ------------------------------------------------------------------ */
/*  Processing Speed Test - FAQ (single source)                        */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type PsFaq = { question: string; answer: string };

export const PROCESSING_SPEED_FAQS: PsFaq[] = [
  {
    question: "What is processing speed?",
    answer:
      "Processing speed is how quickly your brain takes in visual information, decides on a response, and carries it out. It is one of the core cognitive abilities measured in assessments like the WAIS, and it underpins reading fluency, note-taking, mental arithmetic and quick decision-making. This test measures it with symbol-digit coding: matching symbols to digits under time pressure, exactly the task family clinicians have used for decades.",
  },
  {
    question: "How does this test work?",
    answer:
      "You get a key that pairs six symbols with six digits. Symbols then appear one at a time for a 90-second sprint, and your job is to tap the digit that matches each symbol as fast as possible. You can use the mouse, the tap pad, or your keyboard number keys. Every response is timed to the millisecond, and the key is randomised on every attempt so memorising it from a previous run does not help.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Your score is accuracy-safe throughput: the number of correct matches per minute. Only correct answers count, and your session must reach at least 60% accuracy to be scored at all - random tapping lands near 17% with six options, so it is flagged and rejected. Your rate is then mapped onto a Processing Speed Index with a population mean of 100 and a standard deviation of 15, the same scale used for IQ scores, plus a percentile estimate.",
  },
  {
    question: "Is 90 seconds really enough to measure anything?",
    answer:
      "Yes - brief coding sprints are surprisingly reliable. The classic WAIS Coding subtest scores exactly 90 seconds of work, and processing-speed tasks show some of the highest short-form reliabilities in cognitive testing because raw performance is driven by a single, stable trait. Your per-item reaction times, accuracy and pace consistency are all recorded so the score reflects the whole sprint, not one lucky streak.",
  },
  {
    question: "Can I get a better score by practising?",
    answer:
      "Some of it, yes - and that is expected. Processing speed improves with familiarity: after one run you stop re-reading the instructions and your eyes learn to jump between the key, the symbol and the pad faster. That is why the key is re-randomised every attempt, so you are practising the skill, not the mapping. Retaking once or twice to warm up is a fair way to see your true ceiling.",
  },
  {
    question: "Is this a medical diagnosis?",
    answer:
      "No. This is a free educational self-check for curiosity and brain training, not a clinical instrument, and results are not a diagnosis of any condition. Slow scores can simply mean you were tired, distracted, or new to the task. If you have genuine concerns about cognitive function, speak with a qualified professional who can administer standardised assessments under controlled conditions.",
  },
];
