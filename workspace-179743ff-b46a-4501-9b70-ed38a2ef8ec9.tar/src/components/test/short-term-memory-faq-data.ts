/* ------------------------------------------------------------------ */
/*  Short-Term Memory Test - FAQ (single source)                       */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type StmFaq = { question: string; answer: string };

export const STM_FAQS: StmFaq[] = [
  {
    question: "What is a short-term memory test and what does it measure?",
    answer:
      "This is the classic Brown-Peterson filled-delay task from 1950s memory research. A three-letter trigram flashes for under a second, then you count backwards by threes from a random number - which makes rehearsing the letters impossible - and finally you type the trigram back. The filled delay is the whole point: it empties the rehearsal loop and shows you how much your raw short-term buffer retains on its own as the interval stretches from 3 to 15 seconds.",
  },
  {
    question: "Why do I have to count backwards instead of just waiting?",
    answer:
      "Because silent waiting is rehearsal in disguise. Left alone, people silently repeat the letters hundreds of times and the test measures their inner voice rather than their memory. Counting backwards by threes occupies exactly that loop - the original researchers compared it to filling a telephone line with static so the message cannot be re-sent. The typing is not scored; it exists to keep the interference honest. Recall opens when the delay ends, whether or not you typed anything.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Letters must come back in their original positions: typing C-H-J as J-H-C earns only the middle letter. Your score is the number of position-correct letters out of the 27 shown across nine trials, compared against an adult population model (mean about 52%, SD 13%) and mapped onto the standard IQ scale (mean 100, SD 15), clamped to 55-145 like all BrainMetrics tests. The results card also draws your personal decay curve - the share of letters surviving the 3, 9 and 15 second delays separately.",
  },
  {
    question: "What is the decay curve and why does it matter?",
    answer:
      "Short-term memories fade roughly exponentially once rehearsal stops - the original Brown-Peterson experiments showed recall collapsing from about 80% after 3 seconds to around 10% after 18. Your results card reports your own curve: accuracy after the 3s, 9s and 15s delays. Most people show a steep drop between 3 and 9 seconds; a flatter curve is the signature of strong short-term retention. The overall index uses all nine trials together, so the curve is the diagnosis and the index is the headline.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "The average adult brings back about half the letters in position across the nine trials - roughly three quarters after the 3-second delays, half after 9 seconds, and a quarter to a third after 15. Every letter counts one point, so 27 is perfect and maps to the index ceiling of 145. Do not be discouraged by low numbers: this task is genuinely hard by design, and a score around 50% is exactly where the population sits.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every run draws fresh trigrams and fresh start numbers from a seeded generator, so there is nothing to memorise between attempts. Expect a small practice effect on the second run as the count-then-recall rhythm becomes familiar. For tracking real change, run it two or three times in a sitting and compare weekly rather than hourly - sleep, caffeine and stress all move short-term retention by a few letters, which is ordinary variation rather than genuine change.",
  },
];
