/* ------------------------------------------------------------------ */
/*  Word Memory Test - FAQ (single source)                             */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type WmFaq = { question: string; answer: string };

export const WORD_MEMORY_FAQS: WmFaq[] = [
  {
    question: "What is a word memory test and what does it measure?",
    answer:
      "A word memory test measures verbal recognition memory: your ability to tell previously seen words apart from brand-new ones. You watch a stream of common words appear one at a time, then judge a longer mixed stream with two buttons - \"I saw it\" or \"It's new\". Under the hood this exercises encoding (taking words into memory during the study phase), retention across a short filled delay, and the familiarity-versus-novelty discrimination you use every time you recognise a face, a name or a song.",
  },
  {
    question: "How is this different from the Digit Span or Sequence Memory tests?",
    answer:
      "Those tests measure recall: you must reproduce material you were shown, in order. This test measures recognition: you never reproduce anything, you only judge whether each word is old or new. Recognition is typically much easier than recall - most people recognise far more words than they could freely recall - which is exactly why the lists here grow to 16 words and the streams mix in equally many new words. It is also purely verbal: no grids, no digits, no spatial positions.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Your primary metric is overall proportion correct: hits (saying \"I saw it\" to a studied word) plus correct rejections (saying \"It's new\" to a new word), divided by every judgement you made. Because each round's stream is balanced - exactly half studied words, half new foils - pure guessing or mashing either button lands at 50%, so only genuine memory can move your number. That proportion is compared against an adult population model (mean about 76%, SD 8%) and mapped onto the standard IQ scale (mean 100, SD 15), clamped to 55-145 like all BrainMetrics tests.",
  },
  {
    question: "What is d-prime and why does it matter?",
    answer:
      "D-prime (d') is signal-detection theory's measure of sensitivity: how far apart your \"old\" responses to true targets and your \"old\" responses to new words are. It is reported on your results card as a science stat. We deliberately do NOT use it as your score, because d' alone rewards a careless liberal bias - someone who yells \"I saw it\" at everything scores high d' despite half the answers being wrong. Proportion correct punishes both a liberal and a conservative bias equally, which is why it drives the index and d' stays an honest footnote.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "The average adult recognises roughly 76% of the stream correctly across the three growing lists (8, 12 and 16 studied words, each followed by an equally long mix of new words). Around 90% puts you in the top few percent, and a perfect 100% across all 72 judgements maps to the index ceiling of 145. Watch your false alarms: every new word you claim to have seen costs you exactly as much as a missed target, so cautious guessing beats confident guessing when you are unsure.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every run draws fresh study words and foils from a pool of 200+, so there is nothing to memorise between attempts. A small practice effect is normal: the second run often feels smoother because the task format is familiar. For tracking real change, test yourself two or three times in a sitting and compare weekly rather than hourly - sleep, stress and attention all move word memory by a few percent, which is ordinary variation rather than genuine change.",
  },
];
