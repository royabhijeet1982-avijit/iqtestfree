/* ------------------------------------------------------------------ */
/*  Stroop Test - FAQ (single source)                                  */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type StroopFaq = { question: string; answer: string };

export const STROOP_FAQS: StroopFaq[] = [
  {
    question: "What is the Stroop effect?",
    answer:
      "The Stroop effect is one of the most famous findings in psychology, first described by John Ridley Stroop in 1935. When the meaning of a colour word conflicts with the ink it is printed in - the word RED written in blue ink - people take measurably longer to name the ink and make more mistakes. Reading is so automatic for literate adults that the word's meaning fires whether you want it to or not, and that unwanted activation has to be suppressed before you can answer correctly.",
  },
  {
    question: "What does this Stroop test measure?",
    answer:
      "It measures selective attention and cognitive inhibition: your ability to lock onto one dimension of a stimulus (the ink colour) while suppressing a stronger, automatic habit (reading the word). These executive-control skills underpin everyday focus - reading in a noisy room, resisting distractions while driving, or holding your attention on a task when something louder is competing for it. The score also reflects raw response speed, which is why both components feed the final index.",
  },
  {
    question: "Why are incongruent words slower?",
    answer:
      "On congruent trials the word and the ink point to the same answer, so the automatic reading response actually helps you. On incongruent trials it points to the wrong answer, so your brain must first inhibit the word, then select and verify the ink colour - an extra control step that typically costs a few dozen to a few hundred milliseconds. That difference between your incongruent and congruent median reaction times is the Stroop interference, and it is the core number this test reports.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Every response is timed to the millisecond. Your session produces two headline numbers: the median reaction time on congruent and incongruent trials (correct answers only, with taps faster than 200ms excluded as anticipations), and the Stroop interference - the gap between them. A composite Stroop Index is then anchored to a population model with a mean of 100 and a standard deviation of 15, blending overall speed (45%) and interference control (55%), plus a percentile estimate. Sessions with accuracy below 70% are flagged and not scored, because random tapping scores about 25% on four options.",
  },
  {
    question: "Can I get a better score by practising?",
    answer:
      "Yes, and it is a genuine improvement, not a trick. Familiarity with the task removes hesitation and hesitation-removal alone often tightens both your reaction times and your interference effect. The words and inks are randomised on every attempt, so you are training the control skill rather than memorising a sequence. Most of the gain comes in the first two or three runs, which is why a warm-up retake is a fair way to see your true ceiling.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every attempt deals a freshly randomised sequence of words and inks, so no two runs are the same. A good routine is one throwaway warm-up run followed by one or two serious attempts while fresh. Scores drift when you are tired, stressed or distracted, so compare attempts taken in similar conditions rather than reading too much into any single run.",
  },
];
