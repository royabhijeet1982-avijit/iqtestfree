"use client";

/* ------------------------------------------------------------------ */
/*  Matrix Reasoning Test - interactive UI                             */
/*  Raven-style progressive matrices: study the grid, infer the        */
/*  hidden rules, pick the tile that completes it. No time limit per   */
/*  item; response times are still recorded for the honesty panel.     */
/*  Scoring lives in matrix-reasoning-core.ts.                         */
/*                                                                     */
/*  Testing hook: /test/matrix-reasoning?quick=1 shortens the session  */
/*  to 8 items so automated flow tests can run full sessions quickly.  */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Grid3x3,
  MousePointerClick,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Shuffle,
  Timer,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  ITEM_COUNT,
  QUICK_ITEM_COUNT,
  generateItems,
  itemFingerprint,
  scoreMatrixSession,
  type Cell,
  type ElementSpec,
  type FillKind,
  type MatrixItem,
  type MatrixScore,
  type ShapeKind,
} from "./matrix-reasoning-core";

type Phase = "intro" | "active" | "results";

/** Ink colour for every shape (emerald-600, on-theme). */
const INK = "#059669";

const OFFSETS: Record<number, number[]> = {
  1: [0],
  2: [-18, 18],
  3: [-30, 0, 30],
  4: [-37, -13, 13, 37],
};

/** Static polygon point strings (computed once, deterministically). */
function polygonPoints(shape: ShapeKind): string {
  if (shape === "triangle") return "50,16 88,84 12,84";
  if (shape === "diamond") return "50,10 90,50 50,90 10,50";
  if (shape === "cross")
    return "40,10 60,10 60,40 90,40 90,60 60,60 60,90 40,90 40,60 10,60 10,40 40,40";
  const pts: string[] = [];
  if (shape === "pentagon") {
    for (let i = 0; i < 5; i++) {
      const a = -Math.PI / 2 + (i * 2 * Math.PI) / 5;
      pts.push(`${(50 + 40 * Math.cos(a)).toFixed(1)},${(50 + 40 * Math.sin(a)).toFixed(1)}`);
    }
    return pts.join(" ");
  }
  if (shape === "star") {
    for (let i = 0; i < 10; i++) {
      const r = i % 2 === 0 ? 42 : 17;
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      pts.push(`${(50 + r * Math.cos(a)).toFixed(1)},${(50 + r * Math.sin(a)).toFixed(1)}`);
    }
    return pts.join(" ");
  }
  // hexagon
  for (let i = 0; i < 6; i++) {
    const a = (i * Math.PI) / 3;
    pts.push(`${(50 + 40 * Math.cos(a)).toFixed(1)},${(50 + 40 * Math.sin(a)).toFixed(1)}`);
  }
  return pts.join(" ");
}

function ShapeGlyph({ shape, fill }: { shape: ShapeKind; fill: FillKind }) {
  const common: Record<string, string | number> =
    fill === "solid"
      ? { fill: INK }
      : fill === "tinted"
        ? { fill: INK, fillOpacity: 0.32, stroke: INK, strokeWidth: 3 }
        : fill === "outline"
          ? { fill: "none", stroke: INK, strokeWidth: 6 }
          : { fill: "none", stroke: INK, strokeWidth: 6, strokeDasharray: "7 6" };
  if (shape === "circle") return <circle cx="50" cy="50" r="32" {...common} />;
  if (shape === "square") return <rect x="19" y="19" width="62" height="62" rx="4" {...common} />;
  return <polygon points={polygonPoints(shape)} {...common} />;
}

function ElementGlyph({ el }: { el: ElementSpec }) {
  const offs = OFFSETS[el.count] ?? OFFSETS[1] as number[];
  const copyScale =
    el.count === 1 ? el.scale : el.scale * (el.count === 2 ? 0.6 : el.count === 3 ? 0.45 : 0.36);
  return (
    <>
      {offs.map((dx, i) => (
        <g
          key={i}
          transform={`translate(${dx} 0) translate(50 50) scale(${copyScale}) translate(-50 -50)`}
        >
          <g transform={`rotate(${el.rotation} 50 50)`}>
            <ShapeGlyph shape={el.shape} fill={el.fill} />
          </g>
        </g>
      ))}
    </>
  );
}

/** Renders one matrix cell as an SVG. Scales to its parent box. */
function MatrixCellView({ cell }: { cell: Cell }) {
  const primary = cell.elements[0];
  const corner = cell.elements[1];
  return (
    <svg viewBox="0 0 100 100" className="h-full w-full" aria-hidden="true">
      {primary && (
        <g
          transform={
            corner
              ? "translate(43 57) scale(0.72) translate(-50 -50)"
              : undefined
          }
        >
          <ElementGlyph el={primary} />
        </g>
      )}
      {corner && (
        <g transform="translate(73 25) scale(0.4) translate(-50 -50)">
          <ElementGlyph el={corner} />
        </g>
      )}
    </svg>
  );
}

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("matrix-reasoning-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function MatrixReasoningTest() {
  const searchParams = useSearchParams();
  const itemCount = useMemo(
    () => (searchParams.get("quick") === "1" ? QUICK_ITEM_COUNT : ITEM_COUNT),
    [searchParams]
  );

  const [phase, setPhase] = useState<Phase>("intro");
  const [items, setItems] = useState<MatrixItem[]>([]);
  const [index, setIndex] = useState(0);
  const [answerTick, setAnswerTick] = useState(0);
  const [score, setScore] = useState<MatrixScore | null>(null);

  const itemsRef = useRef<MatrixItem[]>([]);
  const indexRef = useRef(0);
  const answersRef = useRef<(number | null)[]>([]);
  const rtsRef = useRef<(number | null)[]>([]);
  const itemStartRef = useRef(0);
  const phaseRef = useRef<Phase>("intro");

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  /* ------------------------- session flow ------------------------- */

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const fresh = generateItems(seed, itemCount);
    itemsRef.current = fresh;
    indexRef.current = 0;
    answersRef.current = new Array(fresh.length).fill(null);
    rtsRef.current = new Array(fresh.length).fill(null);
    setItems(fresh);
    setIndex(0);
    setAnswerTick(0);
    setScore(null);
    setPhase("active");
    requestAnimationFrame(() => scrollToApp(false));
  }, [itemCount]);

  const finish = useCallback(() => {
    const result = scoreMatrixSession(
      itemsRef.current,
      answersRef.current,
      rtsRef.current
    );
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  const answer = useCallback(
    (optionIndex: number) => {
      if (phaseRef.current !== "active") return;
      const i = indexRef.current;
      if (answersRef.current[i] !== null) return; // already answered (exit animation)
      const item = itemsRef.current[i];
      if (!item) return;

      const now = performance.now();
      rtsRef.current[i] = Math.max(0, now - itemStartRef.current);
      answersRef.current[i] = optionIndex;
      setAnswerTick((t) => t + 1);

      if (i + 1 >= itemsRef.current.length) {
        finish();
      } else {
        indexRef.current = i + 1;
        setIndex(i + 1);
      }
    },
    [finish]
  );

  /* Per-item response-time anchor. */
  useEffect(() => {
    if (phase === "active") {
      itemStartRef.current = performance.now();
    }
  }, [phase, index]);

  /* Keyboard input: option keys 1-6. */
  useEffect(() => {
    if (phase !== "active") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      const n = Number(event.key);
      if (!Number.isInteger(n) || n < 1 || n > 6) return;
      event.preventDefault();
      answer(n - 1);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [phase, answer]);

  /* ------------------------- derived data -------------------------- */

  const currentItem = items[index] ?? null;
  // answer() increments the tick exactly once per answered item (double
  // answers are guarded), so the tick IS the answered count - no ref read.
  const answeredCount = answerTick;
  const progressPct = items.length > 0 ? (answerTick / items.length) * 100 : 0;
  const isQuick = itemCount === QUICK_ITEM_COUNT;

  const demoItem = useMemo(() => generateItems(20250717, 1)[0] ?? null, []);

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="matrix-reasoning-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="mr-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Grid3x3 className="h-3.5 w-3.5" aria-hidden="true" />
                Fluid reasoning · {itemCount} visual puzzles
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Find the tile that completes the matrix
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Every grid hides a set of rules - shapes that alternate, counts
                that grow, elements that rotate or combine. Work out the rules
                and pick the one option that completes the missing cell. The
                matrices get harder as you go.
              </p>
            </div>

            {demoItem && (
              <div className="mx-auto mt-6 max-w-lg rounded-xl border border-border bg-muted/60 p-4">
                <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Example matrix
                </p>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
                  <div
                    className={`grid gap-1.5 ${demoItem.size === 2 ? "grid-cols-2" : "grid-cols-3"}`}
                  >
                    {demoItem.cells.map((cell, i) => (
                      <div
                        key={i}
                        className="h-12 w-12 rounded-md border border-border bg-card p-1 sm:h-14 sm:w-14"
                      >
                        {cell ? (
                          <MatrixCellView cell={cell} />
                        ) : (
                          <div
                            aria-hidden="true"
                            className="flex h-full w-full items-center justify-center rounded-md border border-dashed border-primary/50 text-xl font-bold text-primary"
                          >
                            ?
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="grid max-w-56 grid-cols-6 gap-1.5">
                    {demoItem.options.map((option, i) => {
                      const isCorrect = i === demoItem.correctIndex;
                      return (
                        <div
                          key={i}
                          className={`h-10 w-10 rounded-md border bg-card p-0.5 sm:h-11 sm:w-11 ${
                            isCorrect ? "border-primary ring-2 ring-primary" : "border-border"
                          }`}
                        >
                          <MatrixCellView cell={option} />
                        </div>
                      );
                    })}
                  </div>
                </div>
                <p className="mt-3 text-center text-xs text-muted-foreground">
                  Here the highlighted option - the one continuing the quantity
                  pattern - is the correct answer. Your real matrices are
                  generated fresh every attempt.
                </p>
              </div>
            )}

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                No time limit - think each matrix through, accuracy is everything.
              </li>
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Six options per item; exactly one completes the pattern. Keys 1-6 work too.
              </li>
              <li className="flex gap-2.5">
                <Shuffle className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                A brand-new random set is generated for every attempt - retaking never repeats matrices.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Answer times are recorded: a median under 2 seconds per item flags the session as rushed.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="mr-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Grid3x3 className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && currentItem && (
          <motion.div
            key="active"
            data-testid="mr-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Header + progress */}
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Item {index + 1} of {items.length}
              </span>
              <span className="rounded-full border border-border bg-muted/60 px-3 py-1 text-xs font-semibold tabular-nums text-muted-foreground">
                {answeredCount} answered
              </span>
            </div>
            <div
              data-testid="mr-progress"
              className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Session progress"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(progressPct)}
            >
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-300 ease-out"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={index}
                data-testid="mr-item"
                data-index={index}
                data-answer={currentItem.correctIndex}
                data-fingerprint={itemFingerprint(currentItem)}
                initial={{ opacity: 0, x: 24 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -24 }}
                transition={{ duration: 0.25 }}
              >
                {/* The matrix */}
                <div className="mt-6 flex justify-center">
                  <div
                    role="img"
                    aria-label={`Matrix with ${currentItem.size * currentItem.size - 1} given cells and one missing cell`}
                    className={`grid gap-1.5 rounded-xl border border-border bg-muted/40 p-3 sm:gap-2 sm:p-4 ${
                      currentItem.size === 2 ? "grid-cols-2" : "grid-cols-3"
                    }`}
                  >
                    {currentItem.cells.map((cell, i) => (
                      <div
                        key={i}
                        className={`h-16 w-16 rounded-md border border-border bg-card p-1 sm:h-20 sm:w-20 sm:p-1.5 ${
                          cell ? "" : "border-dashed border-primary/50"
                        }`}
                      >
                        {cell ? (
                          <MatrixCellView cell={cell} />
                        ) : (
                          <div
                            aria-hidden="true"
                            className="flex h-full w-full items-center justify-center text-2xl font-black text-primary sm:text-3xl"
                          >
                            ?
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <p className="mt-5 text-center text-sm text-muted-foreground">
                  Which option completes the pattern?
                </p>

                {/* Options */}
                <div className="mx-auto mt-3 grid max-w-xl grid-cols-3 gap-2 sm:grid-cols-6 sm:gap-3">
                  {currentItem.options.map((option, i) => (
                    <button
                      key={i}
                      type="button"
                      data-testid={`mr-option-${i}`}
                      aria-label={`Option ${i + 1}`}
                      onClick={() => answer(i)}
                      className="aspect-square rounded-xl border border-border bg-card p-1.5 transition-[translate,border-color,box-shadow] duration-150 hover:-translate-y-0.5 hover:border-primary hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0 sm:p-2"
                    >
                      <MatrixCellView cell={option} />
                    </button>
                  ))}
                </div>

                <p className="mt-3 hidden text-center text-xs text-muted-foreground sm:block">
                  Tip: number keys 1-6 select options.
                </p>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="mr-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            {score.valid ? (
              <div className="mx-auto max-w-2xl">
                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                    Your result
                  </p>
                  <span
                    data-testid="mr-iq"
                    className="mt-2 block text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Matrix Reasoning Index · mean 100, SD 15
                  </p>
                  <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                    <span
                      data-testid="mr-grade"
                      className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                    >
                      <Grid3x3 className="h-4 w-4" aria-hidden="true" />
                      {score.grade.label}
                    </span>
                    <span
                      data-testid="mr-percentile"
                      className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                    >
                      Higher than {score.percentile} in 100 adults
                    </span>
                  </div>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    {score.grade.blurb}
                  </p>
                </div>

                {score.rushed && (
                  <div
                    data-testid="mr-rushed"
                    className="mt-6 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4"
                  >
                    <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-bold text-amber-800">
                        This session looked rushed
                      </p>
                      <p className="mt-1 text-sm leading-relaxed text-amber-800">
                        Your median answer time was{" "}
                        {(score.medianRtMs / 1000).toFixed(1)}s per item, and{" "}
                        {score.fastCount} of {score.answered} answers landed
                        under 2 seconds. The score below is computed honestly
                        from your answers, but matrix puzzles take thought - a
                        slower retake will give a fairer estimate of your
                        reasoning ability.
                      </p>
                    </div>
                  </div>
                )}

                {/* Stat grid */}
                <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div
                    data-testid="mr-correct"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.correct} / {score.total}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">matrices solved</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {Math.round((score.correct / Math.max(1, score.answered)) * 100)}%
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">accuracy</p>
                  </div>
                  <div
                    data-testid="mr-median-rt"
                    className="rounded-xl border border-border bg-muted/40 p-4 text-center"
                  >
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.medianRtMs > 0 ? `${(score.medianRtMs / 1000).toFixed(1)}s` : "-"}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">median time per item</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">
                      {score.fastCount}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">answers under 2 seconds</p>
                  </div>
                </div>

                {/* Per-rule accuracy */}
                <div className="mt-8">
                  <p className="text-sm font-semibold text-foreground">
                    Accuracy by rule type
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Which pattern families you solved (dual-rule items count toward their primary rule)
                  </p>
                  <div className="mt-3 space-y-2.5">
                    {score.ruleAccuracy.map((rule) => (
                      <div key={rule.category} data-testid={`mr-rule-${rule.category}`}>
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-foreground">{rule.label}</span>
                          <span className="tabular-nums text-muted-foreground">
                            {rule.correct} / {rule.total}
                          </span>
                        </div>
                        <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-muted">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{
                              width: `${rule.total > 0 ? (rule.correct / rule.total) * 100 : 0}%`,
                            }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                            className="h-full rounded-full bg-primary/85"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="mt-6 text-center text-xs leading-relaxed text-muted-foreground">
                  Educational estimate, not a clinical assessment. Every session
                  uses freshly generated matrices, so retakes measure reasoning
                  rather than memory.
                </p>

                <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button
                    type="button"
                    data-testid="mr-retake"
                    onClick={start}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    Retake - new random matrices
                  </button>
                  <a
                    href="/test"
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                  >
                    Try the Full IQ Test
                  </a>
                </div>
              </div>
            ) : (
              <div className="mx-auto max-w-xl text-center" data-testid="mr-invalid">
                <h3 className="text-xl font-bold text-foreground">This session was not scored</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {score.invalidReason}
                </p>
                <button
                  type="button"
                  data-testid="mr-retake"
                  onClick={start}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color] hover:-translate-y-0.5 hover:bg-emerald-700"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Start a fresh session
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
