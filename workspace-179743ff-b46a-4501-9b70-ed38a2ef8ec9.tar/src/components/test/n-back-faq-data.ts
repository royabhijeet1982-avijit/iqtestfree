/* ------------------------------------------------------------------ */
/*  N-Back Test - FAQ (single source)                                  */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type NBackFaqItem = { question: string; answer: string };

export const NBACK_FAQ_ITEMS: NBackFaqItem[] = [
  {
    question: "What does the N-Back test measure?",
    answer:
      "N-Back measures working memory - specifically the 'updating' component: holding a small rolling window of recent items in mind and overwriting it every time a new one arrives. It is one of the most researched tasks in cognitive psychology and neuroscience, and a widely cited 2008 study by Jaeggi and colleagues reported that practising N-back improved measures of fluid intelligence, which is why the task became the poster child of the brain-training debate. Strong N-back performance is linked to reasoning, reading comprehension and the ability to keep track of a conversation or a multi-step plan.",
  },
  {
    question: "What does the N in N-Back mean?",
    answer:
      "N is how many steps back you have to compare. With N = 1 you respond when the current letter repeats the immediately previous one. With N = 2 you respond when it matches the letter two positions ago, while continuing to overwrite the stream in your head. This test runs five blocks with N rising from 1 to 5, so the task gets harder block by block: at N = 3 and beyond you are juggling a three-to-five item window while the letters keep coming every few seconds.",
  },
  {
    question: "How is my score turned into an IQ-scale estimate?",
    answer:
      "Every trial is scored with signal detection: a response on a true match is a hit, a response on a non-match is a false alarm, and staying quiet on a non-match counts just as much as catching a match. Each block gets a balanced score - the average of your hit rate and your correct-rejection rate - and your effective span is the highest N whose block reached 70%. That span is mapped onto adult population anchors and interpolated with how solidly you held the level, producing a working-memory index on the familiar IQ scale (mean 100, SD 15) plus a percentile estimate.",
  },
  {
    question: "How long does the test take?",
    answer:
      "A full run is five blocks with N = 1 through 5, each block showing 20 to 25 letters at a steady rhythm of about 2.8 seconds per letter. That is roughly six minutes of task time, or around 6-10 minutes counting the 3-2-1 countdowns and the short summary screen between blocks. There is no pause button mid-block, so pick a moment when you can give it five uninterrupted minutes - attention lapses show up directly as missed matches.",
  },
  {
    question: "Any tips for reaching a higher N?",
    answer:
      "Yes. First, chunk by letter and position: silently group the stream into pairs or triplets instead of holding loose letters. Second, lock into the rhythm - rehearse the current window under your breath with each new letter, so updating becomes automatic. Third, watch for lures: a letter that matches the one N-1 back but not N back is a deliberate trap, so always count from the current letter, not from the previous one. Finally, if you lose the thread mid-block, let one trial go and re-anchor on the next letter rather than guessing.",
  },
  {
    question: "Can I retake the test, and is it fair?",
    answer:
      "Retake it as often as you like - every run generates fresh random sequences, so you can never memorise your way to a better score, and warm-up gains between attempts reflect genuine task familiarity. The scoring is also mash-proof: responding to every single letter catches every target but buries you in false alarms, while never responding misses everything - both extremes sink the balanced score to about 50%, which anchors to a low index. Only genuine detection (real hits plus real restraint) produces a high score.",
  },
];
