"use client";

/* ------------------------------------------------------------------ */
/*  Digit Span Test - interactive UI                                   */
/*  Two phases: FORWARD (recall in order) then BACKWARD (recall in     */
/*  reverse). Digits flash one at a time; the input stage offers a      */
/*  0-9 on-screen pad plus keyboard typing, chips for what you typed,   */
/*  undo/clear and a submit button. All scoring lives in                */
/*  digit-span-core.ts.                                                 */
/*                                                                      */
/*  Testing hooks: /test/digit-span?quick=1 starts at 4 digits with     */
/*  one attempt per length and faster digit pacing, so automated flow   */
/*  tests can run full sessions quickly.                                */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  Check,
  Delete,
  Eraser,
  Eye,
  Hash,
  Keyboard,
  Repeat,
  RotateCcw,
  X,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  DIGITS,
  MAX_LENGTH,
  buildSequence,
  differentSequence,
  mulberry32,
  scoreSession,
  sessionConfig,
  spanOfPhase,
  submitAttempt,
  type SpanAttempt,
  type SpanDirection,
  type SpanSessionResult,
} from "./digit-span-core";

type Screen = "intro" | "countdown" | "active" | "interphase" | "results";
type Stage = "display" | "input" | "feedback";

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("digit-span-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function DigitSpanTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";
  const config = useMemo(() => sessionConfig(quick), [quick]);

  const [screen, setScreen] = useState<Screen>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [direction, setDirection] = useState<SpanDirection>("forward");
  const [stage, setStage] = useState<Stage>("display");
  const [attemptKey, setAttemptKey] = useState(0);
  const [target, setTarget] = useState<number[]>([]);
  const [seqLength, setSeqLength] = useState(config.startLength);
  const [attemptIndex, setAttemptIndex] = useState(1);
  const [displayState, setDisplayState] = useState<{ digit: number | null; pos: number }>({
    digit: null,
    pos: -1,
  });
  const [buffer, setBuffer] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<{ correct: boolean; message: string } | null>(null);
  const [forwardAttempts, setForwardAttempts] = useState<SpanAttempt[]>([]);
  const [backwardAttempts, setBackwardAttempts] = useState<SpanAttempt[]>([]);
  const [result, setResult] = useState<SpanSessionResult | null>(null);

  const configRef = useRef(config);
  const rngRef = useRef<() => number>(() => 0.5);
  const screenRef = useRef<Screen>("intro");
  const directionRef = useRef<SpanDirection>("forward");
  const stageRef = useRef<Stage>("display");
  const targetRef = useRef<number[]>([]);
  const lengthRef = useRef(config.startLength);
  const attemptIndexRef = useRef(1);
  const bufferRef = useRef<number[]>([]);
  const shownRef = useRef(false);
  const forwardRef = useRef<SpanAttempt[]>([]);
  const backwardRef = useRef<SpanAttempt[]>([]);
  const feedbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    configRef.current = config;
  }, [config]);

  useEffect(() => {
    return () => {
      if (feedbackTimerRef.current) clearTimeout(feedbackTimerRef.current);
    };
  }, []);

  const clearFeedbackTimer = useCallback(() => {
    if (feedbackTimerRef.current) {
      clearTimeout(feedbackTimerRef.current);
      feedbackTimerRef.current = null;
    }
  }, []);

  /* ------------------------- session flow ------------------------- */

  const appendAttempt = useCallback((att: SpanAttempt) => {
    if (att.direction === "forward") {
      forwardRef.current = [...forwardRef.current, att];
      setForwardAttempts(forwardRef.current);
    } else {
      backwardRef.current = [...backwardRef.current, att];
      setBackwardAttempts(backwardRef.current);
    }
  }, []);

  /** Deal a fresh attempt: new sequence (never repeating a failed one
   *  at the same length), reset the input buffer, show the digits. */
  const dealAttempt = useCallback(
    (dir: SpanDirection, len: number, idx: number) => {
      const rng = rngRef.current;
      const priorTargets = (dir === "forward" ? forwardRef.current : backwardRef.current)
        .filter((a) => a.length === len)
        .map((a) => a.target);
      const seq =
        priorTargets.length === 0
          ? buildSequence(len, rng)
          : differentSequence(len, rng, priorTargets);
      targetRef.current = seq;
      setTarget(seq);
      lengthRef.current = len;
      setSeqLength(len);
      attemptIndexRef.current = idx;
      setAttemptIndex(idx);
      bufferRef.current = [];
      setBuffer([]);
      shownRef.current = false;
      setFeedback(null);
      stageRef.current = "display";
      setStage("display");
      setAttemptKey((k) => k + 1);
    },
    []
  );

  const finishSession = useCallback(() => {
    clearFeedbackTimer();
    const score = scoreSession(forwardRef.current, backwardRef.current, configRef.current.quick);
    setResult(score);
    screenRef.current = "results";
    setScreen("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearFeedbackTimer]);

  const endPhase = useCallback(
    (dir: SpanDirection) => {
      if (dir === "forward") {
        screenRef.current = "interphase";
        setScreen("interphase");
        requestAnimationFrame(() => scrollToApp(false));
      } else {
        finishSession();
      }
    },
    [finishSession]
  );

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rngRef.current = mulberry32(seed);
    forwardRef.current = [];
    backwardRef.current = [];
    setForwardAttempts([]);
    setBackwardAttempts([]);
    setResult(null);
    setFeedback(null);
    directionRef.current = "forward";
    setDirection("forward");
    screenRef.current = "countdown";
    setScreen("countdown");
    setCountdownValue(3);
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  const beginBackward = useCallback(() => {
    directionRef.current = "backward";
    setDirection("backward");
    screenRef.current = "countdown";
    setScreen("countdown");
    setCountdownValue(3);
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  const beginActive = useCallback(() => {
    screenRef.current = "active";
    setScreen("active");
    dealAttempt(directionRef.current, configRef.current.startLength, 1);
  }, [dealAttempt]);

  /* Countdown 3-2-1 before each phase. */
  useEffect(() => {
    if (screen !== "countdown") return;
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginActive();
        return;
      }
      timers.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [screen, beginActive]);

  /* Digit display scheduler: show each digit, blank gap, then open
     the input stage. Runs once per dealt attempt. */
  useEffect(() => {
    if (screen !== "active" || stage !== "display") return;
    const cfg = configRef.current;
    const seq = targetRef.current;
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    let t = 400; // beat for the stage transition to settle
    timers.push(setTimeout(() => {
      if (!cancelled) setDisplayState({ digit: null, pos: -1 });
    }, 0));
    seq.forEach((digit, i) => {
      timers.push(
        setTimeout(() => {
          if (!cancelled) setDisplayState({ digit, pos: i });
        }, t)
      );
      t += cfg.displayMs;
      timers.push(
        setTimeout(() => {
          if (!cancelled) setDisplayState({ digit: null, pos: i });
        }, t)
      );
      t += cfg.gapMs;
    });
    timers.push(
      setTimeout(() => {
        if (cancelled) return;
        shownRef.current = true;
        stageRef.current = "input";
        setStage("input");
      }, t)
    );
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [screen, stage, attemptKey]);

  /* --------------------------- responding -------------------------- */

  const pushDigit = useCallback((d: number) => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    if (bufferRef.current.length >= lengthRef.current) return;
    const next = [...bufferRef.current, d];
    bufferRef.current = next;
    setBuffer(next);
  }, []);

  const undoDigit = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    const next = bufferRef.current.slice(0, -1);
    bufferRef.current = next;
    setBuffer(next);
  }, []);

  const clearBuffer = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    bufferRef.current = [];
    setBuffer([]);
  }, []);

  const submit = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    const dir = directionRef.current;
    const attempt = submitAttempt({
      direction: dir,
      length: lengthRef.current,
      attemptIndex: attemptIndexRef.current,
      target: targetRef.current,
      input: bufferRef.current,
      wasShown: shownRef.current,
    });
    appendAttempt(attempt);
    const cfg = configRef.current;
    const wasLastAttempt = attempt.attemptIndex >= cfg.attemptsPerLength;
    const wasLastLength = lengthRef.current >= MAX_LENGTH;
    const message = attempt.correct
      ? wasLastLength
        ? "Sequence recalled - phase complete."
        : "Correct - the next sequence is one digit longer."
      : wasLastAttempt
        ? dir === "forward"
          ? "Both attempts missed - forward phase complete."
          : "Both attempts missed - backward phase complete."
        : "Not quite - one more try at this length with a fresh sequence.";
    stageRef.current = "feedback";
    setStage("feedback");
    setFeedback({ correct: attempt.correct, message });
    clearFeedbackTimer();
    feedbackTimerRef.current = setTimeout(() => {
      feedbackTimerRef.current = null;
      setFeedback(null);
      if (attempt.correct) {
        if (wasLastLength) endPhase(dir);
        else dealAttempt(dir, lengthRef.current + 1, 1);
      } else if (!wasLastAttempt) {
        dealAttempt(dir, lengthRef.current, attempt.attemptIndex + 1);
      } else {
        endPhase(dir);
      }
    }, 850);
  }, [appendAttempt, clearFeedbackTimer, dealAttempt, endPhase]);

  /* Keyboard input: digits type, Backspace undoes, Enter submits. */
  useEffect(() => {
    if (screen !== "active" || stage !== "input") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      if (/^[0-9]$/.test(event.key)) {
        event.preventDefault();
        pushDigit(Number(event.key));
      } else if (event.key === "Backspace") {
        event.preventDefault();
        undoDigit();
      } else if (event.key === "Enter") {
        event.preventDefault();
        submit();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [screen, stage, pushDigit, undoDigit, submit]);

  /* ------------------------- derived data -------------------------- */

  const forwardSpan = spanOfPhase(forwardAttempts);
  const remainingSlots = Math.max(0, seqLength - buffer.length);

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="digit-span-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {screen === "intro" && (
          <motion.div
            key="intro"
            data-testid="ds-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Hash className="h-3.5 w-3.5" aria-hidden="true" />
                Working memory · forward + backward recall
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                How far does your number memory reach?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Digits appear on screen one at a time. After the last one, type back
                what you saw - in order first, then in the harder half, in reverse.
                Sequences grow by one digit until your span runs out, and your score
                is the longest run you survive.
              </p>
            </div>

            <div className="mx-auto mt-6 grid max-w-2xl gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-border bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <ArrowRight className="h-4 w-4 text-primary" aria-hidden="true" />
                  Forward phase
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  Each digit stays up for about a second. Type the whole sequence in
                  the same order you saw it. Sequences start at 3 digits.
                </p>
              </div>
              <div className="rounded-xl border border-border bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <Repeat className="h-4 w-4 text-primary" aria-hidden="true" />
                  Backward phase
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  Same flashing digits - but you type the sequence in reverse, so the
                  last digit you saw goes first. Almost everyone runs a couple of
                  digits shorter here.
                </p>
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Eye className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {config.attemptsPerLength === 1
                  ? "One attempt per length; the sequences speed up as they grow."
                  : "Two attempts per length (the second only if the first fails); one correct answer advances you."}
              </li>
              <li className="flex gap-2.5">
                <Repeat className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Every sequence is freshly randomised - after a miss, the retry at the same length is always a different sequence.
              </li>
              <li className="flex gap-2.5">
                <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The input stage is untimed - tap the pad or type on your keyboard, then submit when it looks right.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="ds-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Hash className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {screen === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="ds-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-md text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                {direction === "forward" ? "Forward phase" : "Backward phase"}
              </p>
              <p className="mt-2 text-base font-medium text-foreground">
                {direction === "forward"
                  ? "Type the digits in the same order you saw them."
                  : "Type the digits in reverse - the last digit you saw goes first."}
              </p>
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {screen === "active" && (
          <motion.div
            key="active"
            data-testid={`ds-phase-${direction}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Phase header */}
            <div className="flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                {direction === "forward" ? (
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                ) : (
                  <Repeat className="h-3.5 w-3.5" aria-hidden="true" />
                )}
                {direction === "forward" ? "Forward" : "Backward"}
              </span>
              <span
                data-testid="ds-attempt-info"
                className="text-sm font-semibold tabular-nums text-muted-foreground"
              >
                Length {seqLength} · attempt {attemptIndex} of {config.attemptsPerLength}
              </span>
            </div>

            <AnimatePresence mode="wait">
              {/* ------------------------- DISPLAY STAGE ------------------------- */}
              {stage === "display" && (
                <motion.div
                  key={`display-${attemptKey}`}
                  data-testid="ds-digit-stage"
                  data-total={seqLength}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5 rounded-xl border border-border bg-secondary/70 py-8 sm:py-10"
                >
                  <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    Watch the digits
                  </p>
                  <div className="mt-4 flex items-center justify-center">
                    <motion.span
                      key={displayState.pos}
                      data-testid="ds-digit"
                      data-pos={displayState.pos}
                      initial={displayState.digit !== null ? { scale: 0.7, opacity: 0 } : false}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.15 }}
                      aria-label={displayState.digit !== null ? `Digit ${displayState.digit}` : "Pause"}
                      className="inline-flex h-24 w-24 select-none items-center justify-center text-7xl font-black leading-none tabular-nums text-foreground sm:h-28 sm:text-8xl"
                    >
                      {displayState.digit !== null ? displayState.digit : ""}
                    </motion.span>
                  </div>
                  <div
                    className="mt-4 flex justify-center gap-1.5"
                    data-testid="ds-digit-progress"
                    aria-hidden="true"
                  >
                    {target.map((_, i) => {
                      const shown = i < displayState.pos || (i === displayState.pos && displayState.digit !== null);
                      return (
                        <span
                          key={i}
                          className={[
                            "h-2 w-2 rounded-full transition-colors duration-150",
                            shown
                              ? "bg-primary"
                              : i === displayState.pos
                                ? "animate-pulse bg-primary/50"
                                : "bg-muted-foreground/25",
                          ].join(" ")}
                        />
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* -------------------------- INPUT STAGE -------------------------- */}
              {stage === "input" && (
                <motion.div
                  key={`input-${attemptKey}`}
                  data-testid="ds-input"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5"
                >
                  <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    {direction === "forward"
                      ? "Type the digits in the same order"
                      : "Type the digits in reverse order"}
                  </p>

                  {/* Typed digits as chips + remaining empty slots */}
                  <div
                    data-testid="ds-input-chips"
                    className="mt-4 flex min-h-14 flex-wrap items-center justify-center gap-2"
                    aria-label="Digits entered so far"
                  >
                    {buffer.map((d, i) => (
                      <span
                        key={`${i}-${d}`}
                        data-testid="ds-chip"
                        className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-primary bg-emerald-50 px-2 text-xl font-bold tabular-nums text-emerald-800"
                      >
                        {d}
                      </span>
                    ))}
                    {Array.from({ length: remainingSlots }).map((_, i) => (
                      <span
                        key={`slot-${i}`}
                        aria-hidden="true"
                        className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-dashed border-border text-lg text-muted-foreground/50"
                      >
                        ·
                      </span>
                    ))}
                  </div>

                  {/* On-screen 0-9 pad */}
                  <div className="mt-5 grid grid-cols-5 gap-2 sm:grid-cols-10 sm:gap-2.5">
                    {DIGITS.map((d) => {
                      const full = buffer.length >= seqLength;
                      return (
                        <button
                          key={d}
                          type="button"
                          data-testid={`ds-pad-btn-${d}`}
                          aria-label={`Enter digit ${d}`}
                          disabled={full}
                          onClick={() => pushDigit(d)}
                          className="h-14 rounded-xl border border-border bg-card text-xl font-bold tabular-nums text-foreground transition-[background-color,border-color,color,translate] duration-100 hover:-translate-y-0.5 hover:border-primary hover:text-primary active:translate-y-0 disabled:pointer-events-none disabled:opacity-40 sm:h-16"
                        >
                          {d}
                        </button>
                      );
                    })}
                  </div>

                  {/* Undo / clear / submit */}
                  <div className="mt-5 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
                    <button
                      type="button"
                      data-testid="ds-undo"
                      onClick={undoDigit}
                      disabled={buffer.length === 0}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground transition-[border-color,color] hover:border-primary hover:text-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Delete className="h-4 w-4" aria-hidden="true" />
                      Undo
                    </button>
                    <button
                      type="button"
                      data-testid="ds-clear"
                      onClick={clearBuffer}
                      disabled={buffer.length === 0}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground transition-[border-color,color] hover:border-primary hover:text-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Eraser className="h-4 w-4" aria-hidden="true" />
                      Clear
                    </button>
                    <button
                      type="button"
                      data-testid="ds-submit"
                      onClick={submit}
                      disabled={buffer.length === 0}
                      className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-2.5 text-sm font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Check className="h-4 w-4" aria-hidden="true" />
                      Submit answer
                    </button>
                  </div>

                  <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
                    <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
                    Number keys type too - Enter submits, Backspace undoes.
                  </p>
                </motion.div>
              )}

              {/* ------------------------- FEEDBACK STAGE ------------------------- */}
              {stage === "feedback" && feedback && (
                <motion.div
                  key={`feedback-${attemptKey}`}
                  data-testid="ds-attempt-feedback"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5 flex min-h-56 flex-col items-center justify-center rounded-xl border border-border bg-muted/40 px-6 py-10 text-center"
                >
                  <span
                    className={[
                      "inline-flex h-12 w-12 items-center justify-center rounded-full",
                      feedback.correct
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-red-50 text-red-600",
                    ].join(" ")}
                    aria-hidden="true"
                  >
                    {feedback.correct ? (
                      <Check className="h-6 w-6" />
                    ) : (
                      <X className="h-6 w-6" />
                    )}
                  </span>
                  <p
                    className={[
                      "mt-3 text-xl font-bold",
                      feedback.correct ? "text-emerald-800" : "text-foreground",
                    ].join(" ")}
                  >
                    {feedback.correct ? "Correct" : "Not quite"}
                  </p>
                  <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-muted-foreground">
                    {feedback.message}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* ---------------------------- INTERPHASE ---------------------------- */}
        {screen === "interphase" && (
          <motion.div
            key="interphase"
            data-testid="ds-interphase"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-md text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Check className="h-3.5 w-3.5" aria-hidden="true" />
                Forward phase complete
              </span>
              <p className="mt-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Your forward span
              </p>
              <p
                data-testid="ds-interphase-span"
                className="mt-1 text-5xl font-black tabular-nums text-foreground"
              >
                {forwardSpan}
              </p>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                Now the harder half: the digits flash the same way, but you type each
                sequence in reverse - the last digit you saw goes first. Sequences
                restart at {config.startLength} digits, and the same rules apply.
              </p>
              <button
                type="button"
                data-testid="ds-interphase-cta"
                onClick={beginBackward}
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Repeat className="h-5 w-5" aria-hidden="true" />
                Start the backward phase
              </button>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {screen === "results" && result && (
          <motion.div
            key="results"
            data-testid="ds-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="ds-iq"
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={result.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Digit Span Index · population mean 100, SD 15
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="ds-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${result.grade.className}`}
                  >
                    <Hash className="h-4 w-4" aria-hidden="true" />
                    {result.grade.label}
                  </span>
                  <span
                    data-testid="ds-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Higher than {result.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {result.grade.blurb}
                </p>
                {result.quick && (
                  <p
                    data-testid="ds-quick-note"
                    className="mx-auto mt-3 max-w-md rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm leading-relaxed text-emerald-800"
                  >
                    Quick practice mode: shorter staircases with a single
                    attempt per length, so measured spans - and scores - run
                    lower than an equivalent full run.
                  </p>
                )}
              </div>

              {/* Spans */}
              <div className="mt-8 grid grid-cols-3 gap-3">
                <div data-testid="ds-forward-span" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-foreground">{result.forwardSpan}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">forward span</p>
                </div>
                <div data-testid="ds-backward-span" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-foreground">{result.backwardSpan}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">backward span</p>
                </div>
                <div data-testid="ds-total-span" className="rounded-xl border border-primary/30 bg-emerald-50 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-emerald-800">{result.totalSpan}</p>
                  <p className="mt-0.5 text-xs text-emerald-700">total span</p>
                </div>
              </div>

              {/* Level ladder */}
              <div className="mt-8" data-testid="ds-ladder">
                <p className="text-sm font-semibold text-foreground">Every attempt, level by level</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Green dots are recalled sequences; red dots are misses.
                </p>
                <div className="mt-3 space-y-3">
                  {[
                    { dir: "forward" as const, label: "Forward", attempts: forwardAttempts },
                    { dir: "backward" as const, label: "Backward", attempts: backwardAttempts },
                  ].map((row) => (
                    <div
                      key={row.dir}
                      data-testid={`ds-ladder-${row.dir}`}
                      className="rounded-xl border border-border bg-muted/40 p-3"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-foreground">{row.label}</span>
                        <span className="text-xs font-semibold tabular-nums text-muted-foreground">
                          span {spanOfPhase(row.attempts)}
                        </span>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {row.attempts.map((a, i) => (
                          <span
                            key={`${a.length}-${a.attemptIndex}-${i}`}
                            data-testid={`ds-ladder-${row.dir}-${i}`}
                            className={[
                              "inline-flex h-8 min-w-8 items-center justify-center gap-0.5 rounded-lg border px-1.5 text-sm font-bold tabular-nums",
                              a.correct
                                ? "border-emerald-300 bg-emerald-100 text-emerald-800"
                                : "border-red-200 bg-red-50 text-red-600",
                            ].join(" ")}
                            title={`Length ${a.length}${a.correct ? " - correct" : " - missed"}`}
                          >
                            {a.length}
                            {a.correct ? (
                              <Check className="h-3.5 w-3.5" aria-hidden="true" />
                            ) : (
                              <X className="h-3.5 w-3.5" aria-hidden="true" />
                            )}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Session stats */}
              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{result.attempts}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">sequences attempted</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-emerald-700">{result.correct}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">recalled correctly</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="ds-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random sequences
                </button>
                <a
                  href="/test"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  Try the Full IQ Test
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
