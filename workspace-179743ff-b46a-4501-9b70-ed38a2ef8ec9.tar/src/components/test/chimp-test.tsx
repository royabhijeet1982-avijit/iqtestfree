"use client";

/* ------------------------------------------------------------------ */
/*  Chimp Test - interactive UI                                        */
/*  The Ayumu / chimpanzee working-memory task: numbered chips appear  */
/*  on an 8x6 grid, tapping chip 1 masks the whole board, the rest     */
/*  must be tapped in ascending order from memory.                     */
/*  All state-machine and scoring logic lives in chimp-test-core.ts.   */
/*                                                                     */
/*  Testing hook: the page passes ?quick=1 down as the `quick` prop,   */
/*  which starts the run at 3 chips with 2 lives so automated flow     */
/*  tests finish quickly.                                              */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Brain,
  CheckCircle2,
  Heart,
  MousePointerClick,
  RotateCcw,
  Sparkles,
  Timer,
  TriangleAlert,
  XCircle,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  CLEARS_TO_ADVANCE,
  GRID_CELLS,
  GRID_COLS,
  GRID_ROWS,
  QUICK_LIVES,
  QUICK_START_N,
  START_LIVES,
  START_N,
  applyTap,
  dealNext,
  formatRoundSeconds,
  mulberry32,
  newRun,
  placeChips,
  scoreRun,
  type Chip,
  type ChimpScore,
  type RunState,
  type TapTiming,
} from "./chimp-test-core";

type UiPhase = "intro" | "countdown" | "run" | "results";

type Flash = { cell: number; correct: boolean; id: number } | null;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("chimp-test-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

/** Fixed demo board for the intro: a stable level-4 layout. */
const DEMO_CHIPS = placeChips(4, mulberry32(20240607));

export function ChimpTest({ quick = false }: { quick?: boolean }) {
  const startN: number = quick ? QUICK_START_N : START_N;
  const maxLives: number = quick ? QUICK_LIVES : START_LIVES;

  const [phase, setPhase] = useState<UiPhase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [run, setRun] = useState<RunState | null>(null);
  const [flash, setFlash] = useState<Flash>(null);
  const [levelUpNote, setLevelUpNote] = useState(false);
  const [score, setScore] = useState<ChimpScore | null>(null);

  const runRef = useRef<RunState | null>(null);
  const phaseRef = useRef<UiPhase>("intro");
  const roundStartRef = useRef(0);
  const lastTapRef = useRef(0);
  const beatTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    return () => {
      if (beatTimerRef.current) clearTimeout(beatTimerRef.current);
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const schedule = useCallback((fn: () => void, ms: number) => {
    if (beatTimerRef.current) clearTimeout(beatTimerRef.current);
    beatTimerRef.current = setTimeout(fn, ms);
  }, []);

  const begin = useCallback(() => {
    const now = performance.now();
    roundStartRef.current = now;
    lastTapRef.current = now;
    setPhase("run");
  }, []);

  const startRun = useCallback(() => {
    if (beatTimerRef.current) clearTimeout(beatTimerRef.current);
    if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const state = newRun(mulberry32(seed), startN, maxLives);
    runRef.current = state;
    setRun(state);
    setScore(null);
    setFlash(null);
    setLevelUpNote(false);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [startN, maxLives]);

  /* Countdown 3-2-1, then deal the first round. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        begin();
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), 700));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, begin]);

  const finishRun = useCallback((state: RunState) => {
    const result = scoreRun(state.records);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, []);

  /* --------------------------- tapping ---------------------------- */

  const handleTap = useCallback(
    (cell: number) => {
      const current = runRef.current;
      if (!current || phaseRef.current !== "run") return;
      if (current.phase !== "show" && current.phase !== "recall") return;

      const now = performance.now();
      const timing: TapTiming = {
        sincePrevMs: now - lastTapRef.current,
        roundMs: now - roundStartRef.current,
      };
      lastTapRef.current = now;

      const result = applyTap(current, cell, timing);
      const next = result.next;
      runRef.current = next;
      setRun(next);

      setFlash({ cell, correct: result.outcome.correct, id: now });
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
      flashTimerRef.current = setTimeout(() => setFlash(null), 320);

      if (next.phase === "done") {
        // Brief red-flash beat, then score the run.
        schedule(() => finishRun(next), 700);
        return;
      }

      if (result.roundEnded) {
        if (result.advanced) setLevelUpNote(true);
        schedule(
          () => {
            const dealt = dealNext(runRef.current ?? next);
            const t = performance.now();
            roundStartRef.current = t;
            lastTapRef.current = t;
            setLevelUpNote(false);
            runRef.current = dealt;
            setRun(dealt);
          },
          next.phase === "cleared-feedback" ? 800 : 950
        );
      }
    },
    [finishRun, schedule]
  );

  /* ------------------------- derived data ------------------------- */

  const cells = useMemo<(Chip | null)[]>(() => {
    const arr: (Chip | null)[] = new Array(GRID_CELLS).fill(null);
    if (run) {
      for (const chip of run.round.chips) arr[chip.cell] = chip;
    }
    return arr;
  }, [run]);

  const status = useMemo(() => {
    if (!run) return { text: "", tone: "muted" as const, icon: null };
    switch (run.phase) {
      case "show":
        return {
          text: "Tap chip 1 to start - the board masks the instant you touch it.",
          tone: "muted" as const,
          icon: MousePointerClick,
        };
      case "recall":
        return {
          text: "From memory - keep tapping in ascending order.",
          tone: "muted" as const,
          icon: Brain,
        };
      case "cleared-feedback":
        return levelUpNote
          ? {
              text: `Level up! Now ${run.level} chips on the board.`,
              tone: "good" as const,
              icon: Sparkles,
            }
          : {
              text: `Cleared - ${run.streak}/${CLEARS_TO_ADVANCE} in a row at this level.`,
              tone: "good" as const,
              icon: CheckCircle2,
            };
      case "failed-feedback":
        return {
          text: `Wrong chip - ${run.lives} ${run.lives === 1 ? "life" : "lives"} left.`,
          tone: "bad" as const,
          icon: XCircle,
        };
      case "done":
        return { text: "Out of lives.", tone: "bad" as const, icon: XCircle };
    }
  }, [run, levelUpNote]);

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="chimp-test-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="ct-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Brain className="h-3.5 w-3.5" aria-hidden="true" />
                Working memory · Ayumu&apos;s chimpanzee task
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                The numbers vanish the moment you move
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Numbered chips appear on the grid. The instant you tap chip 1,
                every chip flips over - then you must tap the rest in ascending
                order, purely from memory. Chimpanzees at Kyoto University beat
                most humans at this. How far up the chip ladder can you climb?
              </p>
            </div>

            {/* Level-4 preview board */}
            <div className="mx-auto mt-6 max-w-md rounded-xl border border-border bg-muted/60 p-3 sm:p-4">
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                A level-4 board
              </p>
              <div
                data-testid="ct-demo-board"
                aria-hidden="true"
                className="mt-2 grid grid-cols-8 gap-1"
              >
                {Array.from({ length: GRID_CELLS }, (_, cell) => {
                  const demoChip = DEMO_CHIPS.find((c) => c.cell === cell) ?? null;
                  return (
                    <div
                      key={cell}
                      className={[
                        "flex aspect-square w-full items-center justify-center rounded-md text-sm font-bold tabular-nums",
                        demoChip
                          ? demoChip.n === 1
                            ? "bg-emerald-600 text-white ring-2 ring-emerald-700 ring-offset-1"
                            : "bg-emerald-600 text-white"
                          : "bg-card/80",
                      ].join(" ")}
                    >
                      {demoChip ? demoChip.n : ""}
                    </div>
                  );
                })}
              </div>
              <p className="mt-2 text-center text-xs text-muted-foreground">
                You would tap 1 first - every chip masks instantly - then find
                2, 3 and 4 blind.
              </p>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Tap chip 1 first - all chips mask into blank squares immediately.
              </li>
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Tap the rest in ascending order, from memory. Memorise before you tap!
              </li>
              <li className="flex gap-2.5">
                <Heart className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {maxLives} {maxLives === 1 ? "life" : "lives"} per run - a wrong tap or wrong order costs one.
              </li>
              <li className="flex gap-2.5">
                <Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Clear {CLEARS_TO_ADVANCE} rounds in a row to level up and add another chip.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="ct-start"
                onClick={startRun}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Brain className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh random boards every run
                {quick ? ` · quick demo: ${startN} chips, ${maxLives} lives` : ""}
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && run && (
          <motion.div
            key="countdown"
            data-testid="ct-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Get ready - {run.level} chips, {run.maxLives}{" "}
              {run.maxLives === 1 ? "life" : "lives"}
            </p>
            <div className="mt-6 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "Go" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
            <p className="mt-6 text-center text-sm text-muted-foreground">
              Eyes on the board - scan every position before your first tap.
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RUN ------------------------------ */}
        {phase === "run" && run && (
          <motion.div
            key="run"
            data-testid="ct-run"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* HUD */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span
                data-testid="ct-level"
                className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-sm font-bold text-emerald-700 tabular-nums"
              >
                Level {run.level} · {run.level} chips
              </span>
              <span
                data-testid="ct-lives"
                aria-label={`${run.lives} of ${run.maxLives} lives left`}
                className="flex items-center gap-1"
              >
                {Array.from({ length: run.maxLives }, (_, i) => (
                  <Heart
                    key={i}
                    aria-hidden="true"
                    className={[
                      "h-4 w-4",
                      i < run.lives ? "fill-primary text-primary" : "text-muted-foreground/40",
                    ].join(" ")}
                  />
                ))}
              </span>
              <span
                data-testid="ct-streak"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold text-foreground tabular-nums"
              >
                {run.streak}/{CLEARS_TO_ADVANCE} to level up
              </span>
            </div>

            {/* Status line */}
            <p
              aria-live="polite"
              className={[
                "mt-3 flex min-h-10 items-center justify-center gap-2 rounded-xl border px-3 py-2 text-center text-sm font-medium",
                status.tone === "good"
                  ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                  : status.tone === "bad"
                    ? "border-red-200 bg-red-50 text-red-700"
                    : "border-border bg-muted/40 text-muted-foreground",
              ].join(" ")}
            >
              {status.icon && <status.icon className="h-4 w-4 shrink-0" aria-hidden="true" />}
              {status.text}
            </p>

            {/* Board */}
            <div
              data-testid="ct-board"
              role="grid"
              aria-label={`Chimp test board, ${GRID_COLS} columns by ${GRID_ROWS} rows`}
              className="mt-4 grid grid-cols-8 gap-1 sm:gap-1.5"
            >
              {cells.map((chip, cell) => {
                // Numbers exist in the DOM only while the round is in "show".
                // (After a wrong tap during "show" the core keeps masked=false
                // through the feedback beat - phase gates the digits instead.)
                const numberVisible = chip !== null && !run.masked && run.phase === "show";
                const isWrong = run.lastWrongCell === cell;
                const flashCorrect = flash !== null && flash.cell === cell && flash.correct;
                const flashWrong = flash !== null && flash.cell === cell && !flash.correct;
                const cls = [
                  "aspect-square w-full rounded-md text-sm font-bold tabular-nums transition-colors duration-100 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-primary sm:text-base",
                  flashCorrect
                    ? "bg-emerald-500 text-white"
                    : isWrong || flashWrong
                      ? "bg-red-500 text-white ring-2 ring-red-600"
                      : numberVisible
                        ? "bg-emerald-600 text-white shadow-sm hover:bg-emerald-500"
                        : chip !== null
                          ? "bg-emerald-600/25 hover:bg-emerald-600/35"
                          : "bg-muted/70 hover:bg-muted",
                ].join(" ");
                return (
                  <button
                    key={cell}
                    type="button"
                    data-testid={`ct-cell-${cell}`}
                    data-cell={cell}
                    aria-label={
                      numberVisible
                        ? `Chip ${chip!.n}`
                        : chip !== null
                          ? "Hidden chip"
                          : "Empty cell"
                    }
                    onClick={() => handleTap(cell)}
                    className={cls}
                  >
                    {numberVisible ? chip!.n : ""}
                  </button>
                );
              })}
            </div>

            <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
              <Timer className="h-3.5 w-3.5" aria-hidden="true" />
              No time limit per round - accuracy and level drive your score.
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="ct-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="ct-iq"
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Working-memory IQ · mean 100, SD 15
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="ct-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <Brain className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="ct-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                {score.botLike && (
                  <p
                    data-testid="ct-botflag"
                    className="mx-auto mt-3 flex max-w-md items-center justify-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-sm font-medium text-amber-800"
                  >
                    <TriangleAlert className="h-4 w-4 shrink-0" aria-hidden="true" />
                    Bot-like speed detected - shown for transparency, score unchanged.
                  </p>
                )}
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div data-testid="ct-stat-level" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.levelReached}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">highest level reached ({score.levelReached} chips)</p>
                </div>
                <div data-testid="ct-stat-effective" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.effectiveLevel.toFixed(1)}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">effective level (continuous mastery)</p>
                </div>
                <div data-testid="ct-accuracy" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {Math.round(score.accuracy * 100)}%
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">tap accuracy</p>
                </div>
                <div data-testid="ct-stat-rounds" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.totalCleared}/{score.totalRounds}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">rounds cleared</p>
                </div>
                <div data-testid="ct-stat-time" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.meanRoundMs !== null ? formatRoundSeconds(score.meanRoundMs) : "—"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg time per round</p>
                </div>
                <div data-testid="ct-stat-streak" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.streakAtDeath}/{CLEARS_TO_ADVANCE}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">clear streak at the end</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="ct-retake"
                  onClick={startRun}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random boards
                </button>
                <Link
                  href="/test/processing-speed"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  Try the Processing Speed Test
                </Link>
              </div>
              <p className="mt-4 text-center text-sm text-muted-foreground">
                Every run deals fresh random positions, so the only thing you can
                train is your memory.{" "}
                <Link
                  href="/test"
                  className="font-semibold text-primary underline underline-offset-4 hover:text-emerald-700"
                >
                  Browse all cognitive tests
                </Link>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * Client wrapper used by the server page: reads ?quick=1 from the URL
 * and passes it down as the `quick` prop. Must be rendered inside a
 * Suspense boundary (useSearchParams requirement).
 */
export function ChimpTestClient() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";
  return <ChimpTest quick={quick} />;
}
