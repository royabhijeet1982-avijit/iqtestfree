"use client";

/* ------------------------------------------------------------------ */
/*  Spatial Memory Test - interactive UI                               */
/*  Symbol-location paired associates: symbols appear one at a time    */
/*  inside their grid cells (STUDY, engine-paced), then the board      */
/*  empties, a shuffled tray appears (RECALL) and every symbol must be */
/*  tapped back into its home cell. Grids grow 3x3 -> 5x5 across five  */
/*  rounds. Scoring lives in spatial-memory-core.ts.                   */
/*                                                                     */
/*  Testing hook: /test/spatial-memory?quick=1 shortens every engine   */
/*  timing (study holds + gaps + feedback) so automated flow tests run */
/*  fast. Quick mode is a timing change only - never a scoring one.    */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (study | recall | feedback); during STUDY the occupied cell        */
/*  carries data-symbol (cleared on recall - anti-cheat); tray symbols */
/*  expose sm-tray-{i} with data-symbol, cells sm-cell-{i}; result      */
/*  numbers expose data-final so CountUp frames cannot fool asserts.   */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Brain,
  Check,
  Hand,
  MapPin,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  PRE_STUDY_MS,
  PRE_STUDY_MS_QUICK,
  ROUND_GRID_DIMS,
  ROUND_ITEM_COUNTS,
  STUDY_GAP_MS,
  STUDY_GAP_MS_QUICK,
  STUDY_ON_MS,
  STUDY_ON_MS_QUICK,
  buildSpatialMemorySession,
  scoreSession,
  type Placement,
  type SpatialMemoryScore,
  type SpatialMemorySession,
} from "./spatial-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "study" | "recall" | "feedback";

/** Idle pause before a round's first study symbol. */
const PRE_STUDY_FALLBACK = PRE_STUDY_MS;
/** Brief pause between study end and recall opening. */
const PRE_RECALL_MS = 450;
const PRE_RECALL_MS_QUICK = 120;

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("spatial-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function SpatialMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("study");
  const [roundIndex, setRoundIndex] = useState(0);
  const [studyIdx, setStudyIdx] = useState(0);
  /** Symbol currently shown in its cell during study (render + hook). */
  const [studySymbol, setStudySymbol] = useState<string | null>(null);
  const [studyCell, setStudyCell] = useState<number | null>(null);
  /** Placed symbols for the current recall: symbol -> cell. */
  const [placements, setPlacements] = useState<{ symbol: string; cell: number }[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const [score, setScore] = useState<SpatialMemoryScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);
  /** Mirrors sessionRef for RENDER-time reads (refs are off-limits in render). */
  const [session, setSession] = useState<SpatialMemorySession | null>(null);

  const sessionRef = useRef<SpatialMemorySession | null>(null);
  const roundRef = useRef(0);
  const placementsRef = useRef<Map<string, { cell: number; rtMs: number }>>(new Map());
  const recallOpenedAtRef = useRef(0);
  const activeStateRef = useRef<ActiveState>("study");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed =
      startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const raw: Placement[] = [];
    placementsRef.current.forEach((v, symbol) => {
      // round is recovered from the session by symbol membership; the
      // scorer only reads placements for the round being scored, so we
      // must attach the round the symbol belongs to.
      const sess = sessionRef.current;
      if (!sess) return;
      for (const r of sess.rounds) {
        if (r.pairs.some((p) => p.symbol === symbol)) {
          raw.push({ round: r.round, symbol, cell: v.cell, rtMs: v.rtMs });
          break;
        }
      }
    });
    const result = scoreSession(raw, sessionRef.current);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  const openRecall = useCallback(
    (round: number) => {
      activeStateRef.current = "recall";
      setActiveState("recall");
      setStudySymbol(null);
      setStudyCell(null);
      setPlacements([]);
      setSelectedSymbol(null);
      recallOpenedAtRef.current = performance.now();
      void round;
    },
    []
  );

  const beginStudy = useCallback(
    (round: number) => {
      roundRef.current = round;
      setRoundIndex(round);
      activeStateRef.current = "study";
      setActiveState("study");
      setStudyIdx(0);
      setPhase("active");
      setPlacements([]);
      setSelectedSymbol(null);
      // NOTE: placementsRef is SESSION-wide (symbols are unique per
      // session) - it must NOT be wiped between rounds, only in start().
      const sess = sessionRef.current;
      if (!sess) return;
      const pairs = sess.rounds[round]!.pairs;
      const preMs = quickRef.current ? PRE_STUDY_MS_QUICK : PRE_STUDY_FALLBACK;
      const onMs = quickRef.current ? STUDY_ON_MS_QUICK : STUDY_ON_MS;
      const gapMs = quickRef.current ? STUDY_GAP_MS_QUICK : STUDY_GAP_MS;
      const preRecallMs = quickRef.current ? PRE_RECALL_MS_QUICK : PRE_RECALL_MS;
      clearTimers();
      let t = preMs;
      pairs.forEach((pair, i) => {
        timersRef.current.push(
          setTimeout(() => {
            setStudyIdx(i);
            setStudySymbol(pair.symbol);
            setStudyCell(pair.cell);
          }, t)
        );
        t += onMs;
        timersRef.current.push(
          setTimeout(() => {
            setStudySymbol(null);
            setStudyCell(null);
          }, t)
        );
        t += gapMs;
      });
      timersRef.current.push(setTimeout(() => openRecall(round), t + preRecallMs));
    },
    [clearTimers, openRecall]
  );

  const beginFeedback = useCallback(
    (round: number) => {
      activeStateRef.current = "feedback";
      setActiveState("feedback");
      const sess = sessionRef.current;
      if (!sess) return;
      const feedbackMs = quickRef.current ? FEEDBACK_MS_QUICK : FEEDBACK_MS;
      clearTimers();
      timersRef.current.push(
        setTimeout(() => {
          if (round + 1 < sess.rounds.length) {
            beginStudy(round + 1);
          } else {
            finish();
          }
        }, feedbackMs)
      );
    },
    [beginStudy, clearTimers, finish]
  );

  const start = useCallback(() => {
    clearTimers();
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const built = buildSpatialMemorySession(seed);
    sessionRef.current = built;
    setSession(built);
    finishedRef.current = false;
    placementsRef.current = new Map();
    setPlacements([]);
    setSelectedSymbol(null);
    setRoundIndex(0);
    setScore(null);
    setRunSeconds(null);
    setStudySymbol(null);
    setStudyCell(null);
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Global 3-2-1 before round 1. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? 180 : 750;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        startedAtRef.current = performance.now();
        beginStudy(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginStudy]);

  /* --------------------------- interaction -------------------------- */

  const tapTraySymbol = useCallback(
    (symbol: string) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recall") return;
      setSelectedSymbol((prev) => (prev === symbol ? null : symbol));
    },
    []
  );

  const tapCell = useCallback(
    (cell: number) => {
      if (finishedRef.current) return;
      if (activeStateRef.current !== "recall") return;
      const symbol = selectedSymbol;
      const rt = recallOpenedAtRef.current > 0 ? performance.now() - recallOpenedAtRef.current : 0;
      if (!symbol) {
        // Tapping an occupied cell without a selection removes it.
        const victim = placements.find((p) => p.cell === cell);
        if (victim) placementsRef.current.delete(victim.symbol);
        setPlacements((prev) => prev.filter((p) => p.cell !== cell));
        return;
      }
      // Session store: set() overwrites any earlier placement of the
      // same symbol (re-place semantics), never touches other rounds.
      placementsRef.current.set(symbol, { cell, rtMs: rt });
      setPlacements((prev) => {
        const next = prev.filter((p) => p.symbol !== symbol && p.cell !== cell);
        next.push({ symbol, cell });
        return next;
      });
      setSelectedSymbol(null);
    },
    [selectedSymbol, placements]
  );

  const submitRound = useCallback(() => {
    if (activeStateRef.current !== "recall") return;
    beginFeedback(roundRef.current);
  }, [beginFeedback]);

  /* Keyboard: Enter = submit during recall. */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      if (activeStateRef.current !== "recall") return;
      if (e.key === "Enter") submitRound();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, submitRound]);

  /* ------------------------- derived data -------------------------- */

  const round = session?.rounds[roundIndex];
  const dim = ROUND_GRID_DIMS[roundIndex] ?? 3;
  const itemCount = ROUND_ITEM_COUNTS[roundIndex] ?? 0;
  const allPlaced = round ? placements.length === round.pairs.length : false;
  const statusText =
    activeState === "study"
      ? "Remember what appears - and exactly where"
      : activeState === "recall"
        ? selectedSymbol
          ? "Now tap the cell it lived in"
          : "Tap a symbol, then its cell"
        : "Green = right home · red = wrong · amber = missed";

  /* ----------------------------- render ---------------------------- */

  const renderCell = (i: number) => {
    const studyHere = activeState === "study" && studyCell === i && studySymbol !== null;
    const placed = placements.find((p) => p.cell === i);
    const inFeedback = activeState === "feedback";
    const truePair = inFeedback && round?.pairs.find((p) => p.cell === i);
    const wrongPlacement =
      inFeedback && placed && round && !round.pairs.some((p) => p.symbol === placed.symbol && p.cell === i);
    const missed = inFeedback && truePair && !placed;
    const canTap = activeState === "recall";

    return (
      <button
        key={i}
        type="button"
        data-testid={`sm-cell-${i}`}
        data-symbol={studyHere ? studySymbol! : undefined}
        data-placed-symbol={activeState === "recall" && placed ? placed.symbol : undefined}
        disabled={!canTap}
        onClick={() => tapCell(i)}
        aria-label={`cell row ${Math.floor(i / dim) + 1} column ${(i % dim) + 1}`}
        className={[
          "relative flex aspect-square items-center justify-center rounded-lg border text-xl font-bold transition-[background-color,border-color,box-shadow] duration-150 sm:rounded-xl sm:text-2xl",
          studyHere
            ? "border-emerald-500 bg-emerald-500/15 shadow-[0_0_14px_rgba(16,185,129,0.35)]"
            : inFeedback
              ? wrongPlacement
                ? "border-red-400 bg-red-400/15"
                : missed
                  ? "border-amber-400 bg-amber-400/15"
                  : truePair
                    ? "border-emerald-500 bg-emerald-500/15"
                    : "border-border bg-muted/30"
              : canTap
                ? placed
                  ? "border-emerald-600/60 bg-emerald-600/10"
                  : "border-border bg-muted/30 hover:border-primary/60"
                : "border-border bg-muted/30",
        ].join(" ")}
      >
        {studyHere ? (
          <motion.span
            key={`study-${studySymbol}`}
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.15 }}
            data-testid="sm-study-symbol"
            className="text-foreground"
          >
            {studySymbol}
          </motion.span>
        ) : placed ? (
          <span className={inFeedback && wrongPlacement ? "text-red-600" : "text-emerald-700"}>
            {placed.symbol}
          </span>
        ) : inFeedback && truePair ? (
          <span className="text-amber-600">{truePair.symbol}</span>
        ) : null}
      </button>
    );
  };

  return (
    <div
      id="spatial-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="sm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                Spatial memory · paired associates · about 5 minutes
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                What appeared - and exactly where?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                Symbols take turns appearing inside grid cells. Then the
                board empties and every symbol must find its way home.
                Five rounds, grids growing from 3×3 to 5×5.
              </p>
            </div>

            {/* Static preview */}
            <div
              data-testid="sm-preview"
              aria-hidden="true"
              className="mx-auto mt-6 w-fit rounded-xl border border-border bg-muted/60 p-4"
            >
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Study a pair, then send it home
              </p>
              <div className="mt-3 flex items-center justify-center gap-4">
                <div className="grid grid-cols-3 gap-1.5">
                  {Array.from({ length: 9 }, (_, i) => (
                    <span
                      key={i}
                      className={[
                        "flex h-8 w-8 items-center justify-center rounded-md text-sm font-bold",
                        i === 4
                          ? "border border-emerald-500 bg-emerald-500/15 text-emerald-700"
                          : "border border-border bg-background",
                      ].join(" ")}
                    >
                      {i === 4 ? "★" : ""}
                    </span>
                  ))}
                </div>
                <span className="text-lg text-muted-foreground">→</span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground">
                  <Hand className="h-3.5 w-3.5" />
                  ★ → centre
                </span>
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Each symbol flashes inside its cell once - the pace is engine-owned, nothing can be slowed for extra studying.
              </li>
              <li className="flex gap-2.5">
                <Hand className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Recall: tap a symbol in the tray, then tap the cell it lived in. Tap a placed symbol to pick it up again.
              </li>
              <li className="flex gap-2.5">
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Grids grow 3×3 → 5×5 and the symbol count climbs from 3 to 7 - only exact homes score.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                No partial credit for close guesses: a symbol scores only in the exact cell it studied in.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="sm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <MapPin className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh bindings every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="sm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Round 1 · 3×3 grid · eyes on the board
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="sm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Round header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="sm-round-chip"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Round {roundIndex + 1}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {activeState === "study"
                    ? "study phase · what goes where"
                    : activeState === "recall"
                      ? "send every symbol home"
                      : "round result"}
                </p>
              </div>
              <span
                data-testid="sm-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {activeState === "study"
                  ? `${Math.min(studyIdx + 1, itemCount)} / ${itemCount}`
                  : `${placements.length} / ${itemCount}`}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="sm-stage"
              data-phase={activeState}
              className="mx-auto mt-5 w-full max-w-[400px]"
            >
              <div
                className={[
                  "grid gap-1.5 rounded-2xl border-2 p-3 transition-[border-color,box-shadow] duration-200 sm:gap-2 sm:p-4",
                  activeState === "feedback"
                    ? "border-emerald-400/70"
                    : activeState === "study"
                      ? "border-border"
                      : "border-border",
                ].join(" ")}
                style={{ gridTemplateColumns: `repeat(${dim}, minmax(0, 1fr))` }}
              >
                {Array.from({ length: dim * dim }, (_, i) => renderCell(i))}
              </div>
            </div>

            {/* Tray - recall only */}
            {activeState === "recall" && round && (
              <div className="mx-auto mt-5 w-full max-w-[400px]">
                <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Symbol tray - tap one, then its cell
                </p>
                <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
                  {round.tray.map((symbol, i) => {
                    const isPlaced = placements.some((p) => p.symbol === symbol);
                    const isSelected = selectedSymbol === symbol;
                    return (
                      <button
                        key={symbol}
                        type="button"
                        data-testid={`sm-tray-${i}`}
                        data-symbol={symbol}
                        data-placed={isPlaced ? "1" : "0"}
                        onClick={() => tapTraySymbol(symbol)}
                        className={[
                          "flex h-12 w-12 items-center justify-center rounded-xl border-2 text-xl font-bold transition-[background-color,border-color,transform] duration-150",
                          isSelected
                            ? "scale-105 border-primary bg-emerald-500/15 text-emerald-700 shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                            : isPlaced
                              ? "border-border bg-muted/40 text-muted-foreground"
                              : "border-border bg-card text-foreground hover:border-primary/60",
                        ].join(" ")}
                      >
                        {symbol}
                      </button>
                    );
                  })}
                </div>
                <div className="mt-4 text-center">
                  <button
                    type="button"
                    data-testid="sm-submit"
                    aria-keyshortcuts="Enter"
                    disabled={!allPlaced}
                    onClick={submitRound}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow,opacity] hover:-translate-y-0.5 hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
                  >
                    <Check className="h-5 w-5" aria-hidden="true" />
                    Submit round
                    <kbd className="ml-1 hidden rounded border border-white/40 px-1.5 text-xs font-bold sm:inline">↵</kbd>
                  </button>
                </div>
              </div>
            )}

            {/* Status */}
            <p
              data-testid="sm-status"
              aria-live="polite"
              className="mt-4 text-center text-sm font-semibold text-muted-foreground sm:text-base"
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="sm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="sm-accuracy"
                    data-final={Math.round(score.accuracy * 100)}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={Math.round(score.accuracy * 100)} duration={1.2} />
                    <span className="text-3xl text-muted-foreground sm:text-4xl">%</span>
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  symbols sent to their exact home · {score.totalItems} bindings
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="sm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Spatial memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="sm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <MapPin className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="sm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Per-round bars */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Round by round
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Bigger grids, more bindings - watch where accuracy starts to slip
                </p>
                <div className="mt-3 space-y-2.5">
                  {score.rounds.map((rs) => {
                    const pct = Math.round(rs.score * 100);
                    return (
                      <div key={rs.round} className="flex items-center gap-3">
                        <span className="w-20 shrink-0 text-xs font-semibold text-muted-foreground sm:w-24 sm:text-sm">
                          Round {rs.round + 1}
                        </span>
                        <div className="h-3 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className={[
                              "h-full rounded-full transition-[width] duration-700",
                              pct >= 80
                                ? "bg-emerald-500"
                                : pct >= 50
                                  ? "bg-emerald-400"
                                  : "bg-amber-400",
                            ].join(" ")}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span
                          data-testid={`sm-round-score-${rs.round}`}
                          data-final={pct}
                          className="w-12 shrink-0 text-right text-sm font-bold tabular-nums text-foreground"
                        >
                          {pct}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="sm-stat-correct" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.correct}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">exact homes</p>
                </div>
                <div data-testid="sm-stat-total" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.totalItems}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">bindings shown</p>
                </div>
                <div data-testid="sm-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.avgRtMs !== null ? `${(score.avgRtMs / 1000).toFixed(1)}s` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg recall time</p>
                </div>
                <div data-testid="sm-stat-rounds" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.rounds.length}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">rounds played</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="sm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - fresh bindings
                </button>
                <a
                  href="/test"
                  data-testid="sm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {score.correct} of {score.totalItems} bindings placed exactly ·{" "}
                {runSeconds !== null ? `${runSeconds.toFixed(0)}s total` : "placement-pure scoring"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
