/* ------------------------------------------------------------------ */
/*  Pattern Memory Test - FAQ (single source)                          */
/*  Used by BOTH the visible FAQ section and the FAQPage JSON-LD in    */
/*  page.tsx, so the two can never drift apart.                        */
/* ------------------------------------------------------------------ */

export type PmFaq = { question: string; answer: string };

export const PATTERN_MEMORY_FAQS: PmFaq[] = [
  {
    question: "What is a pattern memory test and what does it measure?",
    answer:
      "A pattern memory test measures visual-spatial recall: your ability to hold the exact shape of what you just saw and rebuild it from an empty board. Lit tiles flash on a 5x5 grid for a moment, the board goes dark, and you click the tiles you believe were lit. Under the hood this exercises visual encoding (chunking scattered cells into a shape), working storage of locations, and precision at retrieval - the same machinery you use when you remember where keys sit on a keyboard, which pixels changed on a screen, or how a room was laid out after one glance.",
  },
  {
    question: "How is this different from the Visual Memory or Spatial Memory tests?",
    answer:
      "Visual Memory is a survival ladder: one cumulative pattern that grows level after level while the flash speeds up until you miss. This test is six INDEPENDENT rounds - each pattern is its own challenge, scored on its own, with a shrinking peek budget instead of an accelerating clock. Spatial Memory is about binding: symbols appear in cells and you must later say WHICH symbol sat WHERE. Here there are no symbols at all - only the pure form of the lit pattern matters.",
  },
  {
    question: "How is my score calculated?",
    answer:
      "Each round is scored independently: the cells you got right minus the wrong tiles you clicked, divided by the pattern size, floored at zero. Those six round scores are averaged and compared against an adult population model (mean about 0.60, SD 0.13), then mapped onto the standard IQ scale (mean 100, SD 15), clamped to 55-145 like all BrainMetrics tests. The minus-for-wrong rule is the honesty core: clicking every tile on the board catches the whole pattern but pays for all 17+ misses, pinning that round at zero - only careful recall moves your number.",
  },
  {
    question: "What are peeks and should I use them?",
    answer:
      "Peeks are bonus re-flashes: early rounds give you two, middle rounds one, and the final two rounds give none. During recall you can spend a peek to flash the pattern again for a fraction of a second - everything you already clicked stays counted. Spending one never costs score points; it is pure insurance. The strategy that works: commit hard to your first reading, and only spend a peek when your memory of the shape genuinely collapsed - because every peek you keep unused is time the next, larger pattern deserves.",
  },
  {
    question: "What is a good score on this test?",
    answer:
      "The average adult reproduces about 60% of the pattern content across the six rounds, where patterns grow from 3 to 8 tiles while the flash shrinks from 1.4 seconds to 0.7. The late rounds are where scores die: eight tiles in 700 milliseconds with no peek left defeats most people, so a strong finish matters more than a perfect start. Around 85% average puts you in the top few percent, and a flawless 100% across all 33 cells maps to the index ceiling of 145.",
  },
  {
    question: "How often can I retake the test?",
    answer:
      "As often as you like - it is free, needs no sign-up, and every run draws fresh patterns from a seeded generator, so there is nothing to memorise between attempts. A small practice effect is normal: the second run usually improves because the task rhythm is familiar, not because your memory grew. For tracking real change, run it two or three times in a sitting and compare weekly rather than hourly - sleep, screen glare and even sitting position move visual recall by a few percent, which is ordinary variation rather than genuine change.",
  },
];
