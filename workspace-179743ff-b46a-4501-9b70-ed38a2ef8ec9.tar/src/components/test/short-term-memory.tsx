"use client";

/* ------------------------------------------------------------------ */
/*  Short-Term Memory Test - interactive UI                            */
/*  Brown-Peterson filled-delay recall: a consonant trigram flashes    */
/*  (engine-owned), a backwards-subtraction chain fills the retention  */
/*  interval so rehearsal is impossible, then the trigram must be      */
/*  typed back. Delays cycle 3s -> 9s -> 15s over nine trials.         */
/*  Scoring lives in short-term-memory-core.ts.                        */
/*                                                                     */
/*  Testing hook: /test/short-term-memory?quick=1 shortens every       */
/*  engine timing (flash + delays + feedback) so automated flow tests  */
/*  run fast. Quick mode is a timing change only - never a scoring     */
/*  one.                                                               */
/*  Machine-readable hooks: the stage exposes data-phase               */
/*  (show | delay | recall | feedback); the trigram element carries    */
/*  data-letters ONLY during the flash (cleared after - anti-cheat);   */
/*  result numbers expose data-final so CountUp frames cannot fool     */
/*  assertions. The delay clock cannot be paused or shortened.         */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Brain,
  Check,
  Hash,
  RotateCcw,
  ShieldCheck,
  Timer,
  Zap,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  AFTER_SHOW_GAP_MS,
  AFTER_SHOW_GAP_MS_QUICK,
  DELAY_MS_QUICK,
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  SHOW_MS,
  SHOW_MS_QUICK,
  TRIAL_COUNT,
  buildStmSession,
  expectedCount,
  normaliseAnswer,
  scoreSession,
  type Recall,
  type StmScore,
  type StmSession,
} from "./short-term-memory-core";

type Phase = "intro" | "countdown" | "active" | "results";

type ActiveState = "show" | "delay" | "recall" | "feedback";

type ChainStep = { typed: string; expected: number; ok: boolean };

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("stm-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function ShortTermMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";

  const [phase, setPhase] = useState<Phase>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [activeState, setActiveState] = useState<ActiveState>("show");
  const [trialIndex, setTrialIndex] = useState(0);
  /** Trigram currently flashed (null = hidden). */
  const [shownLetters, setShownLetters] = useState<string | null>(null);
  /** Delay task state. */
  const [startNumber, setStartNumber] = useState(0);
  const [delayInput, setDelayInput] = useState("");
  const [chain, setChain] = useState<ChainStep[]>([]);
  /** Recall state. */
  const [recallInput, setRecallInput] = useState("");
  /** Feedback state: the just-recalled trial. */
  const [lastAnswer, setLastAnswer] = useState("");
  const [score, setScore] = useState<StmScore | null>(null);
  const [runSeconds, setRunSeconds] = useState<number | null>(null);
  /** Mirrors sessionRef for RENDER-time reads (refs are off-limits in render). */
  const [session, setSession] = useState<StmSession | null>(null);

  const sessionRef = useRef<StmSession | null>(null);
  const trialRef = useRef(0);
  const recallsRef = useRef<Recall[]>([]);
  const recallOpenedAtRef = useRef(0);
  const activeStateRef = useRef<ActiveState>("show");
  const quickRef = useRef(quick);
  const finishedRef = useRef(false);
  const startedAtRef = useRef(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    quickRef.current = quick;
  }, [quick]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(clearTimeout);
    };
  }, []);

  /* ------------------------- session flow ------------------------- */

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    clearTimers();
    const elapsed =
      startedAtRef.current > 0 ? (performance.now() - startedAtRef.current) / 1000 : null;
    setRunSeconds(elapsed);
    const result = scoreSession(recallsRef.current, sessionRef.current);
    setScore(result);
    setPhase("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearTimers]);

  const openRecall = useCallback(() => {
    activeStateRef.current = "recall";
    setActiveState("recall");
    setShownLetters(null);
    setRecallInput("");
    recallOpenedAtRef.current = performance.now();
  }, []);

  const beginDelay = useCallback(
    (trial: number) => {
      activeStateRef.current = "delay";
      setActiveState("delay");
      const sess = sessionRef.current;
      if (!sess) return;
      const t = sess.trials[trial]!;
      setStartNumber(t.startNumber);
      setDelayInput("");
      setChain([]);
      // The clock is absolute: recall opens at delay end no matter what
      // the user types (or does not type) during the subtraction chain.
      const delay = quickRef.current ? DELAY_MS_QUICK[t.trial % 3]! : t.delayMs;
      timersRef.current.push(setTimeout(() => openRecall(), delay));
    },
    [openRecall]
  );

  const beginShow = useCallback(
    (trial: number) => {
      trialRef.current = trial;
      setTrialIndex(trial);
      activeStateRef.current = "show";
      setActiveState("show");
      setPhase("active");
      setShownLetters(null);
      const sess = sessionRef.current;
      if (!sess) return;
      const t = sess.trials[trial]!;
      const showMs = quickRef.current ? SHOW_MS_QUICK : SHOW_MS;
      const gapMs = quickRef.current ? AFTER_SHOW_GAP_MS_QUICK : AFTER_SHOW_GAP_MS;
      clearTimers();
      timersRef.current.push(
        setTimeout(() => {
          setShownLetters(t.letters);
          timersRef.current.push(
            setTimeout(() => {
              setShownLetters(null);
              timersRef.current.push(setTimeout(() => beginDelay(trial), gapMs));
            }, showMs)
          );
        }, 120)
      );
    },
    [beginDelay, clearTimers]
  );

  const beginFeedback = useCallback(
    (answer: string) => {
      activeStateRef.current = "feedback";
      setActiveState("feedback");
      setLastAnswer(answer);
      const sess = sessionRef.current;
      if (!sess) return;
      const feedbackMs = quickRef.current ? FEEDBACK_MS_QUICK : FEEDBACK_MS;
      clearTimers();
      timersRef.current.push(
        setTimeout(() => {
          const next = trialRef.current + 1;
          if (next < sess.trials.length) {
            beginShow(next);
          } else {
            finish();
          }
        }, feedbackMs)
      );
    },
    [beginShow, clearTimers, finish]
  );

  const start = useCallback(() => {
    clearTimers();
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    const built = buildStmSession(seed);
    sessionRef.current = built;
    setSession(built);
    recallsRef.current = [];
    finishedRef.current = false;
    setTrialIndex(0);
    setScore(null);
    setRunSeconds(null);
    setShownLetters(null);
    setChain([]);
    setDelayInput("");
    setRecallInput("");
    setLastAnswer("");
    setCountdownValue(3);
    setPhase("countdown");
    requestAnimationFrame(() => scrollToApp(false));
  }, [clearTimers]);

  /* Global 3-2-1 before trial 1. */
  useEffect(() => {
    if (phase !== "countdown") return;
    let cancelled = false;
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const stepMs = quickRef.current ? 180 : 750;
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        startedAtRef.current = performance.now();
        beginShow(0);
        return;
      }
      timeouts.push(setTimeout(() => step(n - 1), stepMs));
    };
    step(3);
    return () => {
      cancelled = true;
      timeouts.forEach(clearTimeout);
    };
  }, [phase, beginShow]);

  /* --------------------------- interaction -------------------------- */

  const submitDelayStep = useCallback(() => {
    if (activeStateRef.current !== "delay") return;
    const typed = delayInput.trim();
    if (!/^-?\d+$/.test(typed)) return;
    const stepIndex = chain.length;
    const expected = expectedCount(startNumber, stepIndex + 1);
    const ok = Number(typed) === expected;
    setChain((prev) => [...prev, { typed, expected, ok }]);
    setDelayInput("");
  }, [chain.length, delayInput, startNumber]);

  const submitRecall = useCallback(() => {
    if (activeStateRef.current !== "recall") return;
    const answer = normaliseAnswer(recallInput);
    const sess = sessionRef.current;
    if (!sess) return;
    const trial = sess.trials[trialRef.current]!;
    recallsRef.current.push({
      trial: trial.trial,
      answer,
      rtMs: recallOpenedAtRef.current > 0 ? performance.now() - recallOpenedAtRef.current : null,
    });
    beginFeedback(answer);
  }, [beginFeedback, recallInput]);

  /* Keyboard: Enter submits whichever input is active. */
  useEffect(() => {
    if (phase !== "active") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;
      if (activeStateRef.current === "delay") submitDelayStep();
      else if (activeStateRef.current === "recall") submitRecall();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, submitDelayStep, submitRecall]);

  /* ------------------------- derived data -------------------------- */

  const trial = session?.trials[trialIndex];
  const statusText =
    activeState === "show"
      ? "Memorise the three letters"
      : activeState === "delay"
        ? "Keep counting backwards - recall opens when the bar empties"
        : activeState === "recall"
          ? "Type the three letters - order matters"
          : "";

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="stm-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {phase === "intro" && (
          <motion.div
            key="intro"
            data-testid="stm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Timer className="h-3.5 w-3.5" aria-hidden="true" />
                Short-term memory · filled delay · about 3 minutes
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                Three letters. Fifteen seconds of noise. What survives?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                A trigram flashes, then you count backwards by threes so
                rehearsal becomes impossible - and finally you type the
                letters back. Nine trials, delays growing 3s → 9s → 15s.
              </p>
            </div>

            {/* Static preview */}
            <div
              data-testid="stm-preview"
              aria-hidden="true"
              className="mx-auto mt-6 max-w-[340px] rounded-xl border border-border bg-muted/60 p-4"
            >
              <p className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                The three beats of every trial
              </p>
              <div className="mt-3 flex items-center justify-center gap-2 text-center">
                <span className="rounded-lg border border-emerald-500 bg-emerald-500/15 px-3 py-2 text-xl font-black tracking-widest text-emerald-700">
                  CHJ
                </span>
                <span className="text-muted-foreground">→</span>
                <span className="rounded-lg border border-border bg-background px-3 py-2 text-sm font-bold text-foreground">
                  147−3 = ?
                </span>
                <span className="text-muted-foreground">→</span>
                <span className="rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold text-muted-foreground">
                  _ _ _
                </span>
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Brain className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The trigram shows for under a second - the flash timing is engine-owned and identical for everyone.
              </li>
              <li className="flex gap-2.5">
                <Hash className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Count backwards by 3, typing each step. The clock cannot be paused - typing is practice, not stalling.
              </li>
              <li className="flex gap-2.5">
                <Timer className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Recall opens when the bar empties: type the letters in order. Delays cycle 3, 9 and 15 seconds.
              </li>
              <li className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Fresh letters every run - this is the raw survival of your short-term buffer, not a memory trick.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="stm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <Timer className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results · fresh trigrams every run
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {phase === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="stm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Trial 1 · 3-second delay · eyes on the card
            </p>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {phase === "active" && (
          <motion.div
            key="active"
            data-testid="stm-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Trial header */}
            <div className="flex items-center justify-between gap-3">
              <div>
                <p
                  data-testid="stm-round-chip"
                  className="text-xl font-black tabular-nums text-foreground sm:text-2xl"
                >
                  Trial {trialIndex + 1}
                </p>
                <p className="text-xs text-muted-foreground sm:text-sm">
                  {activeState === "show"
                    ? "memorise"
                    : activeState === "delay"
                      ? `count back by 3 from ${startNumber}`
                      : activeState === "recall"
                        ? "recall"
                        : "result"}
                </p>
              </div>
              <span
                data-testid="stm-progress"
                className="rounded-full border border-border bg-muted/60 px-3 py-1 text-sm font-semibold tabular-nums text-foreground"
              >
                {trialIndex + 1} / {TRIAL_COUNT}
              </span>
            </div>

            {/* Stage */}
            <div
              data-testid="stm-stage"
              data-phase={activeState}
              className="mx-auto mt-5 w-full max-w-[440px] rounded-2xl border-2 border-border p-6 sm:p-8"
            >
              {activeState === "show" && (
                <div className="flex min-h-28 items-center justify-center">
                  <AnimatePresence mode="wait">
                    {shownLetters ? (
                      <motion.span
                        key={shownLetters}
                        data-testid="stm-trigram"
                        data-letters={shownLetters}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        transition={{ duration: 0.12 }}
                        className="text-5xl font-black tracking-[0.35em] text-foreground sm:text-6xl"
                      >
                        {shownLetters}
                      </motion.span>
                    ) : (
                      <motion.span
                        key={`empty-${trialIndex}`}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 0.25 }}
                        className="select-none text-5xl font-black tracking-[0.35em] text-muted-foreground"
                      >
                        · · ·
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {activeState === "delay" && (
                <div>
                  <div className="text-center">
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      keep counting backwards by 3
                    </p>
                    <p className="mt-1 text-3xl font-black tabular-nums text-foreground sm:text-4xl">
                      {chain.length === 0
                        ? startNumber
                        : chain[chain.length - 1]!.expected}{" "}
                      − 3 = ?
                    </p>
                  </div>
                  <div className="mx-auto mt-4 flex max-w-[220px] items-center gap-2">
                    <input
                      data-testid="stm-delay-input"
                      type="text"
                      inputMode="numeric"
                      autoComplete="off"
                      value={delayInput}
                      onChange={(e) => setDelayInput(e.target.value.replace(/[^0-9-]/g, ""))}
                      placeholder="?"
                      aria-label="type the next number in the countdown"
                      className="w-full rounded-xl border-2 border-border bg-background px-4 py-3 text-center text-xl font-bold tabular-nums text-foreground outline-none transition-[border-color] focus:border-primary"
                    />
                    <button
                      type="button"
                      data-testid="stm-delay-submit"
                      onClick={submitDelayStep}
                      className="inline-flex h-[50px] shrink-0 items-center justify-center rounded-xl bg-primary px-4 text-base font-semibold text-primary-foreground shadow-md transition-[background-color] hover:bg-emerald-700"
                    >
                      <Check className="h-5 w-5" aria-hidden="true" />
                    </button>
                  </div>
                  {/* Chain history + remaining-time bar */}
                  <div className="mt-3 flex min-h-8 flex-wrap items-center justify-center gap-1.5">
                    {chain.map((s, i) => (
                      <span
                        key={i}
                        className={[
                          "rounded-md border px-2 py-0.5 text-xs font-bold tabular-nums",
                          s.ok
                            ? "border-emerald-300 bg-emerald-50 text-emerald-700"
                            : "border-red-300 bg-red-50 text-red-600",
                        ].join(" ")}
                      >
                        {s.typed}
                      </span>
                    ))}
                  </div>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted">
                    <motion.div
                      key={`bar-${trialIndex}`}
                      initial={{ width: "100%" }}
                      animate={{ width: "0%" }}
                      transition={{
                        duration:
                          (quick
                            ? DELAY_MS_QUICK[trialIndex % 3]!
                            : trial?.delayMs ?? 3000) / 1000,
                        ease: "linear",
                      }}
                      className="h-full bg-emerald-500"
                    />
                  </div>
                  <p className="mt-2 text-center text-xs text-muted-foreground">
                    recall opens when the bar empties
                  </p>
                </div>
              )}

              {activeState === "recall" && (
                <div className="text-center">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    what were the three letters?
                  </p>
                  <div className="mx-auto mt-3 flex max-w-[240px] items-center gap-2">
                    <input
                      data-testid="stm-recall-input"
                      type="text"
                      autoComplete="off"
                      autoFocus
                      value={recallInput}
                      onChange={(e) => setRecallInput(e.target.value.toUpperCase().slice(0, 5))}
                      placeholder="_ _ _"
                      aria-label="type the three letters you memorised"
                      className="w-full rounded-xl border-2 border-border bg-background px-4 py-3 text-center text-2xl font-black uppercase tracking-[0.3em] text-foreground outline-none transition-[border-color] focus:border-primary"
                    />
                    <button
                      type="button"
                      data-testid="stm-recall-submit"
                      onClick={submitRecall}
                      className="inline-flex h-[54px] shrink-0 items-center justify-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-md transition-[background-color] hover:bg-emerald-700"
                    >
                      Answer
                    </button>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">
                    order matters · blank counts as a miss
                  </p>
                </div>
              )}

              {activeState === "feedback" && trial && (
                <div className="py-2 text-center">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    correct was
                  </p>
                  <p className="mt-1 text-4xl font-black tracking-[0.3em] text-emerald-700 sm:text-5xl">
                    {trial.letters}
                  </p>
                  <div className="mt-3 flex items-center justify-center gap-1.5">
                    {[...trial.letters].map((l, i) => {
                      const typed = lastAnswer[i];
                      const ok = typed === l;
                      return (
                        <span
                          key={i}
                          className={[
                            "flex h-9 w-9 items-center justify-center rounded-lg border-2 text-lg font-bold",
                            ok
                              ? "border-emerald-500 bg-emerald-500/15 text-emerald-700"
                              : "border-red-300 bg-red-50 text-red-500",
                          ].join(" ")}
                        >
                          {typed ?? "·"}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Status */}
            <p
              data-testid="stm-status"
              aria-live="polite"
              className="mt-4 text-center text-sm font-semibold text-muted-foreground sm:text-base"
            >
              {statusText}
            </p>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {phase === "results" && score && (
          <motion.div
            key="results"
            data-testid="stm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="stm-accuracy"
                    data-final={Math.round(score.accuracy * 100)}
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={Math.round(score.accuracy * 100)} duration={1.2} />
                    <span className="text-3xl text-muted-foreground sm:text-4xl">%</span>
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  letters recalled in position · {score.totalLetters} shown
                </p>

                <div className="mt-5 flex items-end justify-center gap-2">
                  <span
                    data-testid="stm-iq"
                    data-final={score.iq}
                    className="text-4xl font-black leading-none tabular-nums text-foreground sm:text-5xl"
                  >
                    <CountUp to={score.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Short-term memory index · mean 100, SD 15
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="stm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${score.grade.className}`}
                  >
                    <Timer className="h-4 w-4" aria-hidden="true" />
                    {score.grade.label}
                  </span>
                  <span
                    data-testid="stm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Better than {score.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {score.grade.blurb}
                </p>
              </div>

              {/* Decay curve */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  The decay curve
                </p>
                <p className="mt-0.5 text-center text-xs text-muted-foreground">
                  Letters surviving each filled delay - watch retention fade with time
                </p>
                <div className="mt-3 space-y-2.5">
                  {score.byDuration.map((d) => {
                    const pct = Math.round(d.accuracy * 100);
                    return (
                      <div key={d.delayMs} className="flex items-center gap-3">
                        <span className="w-20 shrink-0 text-xs font-semibold text-muted-foreground sm:w-24 sm:text-sm">
                          {d.delayMs / 1000}s delay
                        </span>
                        <div className="h-3 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className={[
                              "h-full rounded-full transition-[width] duration-700",
                              pct >= 60
                                ? "bg-emerald-500"
                                : pct >= 30
                                  ? "bg-emerald-400"
                                  : "bg-amber-400",
                            ].join(" ")}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span
                          data-testid={`stm-duration-${d.delayMs}`}
                          data-final={pct}
                          className="w-12 shrink-0 text-right text-sm font-bold tabular-nums text-foreground"
                        >
                          {pct}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Per-trial chips */}
              <div className="mt-8">
                <p className="text-center text-sm font-semibold text-foreground">
                  Trial by trial
                </p>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                  {score.perTrial.map((c, i) => (
                    <span
                      key={i}
                      data-testid={`stm-trial-chip-${i}`}
                      className={[
                        "flex h-9 w-9 items-center justify-center rounded-lg border text-sm font-bold tabular-nums",
                        c === 3
                          ? "border-emerald-500 bg-emerald-500/15 text-emerald-700"
                          : c >= 1
                            ? "border-emerald-300 bg-emerald-50 text-emerald-600"
                            : "border-red-300 bg-red-50 text-red-500",
                      ].join(" ")}
                    >
                      {c}/3
                    </span>
                  ))}
                </div>
              </div>

              {/* Stat grid */}
              <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div data-testid="stm-stat-correct" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.correct}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">letters in place</p>
                </div>
                <div data-testid="stm-stat-total" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.totalLetters}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">letters shown</p>
                </div>
                <div data-testid="stm-stat-trials" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">{score.perTrial.length}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">trials played</p>
                </div>
                <div data-testid="stm-stat-rt" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-2xl font-bold tabular-nums text-foreground">
                    {score.avgRtMs !== null ? `${(score.avgRtMs / 1000).toFixed(1)}s` : "-"}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">avg recall time</p>
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="stm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - fresh trigrams
                </button>
                <a
                  href="/test"
                  data-testid="stm-cta-full-iq"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Try the Full IQ Test
                </a>
              </div>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {score.correct} of {score.totalLetters} letters survived the filled delays ·{" "}
                {runSeconds !== null ? `${runSeconds.toFixed(0)}s total` : "recall-pure scoring"}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
