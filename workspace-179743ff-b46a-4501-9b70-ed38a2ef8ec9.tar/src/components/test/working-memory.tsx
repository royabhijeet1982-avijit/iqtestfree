"use client";

/* ------------------------------------------------------------------ */
/*  Working Memory Test - interactive UI                               */
/*  Letter-Number Sequencing: mixed digits and letters flash one at a  */
/*  time; recall happens in two streams - digits ASCENDING first,      */
/*  letters ALPHABETICAL second. Two tabbed pads (numbers 1-9, letters */
/*  C F H K L Q R S T) with chips, undo/clear and keyboard support     */
/*  (digit keys and letter keys auto-switch the active tab).           */
/*  All scoring lives in working-memory-core.ts.                       */
/*                                                                     */
/*  Testing hooks: /test/working-memory?quick=1 starts at level 5 with */
/*  one attempt per level and faster pacing, so automated flow tests   */
/*  can run full sessions quickly.                                     */
/* ------------------------------------------------------------------ */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  ArrowDownUp,
  Check,
  Delete,
  Eraser,
  Eye,
  Hash,
  Keyboard,
  Repeat,
  RotateCcw,
  Type,
  X,
} from "lucide-react";
import { CountUp } from "@/components/brainmetrics/motion";
import {
  DIGITS,
  LETTERS,
  MAX_LEVEL,
  buildSequence,
  differentSequence,
  mulberry32,
  scoreSession,
  sessionConfig,
  submitAttempt,
  type WmAttempt,
  type WmSessionResult,
  type WmTarget,
} from "./working-memory-core";

type Screen = "intro" | "countdown" | "active" | "results";
type Stage = "display" | "input" | "feedback";
type Tab = "numbers" | "letters";

/** Scroll the test card to the top of the viewport (below the sticky nav). */
function scrollToApp(smooth: boolean) {
  const el = document.getElementById("working-memory-app");
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const y = el.getBoundingClientRect().top + window.scrollY - 88;
  window.scrollTo({ top: y, behavior: !smooth || reduce ? "auto" : "smooth" });
}

export function WorkingMemoryTest() {
  const searchParams = useSearchParams();
  const quick = searchParams.get("quick") === "1";
  const config = useMemo(() => sessionConfig(quick), [quick]);

  const [screen, setScreen] = useState<Screen>("intro");
  const [countdownValue, setCountdownValue] = useState(3);
  const [stage, setStage] = useState<Stage>("display");
  const [attemptKey, setAttemptKey] = useState(0);
  const [target, setTarget] = useState<WmTarget | null>(null);
  const [level, setLevel] = useState(config.startLevel);
  const [attemptIndex, setAttemptIndex] = useState(1);
  const [displayState, setDisplayState] = useState<{ element: string | null; pos: number }>({
    element: null,
    pos: -1,
  });
  const [tab, setTab] = useState<Tab>("numbers");
  const [digitBuffer, setDigitBuffer] = useState<number[]>([]);
  const [letterBuffer, setLetterBuffer] = useState<string[]>([]);
  const [feedback, setFeedback] = useState<{ correct: boolean; message: string } | null>(null);
  const [attempts, setAttempts] = useState<WmAttempt[]>([]);
  const [result, setResult] = useState<WmSessionResult | null>(null);

  const configRef = useRef(config);
  const rngRef = useRef<() => number>(() => 0.5);
  const screenRef = useRef<Screen>("intro");
  const stageRef = useRef<Stage>("display");
  const targetRef = useRef<WmTarget | null>(null);
  const levelRef = useRef(config.startLevel);
  const attemptIndexRef = useRef(1);
  const digitBufferRef = useRef<number[]>([]);
  const letterBufferRef = useRef<string[]>([]);
  const shownRef = useRef(false);
  const attemptsRef = useRef<WmAttempt[]>([]);
  const feedbackTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    configRef.current = config;
  }, [config]);

  useEffect(() => {
    return () => {
      if (feedbackTimerRef.current) clearTimeout(feedbackTimerRef.current);
    };
  }, []);

  const clearFeedbackTimer = useCallback(() => {
    if (feedbackTimerRef.current) {
      clearTimeout(feedbackTimerRef.current);
      feedbackTimerRef.current = null;
    }
  }, []);

  /* ------------------------- session flow ------------------------- */

  const dealAttempt = useCallback((lvl: number, idx: number) => {
    const rng = rngRef.current;
    const priorTargets = attemptsRef.current
      .filter((a) => a.level === lvl)
      .map((a) => a.target);
    const seq =
      priorTargets.length === 0
        ? buildSequence(lvl, rng)
        : differentSequence(lvl, rng, priorTargets);
    targetRef.current = seq;
    setTarget(seq);
    levelRef.current = lvl;
    setLevel(lvl);
    attemptIndexRef.current = idx;
    setAttemptIndex(idx);
    digitBufferRef.current = [];
    setDigitBuffer([]);
    letterBufferRef.current = [];
    setLetterBuffer([]);
    shownRef.current = false;
    setFeedback(null);
    setTab("numbers");
    stageRef.current = "display";
    setStage("display");
    setAttemptKey((k) => k + 1);
  }, []);

  const finishSession = useCallback(() => {
    clearFeedbackTimer();
    const score = scoreSession(attemptsRef.current, configRef.current.quick);
    setResult(score);
    screenRef.current = "results";
    setScreen("results");
    requestAnimationFrame(() => scrollToApp(true));
  }, [clearFeedbackTimer]);

  const start = useCallback(() => {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rngRef.current = mulberry32(seed);
    attemptsRef.current = [];
    setAttempts([]);
    setResult(null);
    setFeedback(null);
    screenRef.current = "countdown";
    setScreen("countdown");
    setCountdownValue(3);
    requestAnimationFrame(() => scrollToApp(false));
  }, []);

  const beginActive = useCallback(() => {
    screenRef.current = "active";
    setScreen("active");
    dealAttempt(configRef.current.startLevel, 1);
  }, [dealAttempt]);

  /* Countdown 3-2-1 before the run. */
  useEffect(() => {
    if (screen !== "countdown") return;
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const step = (n: number) => {
      if (cancelled) return;
      setCountdownValue(n);
      if (n === 0) {
        beginActive();
        return;
      }
      timers.push(setTimeout(() => step(n - 1), 800));
    };
    step(3);
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [screen, beginActive]);

  /* Element display scheduler: show each element, blank gap, then open
     the input stage. Runs once per dealt attempt. */
  useEffect(() => {
    if (screen !== "active" || stage !== "display") return;
    const cfg = configRef.current;
    const seq = targetRef.current;
    if (!seq) return;
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    let t = 400; // beat for the stage transition to settle
    timers.push(
      setTimeout(() => {
        if (!cancelled) setDisplayState({ element: null, pos: -1 });
      }, 0)
    );
    seq.display.forEach((element, i) => {
      timers.push(
        setTimeout(() => {
          if (!cancelled) setDisplayState({ element, pos: i });
        }, t)
      );
      t += cfg.displayMs;
      timers.push(
        setTimeout(() => {
          if (!cancelled) setDisplayState({ element: null, pos: i });
        }, t)
      );
      t += cfg.gapMs;
    });
    timers.push(
      setTimeout(() => {
        if (cancelled) return;
        shownRef.current = true;
        stageRef.current = "input";
        setStage("input");
      }, t)
    );
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
  }, [screen, stage, attemptKey]);

  /* --------------------------- responding -------------------------- */

  const pushDigit = useCallback((d: number) => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    const tgt = targetRef.current;
    if (!tgt || digitBufferRef.current.length >= tgt.digits.length) return;
    digitBufferRef.current = [...digitBufferRef.current, d];
    setDigitBuffer(digitBufferRef.current);
    setTab("numbers");
  }, []);

  const pushLetter = useCallback((l: string) => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    const tgt = targetRef.current;
    if (!tgt || letterBufferRef.current.length >= tgt.letters.length) return;
    letterBufferRef.current = [...letterBufferRef.current, l];
    setLetterBuffer(letterBufferRef.current);
    setTab("letters");
  }, []);

  const undo = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    if (tab === "numbers" && digitBufferRef.current.length > 0) {
      digitBufferRef.current = digitBufferRef.current.slice(0, -1);
      setDigitBuffer(digitBufferRef.current);
      return;
    }
    if (tab === "letters" && letterBufferRef.current.length > 0) {
      letterBufferRef.current = letterBufferRef.current.slice(0, -1);
      setLetterBuffer(letterBufferRef.current);
    }
  }, [tab]);

  const clearBuffers = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    if (tab === "numbers") {
      digitBufferRef.current = [];
      setDigitBuffer([]);
    } else {
      letterBufferRef.current = [];
      setLetterBuffer([]);
    }
  }, [tab]);

  const submit = useCallback(() => {
    if (screenRef.current !== "active" || stageRef.current !== "input") return;
    const tgt = targetRef.current;
    if (!tgt) return;
    const attempt = submitAttempt({
      level: levelRef.current,
      attemptIndex: attemptIndexRef.current,
      target: tgt,
      digitInput: digitBufferRef.current,
      letterInput: letterBufferRef.current,
      wasShown: shownRef.current,
    });
    attemptsRef.current = [...attemptsRef.current, attempt];
    setAttempts(attemptsRef.current);
    const cfg = configRef.current;
    const wasLastAttempt = attempt.attemptIndex >= cfg.attemptsPerLevel;
    const wasLastLevel = levelRef.current >= MAX_LEVEL;
    const streamNote = attempt.correct
      ? "Both streams sorted."
      : attempt.digitStreamCorrect
        ? "Numbers right - letters dropped."
        : attempt.letterStreamCorrect
          ? "Letters right - numbers dropped."
          : "Both streams missed.";
    const message = attempt.correct
      ? wasLastLevel
        ? `Level ${attempt.level} recalled - run complete.`
        : `Correct (${streamNote}) - the next sequence is one element longer.`
      : wasLastAttempt
        ? `Run complete - ${streamNote.toLowerCase()}`
        : `Not quite - ${streamNote.toLowerCase()} One more try at this level with a fresh sequence.`;
    stageRef.current = "feedback";
    setStage("feedback");
    setFeedback({ correct: attempt.correct, message });
    clearFeedbackTimer();
    feedbackTimerRef.current = setTimeout(() => {
      feedbackTimerRef.current = null;
      setFeedback(null);
      if (attempt.correct) {
        if (wasLastLevel) finishSession();
        else dealAttempt(levelRef.current + 1, 1);
      } else if (!wasLastAttempt) {
        dealAttempt(levelRef.current, attempt.attemptIndex + 1);
      } else {
        finishSession();
      }
    }, 1100);
  }, [clearFeedbackTimer, dealAttempt, finishSession]);

  /* Keyboard input: digits and letters type into their own tabs
     (auto-switching), Backspace undoes on the active tab, Enter
     submits. */
  useEffect(() => {
    if (screen !== "active" || stage !== "input") return;
    const handler = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      if (/^[1-9]$/.test(event.key)) {
        event.preventDefault();
        pushDigit(Number(event.key));
      } else if (/^[a-z]$/.test(event.key)) {
        const upper = event.key.toUpperCase();
        if ((LETTERS as readonly string[]).includes(upper)) {
          event.preventDefault();
          pushLetter(upper);
        }
      } else if (event.key === "Backspace") {
        event.preventDefault();
        undo();
      } else if (event.key === "Enter") {
        event.preventDefault();
        submit();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [screen, stage, pushDigit, pushLetter, undo, submit]);

  /* ------------------------- derived data -------------------------- */

  const numSlots =
    target && stage !== "display" ? Math.max(0, target.digits.length - digitBuffer.length) : 0;
  const letSlots =
    target && stage !== "display" ? Math.max(0, target.letters.length - letterBuffer.length) : 0;
  const nothingTyped = digitBuffer.length === 0 && letterBuffer.length === 0;

  /* ----------------------------- render ---------------------------- */

  return (
    <div
      id="working-memory-app"
      className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
    >
      <AnimatePresence mode="wait">
        {/* ------------------------------ INTRO ------------------------------ */}
        {screen === "intro" && (
          <motion.div
            key="intro"
            data-testid="wm-intro"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-xl text-center">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <ArrowDownUp className="h-3.5 w-3.5" aria-hidden="true" />
                Working memory · letter-number sequencing
              </span>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                How well does your mind juggle?
              </h2>
              <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                A stream of mixed numbers and letters flashes by - like{" "}
                <span className="rounded-md border border-border bg-muted px-1.5 py-0.5 font-mono text-sm font-semibold text-foreground">
                  R 7 C 2
                </span>
                . Afterwards, recall the numbers in <strong className="text-foreground">ascending</strong>{" "}
                order, then the letters in <strong className="text-foreground">alphabetical</strong>{" "}
                order. The stream grows by one element until the juggling act breaks.
              </p>
            </div>

            <div className="mx-auto mt-6 grid max-w-2xl gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-border bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <Hash className="h-4 w-4 text-primary" aria-hidden="true" />
                  Numbers first
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  Type back only the digits, smallest to largest. In the example stream
                  R 7 C 2, that is 2 then 7.
                </p>
              </div>
              <div className="rounded-xl border border-border bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <Type className="h-4 w-4 text-primary" aria-hidden="true" />
                  Then letters
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  Switch tabs and type the letters A-to-Z style. In the example, that is
                  C then R. Both streams must land for the level to count.
                </p>
              </div>
            </div>

            <ul className="mx-auto mt-6 max-w-md space-y-2.5 text-sm text-muted-foreground">
              <li className="flex gap-2.5">
                <Eye className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {config.attemptsPerLevel === 1
                  ? "One attempt per level; elements flash fast, so stay locked in."
                  : "Two attempts per level (the second only if the first fails); one correct answer advances you."}
              </li>
              <li className="flex gap-2.5">
                <Repeat className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                Every sequence is freshly randomised, and repeats never appear inside one sequence - after a miss, the retry is always a different stream.
              </li>
              <li className="flex gap-2.5">
                <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                The recall stage is untimed - typing a digit or letter key jumps straight to that pad.
              </li>
            </ul>

            <div className="mt-8 text-center">
              <button
                type="button"
                data-testid="wm-intro-cta"
                onClick={start}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary active:translate-y-0"
              >
                <ArrowDownUp className="h-5 w-5" aria-hidden="true" />
                Start the test
              </button>
              <p className="mt-3 text-xs text-muted-foreground">
                Free · no sign-up · instant results
              </p>
            </div>
          </motion.div>
        )}

        {/* ---------------------------- COUNTDOWN ---------------------------- */}
        {screen === "countdown" && (
          <motion.div
            key="countdown"
            data-testid="wm-countdown"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-md text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Letter-number sequencing
              </p>
              <p className="mt-2 text-base font-medium text-foreground">
                Watch the stream, then sort it: numbers ascending, letters alphabetical.
              </p>
            </div>
            <div className="mt-8 text-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={countdownValue}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="inline-block text-7xl font-black tabular-nums text-primary sm:text-8xl"
                >
                  {countdownValue === 0 ? "GO" : countdownValue}
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* ------------------------------ ACTIVE ------------------------------ */}
        {screen === "active" && (
          <motion.div
            key="active"
            data-testid="wm-test-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="p-4 sm:p-8"
          >
            {/* Run header */}
            <div className="flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <ArrowDownUp className="h-3.5 w-3.5" aria-hidden="true" />
                Level {level}
              </span>
              <span
                data-testid="wm-attempt-info"
                className="text-sm font-semibold tabular-nums text-muted-foreground"
              >
                attempt {attemptIndex} of {config.attemptsPerLevel}
              </span>
            </div>

            <AnimatePresence mode="wait">
              {/* ------------------------- DISPLAY STAGE ------------------------- */}
              {stage === "display" && (
                <motion.div
                  key={`display-${attemptKey}`}
                  data-testid="wm-display-stage"
                  data-total={level}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5 rounded-xl border border-border bg-secondary/70 py-8 sm:py-10"
                >
                  <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    Watch the stream
                  </p>
                  <div className="mt-4 flex items-center justify-center">
                    <motion.span
                      key={displayState.pos}
                      data-testid="wm-element"
                      data-pos={displayState.pos}
                      initial={displayState.element !== null ? { scale: 0.7, opacity: 0 } : false}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.15 }}
                      aria-label={displayState.element !== null ? `Element ${displayState.element}` : "Pause"}
                      className={[
                        "inline-flex h-24 w-24 select-none items-center justify-center text-7xl font-black leading-none sm:h-28 sm:text-8xl",
                        displayState.element !== null && /\d/.test(displayState.element)
                          ? "tabular-nums text-foreground"
                          : "text-primary",
                      ].join(" ")}
                    >
                      {displayState.element !== null ? displayState.element : ""}
                    </motion.span>
                  </div>
                  <div
                    className="mt-4 flex justify-center gap-1.5"
                    data-testid="wm-progress"
                    aria-hidden="true"
                  >
                    {(target?.display ?? []).map((_, i) => {
                      const shown =
                        i < displayState.pos || (i === displayState.pos && displayState.element !== null);
                      return (
                        <span
                          key={i}
                          className={[
                            "h-2 w-2 rounded-full transition-colors duration-150",
                            shown
                              ? "bg-primary"
                              : i === displayState.pos
                                ? "animate-pulse bg-primary/50"
                                : "bg-muted-foreground/25",
                          ].join(" ")}
                        />
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* -------------------------- INPUT STAGE -------------------------- */}
              {stage === "input" && target && (
                <motion.div
                  key={`input-${attemptKey}`}
                  data-testid="wm-input"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5"
                >
                  <p className="text-center text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    Numbers ascending first, then letters A-Z
                  </p>

                  {/* Stream chips: what you have typed so far */}
                  <div className="mt-4 space-y-3">
                    <div
                      data-testid="wm-num-chips"
                      className="flex min-h-12 flex-wrap items-center justify-center gap-2"
                      aria-label="Numbers entered so far"
                    >
                      <span className="mr-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        Numbers
                      </span>
                      {digitBuffer.map((d, i) => (
                        <span
                          key={`n-${i}-${d}`}
                          data-testid="wm-chip-num"
                          className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-primary bg-emerald-50 px-2 text-xl font-bold tabular-nums text-emerald-800"
                        >
                          {d}
                        </span>
                      ))}
                      {Array.from({ length: numSlots }).map((_, i) => (
                        <span
                          key={`ns-${i}`}
                          aria-hidden="true"
                          className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-dashed border-border text-lg text-muted-foreground/50"
                        >
                          ·
                        </span>
                      ))}
                    </div>
                    <div
                      data-testid="wm-let-chips"
                      className="flex min-h-12 flex-wrap items-center justify-center gap-2"
                      aria-label="Letters entered so far"
                    >
                      <span className="mr-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        Letters
                      </span>
                      {letterBuffer.map((l, i) => (
                        <span
                          key={`l-${i}-${l}`}
                          data-testid="wm-chip-let"
                          className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-primary bg-emerald-50 px-2 text-xl font-bold text-emerald-800"
                        >
                          {l}
                        </span>
                      ))}
                      {Array.from({ length: letSlots }).map((_, i) => (
                        <span
                          key={`ls-${i}`}
                          aria-hidden="true"
                          className="inline-flex h-10 min-w-10 items-center justify-center rounded-lg border border-dashed border-border text-lg text-muted-foreground/50"
                        >
                          ·
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Number pad 1-9 */}
                  <div
                    className="mt-5 grid grid-cols-9 gap-1.5 sm:gap-2"
                    aria-label="Number pad"
                  >
                    {DIGITS.map((d) => {
                      const full = digitBuffer.length >= target.digits.length;
                      return (
                        <button
                          key={d}
                          type="button"
                          data-testid={`wm-pad-num-${d}`}
                          aria-label={`Enter number ${d}`}
                          disabled={full}
                          onClick={() => pushDigit(d)}
                          className="h-12 rounded-xl border border-border bg-card text-lg font-bold tabular-nums text-foreground transition-[background-color,border-color,color,translate] duration-100 hover:-translate-y-0.5 hover:border-primary hover:text-primary active:translate-y-0 disabled:pointer-events-none disabled:opacity-40 sm:h-14 sm:text-xl"
                        >
                          {d}
                        </button>
                      );
                    })}
                  </div>

                  {/* Letter pad - always displayed alphabetically */}
                  <div
                    className="mt-2 grid grid-cols-9 gap-1.5 sm:gap-2"
                    aria-label="Letter pad"
                  >
                    {[...LETTERS].sort().map((l) => {
                      const full = letterBuffer.length >= target.letters.length;
                      return (
                        <button
                          key={l}
                          type="button"
                          data-testid={`wm-pad-let-${l}`}
                          aria-label={`Enter letter ${l}`}
                          disabled={full}
                          onClick={() => pushLetter(l)}
                          className="h-12 rounded-xl border border-border bg-card text-lg font-bold text-foreground transition-[background-color,border-color,color,translate] duration-100 hover:-translate-y-0.5 hover:border-primary hover:text-primary active:translate-y-0 disabled:pointer-events-none disabled:opacity-40 sm:h-14 sm:text-xl"
                        >
                          {l}
                        </button>
                      );
                    })}
                  </div>

                  {/* Undo / clear / submit */}
                  <div className="mt-5 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
                    <button
                      type="button"
                      data-testid="wm-undo"
                      onClick={undo}
                      disabled={digitBuffer.length === 0 && letterBuffer.length === 0}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground transition-[border-color,color] hover:border-primary hover:text-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Delete className="h-4 w-4" aria-hidden="true" />
                      Undo
                    </button>
                    <button
                      type="button"
                      data-testid="wm-clear"
                      onClick={clearBuffers}
                      disabled={digitBuffer.length === 0 && letterBuffer.length === 0}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground transition-[border-color,color] hover:border-primary hover:text-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Eraser className="h-4 w-4" aria-hidden="true" />
                      Clear {tab === "numbers" ? "numbers" : "letters"}
                    </button>
                    <button
                      type="button"
                      data-testid="wm-submit"
                      onClick={submit}
                      disabled={nothingTyped}
                      className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-2.5 text-sm font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Check className="h-4 w-4" aria-hidden="true" />
                      Submit answer
                    </button>
                  </div>

                  <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
                    <Keyboard className="h-3.5 w-3.5" aria-hidden="true" />
                    Number and letter keys type straight into their pads - Backspace undoes, Enter submits.
                  </p>
                </motion.div>
              )}

              {/* ------------------------- FEEDBACK STAGE ------------------------- */}
              {stage === "feedback" && feedback && (
                <motion.div
                  key={`feedback-${attemptKey}`}
                  data-testid="wm-attempt-feedback"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="mt-5 flex min-h-56 flex-col items-center justify-center rounded-xl border border-border bg-muted/40 px-6 py-10 text-center"
                >
                  <span
                    className={[
                      "inline-flex h-12 w-12 items-center justify-center rounded-full",
                      feedback.correct
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-red-50 text-red-600",
                    ].join(" ")}
                    aria-hidden="true"
                  >
                    {feedback.correct ? (
                      <Check className="h-6 w-6" />
                    ) : (
                      <X className="h-6 w-6" />
                    )}
                  </span>
                  <p
                    className={[
                      "mt-3 text-xl font-bold",
                      feedback.correct ? "text-emerald-800" : "text-foreground",
                    ].join(" ")}
                  >
                    {feedback.correct ? "Sorted" : "Not quite"}
                  </p>
                  <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-muted-foreground">
                    {feedback.message}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* ------------------------------ RESULTS ------------------------------ */}
        {screen === "results" && result && (
          <motion.div
            key="results"
            data-testid="wm-results"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="p-6 sm:p-10"
          >
            <div className="mx-auto max-w-2xl">
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Your result
                </p>
                <div className="mt-2 flex items-end justify-center gap-2">
                  <span
                    data-testid="wm-iq"
                    className="text-6xl font-black leading-none tabular-nums text-foreground sm:text-7xl"
                  >
                    <CountUp to={result.iq} duration={1.4} />
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Working Memory Index · population mean 100, SD 15
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span
                    data-testid="wm-grade"
                    className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-sm font-bold ${result.grade.className}`}
                  >
                    <ArrowDownUp className="h-4 w-4" aria-hidden="true" />
                    {result.grade.label}
                  </span>
                  <span
                    data-testid="wm-percentile"
                    className="rounded-full border border-border bg-muted/60 px-4 py-1.5 text-sm font-semibold text-foreground"
                  >
                    Higher than {result.percentile} in 100 adults
                  </span>
                </div>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {result.grade.blurb}
                </p>
                {result.quick && (
                  <p
                    data-testid="wm-quick-note"
                    className="mx-auto mt-3 max-w-md rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm leading-relaxed text-emerald-800"
                  >
                    Quick practice mode: one attempt per level from a higher starting
                    point, so measured spans - and scores - run lower than an
                    equivalent full run.
                  </p>
                )}
              </div>

              {/* Span + streams */}
              <div className="mt-8 grid grid-cols-3 gap-3">
                <div data-testid="wm-span" className="rounded-xl border border-primary/30 bg-emerald-50 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-emerald-800">{result.span}</p>
                  <p className="mt-0.5 text-xs text-emerald-700">letter-number span</p>
                </div>
                <div data-testid="wm-correct" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-foreground">{result.correct}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">levels sorted</p>
                </div>
                <div data-testid="wm-partly" className="rounded-xl border border-border bg-muted/40 p-4 text-center">
                  <p className="text-3xl font-bold tabular-nums text-foreground">{result.streamsPartlyCorrect}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">one-stream saves</p>
                </div>
              </div>
              {result.partialBonus > 0 && (
                <p
                  data-testid="wm-bonus-note"
                  className="mt-3 rounded-xl border border-border bg-muted/40 p-3 text-center text-xs leading-relaxed text-muted-foreground"
                >
                  Includes a +0.5 partial-credit step: at your final level one stream
                  came out fully sorted{result.span >= MAX_LEVEL ? " - and you cleared the ladder" : ""}.
                </p>
              )}

              {/* Level ladder */}
              <div className="mt-8" data-testid="wm-ladder">
                <p className="text-sm font-semibold text-foreground">Every attempt, level by level</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Green is a fully sorted level; amber is a one-stream save; red is a miss.
                </p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {attempts.map((a, i) => (
                    <span
                      key={`${a.level}-${a.attemptIndex}-${i}`}
                      data-testid={`wm-ladder-${i}`}
                      className={[
                        "inline-flex h-8 min-w-8 items-center justify-center gap-0.5 rounded-lg border px-1.5 text-sm font-bold tabular-nums",
                        a.correct
                          ? "border-emerald-300 bg-emerald-100 text-emerald-800"
                          : a.valid && (a.digitStreamCorrect || a.letterStreamCorrect)
                            ? "border-amber-300 bg-amber-50 text-amber-700"
                            : "border-red-200 bg-red-50 text-red-600",
                      ].join(" ")}
                      title={`Level ${a.level}${a.correct ? " - sorted" : a.valid && (a.digitStreamCorrect || a.letterStreamCorrect) ? " - one stream saved" : " - missed"}`}
                    >
                      {a.level}
                      {a.correct ? (
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : a.valid && (a.digitStreamCorrect || a.letterStreamCorrect) ? (
                        <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : (
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <button
                  type="button"
                  data-testid="wm-retake"
                  onClick={start}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-base font-semibold text-primary-foreground shadow-md transition-[translate,background-color,box-shadow] hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Retake - new random streams
                </button>
                <a
                  href="/test"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-7 py-3 text-base font-semibold text-foreground transition-[translate,border-color,color] hover:-translate-y-0.5 hover:border-primary hover:text-primary"
                >
                  Try the Full IQ Test
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
