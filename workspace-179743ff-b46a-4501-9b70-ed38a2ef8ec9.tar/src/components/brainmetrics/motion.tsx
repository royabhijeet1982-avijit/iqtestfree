"use client";

import {
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  animate,
  motion,
  useInView,
  useReducedMotion,
  useScroll,
} from "framer-motion";

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

/**
 * Fade-and-rise entrance that replays once when scrolled into view.
 * Pass `scale` to also grow from a slightly smaller size (nice for
 * feature cards and CTA bands).
 */
export function Reveal({
  children,
  delay = 0,
  y = 24,
  scale = false,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  scale?: boolean;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y, scale: scale ? 0.94 : 1 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.65, delay, ease: EASE_OUT }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/** Gentle infinite vertical bob for decorative elements. */
export function Float({
  children,
  delay = 0,
  distance = 7,
  duration = 3.4,
  className,
}: {
  children: ReactNode;
  delay?: number;
  distance?: number;
  duration?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ y: 0 }}
      animate={{ y: [0, -distance, 0] }}
      transition={{ duration, delay, repeat: Infinity, ease: "easeInOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/** Counts from 0 to `to` the first time it scrolls into view. */
export function CountUp({
  to,
  duration = 1.6,
  className,
}: {
  to: number;
  duration?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, to, {
      duration,
      ease: "easeOut",
      onUpdate: (latest) => setValue(Math.round(latest)),
    });
    return () => controls.stop();
  }, [inView, to, duration]);

  return (
    <span ref={ref} className={className}>
      {value}
    </span>
  );
}

/** Springy pop-in (scale 0 -> 1) used for icons and badges. */
export function Pop({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  return (
    <motion.span
      initial={{ scale: 0, opacity: 0 }}
      whileInView={{ scale: 1, opacity: 1 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ type: "spring", stiffness: 320, damping: 18, delay }}
      className={className}
    >
      {children}
    </motion.span>
  );
}

/**
 * Slim emerald scroll-progress bar pinned to the top of the viewport.
 * Uses the raw scroll MotionValue (no spring) so it updates the style
 * directly on the compositor without an extra per-frame rAF spring loop.
 * Hidden entirely when the user prefers reduced motion.
 */
export function ScrollProgress() {
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll();

  if (reduce) return null;

  return (
    <motion.div
      aria-hidden="true"
      className="fixed inset-x-0 top-0 z-[60] h-0.5 origin-left bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-300"
      style={{ scaleX: scrollYProgress }}
    />
  );
}
