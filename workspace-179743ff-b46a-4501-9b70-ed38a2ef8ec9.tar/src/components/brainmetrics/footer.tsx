import Link from "next/link";
import { Brain } from "lucide-react";
import { ARTICLES, POPULAR_TOOLS } from "@/config/tools";
import { Reveal } from "./motion";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t border-border bg-background">
      <div className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <Reveal y={16}>
        <div className="grid gap-10 md:grid-cols-6">
          <div className="md:col-span-2">
            <Link
              href="/"
              aria-label="BrainMetrics home"
              className="inline-flex items-center gap-2.5 rounded-lg focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-primary"
            >
              <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_18px_rgba(4,120,87,0.3)] transition-[transform,box-shadow] duration-300 hover:scale-110 hover:shadow-[0_0_26px_rgba(4,120,87,0.45)]">
                <Brain className="size-5" aria-hidden="true" />
              </span>
              <span className="text-lg font-bold tracking-tight text-foreground">
                BrainMetrics
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Free online IQ test and cognitive tests for memory, attention,
              speed, reasoning and spatial skills.
            </p>
            <p className="mt-4 max-w-xs text-xs leading-relaxed text-muted-foreground/80">
              BrainMetrics tools are inspired by established cognitive testing
              methods and are intended for education and self-exploration -
              they are not a standardized, professionally administered
              assessment or a clinical evaluation.
            </p>
          </div>

          <nav aria-label="Tests">
            <h3 className="text-sm font-semibold text-foreground">Tests</h3>
            <ul className="mt-4 space-y-2.5">
              {[
                { label: "Full IQ Test", href: "/test" },
                { label: "All Cognitive Tests", href: "#all-tests" },
                { label: "Memory Tests", href: "/tests/memory" },
                { label: "Attention & Speed", href: "/tests/attention-speed" },
                {
                  label: "Spatial & Reasoning",
                  href: "/tests/spatial-reasoning",
                },
                { label: "Working Memory", href: "/tests/working-memory" },
              ].map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="inline-flex items-center rounded text-sm text-muted-foreground transition-[color,translate] duration-200 hover:translate-x-1 hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Popular tools">
            <h3 className="text-sm font-semibold text-foreground">
              Popular Tools
            </h3>
            <ul className="mt-4 space-y-2.5">
              {POPULAR_TOOLS.slice(1, 6).map((tool) => (
                <li key={tool.id}>
                  <Link
                    href={tool.href}
                    className="inline-flex items-center rounded text-sm text-muted-foreground transition-[color,translate] duration-200 hover:translate-x-1 hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    {tool.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Learn">
            <h3 className="text-sm font-semibold text-foreground">Learn</h3>
            <ul className="mt-4 space-y-2.5">
              {ARTICLES.map((article) => (
                <li key={article.href}>
                  <Link
                    href={article.href}
                    className="inline-flex items-center rounded text-sm text-muted-foreground transition-[color,translate] duration-200 hover:translate-x-1 hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    {article.title}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Policies">
            <h3 className="text-sm font-semibold text-foreground">Policies</h3>
            <ul className="mt-4 space-y-2.5">
              {[
                { label: "About Us", href: "/about" },
                { label: "Contact Us", href: "/contact" },
                { label: "Privacy Policy", href: "/privacy" },
                { label: "Terms of Use", href: "/terms" },
              ].map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="inline-flex items-center rounded text-sm text-muted-foreground transition-[color,translate] duration-200 hover:translate-x-1 hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
        </Reveal>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-border pt-6 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            © {year} BrainMetrics. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Made for curious minds everywhere.
          </p>
        </div>
      </div>
    </footer>
  );
}
