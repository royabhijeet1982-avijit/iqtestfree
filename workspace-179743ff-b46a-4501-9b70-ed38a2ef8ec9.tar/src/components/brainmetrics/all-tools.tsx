import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { CATEGORIES, toolsByCategory } from "@/config/tools";
import { Reveal } from "./motion";
import { ToolCard } from "./tool-card";

export function AllTools() {
  return (
    <section
      id="all-tests"
      aria-labelledby="all-tests-heading"
      className="scroll-mt-20 bg-muted py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">
              All tools
            </p>
            <h2
              id="all-tests-heading"
              className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            >
              All Cognitive Tests
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Browse every test by skill area and choose the challenge that
              fits your goals.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 space-y-14 sm:space-y-16">
          {CATEGORIES.map((category, categoryIndex) => {
            const tools = toolsByCategory(category.id);
            return (
              <Reveal key={category.id} delay={categoryIndex * 0.04}>
                <div
                  id={category.id}
                  className="scroll-mt-20"
                  aria-labelledby={`${category.id}-heading`}
                >
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                    <div className="max-w-2xl">
                      <h3
                        id={`${category.id}-heading`}
                        className="text-xl font-bold tracking-tight text-foreground sm:text-2xl"
                      >
                        {category.name}
                        <span className="ml-2 align-middle text-sm font-medium text-muted-foreground">
                          ({tools.length})
                        </span>
                      </h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground sm:text-base">
                        {category.intro}
                      </p>
                    </div>
                    <Link
                      href={category.href}
                      className="group inline-flex shrink-0 items-center gap-1.5 rounded-lg text-sm font-semibold text-primary hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                    >
                      View all {category.name}
                      <ArrowRight
                        className="size-4 transition-transform duration-300 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </Link>
                  </div>

                  <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">
                    {tools.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
