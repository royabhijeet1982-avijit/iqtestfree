import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ARTICLES } from "@/config/tools";
import { Reveal } from "./motion";

export function LearnSection() {
  return (
    <section
      id="learn"
      aria-labelledby="learn-heading"
      className="scroll-mt-20 bg-muted py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">
              Learn
            </p>
            <h2
              id="learn-heading"
              className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            >
              Learn About Cognitive Skills
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Understand how different cognitive tasks work and what their
              results can - and cannot - tell you.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {ARTICLES.map((article, index) => (
            <Reveal key={article.href} delay={index * 0.06} className="h-full">
              <article className="group relative flex h-full flex-col rounded-2xl border border-border bg-card p-6 shadow-[0_6px_24px_rgba(10,12,11,0.05)] transition-[translate,box-shadow,border-color] duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-[0_16px_40px_rgba(4,120,87,0.12)]">
                <span className="inline-flex w-fit items-center rounded-full border border-primary/20 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-primary transition-colors duration-200 group-hover:border-primary/40 group-hover:bg-primary/15">
                  {article.category}
                </span>
                <h3 className="mt-4 text-base font-semibold leading-snug text-foreground">
                  {article.title}
                </h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {article.description}
                </p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                  Read Article
                  <ArrowRight
                    className="size-4 transition-transform group-hover:translate-x-0.5"
                    aria-hidden="true"
                  />
                </span>
                <Link
                  href={article.href}
                  className="absolute inset-0 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
                >
                  <span className="sr-only">Read article: {article.title}</span>
                </Link>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
