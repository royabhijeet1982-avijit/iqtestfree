import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQ_ITEMS } from "./faq-data";
import { Reveal } from "./motion";

export function Faq() {
  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="scroll-mt-20 bg-background py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">
              FAQ
            </p>
            <h2
              id="faq-heading"
              className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            >
              Frequently asked questions
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Everything you need to know before you take a test.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <Accordion type="single" collapsible className="mt-10">
            {FAQ_ITEMS.map((item, index) => (
              <AccordionItem
                key={item.question}
                value={`faq-item-${index}`}
                className="mb-3 rounded-2xl border border-border bg-card px-5 shadow-[0_4px_18px_rgba(10,12,11,0.05)] transition-[box-shadow,border-color,background-color] duration-200 hover:border-primary/30 hover:shadow-[0_8px_24px_rgba(4,120,87,0.09)] last:border-b data-[state=open]:border-primary/40 data-[state=open]:bg-primary/5 sm:px-6"
              >
                <AccordionTrigger className="py-5 text-left text-base font-semibold text-foreground transition-colors duration-200 hover:text-primary hover:no-underline sm:text-lg [&>svg]:size-5 [&>svg]:text-muted-foreground [&>svg]:transition-transform [&>svg]:duration-200">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground sm:text-base">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}
