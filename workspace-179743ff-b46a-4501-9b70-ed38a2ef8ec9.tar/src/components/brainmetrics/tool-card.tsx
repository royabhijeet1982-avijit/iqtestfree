import Link from "next/link";
import { ArrowRight, Clock } from "lucide-react";
import type { Tool } from "@/config/tools";

/**
 * Compact, reusable tool card used by the Popular grid and every
 * category grid. Whole card is a semantic link with a visible
 * keyboard-focus ring, a hover lift and a clear "Start Test" action.
 */
export function ToolCard({ tool }: { tool: Tool }) {
  const Icon = tool.icon;

  return (
    <article
      className={`group relative flex h-full flex-col rounded-2xl border bg-card p-4 transition-[translate,box-shadow,border-color] duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-[0_12px_32px_rgba(4,120,87,0.14)] sm:p-5 ${
        tool.featured
          ? "border-primary/50 ring-1 ring-primary/30"
          : "border-border"
      }`}
    >
      {tool.featured ? (
        <span className="absolute -top-2.5 left-4 rounded-full bg-primary px-2.5 py-0.5 text-[11px] font-semibold text-primary-foreground shadow-sm">
          Most popular
        </span>
      ) : null}

      <div className="flex items-start justify-between gap-2">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-[scale,rotate,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15 group-hover:-rotate-6">
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <span className="mt-1 inline-flex items-center gap-1 rounded-full border border-border bg-secondary px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
          <Clock className="size-3" aria-hidden="true" />
          {tool.minutes} min
        </span>
      </div>

      <h4 className="mt-3.5 text-sm font-semibold text-foreground transition-colors duration-200 group-hover:text-primary sm:text-base">
        {tool.name}
      </h4>
      <p className="mt-1.5 flex-1 text-xs leading-relaxed text-muted-foreground sm:text-sm">
        {tool.description}
      </p>

      <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
        Start Test
        <ArrowRight
          className="size-4 transition-transform group-hover:translate-x-0.5"
          aria-hidden="true"
        />
      </span>

      {/* Stretched link: the whole card is clickable, while the label
          above stays the visible, accessible link name. */}
      <Link
        href={tool.href}
        className="absolute inset-0 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
      >
        <span className="sr-only">Start {tool.name}</span>
      </Link>
    </article>
  );
}
