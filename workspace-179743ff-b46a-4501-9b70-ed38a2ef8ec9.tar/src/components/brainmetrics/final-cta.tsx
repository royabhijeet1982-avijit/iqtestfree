import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Reveal } from "./motion";

export function FinalCta() {
  return (
    <section
      aria-labelledby="cta-heading"
      className="bg-background pb-16 sm:pb-20 lg:pb-24"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal scale>
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-950 px-6 py-14 text-center shadow-[0_24px_60px_-16px_rgba(4,120,87,0.45)] sm:px-12 sm:py-16 lg:py-20">
            <div
              aria-hidden="true"
              className="bm-drift pointer-events-none absolute -left-16 -top-16 size-48 rounded-full bg-white/10 blur-2xl"
            />
            <div
              aria-hidden="true"
              className="bm-drift-slow pointer-events-none absolute -bottom-20 -right-10 size-56 rounded-full bg-emerald-300/25 blur-2xl"
            />

            <div className="relative">
              <h2
                id="cta-heading"
                className="text-3xl font-bold tracking-tight text-white sm:text-4xl"
              >
                Ready to measure your mind?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-emerald-50/95 sm:text-lg">
                Pick a free test, answer a few questions, and see your results
                in minutes.
              </p>

              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Button
                  asChild
                  size="lg"
                  className="h-12 w-full bg-white px-7 text-base font-semibold text-emerald-800 shadow-[0_8px_24px_rgba(2,60,45,0.45)] transition-[translate,box-shadow,background-color] duration-300 hover:-translate-y-0.5 hover:bg-emerald-50 hover:shadow-[0_10px_30px_rgba(2,60,45,0.6)] active:translate-y-0 sm:w-auto bm-shine bm-shine-emerald"
                >
                  <Link href="/test">Start Free IQ Test</Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="h-12 w-full border-white/60 bg-white/10 px-7 text-base text-white transition-[translate,background-color] duration-300 hover:-translate-y-0.5 hover:bg-white/20 hover:text-white active:translate-y-0 sm:w-auto"
                >
                  <a href="#all-tests">Explore All Tests</a>
                </Button>
              </div>

              <p className="mt-6 text-xs font-medium text-emerald-100/90">
                No sign-up · Instant results · Free forever
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
