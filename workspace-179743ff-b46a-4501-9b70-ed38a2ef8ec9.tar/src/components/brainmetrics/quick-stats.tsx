import { BookOpen, LayoutGrid, ShieldCheck, Zap } from "lucide-react";
import { TOOLS } from "@/config/tools";
import { CountUp, Pop, Reveal } from "./motion";

export function QuickStats() {
  return (
    <section
      aria-label="Why BrainMetrics"
      className="bg-background py-16 sm:py-20"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal scale>
          <div className="rounded-3xl border border-border bg-muted px-6 py-8 sm:px-10">
            <ul className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <li className="group flex items-center gap-3.5 transition-transform duration-300 hover:-translate-y-0.5">
                <Pop delay={0}>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[transform,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                    <LayoutGrid className="size-5" aria-hidden="true" />
                  </span>
                </Pop>
                <p className="text-sm font-semibold text-foreground">
                  <span className="block text-2xl font-extrabold tracking-tight">
                    <CountUp to={TOOLS.length} />
                  </span>
                  Cognitive tests available
                </p>
              </li>
              <li className="group flex items-center gap-3.5 transition-transform duration-300 hover:-translate-y-0.5">
                <Pop delay={0.08}>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[transform,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                    <BookOpen className="size-5" aria-hidden="true" />
                  </span>
                </Pop>
                <p className="text-sm font-semibold text-foreground">
                  Established frameworks
                  <span className="mt-0.5 block text-xs font-normal text-muted-foreground">
                    Based on established cognitive testing methods
                  </span>
                </p>
              </li>
              <li className="group flex items-center gap-3.5 transition-transform duration-300 hover:-translate-y-0.5">
                <Pop delay={0.16}>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[transform,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                    <Zap className="size-5" aria-hidden="true" />
                  </span>
                </Pop>
                <p className="text-sm font-semibold text-foreground">
                  Instant free results
                  <span className="mt-0.5 block text-xs font-normal text-muted-foreground">
                    See your score the moment you finish
                  </span>
                </p>
              </li>
              <li className="group flex items-center gap-3.5 transition-transform duration-300 hover:-translate-y-0.5">
                <Pop delay={0.24}>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[transform,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                    <ShieldCheck className="size-5" aria-hidden="true" />
                  </span>
                </Pop>
                <p className="text-sm font-semibold text-foreground">
                  No signup required
                  <span className="mt-0.5 block text-xs font-normal text-muted-foreground">
                    Start any test without an account
                  </span>
                </p>
              </li>
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
