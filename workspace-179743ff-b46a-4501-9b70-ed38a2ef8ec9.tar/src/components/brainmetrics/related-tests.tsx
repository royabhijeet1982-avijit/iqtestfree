import Link from "next/link";
import { ArrowRight, Clock } from "lucide-react";
import { TOOLS } from "@/config/tools";

/**
 * Slugs of tool pages that are LIVE right now (route exists, verified).
 * Every rebuilt page must be added here ONLY after its gates pass, so
 * RelatedTests never renders a link that 404s.
 */
export const LIVE_TOOL_IDS = [
  "matrix-reasoning",
  "digit-span",
  "reaction-time",
  "visual-memory",
  "processing-speed",
  "stroop-test",
  "mental-rotation",
  "chimp-test",
  "n-back",
  "full-iq",
  "working-memory",
  "sequence-memory",
  "word-memory",
  "pattern-memory",
  "spatial-memory",
  "short-term-memory",
  "sustained-attention",
] as const;

/**
 * "Related tests" band rendered at the bottom of every tool page.
 * Shows up to 4 OTHER live tests (never the current one), keeping the
 * internal link mesh closed - every link on a live page is live.
 */
export function RelatedTests({ currentId }: { currentId: string }) {
  const others = TOOLS.filter(
    (tool) =>
      (LIVE_TOOL_IDS as readonly string[]).includes(tool.id) &&
      tool.id !== currentId
  ).slice(0, 4);

  if (others.length === 0) return null;

  return (
    <section aria-labelledby="related-tests-heading" className="mt-14">
      <h2
        id="related-tests-heading"
        className="text-xl font-bold tracking-tight text-foreground sm:text-2xl"
      >
        Try another test
      </h2>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Different cognitive skills, same instant scoring - all free.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {others.map((tool) => {
          const Icon = tool.icon;
          return (
            <Link
              key={tool.id}
              href={tool.href}
              className="group relative flex flex-col rounded-2xl border border-border bg-card p-5 transition-[translate,box-shadow,border-color] duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-[0_12px_32px_rgba(4,120,87,0.14)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-[scale,rotate] duration-300 group-hover:scale-110 group-hover:-rotate-6">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <span className="mt-1 inline-flex items-center gap-1 rounded-full border border-border bg-secondary px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                  <Clock className="size-3" aria-hidden="true" />
                  {tool.minutes} min
                </span>
              </div>
              <h3 className="mt-3.5 text-sm font-semibold text-foreground transition-colors duration-200 group-hover:text-primary sm:text-base">
                {tool.name}
              </h3>
              <p className="mt-1.5 flex-1 text-xs leading-relaxed text-muted-foreground sm:text-sm">
                {tool.description}
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                Start Test
                <ArrowRight
                  className="size-4 transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
