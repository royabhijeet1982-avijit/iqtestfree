import { POPULAR_TOOLS } from "@/config/tools";
import { Reveal } from "./motion";
import { ToolCard } from "./tool-card";

export function PopularTools() {
  return (
    <section
      id="popular-tests"
      aria-labelledby="popular-tests-heading"
      className="scroll-mt-20 bg-background py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">
              Most used
            </p>
            <h2
              id="popular-tests-heading"
              className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            >
              Popular Cognitive Tests
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Choose a quick challenge or start with the comprehensive Full IQ
              Test - every tool below is free.
            </p>
          </div>
        </Reveal>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-6 md:grid-cols-3 xl:grid-cols-4">
          {POPULAR_TOOLS.map((tool, index) => (
            <Reveal key={tool.id} delay={index * 0.05} className="h-full">
              <ToolCard tool={tool} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
