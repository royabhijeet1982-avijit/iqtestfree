"use client";

import Link from "next/link";
import {
  ArrowRight,
  Award,
  FileText,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { CountUp, Float, Reveal } from "./motion";

/* Bell-curve geometry: scores 55-145 map to x 40-520 on a 560x250 canvas. */
const BASELINE = 205;
const PEAK = 160;
const MEAN_X = 280;
const SIGMA = 72;
const MARKER_X = 40 + ((118 - 55) / 90) * 480; // score 118

const curveY = (x: number) =>
  BASELINE - PEAK * Math.exp(-((x - MEAN_X) ** 2) / (2 * SIGMA * SIGMA));

const toPath = (points: number[]) =>
  points
    .map(
      (x, i) =>
        `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${curveY(x).toFixed(1)}`
    )
    .join(" ");

const ALL_POINTS = Array.from({ length: 61 }, (_, i) => 40 + i * 8); // 40..520
const mainPath = toPath(ALL_POINTS);

const fillPoints = ALL_POINTS.filter((x) => x <= MARKER_X); // up to score 118
const fillPath = `${toPath(fillPoints)} L ${MARKER_X.toFixed(
  1
)} ${BASELINE} L 40 ${BASELINE} Z`;

const tailPoints = [
  MARKER_X,
  ...Array.from({ length: 18 }, (_, i) => 384 + i * 8), // 384..520
];
const tailPath = `${toPath(tailPoints)} L 520 ${BASELINE} L ${MARKER_X.toFixed(
  1
)} ${BASELINE} Z`;

const MARKER_Y = curveY(MARKER_X);
const MEAN_Y = curveY(MEAN_X);

const AXIS_TICKS = [70, 85, 100, 115, 130];

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-background">
      <div
        aria-hidden="true"
        className="bm-drift pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-emerald-500/10 blur-2xl"
      />
      <div
        aria-hidden="true"
        className="bm-drift-slow pointer-events-none absolute -bottom-32 -left-20 size-64 rounded-full bg-emerald-500/10 blur-2xl"
      />

      <div className="relative mx-auto grid w-full max-w-7xl gap-14 px-4 pb-16 pt-10 sm:px-6 sm:pb-20 sm:pt-14 lg:grid-cols-2 lg:items-center lg:gap-12 lg:pb-28 lg:pt-20 lg:px-8">
        <div className="text-center lg:text-left">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-700/20 bg-emerald-600/10 px-3.5 py-1.5 text-xs font-semibold text-emerald-800">
              <Sparkles className="size-3.5" aria-hidden="true" />
              Explore Your Cognitive Skills
            </span>
          </Reveal>

          <Reveal delay={0.08}>
            <h1 className="mt-6 text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Free Online IQ Test{" "}
              <span className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                &amp; Cognitive Tests
              </span>
            </h1>
          </Reveal>

          <Reveal delay={0.16}>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground lg:mx-0">
              Explore your reasoning, memory, attention, processing speed and
              spatial thinking with a collection of interactive cognitive
              tests. Start with the Full IQ Test or pick a skill you want to
              measure.
            </p>
          </Reveal>

          <Reveal delay={0.24}>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start">
              <Button
                asChild
                size="lg"
                className="h-12 w-full px-7 text-base shadow-[0_8px_24px_rgba(4,120,87,0.35)] transition-all hover:shadow-[0_10px_30px_rgba(4,120,87,0.45)] hover:-translate-y-0.5 active:translate-y-0 sm:w-auto bm-shine"
              >
                <Link href="/test">
                  Start Free IQ Test
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 w-full border-border bg-card px-7 text-base shadow-sm transition-[translate,box-shadow,border-color] duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md active:translate-y-0 sm:w-auto"
              >
                <a href="#all-tests">Explore All Tests</a>
              </Button>
            </div>
          </Reveal>

          <Reveal delay={0.32}>
            <p className="mt-5 text-sm font-medium text-muted-foreground">
              Instant results · No signup · Free
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.2} y={32} scale>
          <div className="relative lg:pl-6">
            <div className="relative rounded-2xl border border-border bg-card p-6 shadow-[0_24px_60px_-20px_rgba(10,12,11,0.2)] transition-transform duration-300 hover:-translate-y-1 sm:p-8">
              <div className="flex items-center justify-between gap-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Full IQ Test preview
                </p>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-600/20 bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
                  <span
                    className="size-1.5 rounded-full bg-emerald-500 bm-pulse-dot"
                    aria-hidden="true"
                  />
                  Instant result
                </span>
              </div>

              <div className="mt-5 flex flex-wrap items-end gap-x-5 gap-y-2">
                <p className="text-6xl font-extrabold leading-none tracking-tight text-foreground">
                  <CountUp to={118} />
                </p>
                <div className="pb-1">
                  <p className="flex items-center gap-1.5 text-base font-semibold text-foreground">
                    <TrendingUp
                      className="size-4 text-emerald-600"
                      aria-hidden="true"
                    />
                    Higher than 88% of people
                  </p>
                  <p className="mt-0.5 text-sm text-muted-foreground">
                    Scale average: 100
                  </p>
                </div>
              </div>

              <svg
                viewBox="0 0 560 250"
                className="mt-6 h-auto w-full"
                aria-hidden="true"
                focusable="false"
              >
                <defs>
                  <linearGradient
                    id="bmScoreFill"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop offset="0%" stopColor="#34d399" stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#047857" stopOpacity="0.9" />
                  </linearGradient>
                </defs>

                <motion.path
                  d={tailPath}
                  fill="#cbd5e1"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 0.8 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7, delay: 1.05 }}
                />
                <motion.path
                  d={fillPath}
                  fill="url(#bmScoreFill)"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 1.25 }}
                />
                <motion.path
                  d={mainPath}
                  fill="none"
                  stroke="#047857"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5, delay: 0.35, ease: "easeInOut" }}
                />

                <motion.line
                  x1={MEAN_X}
                  y1={BASELINE}
                  x2={MEAN_X}
                  y2={MEAN_Y}
                  stroke="#94a3b8"
                  strokeWidth="1.5"
                  strokeDasharray="4 5"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.25 }}
                />
                <motion.g
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 1.55 }}
                >
                  <line
                    x1={MARKER_X}
                    y1={BASELINE}
                    x2={MARKER_X}
                    y2={MARKER_Y}
                    stroke="#047857"
                    strokeWidth="2.5"
                  />
                  <circle
                    className="bm-ping"
                    cx={MARKER_X}
                    cy={MARKER_Y}
                    r="6"
                    fill="#047857"
                  />
                  <circle
                    cx={MARKER_X}
                    cy={MARKER_Y}
                    r="6"
                    fill="#047857"
                    stroke="#ffffff"
                    strokeWidth="2.5"
                  />
                  <text
                    x={MARKER_X}
                    y={MARKER_Y - 16}
                    textAnchor="middle"
                    fontSize="20"
                    fontWeight="700"
                    fill="#047857"
                    fontFamily="inherit"
                  >
                    118
                  </text>
                </motion.g>

                <motion.line
                  x1="30"
                  y1={BASELINE}
                  x2="530"
                  y2={BASELINE}
                  stroke="#cbd5e1"
                  strokeWidth="1.5"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7, delay: 0.15 }}
                />
                {AXIS_TICKS.map((score) => {
                  const x = 40 + ((score - 55) / 90) * 480;
                  return (
                    <text
                      key={score}
                      x={x}
                      y="230"
                      textAnchor="middle"
                      fontSize="14"
                      fill="#4d5c55"
                      fontFamily="inherit"
                    >
                      {score}
                    </text>
                  );
                })}
                <text
                  x="530"
                  y="248"
                  textAnchor="end"
                  fontSize="13"
                  fill="#94a3b8"
                  fontFamily="inherit"
                >
                  IQ score
                </text>
              </svg>
            </div>

            <Float className="absolute -top-5 right-4 hidden sm:block">
              <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2.5 shadow-[0_8px_30px_rgba(10,12,11,0.12)]">
                <Award
                  className="size-4 text-emerald-600"
                  aria-hidden="true"
                />
                <span className="text-xs font-semibold text-foreground">
                  Certificate with unique ID
                </span>
              </div>
            </Float>
            <Float
              delay={0.9}
              className="absolute -bottom-5 left-4 hidden sm:block"
            >
              <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2.5 shadow-[0_8px_30px_rgba(10,12,11,0.12)]">
                <FileText className="size-4 text-emerald-700" aria-hidden="true" />
                <span className="text-xs font-semibold text-foreground">
                  Per-question explanations
                </span>
              </div>
            </Float>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
