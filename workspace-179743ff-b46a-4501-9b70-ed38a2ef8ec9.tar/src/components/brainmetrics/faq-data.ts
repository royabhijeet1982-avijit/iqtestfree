export type FaqItem = {
  question: string;
  answer: string;
};

/**
 * Single source of truth for FAQ content.
 * Imported by both the FAQ accordion (visible copy) and the FAQPage
 * JSON-LD schema so they can never drift apart.
 */
export const FAQ_ITEMS: FaqItem[] = [
  {
    question: "Is the Full IQ Test free?",
    answer:
      "Yes. Every test on BrainMetrics, including the Full IQ Test, is completely free to take. You can explore the whole library of cognitive tests - memory, attention, speed, reasoning and more - without paying anything or entering card details.",
  },
  {
    question: "Do I need to create an account?",
    answer:
      "No. There is no sign-up or login. Open a test, complete it, and see your results straight away. You never need to hand over an email address just to take a test and view your score.",
  },
  {
    question: "How long does the Full IQ Test take?",
    answer:
      "The Full IQ Test takes around 25 minutes because it covers several skill areas in one sitting. Individual cognitive tests are much shorter - most take between 2 and 12 minutes, so they fit easily into a quick break.",
  },
  {
    question: "What do the cognitive tests measure?",
    answer:
      "Each test targets a specific skill - memory, attention, processing speed, reasoning or spatial thinking. Together they give a rounded picture of how you think. Results are intended for education and self-exploration; they are not a substitute for a standardized, professionally administered assessment.",
  },
];
