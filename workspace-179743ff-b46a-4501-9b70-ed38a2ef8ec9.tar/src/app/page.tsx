import { Navbar } from "@/components/brainmetrics/navbar";
import { Hero } from "@/components/brainmetrics/hero";
import { PopularTools } from "@/components/brainmetrics/popular-tools";
import { AllTools } from "@/components/brainmetrics/all-tools";
import { QuickStats } from "@/components/brainmetrics/quick-stats";
import { LearnSection } from "@/components/brainmetrics/learn-section";
import { Faq } from "@/components/brainmetrics/faq";
import { FinalCta } from "@/components/brainmetrics/final-cta";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { FAQ_ITEMS } from "@/components/brainmetrics/faq-data";
import { MotionConfig } from "framer-motion";

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQ_ITEMS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

export default function HomePage() {
  return (
    <MotionConfig reducedMotion="user">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        <Hero />
        <PopularTools />
        <AllTools />
        <QuickStats />
        <LearnSection />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </MotionConfig>
  );
}
