import { NextResponse } from "next/server";

// force-static keeps this placeholder route compatible with
// `BUILD_STATIC=1 next build` (output: "export") — no server needed.
export const dynamic = "force-static";

export async function GET() {
  return NextResponse.json({ message: "Hello, world!" });
}