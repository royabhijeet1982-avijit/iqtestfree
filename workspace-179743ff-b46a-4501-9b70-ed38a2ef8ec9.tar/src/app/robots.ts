import type { MetadataRoute } from "next";

// force-static keeps robots.txt compatible with `BUILD_STATIC=1` static export
export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
    },
    sitemap: "https://brainmetrics.app/sitemap.xml",
  };
}
