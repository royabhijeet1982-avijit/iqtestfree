import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { ShortTermMemoryTest } from "@/components/test/short-term-memory";
import { STM_FAQS } from "@/components/test/short-term-memory-faq-data";
import { Brain, Hash, ShieldCheck, Sparkles, Target, Timer, TrendingUp } from "lucide-react";

const PAGE_TITLE = "Free Short-Term Memory Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free short-term memory test based on the classic Brown-Peterson task. Memorise a trigram, count backwards to block rehearsal, then recall - instant index, no sign-up.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "short term memory test",
    "brown peterson test",
    "trigram recall test",
    "memory span test online",
    "filled delay recall",
    "free memory test",
    "working memory test",
    "STM test online",
    "cognitive test",
    "counting backwards memory",
  ],
  alternates: { canonical: "/test/short-term-memory" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/short-term-memory",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Short-Term Memory Test",
  alternateName: "Brown-Peterson Filled-Delay Recall Test",
  url: "https://brainmetrics.app/test/short-term-memory",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Short-Term Memory Test",
      item: "https://brainmetrics.app/test/short-term-memory",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: STM_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Timer,
    title: "Rehearsal, blocked",
    body: "The counting-backwards task is not a distraction - it is the instrument. By occupying your inner voice with arithmetic, it prevents the silent repetition that usually rescues memories, so what you recall at the end is what your short-term buffer genuinely kept on its own.",
  },
  {
    icon: TrendingUp,
    title: "Time as the variable",
    body: "Span tests grow the LOAD until you fail; this test holds the load at three letters and grows the TIME instead. Nine trials cycle through 3, 9 and 15 second filled delays, tracing your personal forgetting curve - the same shape Peterson and Peterson first plotted in 1959.",
  },
  {
    icon: Hash,
    title: "Order is the score",
    body: "A recalled letter earns a point only in its original position: C-H-J answered as J-H-C gets one, not three. Position-wise scoring is what makes the measure sensitive to the true structure of the buffer rather than to a bag of remembered letters.",
  },
];

const STEPS = [
  {
    title: "Catch the trigram",
    body: "Three consonants flash for under a second - the timing is engine-owned and identical for everyone. Read them once; there is no time to repeat them anyway.",
  },
  {
    title: "Count backwards by 3",
    body: "A number appears - type each step down: 147, 144, 141... The bar empties at the trial's delay (3, 9 or 15 seconds) and cannot be paused. Typing keeps the interference honest; it is never scored.",
  },
  {
    title: "Type the letters back",
    body: "Recall opens the moment the bar empties. Type the three letters in their original order - a blank counts as a miss. Nine trials later your index and personal decay curve arrive.",
  },
];

const TIPS = [
  "During the flash, encode the letters as a pronounceable chunk - CHJ becomes \"chij\" - one sound survives interference better than three separate letters.",
  "Keep the subtraction mechanical: look at the number, subtract 3, type, repeat. Every microsecond of deliberation is rehearsal time for the letters.",
  "Do not panic when the letters feel gone - type the fragments that remain. A single surviving letter is a real point on the board.",
  "The 3-second trials are your bank: be flawless there. The 15-second trials are hard for everyone, so the short delays carry your index.",
];

/* ------------------------------ Page ------------------------------ */

export default function ShortTermMemoryPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Timer className="h-3.5 w-3.5" aria-hidden="true" />
                Short-term memory · filled delay · about 3 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Short-Term{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Memory Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                A trigram flashes. Counting backwards fills the delay so you
                cannot rehearse. Then the question is simple: what survived?
                A free, faithful build of the classic Brown-Peterson task.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh trigrams every run
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <ShortTermMemoryTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="stm-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="stm-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                In 1959, Peterson and Peterson showed that without rehearsal,
                short-term memories evaporate in seconds - a finding that
                reshaped how psychology thinks about memory. This test
                rebuilds their experiment in your browser and measures your
                own forgetting curve.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="stm-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="stm-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Brain className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="stm-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="stm-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Short-Term Memory Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {STM_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`stm-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="short-term-memory" />
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Short-term retention is one piece of the puzzle. The Full IQ
                Test adds reasoning, spatial, numeric and processing-speed
                domains for a complete picture of your cognitive profile.
              </p>
              <a
                href="/test"
                data-testid="stm-cta-full-iq-page"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
