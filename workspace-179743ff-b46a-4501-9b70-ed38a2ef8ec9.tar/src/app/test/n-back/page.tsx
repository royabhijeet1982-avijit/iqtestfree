import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { NBackTestFromQuery } from "@/components/test/n-back";
import { NBACK_FAQ_ITEMS } from "@/components/test/n-back-faq-data";
import { BarChart3, Brain, Filter, History, Keyboard, ShieldCheck, Target } from "lucide-react";

const PAGE_TITLE = "Free N-Back Working Memory Test | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free N-Back working memory test. Track letters across rising N levels in the classic updating task and get an instant working-memory index and percentile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "n-back test",
    "working memory test",
    "n back test online",
    "free n-back test",
    "working memory span test",
    "cognitive updating task",
    "dual n-back training",
    "Jaeggi n-back study",
    "brain training working memory",
    "working memory IQ test",
  ],
  alternates: { canonical: "/test/n-back" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/n-back",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "N-Back Test",
  alternateName: "Working Memory N-Back Task",
  url: "https://brainmetrics.app/test/n-back",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "N-Back Test",
      item: "https://brainmetrics.app/test/n-back",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: NBACK_FAQ_ITEMS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Brain,
    title: "Working-memory updating",
    body: "Every letter forces the same operation: read the new item, overwrite the oldest slot in your rolling window, keep the rest intact. That continuous read-overwrite loop is the updating function at the core of working memory.",
  },
  {
    icon: Filter,
    title: "Interference control",
    body: "Blocks deliberately contain lures - letters that match the one N-1 back but not N back. Resisting a near-match takes the same inhibitory machinery you use to stop a wrong, habitual response.",
  },
  {
    icon: BarChart3,
    title: "Capacity & span",
    body: "Because N climbs from 1 to 5, the test finds the widest window you can actually hold - your effective span - which is why N-back scores map so cleanly onto broader cognitive ability.",
  },
];

const STEPS = [
  {
    title: "Watch the stream",
    body: "Letters appear one at a time on a steady rhythm - visible for about a second and a half, then a short gap. The display sets the pace; you cannot slow it down or skip ahead.",
  },
  {
    title: "Press on a repeat",
    body: "Whenever the current letter matches the one exactly N steps back, hit SPACE or A - or tap MATCH on a touch screen. The first N letters of each block are warm-up, and one response per letter counts.",
  },
  {
    title: "Climb from N = 1 to 5",
    body: "Five blocks raise the lag block by block. A block clears at 70% balanced accuracy - hits and correct rejections count equally - and your span is the highest N you cleared.",
  },
];

const TIPS = [
  "Chunk by letter and position: group the stream into pairs or triplets instead of holding loose letters - chunking is the strongest known span strategy.",
  "Lock into the rhythm. Rehearse the rolling window with each new letter (\"C, H, C…\") so updating becomes automatic rather than effortful.",
  "Beware lures: a letter matching N-1 back but not N back is a deliberate trap. Always count from the current letter, never from the previous one.",
  "Never respond to everything - mashing catches every target but buries the score in false alarms. Balanced scoring punishes both extremes, so stay selective.",
];

/* ------------------------------ Page ------------------------------ */

export default function NBackPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <History className="h-3.5 w-3.5" aria-hidden="true" />
                Working Memory · N = 1 → 5
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                N-Back{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                How wide is your mental window? The classic N-back task makes you
                track a stream of letters and fire only when one repeats from N
                steps back - the gold-standard measure of working-memory updating.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh sequences every run
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <NBackTestFromQuery />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="nb-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="nb-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Since Kirchner introduced it in 1958, N-back has become the most
                widely used working-memory task in cognitive neuroscience - it is
                simple to explain, impossible to shortcut, and exquisitely
                sensitive to how well you update information in mind.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="nb-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="nb-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for a higher span
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="nb-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="nb-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                N-Back Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {NBACK_FAQ_ITEMS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`nb-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Working memory is one pillar of cognition. The Full IQ Test adds
                reasoning, verbal, numeric and spatial domains for a complete
                picture.
              </p>
              <a
                href="/test"
                data-testid="nb-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <div className="mx-auto w-full max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="n-back" />
        </div>
      </main>
      <Footer />
    </div>
  );
}
