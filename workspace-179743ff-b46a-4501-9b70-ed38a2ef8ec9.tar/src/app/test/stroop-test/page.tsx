import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { StroopTest } from "@/components/test/stroop-test";
import { STROOP_FAQS } from "@/components/test/stroop-test-faq-data";
import { Brain, Eye, Keyboard, Palette, ShieldCheck, Target, Zap } from "lucide-react";

const PAGE_TITLE = "Free Stroop Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free Stroop test online. Name the ink colour while the word interferes and get your Stroop interference score, accuracy and an IQ-anchored index instantly.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "stroop test",
    "stroop effect",
    "stroop color word test",
    "free stroop test",
    "color word interference test",
    "stroop effect test online",
    "selective attention test",
    "cognitive inhibition test",
    "stroop experiment online",
    "attention and inhibition test",
  ],
  alternates: { canonical: "/test/stroop-test" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/stroop-test",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Stroop Test",
  alternateName: "Stroop Color-Word Interference Test",
  url: "https://brainmetrics.app/test/stroop-test",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Stroop Test",
      item: "https://brainmetrics.app/test/stroop-test",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: STROOP_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Eye,
    title: "Selective attention",
    body: "Each word demands that you lock onto one visual dimension - the ink - while a louder, more practiced dimension screams something else. How quickly you find the ink and stay locked on it is the attention component of your score.",
  },
  {
    icon: Brain,
    title: "Cognitive inhibition",
    body: "Reading fires automatically, so on incongruent trials the wrong answer is already active before you choose. Suppressing that habit is executive control at work, and the time it costs - your Stroop interference - is the classic lab measure of inhibitory strength.",
  },
  {
    icon: Zap,
    title: "Response speed",
    body: "Interference alone does not tell the whole story: a cautious player can shrink their gap by answering slowly everywhere. The index therefore blends your overall median reaction time with your interference effect, so both fast and controlled performance count.",
  },
];

const STEPS = [
  {
    title: "Watch the word appear",
    body: "A colour word - RED, GREEN, BLUE or YELLOW - is printed in an ink that matches it half the time and clashes the other half. Words and inks are randomised on every trial and every attempt.",
  },
  {
    title: "Answer the ink colour",
    body: "Tap one of the four colour buttons, or press R, G, B and Y on the keyboard for maximum speed. Every response is timed to the millisecond from the moment the word appears.",
  },
  {
    title: "Get your index instantly",
    body: "After 60 trials you receive your Stroop Index, percentile, accuracy, congruent and incongruent median reaction times, and your interference in milliseconds - no sign-up required.",
  },
];

const TIPS = [
  "Decide before each word appears that you will look at the colour, never read the word.",
  "On desktop, rest four fingers over R, G, B and Y so each colour has a dedicated key.",
  "Aim for accuracy on the first few trials; speed settles once the mapping feels automatic.",
  "Sit somewhere quiet - a single interruption inflates your interference more than a slow phone.",
];

/* ------------------------------ Page ------------------------------ */

export default function StroopTestPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Palette className="h-3.5 w-3.5" aria-hidden="true" />
                Attention &amp; Inhibition · 60 trials
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Stroop{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                The word says one colour, the ink says another. This free Stroop
                test measures how fast - and how cleanly - your brain suppresses
                the automatic urge to read, the same color-word interference
                task psychologists have used since 1935.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · words randomised every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <StroopTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="st-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="st-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What the Stroop effect reveals
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                For literate adults, reading is not a choice - it is an automatic
                reflex. The Stroop task weaponises that reflex: it makes the
                word the enemy of the answer and measures, millisecond by
                millisecond, how much effort your brain spends winning the
                fight. Nearly a century of research has used this single
                paradigm to study attention, executive control, development and
                aging, because the effect is large, reliable and remarkably
                difficult to fake.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="st-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="st-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                One rule, sixty trials, zero trick questions: respond to the ink
                and ignore the word. Half of the words agree with their ink, so
                your congruent pace sets the baseline; the other half clash, and
                the extra time they cost is your personal Stroop interference.
              </p>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="st-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="st-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Stroop Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {STROOP_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`st-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Inhibition is one piece of the puzzle. The Full IQ Test adds
                reasoning, verbal, numeric and spatial domains for a complete
                picture of how you think.
              </p>
              <a
                href="/test"
                data-testid="st-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
          <RelatedTests currentId="stroop-test" />
        </section>
      </main>
      <Footer />
    </div>
  );
}
