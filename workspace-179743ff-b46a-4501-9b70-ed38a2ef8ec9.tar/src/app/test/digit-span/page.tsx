import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { DigitSpanTest } from "@/components/test/digit-span";
import { DIGIT_SPAN_FAQS } from "@/components/test/digit-span-faq-data";
import { Brain, Ear, Hash, Keyboard, Layers, ShieldCheck, Target } from "lucide-react";

const PAGE_TITLE = "Free Digit Span Test - Number Memory | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free digit span test online. Recall forward and backward number sequences, find your working memory span and get an instant IQ-scale score with percentile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "digit span test",
    "number memory test",
    "working memory test",
    "forward digit span",
    "backward digit span",
    "memory span test",
    "short term memory test",
    "WAIS digit span",
    "cognitive memory test",
    "free digit span test",
  ],
  alternates: { canonical: "/test/digit-span" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/digit-span",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Digit Span Test",
  alternateName: "Number Memory Test",
  url: "https://brainmetrics.app/test/digit-span",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Digit Span Test",
      item: "https://brainmetrics.app/test/digit-span",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: DIGIT_SPAN_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Ear,
    title: "Phonological storage",
    body: "Forward recall leans on the phonological loop - the mind's scratchpad for sound-based information. Digits are held as an inner voice rehearsing itself, and within a couple of seconds that trace starts to fade. Your forward span is essentially how much you can keep alive in that loop before it decays.",
  },
  {
    icon: Brain,
    title: "Executive load",
    body: "Backward recall adds a second job: while the digits sit in storage, the central executive has to unpack the sequence and re-order it on the fly. That dual demand is why nearly everyone scores lower backward, and why clinicians treat the backward task as a truer working-memory measure than simple storage.",
  },
  {
    icon: Layers,
    title: "Capacity and chunking",
    body: "In 1956 George Miller put immediate memory at seven items plus or minus two. Modern research shrinks raw capacity to roughly three or four chunks - the open question is what counts as a chunk. Because every sequence here is randomised, grouping strategies still help, but nothing can be pre-memorised.",
  },
];

const STEPS = [
  {
    title: "Watch the digits",
    body: "Digits appear one at a time for about a second each, with a short gap between. Nobody can skim ahead - the display sets the pace, so your only job is to attend and encode while the sequence builds.",
  },
  {
    title: "Type them back",
    body: "After the last digit, the input stage opens with a 0-9 pad and keyboard support. Forward sequences go back in order; backward sequences go in reverse. Submitting is untimed, so accuracy beats speed.",
  },
  {
    title: "Climb the staircase",
    body: "Sequences grow one digit at a time, and one correct recall at a length is enough to advance. Two misses at the same level end the phase, and your span is the highest level you cleared.",
  },
];

const TIPS = [
  "Rehearse with an inner voice as each digit lands - a steady rhythm keeps the memory trace alive.",
  "Group digits into pairs or threes as they appear; chunking is the single most effective span strategy.",
  "In the backward phase, let the whole sequence finish before you start reversing - juggling both at once invites errors.",
  "On desktop, rest your fingers on the number row - hunting for keys mid-recall is where sequences die.",
];

/* ------------------------------ Page ------------------------------ */

export default function DigitSpanPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Hash className="h-3.5 w-3.5" aria-hidden="true" />
                Memory · forward + backward spans
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Digit{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Span Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                How many numbers can your brain hold at once? Find your forward and
                backward digit span - the classic working-memory measure used in the
                WAIS - and see your score on the same 100-point scale as an IQ test.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · new sequences every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <DigitSpanTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="ds-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="ds-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Digit span is one of the oldest measures in psychology - number-recall
                experiments date back to the 1880s, and the task sits inside the
                working-memory index of today&apos;s WAIS. Its endurance comes from how
                much a few flashing digits reveal. Every attempt in this test taps
                three distinct ingredients of memory capacity.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="ds-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="ds-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                The test runs the same staircase clinicians use, split into a forward
                and a backward phase. There is no clock to race and nothing to
                configure - you watch digits, you type digits, and the levels take
                care of themselves until your span runs out.
              </p>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for a longer span
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="ds-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="ds-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Digit Span Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {DIGIT_SPAN_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`ds-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Digit span measures the memory piece of cognition. The Full IQ Test
                adds reasoning, verbal, numeric and spatial domains for a complete
                picture of how you think.
              </p>
              <a
                href="/test"
                data-testid="ds-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <div className="mx-auto w-full max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="digit-span" />
        </div>
      </main>
      <Footer />
    </div>
  );
}
