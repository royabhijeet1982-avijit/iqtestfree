import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { WordMemoryTest } from "@/components/test/word-memory";
import { WORD_MEMORY_FAQS } from "@/components/test/word-memory-faq-data";
import { Brain, ShieldCheck, Sparkles, Target, TrendingUp, Type } from "lucide-react";

const PAGE_TITLE = "Free Word Memory Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free word memory test. Study a stream of words, then separate old from new - instant verbal memory index, d-prime science stat, no sign-up.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "word memory test",
    "verbal memory test",
    "word recognition test",
    "memory words test",
    "remember words test",
    "free memory test online",
    "short term memory test",
    "brain memory game",
    "vocabulary memory test",
    "cognitive test",
  ],
  alternates: { canonical: "/test/word-memory" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/word-memory",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Word Memory Test",
  alternateName: "Word Recognition Memory Test",
  url: "https://brainmetrics.app/test/word-memory",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Word Memory Test",
      item: "https://brainmetrics.app/test/word-memory",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: WORD_MEMORY_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Type,
    title: "Recognition, not recall",
    body: "Recall tests force you to rebuild material from nothing; recognition only asks whether a word feels old or new. That single judgement taps the familiarity signal your brain computes constantly - recognising a face across the street, a name at a party, a chorus on the radio - without the extra machinery of ordered reproduction.",
  },
  {
    icon: Sparkles,
    title: "Old words against new",
    body: "Every stream is balanced: exactly half the words were studied, half were never shown. The mixture is what makes the score honest - a confident guesser who claims every word catches all the targets but false-alarms on every new one, landing at exactly 50%. Only real memory separates old from new.",
  },
  {
    icon: TrendingUp,
    title: "A memory-pure index",
    body: "Response speed is not scored and there is no timer pressure - think as long as you like per word. Accuracy alone drives your verbal memory index, and the science-grade d-prime stat on your results card shows how cleanly your familiarity signal separates studied words from strangers.",
  },
];

const STEPS = [
  {
    title: "Study the stream",
    body: "Words appear one at a time in the centre card - about a second each, at a pace the engine fixes and nobody can slow down. Three rounds, with the lists growing from 8 to 12 to 16 words. Just read; nothing to type or click yet.",
  },
  {
    title: "Clear the slate",
    body: "A short countdown fills the gap between study and test - the same filled-delay trick memory researchers use to stop you rehearsing. What survives that pause is what your memory genuinely kept, not what you repeated under your breath.",
  },
  {
    title: "Judge every word",
    body: "A longer stream appears: studied words mixed with equally many new ones. Press \"I saw it\" (or key A) for old, \"It's new\" (or key L) for fresh. No time limit per word - but every false alarm costs exactly as much as a miss.",
  },
];

const TIPS = [
  "Turn words into pictures: \"anchor\" becomes an image of an anchor dropping. Visual encoding gives verbal memory a second copy to lean on.",
  "String early words into a quick story - narratives glue arbitrary words together far better than silent repetition.",
  "Use the confidence gradient: words that feel instantly familiar are safe \"I saw it\" calls; words that merely look plausible deserve \"It's new\".",
  "Do not rush. There is no per-word timer, so a beat of hesitation costs nothing - but a false alarm costs a full point.",
];

/* ------------------------------ Page ------------------------------ */

export default function WordMemoryPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Type className="h-3.5 w-3.5" aria-hidden="true" />
                Verbal memory · recognition · about 5 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Word{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Memory Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Watch words drift past one at a time. Then judge a longer
                stream - which did you actually see, and which are impostors?
                A free, modern take on the classic old/new recognition task
                with an honest, memory-pure score.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh words every run
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <WordMemoryTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="wm-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="wm-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Old/new word recognition has been a workhorse of memory
                research for over a century, because it isolates something
                recall tests cannot: the raw familiarity signal that tells
                you &ldquo;I have met this before&rdquo; - and how reliably you can
                trust it.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="wm-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="wm-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Brain className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="wm-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="wm-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Word Memory Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {WORD_MEMORY_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`wm-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="word-memory" />
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Word memory is one piece of the puzzle. The Full IQ Test adds
                reasoning, spatial, numeric and processing-speed domains for a
                complete picture of your cognitive profile.
              </p>
              <a
                href="/test"
                data-testid="wm-cta-full-iq-page"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
