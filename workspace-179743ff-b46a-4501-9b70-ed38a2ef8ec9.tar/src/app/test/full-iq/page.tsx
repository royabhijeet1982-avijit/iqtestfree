import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { FullIqTest } from "@/components/test/full-iq-test";
import { TEST_FAQ_ITEMS } from "@/components/test/test-faq-data";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import {
  Brain,
  Keyboard,
  ListChecks,
  ShieldCheck,
  Sparkles,
  Target,
  Timer,
  Users,
} from "lucide-react";

const PAGE_TITLE = "Free Full IQ Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free full IQ test online. 12 questions across logic, verbal, numerical, pattern, memory and spatial skills with an instant estimated IQ and breakdown.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "full iq test",
    "free iq test online",
    "iq test with instant results",
    "cognitive ability test",
    "logic and verbal reasoning test",
    "iq test for adults",
    "iq test for teens",
    "iq test for kids",
    "brain test online",
    "intelligence test free",
  ],
  alternates: { canonical: "/test/full-iq" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/full-iq",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Full IQ Test",
  alternateName: "Complete Cognitive Assessment",
  url: "https://brainmetrics.app/test/full-iq",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Full IQ Test",
      item: "https://brainmetrics.app/test/full-iq",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: TEST_FAQ_ITEMS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Brain,
    title: "Seven domains, one sitting",
    body: "Every 12-question set samples logical reasoning, verbal understanding, numerical thinking, pattern recognition, attention to detail, working memory and spatial thinking - so no single skill dominates your result.",
  },
  {
    icon: Users,
    title: "Built for your age group",
    body: "Pick Kids (7-12), Teens (13-17) or Adults (18+) and the test deals from a completely separate bank of hand-built question sets tuned to that stage - playful puzzles for kids, brainteasers for teens, classic IQ items for adults.",
  },
  {
    icon: ListChecks,
    title: "Instant domain breakdown",
    body: "Your results screen shows the estimated IQ alongside a per-domain breakdown, so you can see exactly where you are strongest and which areas are worth practising before you retake.",
  },
];

const STEPS = [
  {
    title: "Pick your age group",
    body: "One tap selects Kids, Teens or Adults. Each group has its own bank of 10 hand-built sets, and the test draws a fresh 12-question paper every attempt.",
  },
  {
    title: "Answer 12 questions",
    body: "No enforced clock - a timer only tracks your elapsed time. Most people finish in 5 to 10 minutes, thinking each logic, verbal, numeric, pattern, memory or spatial item through at their own pace.",
  },
  {
    title: "See your estimate instantly",
    body: "Correct answers map onto an IQ-style scale where 100 is the population average, with a percentile read and a breakdown by domain on the results screen.",
  },
];

const TIPS = [
  "Read every option before answering - several items hinge on a detail that rules out the obvious-looking choice.",
  "For the pattern and spatial items, describe what you see in words; naming the rule makes the odd-one-out pop.",
  "Do not rush the memory questions - a few extra seconds of rehearsal beats a fast, fuzzy guess.",
  "Take the test in one quiet sitting; interruptions cost more points here than on any timed sprint.",
];

/* ------------------------------ Page ------------------------------ */

export default function FullIqPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Brain className="h-3.5 w-3.5" aria-hidden="true" />
                Complete assessment · 5-10 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Full{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  IQ Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Reasoning, verbal, numerical, pattern, memory and spatial skills
                in one free 12-question assessment - with an instant estimated
                IQ, percentile read and per-domain breakdown.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · fresh questions every attempt · age-specific banks
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <FullIqTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------- */}
        <section aria-labelledby="fi-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="fi-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                A full-scale IQ-style assessment samples several cognitive
                domains rather than one. Here is how this short version keeps
                that breadth while staying quick enough to finish in a coffee
                break.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="fi-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="fi-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="fi-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="fi-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Full IQ Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {TEST_FAQ_ITEMS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`fi-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section aria-labelledby="fi-related-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2
              id="fi-related-heading"
              className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            >
              Train one skill at a time
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-center text-lg leading-relaxed text-muted-foreground">
              Your breakdown shows which domains pulled the average down. Each
              of these focused drills targets one of them in five minutes or
              less.
            </p>
            <div className="mt-10">
              <RelatedTests currentId="full-iq" />
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="pb-16 sm:pb-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious about a single ability?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                The Full IQ Test gives you the broad picture. The focused tests
                dig into one skill at a time - and they all take five minutes or
                less.
              </p>
              <a
                href="/#popular-tests"
                data-testid="fi-cta-all-tests"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Browse all cognitive tests
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
