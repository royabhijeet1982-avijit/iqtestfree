import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { SustainedAttentionTest } from "@/components/test/sustained-attention";
import { SA_FAQS } from "@/components/test/sustained-attention-faq-data";
import { Activity, Brain, ShieldCheck, Sparkles, Target, TrendingUp } from "lucide-react";

const PAGE_TITLE = "Free Sustained Attention Test Online (SART) | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free sustained attention test based on the classic SART. Respond to every digit, withhold on the rare 3, and see how your focus holds across four monotonous minutes - no sign-up.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "sustained attention test",
    "SART test online",
    "vigilance test",
    "attention span test",
    "free attention test",
    "focus test online",
    "sustained attention to response task",
    "concentration test",
    "cognitive test",
    "attention drift test",
  ],
  alternates: { canonical: "/test/sustained-attention" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/sustained-attention",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Sustained Attention Test",
  alternateName: "SART - Sustained Attention to Response Task",
  url: "https://brainmetrics.app/test/sustained-attention",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Sustained Attention Test",
      item: "https://brainmetrics.app/test/sustained-attention",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: SA_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Activity,
    title: "Monotony is the instrument",
    body: "Exciting tests measure excitement. This one is deliberately boring - digits, digits, and more digits - because sustained attention only reveals itself when nothing rescues it. The moment your mind wanders to lunch, the rare 3 slides past unopposed, and that slip is the data.",
  },
  {
    icon: TrendingUp,
    title: "A stream you cannot game",
    body: "Every run is exactly 180 digits built from twenty shuffles of 1-9, so the rare 3 appears precisely 20 times - never more, never less, never where you expect. Mashing every digit or zoning out entirely both floor the score; the composite rewards steady hands and a withheld thumb.",
  },
  {
    icon: Sparkles,
    title: "Rhythm, not just accuracy",
    body: "Your tapping rhythm is measured alongside your accuracy. The coefficient of variation of your response times captures the wobble that grows as vigilance fades - the block-by-block chips on your results show exactly where the drift began.",
  },
];

const STEPS = [
  {
    title: "Set the rhythm",
    body: "Digits 1-9 appear one at a time for a quarter second each, roughly a second apart. Press SPACE (or the big GO button) for every single one. Six blocks of thirty - the pace never changes.",
  },
  {
    title: "Withhold on the rare 3",
    body: "Exactly 20 of the 180 digits are 3s, scattered unpredictably. When one appears, do nothing: hands off, breath out, wait for the next digit. There is no feedback during the run - you will not be told how you are doing.",
  },
  {
    title: "Read your drift",
    body: "After six blocks your index arrives, built from slips, misses and rhythm consistency. The block-by-block chips show where attention held and where it started sliding - most people drift late, which is exactly what the test is designed to catch.",
  },
];

const TIPS = [
  "Lock a physical rhythm: tap on every digit onset like a metronome. A steady motor loop leaves less bandwidth for the mind to wander.",
  "Do not hunt for 3s - watching FOR the rare digit makes you press on it more, not less. Keep the respond-to-everything rhythm and let the 3 arrive unannounced.",
  "Use the block breaks to reset your posture and blink. Four minutes of staring dries eyes and loosens rhythm - a deliberate reset beats a heroic slog.",
  "If you feel a slip happen, do not chase it: the next digit is a fresh trial. Chasing errors is how one miss becomes five.",
];

/* ------------------------------ Page ------------------------------ */

export default function SustainedAttentionPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Activity className="h-3.5 w-3.5" aria-hidden="true" />
                Sustained attention · SART · about 4 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Sustained{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Attention Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Respond to every digit - except the rare 3. Four monotonous
                minutes, no feedback, nowhere to hide. A free, faithful
                build of the classic SART vigilance task.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh stream every run
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <SustainedAttentionTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="sa-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="sa-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                SART grew out of vigilance research on radar operators and
                long-haul drivers: attention that holds for a sprint fails
                predictably over a marathon. By making the task automatic
                and the target rare, it exposes the moment control shifts
                from active attention to autopilot - and what escapes then.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="sa-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="sa-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Brain className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="sa-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="sa-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Sustained Attention Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {SA_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`sa-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="sustained-attention" />
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Sustained attention is one piece of the puzzle. The Full IQ
                Test adds reasoning, spatial, numeric and processing-speed
                domains for a complete picture of your cognitive profile.
              </p>
              <a
                href="/test"
                data-testid="sa-cta-full-iq-page"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
