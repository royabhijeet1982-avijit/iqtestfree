import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { ReactionTimeTest } from "@/components/test/reaction-time";
import { REACTION_TIME_FAQS } from "@/components/test/reaction-time-faq-data";
import { Activity, MousePointerClick, ShieldCheck, Split, Target, Zap } from "lucide-react";

const PAGE_TITLE = "Free Reaction Time Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free reaction time test. Wait for green, tap fast, then take the four-choice round - instant RT index, percentile and population comparison.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "reaction time test",
    "free reaction time test",
    "simple reaction time",
    "choice reaction time test",
    "reflex test online",
    "reaction time average",
    "human benchmark reaction time",
    "cognitive speed test",
    "millisecond reaction time",
    "reaction time by age",
  ],
  alternates: { canonical: "/test/reaction-time" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/reaction-time",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Reaction Time Test",
  alternateName: "Simple & Choice Reaction Time Test",
  url: "https://brainmetrics.app/test/reaction-time",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Reaction Time Test",
      item: "https://brainmetrics.app/test/reaction-time",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: REACTION_TIME_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Zap,
    title: "Reflex speed",
    body: "The simple round isolates the pure sensorimotor loop: light hits your retina, the signal reaches your visual cortex, and your finger moves. Nothing but raw wiring speed stands between the green flash and your tap.",
  },
  {
    icon: Split,
    title: "Decision speed",
    body: "The choice round adds a decision on every trial: any of four quadrants can light up, and you must identify which one and select the matching response. The gap between your two medians is your personal decision cost.",
  },
  {
    icon: Activity,
    title: "Consistency",
    body: "Fast once is easy; fast every time is the real skill. The spread (standard deviation) of your simple-round times reveals how stable your attention is across the random waits - a steadiness that single lucky taps hide.",
  },
];

const STEPS = [
  {
    title: "Wait for green",
    body: "The stage turns red and stays red for a random 1.5 to 4.5 seconds. Do not tap on a rhythm - the timing is re-randomised every trial, so guessing the flash never works.",
  },
  {
    title: "Tap the lit quadrant",
    body: "Round two raises the stakes: four boxes, one flashes emerald, and you must hit the lit one. Tapping too early (under 150ms) or hitting the wrong box both cost you.",
  },
  {
    title: "Read your RT Index",
    body: "Medians, variability and accuracy combine into a single RT Index on the familiar 100-point scale, complete with percentile, population curve and an honesty check on validity.",
  },
];

const TIPS = [
  "Sit comfortably and rest your hand or finger so every tap starts from the same position - consistency beats raw effort.",
  "Keep your eyes on the centre of the stage; peripheral cues register a few milliseconds later.",
  "Never tap on a rhythm. The waits are random on purpose, and a guessed tap under 150ms is discarded as an anticipation.",
  "If your first run feels awkward, retake it - most people settle into the task by the second attempt and score their true speed.",
];

/* ------------------------------ Page ------------------------------ */

export default function ReactionTimePage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Zap className="h-3.5 w-3.5" aria-hidden="true" />
                Attention &amp; Speed · two rounds · about 2 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Reaction{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Time Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                How fast does your brain turn what it sees into action? This
                free two-round test measures it directly: first a classic
                red-to-green sprint for pure reflex speed, then a four-quadrant
                round where you must pick the right target under the same time
                pressure. Every response is timed to the millisecond, and you
                get your score the moment the last trial ends.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · waits randomised every trial
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <ReactionTimeTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="rt-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="rt-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Reaction time has been measured in laboratories since the
                nineteenth century, and it remains one of the most reproducible
                numbers in psychology. A single tap tells you little, but the
                pattern across fifteen carefully controlled trials tells you
                three distinct things about how your brain handles speed.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="rt-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="rt-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                The whole session takes about two minutes: five red-to-green
                trials, ten choice trials, and no timer breathing down your
                neck between cues. The randomised waits are the quiet hero here
                - they keep the measurement honest, because a brain that
                guesses the flash is not measuring anything at all.
              </p>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <MousePointerClick className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="rt-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="rt-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Reaction Time Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {REACTION_TIME_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`rt-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Reflexes are one piece of the puzzle. The Full IQ Test adds
                reasoning, verbal, numeric and spatial domains for a complete
                picture of how you think.
              </p>
              <a
                href="/test"
                data-testid="rt-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
          <RelatedTests currentId="reaction-time" />
        </section>
      </main>
      <Footer />
    </div>
  );
}
