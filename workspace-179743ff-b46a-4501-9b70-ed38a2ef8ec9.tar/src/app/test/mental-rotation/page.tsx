import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { MentalRotationTest } from "@/components/test/mental-rotation";
import { MENTAL_ROTATION_FAQS } from "@/components/test/mental-rotation-faq-data";
import { Brain, Gauge, Lightbulb, Rotate3d, ShieldCheck, Target } from "lucide-react";

const PAGE_TITLE = "Free Mental Rotation Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free mental rotation test online. Compare rotated 3D cube figures, spot the mirrored ones, and get an instant spatial score with percentile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "mental rotation test",
    "spatial ability test",
    "shepard metzler test",
    "3d rotation test",
    "mental rotation task online",
    "spatial reasoning test",
    "visualization ability test",
    "free mental rotation test",
    "cognitive ability test",
    "rotated figures test",
  ],
  alternates: { canonical: "/test/mental-rotation" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/mental-rotation",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Mental Rotation Test",
  alternateName: "Shepard-Metzler Figure Comparison Test",
  url: "https://brainmetrics.app/test/mental-rotation",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Mental Rotation Test",
      item: "https://brainmetrics.app/test/mental-rotation",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: MENTAL_ROTATION_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Brain,
    title: "Mental imagery",
    body: "Mental rotation asks you to hold a shape in your mind's eye and transform it without seeing it change. This generate-and-inspect loop is the foundation of spatial thought - the same machinery engineers use to picture a part from a blueprint, or a surgeon uses to plan around anatomy they cannot directly see.",
  },
  {
    icon: Gauge,
    title: "Rotation efficiency",
    body: "Your response times rise almost linearly with the angle between the two figures, so we regress time against angle to estimate your rotation cost in milliseconds per degree. It is the purest behavioural readout of how fast your brain spins objects - the exact signature Shepard and Metzler documented in 1971.",
  },
  {
    icon: Target,
    title: "Shape accuracy",
    body: "Rotating quickly means little if mirrors slip past you. Every item pits a true rotation against a handedness-flipped copy, so accuracy captures how carefully you encode the order of arms around each junction - the detail that separates genuine rotation from a pattern-match done too casually.",
  },
];

const STEPS = [
  {
    title: "Study both figures",
    body: "Figure A sits on the left, Figure B on the right, with the rotation angle shown between them. Anchor your eye on one arm of Figure A and trace where it leads.",
  },
  {
    title: "Rotate or reject",
    body: "Turn Figure A in your mind by the stated angle and compare it to Figure B. If every arm and joint lines up, answer Same figure. If the joints are flipped, it is a mirrored copy.",
  },
  {
    title: "Get your index instantly",
    body: "Accuracy and your personal milliseconds-per-degree combine into a Mental Rotation Index with percentile, median time, per-angle accuracy bars and honest pace checks.",
  },
];

const TIPS = [
  "Rotate one arm at a time - tracking a single joint is far easier than spinning the whole shape at once.",
  "Check joint handedness: a mirror flips the order of arms around every junction, even when all arm lengths match.",
  "On small angles (0 and 90 degrees) trust a quick glance; save your deliberate checking for 180 and 270 degrees.",
  "Answer with keys 1 and 2 on desktop so your eyes never leave the figures.",
];

/* ------------------------------ Page ------------------------------ */

export default function MentalRotationPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Rotate3d className="h-3.5 w-3.5" aria-hidden="true" />
                Spatial ability · 24 figure pairs
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Mental{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Rotation Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Can your brain spin 3D objects in place? Compare rotated cube
                figures, catch the mirrored impostors, and get a spatial score
                built on the classic Shepard-Metzler paradigm.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh figures every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <MentalRotationTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="mrot-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="mrot-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                In the classic 1971 experiments, people took roughly a second
                longer to compare figures turned a full 180 degrees than figures
                already aligned - as if an inner image were being cranked round
                at a fixed speed. Every second of this test taps that machinery.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
            <div className="mx-auto mt-10 max-w-3xl space-y-4 text-base leading-relaxed text-muted-foreground">
              <p>
                Mental rotation is one of the most replicated phenomena in
                cognitive psychology. The linear angle-time slope appears across
                ages, cultures and stimulus formats, which is why it remains a
                cornerstone measure of spatial ability alongside paper-folding
                and cube-comparison tasks. Spatial skill itself predicts
                achievement in mathematics, engineering, architecture, surgery
                and the natural sciences, and unlike many cognitive traits it
                responds visibly to practice - video games, model building and
                design work all leave measurable traces on rotation speed.
              </p>
              <p>
                Our version compresses the paradigm into a few minutes. Instead
                of hand-drawn 3D assemblies you compare procedurally generated
                arm-like figures rendered as cube cells, which keeps the
                rotation-versus-mirror logic intact while guaranteeing that no
                two sessions ever share the same figures.
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="mrot-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="mrot-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Lightbulb className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Rotate3d className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="mrot-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="mrot-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Mental Rotation Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {MENTAL_ROTATION_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`mrot-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Mental rotation is one pillar of spatial intelligence. The Full
                IQ Test adds reasoning, verbal, numeric and memory domains for a
                complete picture in a few minutes.
              </p>
              <a
                href="/test"
                data-testid="mrot-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pb-20 pt-4 sm:px-6 lg:px-8">
          <RelatedTests currentId="mental-rotation" />
        </section>
      </main>
      <Footer />
    </div>
  );
}
