import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { ProcessingSpeedTest } from "@/components/test/processing-speed";
import { PROCESSING_SPEED_FAQS } from "@/components/test/processing-speed-faq-data";
import { Gauge, Keyboard, ScanEye, ShieldCheck, Target, TrendingUp, Zap } from "lucide-react";

const PAGE_TITLE = "Free Processing Speed Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free 90-second processing speed test. Match symbols to digits in a classic coding sprint and get an instant PSI score, percentile and pace profile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "processing speed test",
    "symbol digit coding test",
    "cognitive speed test",
    "processing speed index",
    "free processing speed test",
    "mental speed test",
    "WAIS processing speed",
    "brain speed test",
    "reaction and processing speed",
    "attention and speed test",
  ],
  alternates: { canonical: "/test/processing-speed" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/processing-speed",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Processing Speed Test",
  alternateName: "Symbol-Digit Coding Test",
  url: "https://brainmetrics.app/test/processing-speed",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Processing Speed Test",
      item: "https://brainmetrics.app/test/processing-speed",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: PROCESSING_SPEED_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: ScanEye,
    title: "Visual scanning",
    body: "Your eyes jump between the symbol, the key and the digit pad dozens of times per minute. How efficiently they find what they need is the raw engine of processing speed.",
  },
  {
    icon: Zap,
    title: "Decision speed",
    body: "Once the symbol is found, your brain must retrieve the paired digit and commit to a response. This test captures that decide-and-act loop to the millisecond on every single trial.",
  },
  {
    icon: TrendingUp,
    title: "Sustained output",
    body: "A 90-second sprint is long enough for fatigue and drift to show. Your throughput profile across six 15-second slices reveals whether you warm up, cruise or fade.",
  },
];

const STEPS = [
  {
    title: "Study the key",
    body: "Six symbols, six digits, one mapping - visible the whole time. During the 3-second countdown, scan the pairs so your eyes know where to look.",
  },
  {
    title: "Sprint for 90 seconds",
    body: "Symbols appear one at a time. Tap the matching digit on the pad, or hit the number keys if you want maximum speed. The clock never stops.",
  },
  {
    title: "Get your index instantly",
    body: "Correct-per-minute becomes a Processing Speed Index with percentile, accuracy, average response time, best streak and a six-slice pace profile.",
  },
];

const TIPS = [
  "Keep your eyes on the key between responses - hunting for the symbol is where most time is lost.",
  "On desktop, rest your fingers on the number row and answer with keys instead of clicks.",
  "Aim for accuracy first for the first few items; speed follows once the mapping feels automatic.",
  "Sit somewhere quiet and undisturbed - a single interruption costs several items.",
];

/* ------------------------------ Page ------------------------------ */

export default function ProcessingSpeedPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Gauge className="h-3.5 w-3.5" aria-hidden="true" />
                Attention &amp; Speed · 90-second sprint
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Processing{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Speed Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                How fast does your brain turn what it sees into action? Find out
                with a classic symbol-digit coding sprint - the same task family
                clinicians use to measure the WAIS Processing Speed Index.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · key randomised every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <ProcessingSpeedTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="ps-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="ps-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Symbol-digit coding has been a staple of cognitive assessment
                since the early twentieth century. Every second of the sprint
                taps three distinct ingredients of mental speed.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="ps-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="ps-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Keyboard className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="ps-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="ps-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Processing Speed Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {PROCESSING_SPEED_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`ps-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Processing speed is one piece of the puzzle. The Full IQ Test
                adds reasoning, verbal, numeric and spatial domains for a
                complete picture.
              </p>
              <a
                href="/test"
                data-testid="ps-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
