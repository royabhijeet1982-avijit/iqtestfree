import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { WorkingMemoryTest } from "@/components/test/working-memory";
import { WORKING_MEMORY_FAQS } from "@/components/test/working-memory-faq-data";
import {
  ArrowDownUp,
  Brain,
  Focus,
  Keyboard,
  ShieldCheck,
} from "lucide-react";

const PAGE_TITLE = "Free Working Memory Test Online - Letter-Number Sequencing | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free working memory test online. Sort mixed letters and numbers from memory, find your letter-number span and get an instant IQ-scale score with percentile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "working memory test",
    "letter number sequencing",
    "working memory test online free",
    "cognitive test",
    "WM capacity test",
    "mental juggling test",
    "memory reorganization test",
    "WAIS working memory",
    "brain test",
    "free working memory test",
  ],
  alternates: { canonical: "/test/working-memory" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/working-memory",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Working Memory Test",
  alternateName: "Letter-Number Sequencing Test",
  url: "https://brainmetrics.app/test/working-memory",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Working Memory Test",
      item: "https://brainmetrics.app/test/working-memory",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: WORKING_MEMORY_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Brain,
    title: "The central executive",
    body: "Working memory is not a bigger bucket - it is a workbench. The central executive keeps the whole stream alive while running a second operation on it, and letter-number sequencing loads that system directly. Research on complex span tasks shows this dual demand is what predicts real-world reasoning better than simple storage ever does.",
  },
  {
    icon: ArrowDownUp,
    title: "Mental reorganisation",
    body: "Recalling the stream in display order would be storage. Recalling numbers ascending and letters alphabetical forces a genuine transformation: you must hold the set, split it into two streams and rebuild each in a new order. The gap between your display span and your sorted span is the executive's overhead - and it is what this test scores.",
  },
  {
    icon: Focus,
    title: "Attention control",
    body: "Every new element that flashes by threatens to overwrite the ones you are still holding. Keeping the growing set intact - while the display keeps moving - is an attention task as much as a memory one. That is why scores dip when you are tired or distracted, and why the staircase keeps pushing until the juggling act genuinely breaks.",
  },
];

const STEPS = [
  {
    title: "Watch the stream",
    body: "Digits and letters appear one at a time - like R 7 C 2 - with the display setting the pace. Nobody can skim ahead, so your only job is to encode each element as it lands while the sequence grows.",
  },
  {
    title: "Sort the numbers",
    body: "When the stream ends, the pads open. Type the digits you saw in ascending order - the number keys type straight into the numbers row, and empty slots show how many are still missing.",
  },
  {
    title: "Sort the letters",
    body: "Then type the letters in alphabetical order - letter keys jump straight to the letter pad. Submit both streams to score the level; one correct recall at a level advances you, two misses end the run.",
  },
];

const TIPS = [
  "Sort as you go: when a digit lands, park it in its ranked position in your head instead of memorising the display order.",
  "Chunk the letters into a pronounceable string - C-Q-R becomes 'cuh-quh-arr' and survives far longer than three separate items.",
  "Let the whole stream finish before you start rearranging; splitting attention between encoding and sorting is where sequences die.",
  "Numbers first, always - they are the easier stream, and banking them frees capacity for the letters.",
];

/* ------------------------------ Page ------------------------------ */

export default function WorkingMemoryPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <ArrowDownUp className="h-3.5 w-3.5" aria-hidden="true" />
                Memory · hold, split, re-sort
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Working{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Memory Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Mixed numbers and letters flash past - can your mind hold them all and
                hand them back reorganised? This letter-number sequencing test measures
                true working memory: storage plus the juggling act on top, scored on the
                same 100-point scale as an IQ test.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · new sequences every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <WorkingMemoryTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="wm-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="wm-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Letter-number sequencing comes from the clinical batteries - it is the
                working memory subtest of the WAIS - because it isolates the skill that
                simple recall tests miss: keeping information alive while actively
                transforming it. Three ingredients decide how far you get.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="wm-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="wm-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                There is no clock to race and nothing to configure. You watch a stream,
                you sort it two ways, and the levels take care of themselves - growing by
                one element until your juggling capacity runs out.
              </p>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Keyboard className="h-5 w-5" aria-hidden="true" />
                Tips for a longer span
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <ArrowDownUp className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="wm-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="wm-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Working Memory Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {WORKING_MEMORY_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`wm-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Working memory is one piece of cognition. The Full IQ Test adds
                reasoning, verbal, numeric and spatial domains for a complete picture of
                how you think.
              </p>
              <a
                href="/test"
                data-testid="wm-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <div className="mx-auto w-full max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="working-memory" />
        </div>
      </main>
      <Footer />
    </div>
  );
}
