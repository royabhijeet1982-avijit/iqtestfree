import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { MatrixReasoningTest } from "@/components/test/matrix-reasoning";
import { MATRIX_REASONING_FAQS } from "@/components/test/matrix-reasoning-faq-data";
import { Grid3x3, Layers, Lightbulb, Puzzle, Shapes, ShieldCheck, Sigma } from "lucide-react";

const PAGE_TITLE = "Free Matrix Reasoning Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free matrix reasoning test. Solve 20 Raven-style visual matrices and get an instant IQ-scale score, percentile and per-rule accuracy profile.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "matrix reasoning test",
    "ravens progressive matrices test",
    "fluid intelligence test",
    "abstract reasoning test",
    "visual puzzle iq test",
    "nonverbal reasoning test",
    "pattern completion test",
    "free iq test",
    "cognitive ability test",
    "iq test with instant results",
  ],
  alternates: { canonical: "/test/matrix-reasoning" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/matrix-reasoning",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Matrix Reasoning Test",
  alternateName: "Raven-Style Progressive Matrices Test",
  url: "https://brainmetrics.app/test/matrix-reasoning",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Matrix Reasoning Test",
      item: "https://brainmetrics.app/test/matrix-reasoning",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: MATRIX_REASONING_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: Puzzle,
    title: "Rule extraction",
    body: "Every matrix is generated from hidden rules - a count that grows, a shape that alternates, an element that rotates. Before you can pick an answer, your brain must discover which rules are in play, and that hypothesis-testing loop is the essence of inductive reasoning.",
  },
  {
    icon: Layers,
    title: "Working memory",
    body: "Solving a matrix means holding several attributes in mind at once: the quantity in this column, the shading in that row, the rotation steps between cells. Later items combine two independent rules, so your mental workspace has to juggle both dimensions without dropping either.",
  },
  {
    icon: Shapes,
    title: "Abstract deduction",
    body: "The distractors are deliberately built by tweaking a single feature of the correct tile, so pattern-matching alone will not save you. You must deduce what the missing cell must be, then find the option that satisfies every rule simultaneously - pure fluid reasoning with no learned knowledge required.",
  },
];

const STEPS = [
  {
    title: "Study the grid",
    body: "Each item shows a 3x3 grid of shapes - or a 2x2 warm-up early on - with the bottom-right cell missing. Scan the rows and columns for rules that connect the cells.",
  },
  {
    title: "Pick the missing tile",
    body: "Six options are offered and exactly one completes every pattern at once. There is no time limit, so think it through - only correct answers raise your score.",
  },
  {
    title: "Get your index instantly",
    body: "Your correct count maps onto an IQ-style scale with percentile, per-rule accuracy bars, median answer time and a rushed-session honesty check.",
  },
];

const TIPS = [
  "Check rows and columns separately - many items hide one rule across and another down.",
  "Eliminate options that break an obvious rule before comparing the survivors in detail.",
  "On quantity items, count first: the numbers usually form the simplest progression.",
  "Take your time. There is no clock, and a rushed median under 2 seconds flags your session.",
];

/* ------------------------------ Page ------------------------------ */

export default function MatrixReasoningPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <Grid3x3 className="h-3.5 w-3.5" aria-hidden="true" />
                Fluid reasoning · 20 visual puzzles · untimed
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Matrix{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Reasoning Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                How well does your mind find order in visual chaos? This free
                matrix reasoning test serves you twenty Raven-style progressive
                matrices, each hiding rules of quantity, shape, rotation,
                shading or combination. Infer the rules, pick the missing tile,
                and get an instant IQ-scale estimate with a full rule-by-rule
                breakdown of how you think.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh matrices every attempt
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <MatrixReasoningTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="mr-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="mr-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Progressive matrices have anchored intelligence research for
                nearly a century because they sample reasoning with almost no
                dependence on language, schooling or culture. Solving even one
                item engages three distinct mental systems, and the difficulty
                ramp across our twenty matrices stresses each of them in turn.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="mr-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="mr-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Lightbulb className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Grid3x3 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------ Fluid intelligence ------------------------ */}
        <section aria-labelledby="mr-science-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Background
              </p>
              <h2
                id="mr-science-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Matrix reasoning and fluid intelligence
              </h2>
            </div>
            <div className="mt-8 space-y-5 text-base leading-relaxed text-muted-foreground">
              <p>
                In 1938 John C. Raven published the Progressive Matrices, a test
                built from a simple observation: you do not need words to measure
                reasoning. Present a grid of figures governed by hidden rules,
                remove one piece, and ask the person to complete it from a set of
                options. Because the task relies on relationships rather than
                vocabulary or arithmetic, it travels across languages and
                education levels better than almost any other cognitive measure.
                It quickly became the textbook operationalisation of fluid
                intelligence - Cattell&apos;s Gf, the ability to solve novel
                problems independently of everything you have already been
                taught.
              </p>
              <p>
                The research behind Gf is striking. Fluid intelligence predicts
                how quickly people acquire new skills, how they perform in
                STEM fields, and how adaptably they respond to situations no
                manual has covered. Unlike crystallised abilities, which grow
                through schooling and remain stable into later adulthood, Gf is
                at its peak in young adulthood and is the first ability to feel
                the effects of fatigue, stress and distraction. That is exactly
                why standardised batteries such as the WAIS include a matrix
                reasoning subtest alongside vocabulary and arithmetic: the
                contrast between the two paints a far richer picture than either
                alone.
              </p>
              <p>
                Our generator builds every session from the same rule families
                used in classical item design - quantity and size progressions,
                shape alternation, rotation, shading logic and element
                superposition - starting with single-rule 2x2 warm-ups and
                finishing with matrices that combine two independent rules at
                once. The engine is procedural, which means the app can serve an
                effectively unlimited supply of fresh items and recalibrate your
                estimate against a simulated reference population on every run.
              </p>
            </div>
            <div className="mx-auto mt-8 flex max-w-3xl items-start gap-3 rounded-2xl border border-border bg-card p-5">
              <Sigma className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
              <p className="text-sm leading-relaxed text-muted-foreground">
                <span className="font-semibold text-foreground">How scoring is anchored:</span>{" "}
                your raw correct count is placed on a scale where 100 is the
                simulated population average and 15 points is one standard
                deviation - the same convention used by mainstream IQ batteries.
                A score of 115 therefore means you solved more matrices than
                roughly 84 out of 100 adults, while 85 means roughly 16 out of
                100.
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="mr-faq-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="mr-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Matrix Reasoning Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {MATRIX_REASONING_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`mr-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="bg-muted/40 pb-16 pt-2 sm:pb-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Want the bigger cognitive picture?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Matrix reasoning is one pillar of fluid intelligence. The Full
                IQ Test adds verbal, numeric, memory and attention domains for a
                complete profile in a few minutes.
              </p>
              <a
                href="/test"
                data-testid="mr-cta-full-iq"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pb-20 pt-4 sm:px-6 lg:px-8">
          <RelatedTests currentId="matrix-reasoning" />
        </section>
      </main>
      <Footer />
    </div>
  );
}
