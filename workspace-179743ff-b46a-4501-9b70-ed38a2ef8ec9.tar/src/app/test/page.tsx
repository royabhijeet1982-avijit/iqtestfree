import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  Brain,
  Check,
  ChevronDown,
  Eye,
  FileText,
  Lightbulb,
  ListChecks,
  MousePointerClick,
  PenLine,
  Puzzle,
  Sparkles,
  Type,
} from "lucide-react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { Reveal } from "@/components/brainmetrics/motion";
import { FullIqTest } from "@/components/test/full-iq-test";
import { TEST_FAQ_ITEMS } from "@/components/test/test-faq-data";
import {
  AGE_SETS,
  SET_SIZE,
  TOTAL_QUESTION_COUNT,
  TOTAL_SET_COUNT,
} from "@/components/test/iq-questions";

const PAGE_URL = "https://brainmetrics.app/test";
const PAGE_TITLE = "Free Online IQ Test with Instant Results | BrainMetrics";
const PAGE_DESCRIPTION =
  "Free IQ test for kids, teens and adults. Each age group gets its own 10 hand-built sets of 12 questions — a fresh set every visit, instant score across 7 skills. No signup.";

/* ----------------------------- JSON-LD ------------------------------ */

const softwareAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Free Online IQ Test",
  alternateName: "BrainMetrics Full IQ Test",
  url: PAGE_URL,
  description: PAGE_DESCRIPTION,
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  browserRequirements: "Requires JavaScript",
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "Home",
      item: "https://brainmetrics.app/",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Free IQ Test",
      item: PAGE_URL,
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: TEST_FAQ_ITEMS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: { "@type": "Answer", text: item.answer },
  })),
};

/* --------------------------- Metadata ------------------------------- */

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "free IQ test",
    "IQ test for kids",
    "IQ test for teens",
    "IQ test for adults",
    "full IQ test online",
    "IQ test with instant results",
    "randomized IQ test",
    "take an IQ test free",
    "numerical reasoning test",
    "working memory test",
    "estimated IQ score",
    "BrainMetrics IQ test",
  ],
  alternates: {
    canonical: "/test",
  },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test",
    siteName: "BrainMetrics",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
  robots: {
    index: true,
    follow: true,
  },
};

/* ---------------------------- Content ------------------------------- */

const DOMAINS = [
  {
    icon: Lightbulb,
    name: "Logical reasoning",
    text: "Syllogisms and deduction items test whether you can chain premises to a guaranteed conclusion - the core skill behind structured problem solving.",
  },
  {
    icon: Type,
    name: "Verbal understanding",
    text: "Analogies, opposites and odd-one-out questions probe vocabulary depth and how precisely you grasp relationships between word meanings.",
  },
  {
    icon: ListChecks,
    name: "Numerical thinking",
    text: "Number series, fractions and percentage problems measure how quickly you spot quantitative rules and apply them without a calculator.",
  },
  {
    icon: Puzzle,
    name: "Pattern recognition",
    text: "Letter, word and Fibonacci-style sequences reward the ability to extract an underlying rule from minimal examples and project it forward.",
  },
  {
    icon: Eye,
    name: "Attention to detail",
    text: "Trap-style questions check whether you read precisely and resist jumping to the obvious-but-wrong answer under mild pressure.",
  },
  {
    icon: Brain,
    name: "Working & spatial memory",
    text: "Held-sequence recall, mental rotation and shape reasoning sample how well you manipulate information in your mind's workspace.",
  },
];

const STEPS = [
  {
    icon: MousePointerClick,
    title: "Pick your age group",
    text: "Choose Kids (7-12), Teens (13-17) or Adults (18+). Every group has its own 10 hand-built question sets — completely separate banks — and the moment you choose, a fresh set is dealt from that group's bank.",
  },
  {
    icon: PenLine,
    title: `Answer ${SET_SIZE} questions`,
    text: "Work through logic, verbal, numerical, pattern, attention, memory and spatial items with a friendly mix of easier and harder questions. Pick an answer, move on, and revisit earlier questions anytime before you finish.",
  },
  {
    icon: FileText,
    title: "Get your estimate",
    text: "See your estimated IQ-style score instantly, a percentile comparison, a per-skill breakdown and a question-by-question review with explanations so every answer becomes a small lesson.",
  },
];

export default function IqTestPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ HERO ------------------------------ */}
        <section className="relative overflow-hidden bg-background">
          <div
            aria-hidden="true"
            className="bm-drift pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-emerald-500/10 blur-2xl"
          />
          <div className="relative mx-auto w-full max-w-4xl px-4 pb-14 pt-10 text-center sm:px-6 sm:pt-14 lg:px-8">
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-emerald-700/20 bg-emerald-600/10 px-3.5 py-1.5 text-xs font-semibold text-emerald-800">
                <Sparkles className="size-3.5" aria-hidden="true" />
                3 age groups · {SET_SIZE} questions per set · new set every visit
              </span>
            </Reveal>
            <Reveal delay={0.08}>
              <h1 className="mt-6 text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl">
                Free Online{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                  IQ Test
                </span>
              </h1>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
                Pick your age group — kids, teens or adults — and get a fresh
                set of {SET_SIZE} questions every time. Each group has its own
                bank of {AGE_SETS.kids.length} hand-built sets —{" "}
                {TOTAL_SET_COUNT} sets and {TOTAL_QUESTION_COUNT} questions in
                total — and no two groups share a single question. Every set
                tests logic, verbal, numerical, pattern, memory, attention and
                spatial skills. No signup, no payment, no waiting.
              </p>
            </Reveal>
            <Reveal delay={0.24}>
              <p className="mt-4 text-sm font-medium text-muted-foreground">
                Instant results · No signup · Works on phone and desktop
              </p>
            </Reveal>
          </div>
        </section>

        {/* --------------------------- TEST APP ---------------------------- */}
        <section aria-label="Take the IQ test" className="bg-background pb-16 sm:pb-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <Reveal delay={0.1} y={28} scale>
              <div id="test-app" className="scroll-mt-24">
                <FullIqTest />
              </div>
            </Reveal>
          </div>
        </section>

        {/* ---------------------- WHAT IT MEASURES ------------------------- */}
        <section
          aria-labelledby="measures-heading"
          className="bg-muted py-16 sm:py-20"
        >
          <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
            <Reveal>
              <div className="mx-auto max-w-2xl text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  The science
                </p>
                <h2
                  id="measures-heading"
                  className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
                >
                  What this IQ test measures
                </h2>
                <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                  Real intelligence assessments sample several mental
                  abilities rather than one. This test follows the same idea:
                  every question targets a specific cognitive domain, and
                  your result page shows how you performed in each.
                </p>
              </div>
            </Reveal>

            <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {DOMAINS.map((domain, index) => {
                const Icon = domain.icon;
                return (
                  <Reveal key={domain.name} delay={index * 0.05}>
                    <li className="group h-full rounded-2xl border border-border bg-card p-6 shadow-[0_6px_24px_rgba(10,12,11,0.05)] transition-[translate,box-shadow,border-color] duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-[0_16px_40px_rgba(4,120,87,0.12)]">
                      <span className="flex size-11 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary transition-[scale,background-color] duration-300 group-hover:scale-110 group-hover:bg-primary/15">
                        <Icon className="size-5" aria-hidden="true" />
                      </span>
                      <h3 className="mt-4 text-base font-semibold text-foreground">
                        {domain.name}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        {domain.text}
                      </p>
                    </li>
                  </Reveal>
                );
              })}
            </ul>
          </div>
        </section>

        {/* --------------------------- HOW IT WORKS ------------------------ */}
        <section
          aria-labelledby="how-heading"
          className="bg-background py-16 sm:py-20"
        >
          <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
            <Reveal>
              <div className="mx-auto max-w-2xl text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Simple flow
                </p>
                <h2
                  id="how-heading"
                  className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
                >
                  How the test works
                </h2>
                <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                  From picking an age group to reading your breakdown takes
                  about seven minutes. Here is exactly what to expect.
                </p>
              </div>
            </Reveal>

            <ol className="mt-12 grid gap-6 md:grid-cols-3">
              {STEPS.map((step, index) => {
                const Icon = step.icon;
                return (
                  <Reveal key={step.title} delay={index * 0.06}>
                    <li className="relative h-full rounded-2xl border border-border bg-card p-6 shadow-[0_6px_24px_rgba(10,12,11,0.05)]">
                      <span
                        className="absolute -top-3 left-6 rounded-full bg-primary px-2.5 py-0.5 text-[11px] font-bold text-primary-foreground shadow-sm"
                        aria-hidden="true"
                      >
                        Step {index + 1}
                      </span>
                      <span className="flex size-11 items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
                        <Icon className="size-5" aria-hidden="true" />
                      </span>
                      <h3 className="mt-4 text-base font-semibold text-foreground">
                        {step.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        {step.text}
                      </p>
                    </li>
                  </Reveal>
                );
              })}
            </ol>

            <Reveal delay={0.1}>
              <ul className="mx-auto mt-10 flex max-w-3xl flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
                {[
                  "No time limit — think freely",
                  "A new set of 12 every attempt",
                  "10 unique sets per age group",
                  "Change earlier answers anytime",
                  "Explanations for every question",
                ].map((point) => (
                  <li key={point} className="inline-flex items-center gap-1.5">
                    <Check className="size-4 text-emerald-600" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        {/* ------------------------------- FAQ ----------------------------- */}
        <section
          id="faq"
          aria-labelledby="test-faq-heading"
          className="bg-muted py-16 sm:py-20 lg:py-24"
        >
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <Reveal>
              <div className="text-center">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  FAQ
                </p>
                <h2
                  id="test-faq-heading"
                  className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
                >
                  IQ test questions, answered
                </h2>
                <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                  How the age groups work, how scoring works, and what this
                  test can - and cannot - tell you about your mind.
                </p>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="mt-10 space-y-4">
                {TEST_FAQ_ITEMS.map((item) => (
                  <details
                    key={item.question}
                    className="group rounded-2xl border border-border bg-card px-5 py-4 shadow-[0_4px_18px_rgba(10,12,11,0.05)] transition-[border-color,box-shadow] duration-200 open:border-primary/40 open:shadow-[0_8px_24px_rgba(4,120,87,0.09)] sm:px-6"
                  >
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-base font-semibold text-foreground [&::-webkit-details-marker]:hidden">
                      {item.question}
                      <ChevronDown
                        className="size-4 shrink-0 text-muted-foreground transition-transform duration-200 group-open:rotate-180"
                        aria-hidden="true"
                      />
                    </summary>
                    <p className="mt-3 border-t border-border/70 pt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
                      {item.answer}
                    </p>
                  </details>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {/* --------------------------- FINAL CTA --------------------------- */}
        <section aria-label="Explore more tests" className="bg-background pb-16 sm:pb-20 lg:pb-24">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <Reveal scale>
              <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-950 px-6 py-12 text-center shadow-[0_24px_60px_-16px_rgba(4,120,87,0.45)] sm:px-12 sm:py-14">
                <div
                  aria-hidden="true"
                  className="bm-drift pointer-events-none absolute -left-16 -top-16 size-48 rounded-full bg-white/10 blur-2xl"
                />
                <div className="relative">
                  <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
                    Finished? Keep the momentum going.
                  </h2>
                  <p className="mx-auto mt-3 max-w-xl text-base leading-relaxed text-emerald-50/95">
                    The Full IQ Test is just the beginning. Train one skill
                    at a time with focused tests for memory, attention,
                    reaction speed and more - all free.
                  </p>
                  <Link
                    href="/#all-tests"
                    className="mt-7 inline-flex h-12 items-center justify-center gap-2 rounded-lg bg-white px-7 text-base font-semibold text-emerald-800 shadow-[0_8px_24px_rgba(2,60,45,0.45)] transition-[translate,box-shadow] duration-300 hover:-translate-y-0.5 hover:bg-emerald-50 hover:shadow-[0_10px_30px_rgba(2,60,45,0.6)] active:translate-y-0 bm-shine bm-shine-emerald"
                  >
                    Explore all 26 cognitive tests
                    <ArrowRight className="size-4" aria-hidden="true" />
                  </Link>
                </div>
              </div>
            </Reveal>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
