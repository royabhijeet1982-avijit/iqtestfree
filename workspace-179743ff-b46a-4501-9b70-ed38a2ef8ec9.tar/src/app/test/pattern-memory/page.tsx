import type { Metadata } from "next";
import { Suspense } from "react";
import { Navbar } from "@/components/brainmetrics/navbar";
import { Footer } from "@/components/brainmetrics/footer";
import { ScrollProgress } from "@/components/brainmetrics/motion";
import { RelatedTests } from "@/components/brainmetrics/related-tests";
import { PatternMemoryTest } from "@/components/test/pattern-memory";
import { PATTERN_MEMORY_FAQS } from "@/components/test/pattern-memory-faq-data";
import { Brain, ShieldCheck, Sparkles, Target, TrendingUp, LayoutGrid } from "lucide-react";

const PAGE_TITLE = "Free Pattern Memory Test Online | BrainMetrics";
const PAGE_DESCRIPTION =
  "Take a free pattern memory test. Memorise flashing tile patterns, rebuild them from an empty board, watch the hints disappear - instant visual memory index, no sign-up.";

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  keywords: [
    "pattern memory test",
    "visual pattern test",
    "tile memory test",
    "grid memory test",
    "visual memory test online",
    "free memory test",
    "spatial pattern recall",
    "brain training game",
    "cognitive test",
    "memorize patterns",
  ],
  alternates: { canonical: "/test/pattern-memory" },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: "/test/pattern-memory",
    siteName: "BrainMetrics",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
  },
};

/* ------------------------------ JSON-LD ------------------------------ */

const webAppJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Pattern Memory Test",
  alternateName: "Tile Pattern Memory Test",
  url: "https://brainmetrics.app/test/pattern-memory",
  applicationCategory: "EducationalApplication",
  operatingSystem: "Any (web browser)",
  description: PAGE_DESCRIPTION,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
  publisher: {
    "@type": "Organization",
    name: "BrainMetrics",
    url: "https://brainmetrics.app",
  },
};

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "BrainMetrics",
      item: "https://brainmetrics.app",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Pattern Memory Test",
      item: "https://brainmetrics.app/test/pattern-memory",
    },
  ],
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: PATTERN_MEMORY_FAQS.map((item) => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: item.answer,
    },
  })),
};

/* --------------------------- Content data --------------------------- */

const MEASURE_CARDS = [
  {
    icon: LayoutGrid,
    title: "Shape, not sequence",
    body: "Nothing here repeats or grows forever - each round is a brand-new pattern that exists only as a shape. Your brain has roughly a second to stop seeing 25 tiles and start seeing two or three chunks, and that chunking reflex is exactly what the score tracks.",
  },
  {
    icon: TrendingUp,
    title: "Hints drain to zero",
    body: "Early rounds hand you peeks - bonus re-flashes that rescue a collapsed memory. By the final two rounds the safety net is gone: eight tiles, 700 milliseconds, one look. The budget decays so improvement must come from your encoding, not from extra glances.",
  },
  {
    icon: Sparkles,
    title: "Spraying earns nothing",
    body: "Wrong tiles cancel right ones before the round score is computed, and every round floors at zero. Clicking all 25 tiles technically catches the pattern but pays for every miss - so the only path to a high index is careful, honest recall.",
  },
];

const STEPS = [
  {
    title: "Watch the flash",
    body: "Lit tiles appear on the 5x5 board for a moment the engine controls - 1.4 seconds on the first pattern, shrinking every round. The patterns are built so no two tiles touch and none sit in a single line, so raw position spam never beats real shape memory.",
  },
  {
    title: "Rebuild from the dark board",
    body: "The grid goes blank and clicking opens. Click every tile you believe was lit - your picks stay counted while you think. Peeks appear as a button: spend one to re-flash the pattern briefly, if the round's budget still has any left.",
  },
  {
    title: "Submit and see the truth",
    body: "Submit grades the round instantly: green tiles were right, bright green ones you missed, red ones you imagined. Six rounds later your index arrives - built from all six round scores with wrong tiles already subtracted.",
  },
];

const TIPS = [
  "Chunk the tiles into a shape - a triangle, an L, a connect-the-dots line. Three chunked shapes beat eight memorised positions every time.",
  "Sweep the board in one fixed path (left-to-right, top-to-bottom) during the flash; a consistent scan route turns the pattern into a short motor story.",
  "Spend peeks on the big patterns, not the small ones - a rescued 8-tile round is worth more points than a guaranteed 3-tile one.",
  "When unsure, leave a tile OUT rather than guessing in: a wrong tile costs exactly as much as a missed one, so false confidence has no edge here.",
];

/* ------------------------------ Page ------------------------------ */

export default function PatternMemoryPage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webAppJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" className="flex-1">
        {/* ------------------------------ Hero ------------------------------ */}
        <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-background to-background">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-200/40 blur-3xl"
          />
          <div className="relative mx-auto w-full max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pb-12 sm:pt-16 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <LayoutGrid className="h-3.5 w-3.5" aria-hidden="true" />
                Visual memory · tile patterns · about 4 minutes
              </p>
              <h1 className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                Pattern{" "}
                <span className="bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 bg-clip-text text-transparent">
                  Memory Test
                </span>
              </h1>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                A pattern of tiles flashes once, then the board goes dark.
                Rebuild what you saw while the patterns grow, the flashes
                shrink and the hints run out - a free, honest take on the
                classic visual recall task.
              </p>
              <p className="mt-3 text-sm text-muted-foreground">
                Free · no sign-up · instant results · fresh patterns every run
              </p>
            </div>
          </div>
        </section>

        {/* ------------------------------ Test ------------------------------ */}
        <section className="mx-auto w-full max-w-4xl px-4 pb-16 sm:px-6 lg:px-8">
          <Suspense
            fallback={
              <div className="flex min-h-72 items-center justify-center rounded-2xl border border-border bg-card">
                <p className="text-sm text-muted-foreground">Loading the test…</p>
              </div>
            }
          >
            <PatternMemoryTest />
          </Suspense>
        </section>

        {/* ------------------------ What it measures ------------------------ */}
        <section aria-labelledby="pm-measures-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                The science
              </p>
              <h2
                id="pm-measures-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                What this test measures
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Brief-pattern reproduction has been a staple of visual memory
                research since the days of paper grids, because it isolates
                something earlier tests missed: how accurately your mind
                stores the FORM of a scene, not just the fact that you saw it.
              </p>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-3">
              {MEASURE_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <card.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{card.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- How it works --------------------------- */}
        <section aria-labelledby="pm-steps-heading" className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Simple by design
              </p>
              <h2
                id="pm-steps-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                How the test works
              </h2>
            </div>
            <ol className="mt-10 grid gap-6 sm:grid-cols-3">
              {STEPS.map((step, i) => (
                <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6 shadow-sm">
                  <span className="absolute -top-3 left-6 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {i + 1}
                  </span>
                  <h3 className="mt-2 text-lg font-semibold text-foreground">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50/70 p-6">
              <h3 className="flex items-center gap-2 text-base font-semibold text-emerald-800">
                <Target className="h-5 w-5" aria-hidden="true" />
                Tips for your best score
              </h3>
              <ul className="mt-3 space-y-2">
                {TIPS.map((tip) => (
                  <li key={tip} className="flex gap-2.5 text-sm leading-relaxed text-emerald-900">
                    <Brain className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------- FAQ ------------------------------- */}
        <section aria-labelledby="pm-faq-heading" className="bg-muted/40 py-16 sm:py-20">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                Good to know
              </p>
              <h2
                id="pm-faq-heading"
                className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              >
                Pattern Memory Test FAQ
              </h2>
            </div>
            <div className="mt-8 space-y-3">
              {PATTERN_MEMORY_FAQS.map((faq, i) => (
                <details
                  key={faq.question}
                  data-testid={`pm-faq-item-${i}`}
                  className="group rounded-xl border border-border bg-card px-5 py-4 [&_summary::-webkit-details-marker]:hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-4 text-left text-base font-semibold text-foreground">
                    {faq.question}
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-primary transition-transform duration-200 group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* --------------------------- Related tests --------------------------- */}
        <section className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
          <RelatedTests currentId="pattern-memory" />
        </section>

        {/* ----------------------------- Final CTA ----------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="mx-auto w-full max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-emerald-500 px-6 py-12 text-center shadow-lg sm:px-12">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Curious how your mind compares overall?
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-lg leading-relaxed text-emerald-50">
                Pattern memory is one piece of the puzzle. The Full IQ Test adds
                reasoning, verbal, numeric and processing-speed domains for a
                complete picture of your cognitive profile.
              </p>
              <a
                href="/test"
                data-testid="pm-cta-full-iq-page"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-emerald-800 shadow-md transition-[translate,box-shadow] hover:-translate-y-0.5 hover:shadow-xl"
              >
                <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                Take the Full IQ Test
              </a>
              <p className="mt-4 text-sm text-emerald-100">
                Or head back to{" "}
                <a href="/#popular-tests" className="font-semibold underline underline-offset-4">
                  all cognitive tests
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
