import {
  ArrowLeftRight,
  Boxes,
  Brain,
  Compass,
  Eye,
  Focus,
  Gauge,
  Grid3x3,
  Hand,
  Hash,
  LayoutGrid,
  Lightbulb,
  ListOrdered,
  MapPin,
  Palette,
  Puzzle,
  Repeat,
  Rotate3d,
  Scan,
  Shapes,
  Shuffle,
  Squirrel,
  Type,
  Zap,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Central tool configuration                                         */
/*  Single source of truth for every cognitive test on the site:       */
/*  name, description, category, route, estimated duration and icon.   */
/*  To add a new tool: append an entry here - every grid on the        */
/*  homepage (popular + category-wise) updates automatically.          */
/* ------------------------------------------------------------------ */

export type ToolCategory = "memory" | "attention" | "reasoning" | "advanced";

export type Tool = {
  id: string;
  name: string;
  description: string;
  category: ToolCategory;
  /** Estimated completion time in minutes. */
  minutes: number;
  /** Route of the test page. The Full IQ Test uses the primary /test route. */
  href: string;
  icon: LucideIcon;
  featured?: boolean;
};

export const TOOLS: Tool[] = [
  /* ---- Spatial & Reasoning ---- */
  {
    id: "full-iq",
    name: "Full IQ Test",
    description:
      "A complete assessment covering reasoning, memory, speed and spatial skills.",
    category: "reasoning",
    minutes: 25,
    href: "/test",
    icon: Brain,
    featured: true,
  },
  {
    id: "matrix-reasoning",
    name: "Matrix Reasoning",
    description:
      "Find patterns and identify the missing element in visual sequences.",
    category: "reasoning",
    minutes: 10,
    href: "/test/matrix-reasoning",
    icon: Grid3x3,
  },
  {
    id: "mental-rotation",
    name: "Mental Rotation Test",
    description: "Rotate 3D shapes in your mind and spot the matching pair.",
    category: "reasoning",
    minutes: 8,
    href: "/test/mental-rotation",
    icon: Rotate3d,
  },
  {
    id: "spatial-reasoning",
    name: "Spatial Reasoning Test",
    description:
      "Judge shapes, folds and perspectives to map out your spatial thinking.",
    category: "reasoning",
    minutes: 10,
    href: "/test/spatial-reasoning",
    icon: Compass,
  },
  {
    id: "pattern-recognition",
    name: "Pattern Recognition Test",
    description:
      "Spot the rule hiding inside a series and predict what comes next.",
    category: "reasoning",
    minutes: 8,
    href: "/test/pattern-recognition",
    icon: Shapes,
  },
  {
    id: "logical-reasoning",
    name: "Logical Reasoning Test",
    description:
      "Work through deductions and syllogisms to test structured thinking.",
    category: "reasoning",
    minutes: 12,
    href: "/test/logical-reasoning",
    icon: Lightbulb,
  },
  {
    id: "chimp-test",
    name: "Chimp Test",
    description:
      "Memorise number positions, then tap them in order after they hide.",
    category: "reasoning",
    minutes: 5,
    href: "/test/chimp-test",
    icon: Squirrel,
  },

  /* ---- Memory ---- */
  {
    id: "digit-span",
    name: "Digit Span / Number Memory",
    description:
      "Memorise increasingly long digit sequences and see how far your span reaches.",
    category: "memory",
    minutes: 5,
    href: "/test/digit-span",
    icon: Hash,
  },
  {
    id: "visual-memory",
    name: "Visual Memory Test",
    description:
      "Watch a pattern flash, then rebuild it from memory as levels speed up.",
    category: "memory",
    minutes: 4,
    href: "/test/visual-memory",
    icon: Eye,
  },
  {
    id: "working-memory",
    name: "Working Memory Test",
    description:
      "Hold and juggle information in your mind across quick challenges.",
    category: "memory",
    minutes: 6,
    href: "/test/working-memory",
    icon: Boxes,
  },
  {
    id: "sequence-memory",
    name: "Sequence Memory Test",
    description:
      "Repeat growing light sequences to stretch your memory step by step.",
    category: "memory",
    minutes: 4,
    href: "/test/sequence-memory",
    icon: ListOrdered,
  },
  {
    id: "word-memory",
    name: "Word Memory Test",
    description:
      "Study a stream of words, then spot which ones you have seen before.",
    category: "memory",
    minutes: 5,
    href: "/test/word-memory",
    icon: Type,
  },
  {
    id: "pattern-memory",
    name: "Pattern Memory Test",
    description:
      "Memorise tile patterns and reproduce them with fewer hints each round.",
    category: "memory",
    minutes: 4,
    href: "/test/pattern-memory",
    icon: LayoutGrid,
  },
  {
    id: "spatial-memory",
    name: "Spatial Memory Test",
    description:
      "Remember where items appeared on the board as the grid keeps growing.",
    category: "memory",
    minutes: 5,
    href: "/test/spatial-memory",
    icon: MapPin,
  },
  {
    id: "short-term-memory",
    name: "Short-Term Memory Test",
    description:
      "Measure how much detail you can retain after a single brief glance.",
    category: "memory",
    minutes: 3,
    href: "/test/short-term-memory",
    icon: Scan,
  },

  /* ---- Attention & Speed ---- */
  {
    id: "reaction-time",
    name: "Reaction Time Test",
    description:
      "Wait for green, then tap as fast as you can. Every millisecond counts.",
    category: "attention",
    minutes: 2,
    href: "/test/reaction-time",
    icon: Zap,
  },
  {
    id: "stroop-test",
    name: "Stroop Test",
    description:
      "Name the ink colour while the word itself tries to confuse you.",
    category: "attention",
    minutes: 3,
    href: "/test/stroop-test",
    icon: Palette,
  },
  {
    id: "processing-speed",
    name: "Processing Speed Test",
    description:
      "Compare symbols quickly and measure how fast you process information.",
    category: "attention",
    minutes: 4,
    href: "/test/processing-speed",
    icon: Gauge,
  },
  {
    id: "sustained-attention",
    name: "Sustained Attention Test",
    description:
      "Stay sharp through a long, repetitive stream and catch every rare target.",
    category: "attention",
    minutes: 6,
    href: "/test/sustained-attention",
    icon: Focus,
  },
  {
    id: "go-no-go",
    name: "Go / No-Go Test",
    description:
      "Tap on every go cue and hold back on the no-go cues - impulse control matters.",
    category: "attention",
    minutes: 4,
    href: "/test/go-no-go",
    icon: Hand,
  },
  {
    id: "choice-reaction-time",
    name: "Choice Reaction Time Test",
    description:
      "React to the right side, colour or sound - speed plus decision-making.",
    category: "attention",
    minutes: 3,
    href: "/test/choice-reaction-time",
    icon: ArrowLeftRight,
  },

  /* ---- Working Memory & Advanced ---- */
  {
    id: "n-back",
    name: "N-Back Test",
    description:
      "Track whether the current item matches the one from N steps ago.",
    category: "advanced",
    minutes: 10,
    href: "/test/n-back",
    icon: Repeat,
  },
  {
    id: "dual-n-back",
    name: "Dual N-Back Test",
    description:
      "Follow two streams at once - audio and position - in a single challenge.",
    category: "advanced",
    minutes: 12,
    href: "/test/dual-n-back",
    icon: Puzzle,
  },
  {
    id: "operation-span",
    name: "Operation Span Test",
    description: "Solve quick sums while memorising letters between each one.",
    category: "advanced",
    minutes: 8,
    href: "/test/operation-span",
    icon: Hash,
  },
  {
    id: "complex-working-memory",
    name: "Complex Working Memory Test",
    description:
      "Combine storage and processing in one demanding memory workout.",
    category: "advanced",
    minutes: 10,
    href: "/test/complex-working-memory",
    icon: Boxes,
  },
  {
    id: "task-switching",
    name: "Task Switching Test",
    description:
      "Flip between rules again and again and measure the cost of every switch.",
    category: "advanced",
    minutes: 6,
    href: "/test/task-switching",
    icon: Shuffle,
  },
];

/* ------------------------------------------------------------------ */
/*  Categories                                                         */
/* ------------------------------------------------------------------ */

export type Category = {
  id: ToolCategory;
  name: string;
  intro: string;
  /** Planned category landing page. */
  href: string;
};

export const CATEGORIES: Category[] = [
  {
    id: "memory",
    name: "Memory Tests",
    intro:
      "From digit spans to tile patterns - measure how much your memory can hold and how long it lasts.",
    href: "/tests/memory",
  },
  {
    id: "attention",
    name: "Attention & Speed",
    intro:
      "How fast do you notice, decide and respond? These quick tasks put your reaction and focus to the test.",
    href: "/tests/attention-speed",
  },
  {
    id: "reasoning",
    name: "Spatial & Reasoning",
    intro:
      "Logic, patterns and mental imagery - the core skills behind every classic IQ assessment.",
    href: "/tests/spatial-reasoning",
  },
  {
    id: "advanced",
    name: "Working Memory Advanced",
    intro:
      "Demanding dual-task challenges for anyone who wants to push working memory to its limits.",
    href: "/tests/working-memory",
  },
];

export const toolsByCategory = (categoryId: ToolCategory): Tool[] =>
  TOOLS.filter((tool) => tool.category === categoryId);

/* ------------------------------------------------------------------ */
/*  Popular tools - the highlighted grid, in display order.            */
/* ------------------------------------------------------------------ */

export const POPULAR_TOOL_IDS = [
  "full-iq",
  "matrix-reasoning",
  "digit-span",
  "reaction-time",
  "visual-memory",
  "stroop-test",
  "mental-rotation",
  "n-back",
  "chimp-test",
  "processing-speed",
] as const;

export const POPULAR_TOOLS: Tool[] = POPULAR_TOOL_IDS.map(
  (id) => TOOLS.find((tool) => tool.id === id) as Tool
);

/* ------------------------------------------------------------------ */
/*  Learn / blog articles                                              */
/* ------------------------------------------------------------------ */

export type Article = {
  title: string;
  category: string;
  description: string;
  href: string;
};

export const ARTICLES: Article[] = [
  {
    title: "What Is an IQ Test? Understanding the Basics",
    category: "IQ Testing",
    description:
      "A plain-English walkthrough of what IQ tests measure, how scoring works and what the numbers do - and don't - tell you.",
    href: "/blog/what-is-an-iq-test",
  },
  {
    title: "Fluid vs. Crystallized Intelligence",
    category: "Intelligence",
    description:
      "Two different engines behind your thinking: solving brand-new problems versus drawing on everything you already know.",
    href: "/blog/fluid-vs-crystallized-intelligence",
  },
  {
    title: "What Does a Reaction Time Test Measure?",
    category: "Attention & Speed",
    description:
      "Why a simple tap test can reveal surprisingly much about processing speed, alertness and motor response.",
    href: "/blog/what-does-reaction-time-measure",
  },
  {
    title: "Working Memory: What It Is and How It Works",
    category: "Memory",
    description:
      "The mind's scratchpad: how holding and juggling information works, and why it predicts so many everyday skills.",
    href: "/blog/working-memory-explained",
  },
];
