# Worklog

---
Task ID: 1
Agent: Main agent (Z.ai)
Task: Build the BrainMetrics home page (/) — navbar, hero with bell-curve result card, trust row, tests grid, how-it-works, games teaser, social proof strip, FAQ accordion with JSON-LD, final CTA band, footer, full SEO metadata.

Work Log:
- Initialized fullstack dev environment (init-fullstack.sh), reviewed scaffold (Next.js 16 App Router + Tailwind CSS 4 + shadcn/ui).
- Updated globals.css: brand tokens (primary #4F46E5, foreground #111827, muted #F9FAFB, ring, border), Inter font mapping (--font-sans -> --font-inter), mono stack fix, smooth scroll + reduced-motion guard, selection color.
- Rewrote layout.tsx: Inter via next/font, full metadata (48-char title, 134-char description, canonical https://brainmetrics.app/, OG/Twitter, robots), Organization + WebSite JSON-LD, skip-to-content link, sticky-footer body classes (min-h-screen flex-col).
- Created public/favicon.svg (indigo rounded square + white brain glyph).
- Built src/components/brainmetrics/: navbar.tsx (client, scroll-blur + hamburger with aria-expanded/Escape close), hero.tsx (H1, both CTAs, SVG bell curve with shaded area/marker at 118, floating premium chips), trust-row.tsx, tests-grid.tsx (4 TestCards with icons/duration badges/CTAs), how-it-works.tsx (3 steps), games-teaser.tsx (3 CSS thumbnails + Play free links), social-proof.tsx (neutral line, no fake numbers), faq-data.ts (single source for FAQ copy), faq.tsx (shadcn accordion), final-cta.tsx (indigo band), footer.tsx (4 columns + disclaimer + copyright).
- Rewrote page.tsx: composes all sections in spec order + FAQPage JSON-LD generated from faq-data.ts (guaranteed parity with visible copy).
- Verification via Agent Browser: loaded / (title correct), zero console/page errors; hamburger opens/closes (aria-expanded, Escape); anchor scroll to #tests lands at 79.5px below sticky nav; FAQ opens via keyboard (focus + Enter); JSON-LD x3 (FAQPage, Organization, WebSite) present; canonical + meta description confirmed; 375px: no horizontal overflow, menu/hero/card render clean; 1440px: full-page render of all 10 sections clean; all CTA hrefs correct (/test, /test/eq, /test/personality, /test/career, /games, /blog, /#faq, footer pages); bun run lint clean; dev.log shows GET / 200 throughout.

Stage Summary:
- Home page complete and browser-verified at 375px and 1440px; lint clean; no placeholder text; science-inspired wording used throughout; social proof intentionally shows a neutral line (no Supabase data yet, no fake numbers).
- Routes referenced but intentionally not created (future prompts): /test, /test/eq, /test/personality, /test/career, /games, /blog, /about, /contact, /privacy, /terms.
- Key files: src/app/layout.tsx, src/app/page.tsx, src/app/globals.css, public/favicon.svg, src/components/brainmetrics/* (11 files).

---
Task ID: 2
Agent: Main agent (Z.ai)
Task: (a) Dark bg + yellow text + animations; (b) pivot to eye-relaxing color combination with compelling, click-driving UI.

Work Log:
- Pass 1 (dark/yellow): tokens to #0a0f1c bg + #fde047 text; added motion.tsx (Reveal scroll-reveal, Float bob, CountUp score counter, framer-motion); navbar mobile menu AnimatePresence height/fade; accordion-down/up keyframes + bm-drift ambient blob keyframes with reduced-motion guard; all 10 sections restyled dark.
- Pass 2 (calm sage-teal, supersedes per user request "eyes ko relaxing + click karne par majboor"): tokens to #fafaf7 warm off-white bg, #1f3d3a deep-pine text, #0f766e teal-700 primary (white text 5.5:1 AA), #eff5f2 sage mist sections, #dce5e0 borders; hero teal bell-curve gradient + gradient "Mind Works" headline; IQ card got "Most popular" pill + teal ring (conversion pattern); teal gradient final CTA band (white text, white primary button); soft rgba(31,61,58,.06-.15) shadows replacing black; teal logo glows; favicon -> teal; viewport themeColor #fafaf7; animations retained (Reveal stagger, Float chips, CountUp 118, accordion height animation, drifting glow blobs).
- Verified: lint clean; 1440px hero/tests/footer screenshots good; 375px no horizontal overflow; hamburger opens with animation (7 links); 3 JSON-LD schemas intact; zero console errors; dev.log GET / 200.

Stage Summary:
- Live theme: Calm Sage-Teal light palette (eye-comfort) + conversion-focused CTAs + framer-motion entrance/scroll/counter animations. Dark+yellow pass exists in git history of worklog only.
- Files touched: globals.css, layout.tsx (themeColor), favicon.svg, all 11 brainmetrics components incl. new motion.tsx.

---
Task ID: 2-final
Agent: Main agent (Z.ai)
Task: Post-continuation final verification of the live Calm Sage-Teal theme (eye-relaxing palette + click-driving UI).

Work Log:
- Confirmed consistency: zero leftover yellow/amber/navy classes in src (grep clean); globals.css tokens #fafaf7/#1f3d3a/#0f766e; layout.tsx themeColor #fafaf7; favicon teal; hero bell-curve teal gradient; final CTA teal band.
- bun run lint: clean.
- dev.log: GET / 200 throughout, no runtime errors.
- Agent-browser 1440px: hero (teal gradient headline, glow CTA, floating chips, CountUp 118), tests grid (IQ card "Most popular" teal ring), how-it-works, games (3 thumbnails), neutral social-proof strip, FAQ, teal final CTA band, footer all render correctly on scroll. Full-page screenshot blanks below fold are the Reveal whileInView animation not firing in virtual-viewport capture - not a bug (confirmed by scroll-through).
- JSON-LD x3 intact (FAQPage, Organization, WebSite).
- FAQ accordion opens via click ("Are these tests free?" data-state=open).
- 375px: 0px horizontal overflow; hero clean; hamburger opens animated menu (6 links + CTA), Escape closes (aria-expanded 2 -> 1).
- Zero page errors; console only React DevTools/HMR info logs.

Stage Summary:
- BrainMetrics home page shipped with eye-comfort Calm Sage-Teal light palette (#fafaf7 bg, deep-pine text, teal-700 primary), conversion-focused CTAs (glow shadows, Most-popular ring, gradient CTA band) and framer-motion Reveal/Float/CountUp + CSS drift animations. All acceptance criteria verified at 375px and 1440px.

---
Task ID: 3
Agent: Main agent (Z.ai)
Task: Full re-theme to White + Emerald + Black combination (user request with screenshot of the emerald TAP button as color reference).

Work Log:
- globals.css tokens: --background #ffffff, --foreground #0a0c0b (near-black), --primary #047857 (emerald-700, 5.5:1 AA with white text), --secondary/--muted #eef6f1, --muted-foreground #4d5c55 (7:1), --accent #d9f2e6 + accent-foreground #065f46, --border/--input #e2e9e5, --ring #047857, selection emerald.
- layout.tsx: themeColor #ffffff. favicon.svg: emerald #047857 rounded square + white brain.
- navbar/footer: logo glow rgba(4,120,87,.3), navbar scroll shadow black-based.
- hero: emerald gradient headline (emerald-700->600->500), badge emerald-800 on emerald-600/10, CTA glow shadows rgba(4,120,87,.35/.45), bell curve gradient #34d399->#047857 with stroke/marker #047857, axis text #4d5c55, chip shadows black-based.
- tests-grid: popular card border-primary/50 ring-primary/30, icon chips bg-primary/10, hover shadows emerald-tinted; how-it-works + games-teaser + faq: teal classes -> primary token, shadows rgba(10,12,11,...).
- games-teaser: TAP circle kept emerald-500 (matches user screenshot), visual memory cells bg-primary.
- final-cta: black gradient band (neutral-950 -> black -> emerald-950) with emerald glow blobs, white button with black text + emerald glow shadow, outline white secondary - completes the black element of the trio.
- Verified: grep zero leftover teal/old hex; lint clean; dev.log 200; 1440px hero/tests/how-it-works/CTA/footer screenshots correct; 375px 0px overflow, hamburger + Escape close OK; JSON-LD x3 intact; zero console/page errors.

Stage Summary:
- Live theme: White + Emerald + Black trio - white background, near-black text, emerald-700 primary with emerald-500 accents, black gradient final CTA band. Animations (Reveal/Float/CountUp/drift) unchanged.
- Files touched: globals.css, layout.tsx, favicon.svg, navbar.tsx, hero.tsx, tests-grid.tsx, how-it-works.tsx, games-teaser.tsx, faq.tsx, final-cta.tsx, footer.tsx (trust-row/social-proof were already token-based).

---
Task ID: 4
Agent: Main agent (Z.ai)
Task: Rebuild homepage as cognitive testing platform per user's simplified layout spec (Hinglish): Hero -> Popular 10 tools -> Category-wise All Tools -> Quick Stats -> Learn -> Footer. Keep White+Emerald+Black theme.

Work Log:
- Created src/config/tools.ts (central config): 26 tools with id/name/1-line description/category/minutes/href/icon; 4 categories (Memory 8, Attention & Speed 6, Spatial & Reasoning 7, Working Memory Advanced 5) each with intro + planned /tests/<cat> route; POPULAR_TOOL_IDS (10, exact user order: Full IQ, Matrix Reasoning, Digit Span, Reaction Time, Visual Memory, Stroop, Mental Rotation, N-Back, Chimp, Processing Speed); ARTICLES (4 blog posts with planned /blog/<slug> routes).
- New components: tool-card.tsx (compact card: icon chip, time badge, name, description, Start Test arrow, stretched-link whole-card click with sr-only label + focus ring, "Most popular" pill on featured); popular-tools.tsx (H2 + 10 cards, grid-cols-2 mobile / md:3 / xl:4); all-tools.tsx (H2 + 4 category blocks with H3, intro, per-category grid + "View all <Category>" links to /tests/<cat>); quick-stats.tsx (CountUp 26 "Cognitive tests available" from TOOLS.length + Established frameworks + Instant free results + No signup required); learn-section.tsx (4 article cards with category chips + Read Article).
- Updated hero.tsx: eyebrow "Explore Your Cognitive Skills", H1 "Free Online IQ Test & Cognitive Tests" (emerald gradient), new supporting paragraph, CTAs "Start Free IQ Test"->/test + "Explore All Tests"->#all-tests, trust line "Instant results - No signup - Free", card label "Full IQ Test preview"; bell-curve preview kept.
- navbar.tsx: Home(/), IQ Test(/test), All Tests(#all-tests), Learn(#learn) + "Start IQ Test" CTA. faq-data.ts rewritten for cognitive-testing focus (free? account? how long? what measured?) - FAQPage JSON-LD stays in parity via single source. footer.tsx: Tests / Popular Tools / Learn(articles) / Policies columns + honest disclaimer. layout.tsx: title "Free Online IQ Test & Cognitive Tests | BrainMetrics", new description/keywords/Org JSON-LD. final-cta button text "Start Free IQ Test".
- page.tsx order: Navbar, Hero, PopularTools, AllTools, QuickStats, LearnSection, Faq, FinalCta, Footer. Deleted replaced components: tests-grid, how-it-works, games-teaser, social-proof, trust-row.
- Verified: lint clean; dev.log 200; 1440px all sections screenshot-verified (hero/popular/all-tools/quickstats/learn/faq/cta/footer); 375px 0px overflow + 2-col card grid renders clean; mobile menu open/Escape close (0 expanded); FAQ accordion opens; JSON-LD x3 (FAQPage|4 questions, Organization, WebSite); DOM counts 10 popular + 26 category + 4 article cards; zero console/page errors.

Stage Summary:
- Homepage is now a cognitive-testing platform with 26-tool catalog driven entirely by src/config/tools.ts (add a tool entry -> appears in grids automatically).
- Routes still to implement (referenced, intentionally not built - single-route environment): /test/<slug> x25 tools, /tests/<category> x4, /blog + /blog/<slug> x4, /about, /contact, /privacy, /terms. Until built, those links 404 by design of the progressive rollout.
- Theme unchanged: White + Emerald + Black. Animations (Reveal/Float/CountUp) unchanged.

---
Task ID: 4-final
Agent: Main agent (Z.ai)
Task: Final verification pass of the rebuilt cognitive-testing homepage (continuation after context reset).

Work Log:
- Confirmed on-disk state: src/config/tools.ts (26 tools, 4 categories, POPULAR_TOOL_IDS x10, ARTICLES x4) and all new components (tool-card, popular-tools, all-tools, quick-stats, learn-section) exist; page.tsx composes Navbar -> Hero -> PopularTools -> AllTools -> QuickStats -> LearnSection -> Faq -> FinalCta -> Footer.
- bun run lint: clean.
- agent-browser 1440px: title correct; JSON-LD x3 (FAQPage, Organization, WebSite); DOM counts 10 popular cards / 25 category cards / 4 article cards; 0px horizontal overflow; section screenshots captured (hero, popular 4-col grid with Most-popular ring on Full IQ, All Tools category block with View-all link, Quick Stats CountUp 26, Learn 4 article cards, black final CTA + 4-column footer).
- agent-browser 375px: 0px horizontal overflow; popular grid renders 2 columns; hero bell-curve card + CountUp animate; hamburger menu opens (Home / IQ Test / All Tests / Learn + Start IQ Test CTA), Escape closes (aria-expanded back to 0 open).
- FAQ accordion opens on click; zero page errors; zero console errors; dev.log GET / 200 throughout.

Stage Summary:
- Task 4 verified end-to-end at 1440px and 375px. Homepage now matches the user's recommended layout: Hero (big headline + Full Free IQ Test CTA + "Instant results - No signup - Free" trust line) -> 10 Popular Cognitive Tests (exact user order, 2-col mobile / 3-col md / 4-col xl) -> All Cognitive Tests by category with View-all links -> Quick Stats (honest 26-tool count) -> Learn About Cognitive Skills -> FAQ -> black final CTA -> complete footer. Single source of truth: src/config/tools.ts. Theme White + Emerald + Black unchanged.

---
Task ID: 5
Agent: Main agent (Z.ai)
Task: Restyle final CTA band colour combination to match the White + Emerald theme (user screenshot of the black CTA band + "Iska colour combination theme anusar banayye").

Work Log:
- final-cta.tsx: black gradient band (neutral-950 via black to emerald-950) replaced with theme-consistent emerald gradient (from-emerald-600 via-emerald-700 to-emerald-950, dark corner bottom-right keeps depth); glow blobs white/10 + emerald-300/25; subtitle emerald-50/95; primary button white bg with emerald-800 text + deep-emerald glow rgba(2,60,45,...); secondary button white/60 border, white/5 bg + backdrop-blur; small print emerald-100/90.
- Bug fix: "Explore All Tests" dead anchor #tests -> #all-tests (section id renamed in Task 4).
- Verified: bun run lint clean; dev.log 200; 1440px full-band screenshot correct (white heading, emerald buttons harmony); 375px 0px horizontal overflow, buttons stack cleanly; zero console/page errors.

Stage Summary:
- Final CTA band now blends with the White + Emerald page theme (emerald gradient with subtle dark edge), anchor fixed. Rest of homepage untouched.

---
Task ID: 6
Agent: Main agent (Z.ai)
Task: Site-wide animation upgrade ("pura home page pe animations") - second motion layer on top of existing Reveal/Float/CountUp.

Work Log:
- globals.css: new keyframes + reduced-motion guards - bm-gradient-pan (living gradient on H1 emerald text), bm-ping (SVG radar ping on bell-curve marker, transform-box fill-box), bm-heartbeat (logo brain tile), bm-pulse-dot (status dot blink), bm-shine / bm-shine-emerald (button light-sweep on hover).
- motion.tsx: Reveal gained `scale` prop (0.94->1 grow-in for feature cards/CTA); new `Pop` (spring icon pop-in, staggerable); new `Tilt` (pointer-follow 3D tilt with spring, useReducedMotion disable); new `ScrollProgress` (fixed top emerald gradient bar, useScroll+spring, hidden on reduced motion).
- hero.tsx -> "use client": bell-curve SVG now animates in view - axis line + dashed mean fade, main curve draws in via pathLength (1.5s), emerald fill + grey tail fade after, marker group (line/dot/118 label) fades late + continuous bm-ping ring behind dot; H1 gradient span bm-gradient-pan; preview card wrapped in Tilt (max 4deg); "Instant result" dot bm-pulse-dot; primary CTA bm-shine + hover lift.
- navbar.tsx: motion.header entrance slide-down; logo bm-heartbeat; desktop links underline slide-in (after: scaleX); CTA bm-shine.
- tool-card.tsx: icon tile group-hover scale-110 -rotate-6. all-tools.tsx: View-all links group-hover arrow slide. quick-stats.tsx: 4 stat icons in Pop spring stagger (0/.08/.16/.24) + hover scale. final-cta.tsx: blobs now bm-drift/bm-drift-slow, Reveal scale entrance, primary button bm-shine-emerald + lift, secondary lift. faq.tsx: item hover border/shadow lift. footer.tsx: columns in subtle Reveal.
- page.tsx: added <ScrollProgress /> and wrapped app in <MotionConfig reducedMotion="user"> so all framer transform animations auto-respect OS preference (CountUp JS unaffected).
- Verified: lint clean; dev.log 200; DOM checks - scrollProgress bar present, 1 ping circle, heartbeat logo, 3 shine buttons, gradient-pan H1, 4 pop icons; 1440px screenshots (hero curve fully drawn + marker ring, QuickStats CountUp mid-flight 25->26, scroll bar visible at ~55% and 100%, CTA + footer fine); 375px 0px overflow, menu open/Escape close, FAQ opens; zero console/page errors.

Stage Summary:
- Whole homepage now has a cohesive two-layer motion system: entrance/stagger (Reveal/Pop/CountUp/SVG draw) + ambient/micro (drift/heartbeat/ping/gradient-pan/sheen/tilt/scroll-progress), all reduced-motion safe. Theme White + Emerald + Black unchanged.

---
Task ID: 7
Agent: Main agent (Z.ai)
Task: Homepage performance optimisation ("Home page bohot slow ho chuka hai, isko fast kijiye") - remove expensive rendering paths added by the Task-6 animation layer while keeping the visual design intact.

Work Log:
- Diagnosed 5 bottlenecks: (1) sticky navbar backdrop-blur-md re-blurring every scroll frame, (2) bm-gradient-pan infinite background-position animation repainting the bg-clip-text H1 at 60fps, (3) Tilt pointer-follow 3D springs on the hero preview card, (4) four large blur-3xl glow blobs animating transform scale (forces blurred-layer re-rasterization), (5) ScrollProgress useSpring running an extra rAF loop while scrolling.
- globals.css: bm-drift keyframes now translate+opacity only (no scale); deleted bm-gradient-pan keyframes/class; bm-ping slowed 2.4s->3s; new low-power media query (max-resolution 1.5dppx / update: slow) disables all ambient infinite loops; reduced-motion guards updated.
- motion.tsx: removed Tilt component entirely (pointermove spring jank source); ScrollProgress now binds raw scrollYProgress MotionValue (no spring rAF); unused imports cleaned.
- hero.tsx: Tilt wrapper removed (card keeps cheap CSS hover lift via transition-transform); H1 gradient now static (no bg-position animation); hero blobs shrunk size-96/80 blur-3xl -> size-72/64 blur-2xl.
- navbar.tsx: backdrop-blur-md removed - solid bg-background + border/shadow on scroll; header transition-all -> transition-[box-shadow,border-color]; mobile menu bg-background/95 backdrop-blur-md -> solid bg-background.
- final-cta.tsx: secondary button backdrop-blur-sm removed (bg-white/10 solid); primary transition-all -> targeted properties; blobs shrunk (size-56/64 -> size-48/56, blur-3xl -> blur-2xl).
- tool-card.tsx / learn-section.tsx / faq.tsx: transition-all -> targeted transition-[transform,box-shadow,border-color] (avoids transitioning unrelated properties; no will-change spam on 26+ cards).
- Verified: bun run lint clean; zero leftover Tilt/bm-gradient-pan/useSpring/backdrop-blur refs; agent-browser 1440px - hero identical (static gradient, curve, CountUp 118, chips, ping), scrolled navbar solid, CTA band + footer correct; DOM audit - backdrop-blur count 0, ping 1, heartbeat 1, drift 2, shine 3, scroll-progress bar present, 40 popular+category card links; rAF FPS probe during full-page programmatic scroll: 61fps (vsync-locked, no main-thread blocking); 375px - 0px horizontal overflow, hamburger menu opens, zero blur elements; zero console/page errors; dev.log GET / 200.

Stage Summary:
- Homepage animation layer now compositor-friendly: no backdrop filters, no per-frame text repaints, no pointer-spring transforms, translate-only ambient drift, spring-free scroll bar, low-power devices skip ambient loops entirely. Visual design (White+Emerald+Black, all entrance/stagger/hover animations) unchanged.
- Files touched: globals.css, motion.tsx, hero.tsx, navbar.tsx, final-cta.tsx, tool-card.tsx, learn-section.tsx, faq.tsx.

---
Task ID: 8
Agent: Main agent (Z.ai)
Task: Add hover effects across the homepage ("Abhi hover effect add kijiye") - keep them GPU-friendly after the Task-7 perf work.

Work Log:
- footer.tsx: all 16 nav links now slide right (hover:translate-x-1) + emerald color via transition-[color,translate]; footer logo tile scales 1.1 with boosted emerald glow on hover.
- navbar.tsx: logo link scales 1.03 on hover (transition-transform; heartbeat animation on the tile untouched).
- quick-stats.tsx: stat rows are now hover groups - row lifts (-2px), icon tile scales 1.1 + bg brightens via group-hover (transition-[transform,background-color] on icon, transition-transform on row).
- hero.tsx: "Explore All Tests" outline button gains lift + emerald border tint + shadow-md on hover (transition-[translate,box-shadow,border-color]).
- learn-section.tsx: category chip brightens (bg-primary/15 + border-primary/40) when its article card is hovered.
- faq.tsx: trigger question text shifts to primary emerald on hover; chevron gets transition-transform (smooth Radix rotate on open).
- tool-card.tsx: card title shifts to emerald on card hover (group-hover:text-primary).
- CRITICAL Tailwind-4 fix found during verification: translate-x-*/scale-*/-rotate-* utilities map to the CSS translate/scale/rotate individual properties (NOT transform), so arbitrary transitions must list them explicitly - replaced transition-[transform,...] with transition-[translate,...] / transition-[scale,rotate,...] in tool-card, learn-section, hero, final-cta, footer. (Built-in transition-transform already includes translate/scale/rotate in v4.)
- Verification: bun run lint clean; zero console/page errors. agent-browser headless reports (hover:none) so Tailwind 4 @media (hover: hover) gated styles cannot apply there - switched to Playwright with a desktop context (hover:hover confirmed true). Computed-style results: footer link translate 4px + emerald; tool card translate -2px + emerald title + icon scale 1.1/rotate -6deg; quick-stat row -2px + icon scale 1.1 + bg brighten; nav logo scale 1.03; FAQ trigger emerald; hero secondary btn -2px + emerald border; learn chip bg brighten; footer logo scale. Proof screenshots /tmp/pw-hover-card.png, /tmp/pw-hover-footer.png. Verification scripts persisted at scripts/verify-hover.js, scripts/verify-hover2.js.

Stage Summary:
- Every interactive element on the homepage now has a cohesive hover language (lift / slide / scale / emerald tint) built only from transform/color/shadow transitions - no perf regressions from Task 7. Tailwind-4 individual-property transition pitfall documented and fixed everywhere.

---
Task ID: 9
Agent: Main agent (Z.ai)
Task: Build the Full IQ Test page (/test) with a working interactive test and full SEO optimisation ("full iq test bala page banaye, aur seo optimize kijiye").

Work Log:
- Fixed leftover lint failure from Task 8 first: eslint.config.mjs ignores extended to scripts/**, tests/**, mini-services/**, db/** (verification scripts used require()).
- src/components/test/iq-questions.ts: 12-question bank (numeric/verbal/logic/pattern/attention/memory/spatial), easy->hard, each with options + answer index + explanation; estimateIq() maps correct count to 78-135 scale, estimatePercentile(), scoreLabel().
- src/components/test/full-iq-test.tsx (client): 3 phases - intro card (checklist + Start CTA), active test (category chip, live mm:ss timer, animated progressbar, AnimatePresence slide between questions, A/B/C/D option buttons with aria-pressed, Back/Next with disabled-until-selected, last button becomes "See my results"), results screen (CountUp score, range label, percentile line, 7 animated skill-breakdown bars, 12 collapsible per-question reviews with correct/incorrect + explanations, Retake + Explore-all-tests CTAs). Perf-safe: transform/color transitions only.
- src/components/test/test-faq-data.ts: 5 test-specific FAQs (single source for visible FAQ + FAQPage JSON-LD).
- src/app/test/page.tsx (server, SEO-first): metadata (title 56 chars "Free Online IQ Test with Instant Results | BrainMetrics", description, 10 keywords, canonical /test, OG/Twitter, robots); 3 JSON-LD (WebApplication w/ free Offer + publisher, BreadcrumbList Home>Free IQ Test, FAQPage from test-faq-data); server-rendered hero (H1 "Free Online IQ Test" + emerald gradient span), interactive test, "What this IQ test measures" (6 domain cards with copy), "How the test works" (3 steps + 4 trust bullets), FAQ (details/summary native accordion with rotating chevron), emerald final CTA band; Navbar/Footer reused; theme White+Emerald+Black + drift blob + Reveal animations consistent.
- Site-wide SEO: src/app/robots.ts (allow all + sitemap ref) and src/app/sitemap.ts (/ priority 1, /test priority 0.9). Removed conflicting public/robots.txt (Next 500 error "conflicting public file and page") - metadata route now serves robots.txt with Sitemap line.
- Verified: lint clean; /test 200; title/H1/canonical/desc(162c) correct; 5 JSON-LD types present (WebApplication, BreadcrumbList, FAQPage, Organization, WebSite); full 12-question flow via real clicks -> results (135, "Very high range", 96th percentile, 7/7 breakdown bars, 12 reviews, retake works); robots.txt + sitemap.xml 200; homepage has 7 links to /test; 375px no horizontal overflow, question card renders clean; zero console/page errors.

Stage Summary:
- /test is live: a complete, working, free IQ test experience (12 questions, instant estimated score 78-135, per-skill breakdown, explanations, retake) wrapped in SEO-optimised server-rendered content with 3 page-level + 2 site-level JSON-LD schemas, canonical, OG/Twitter tags, robots.txt and sitemap.xml.
- Files: src/app/test/page.tsx, src/app/robots.ts, src/app/sitemap.ts, src/components/test/{full-iq-test.tsx, iq-questions.ts, test-faq-data.ts}, eslint.config.mjs, removed public/robots.txt.

---
Task ID: 10
Agent: Main agent (Z.ai)
Task: Randomized 10-question engine for the Full IQ Test ("jis mai 10 questions set rahega, aur har baar naya naya set apply hoga, jissse unique ness aur jyada hoga") - replace the fixed 12-question test with a fresh random draw of 10 per attempt, keep SEO in parity.

Work Log:
- iq-questions.ts rebuilt: bank grew 12 -> 61 questions in 7 category arrays (logic/verbal/numeric/pattern 9 each, attention/memory 8 each, spatial 9), every question gained a difficulty field (1|2|3) with a 20/21/20 easy/medium/hard spread; IqQuestion type + QUIZ_SIZE=10 exported; explanations never reference option letters (safe under option shuffling).
- New buildQuizSet(): Fisher-Yates shuffle + stratified draw (3 easy / 4 medium / 3 hard via 30/30 split) -> score stays comparable across attempts; guaranteed 7-category coverage by swapping duplicate-category picks for undrawn questions of any missing category (difficulty-matched first, fallback swap if none); question order shuffled; per-question option order shuffled with answer index remapped (withShuffledOptions). Billions of possible combinations.
- full-iq-test.tsx rewired: questions state (placeholder = bank.slice(0,10), never rendered pre-start), start() now draws buildQuizSet() on EVERY attempt incl. retake; answers sized to QUIZ_SIZE; results useMemo tracks questions (deps [answers, questions], uses questions.length - fixed React Compiler preserve-manual-memoization error); review list + breakdown render the served set; intro copy "a new set every time" + "Ten questions drawn at random from our 61-question bank" + 4th checklist bullet; results note "drawn randomly from the 61-question bank - no two sets are alike"; retake button "Retake - new 10 questions".
- SEO parity: /test metadata description -> "10 fresh questions every attempt, drawn from a 60+ question bank" (148c); keywords + randomized/unique IQ test; hero badge "10 questions · new set every attempt · free forever"; hero paragraph mentions the 61-question bank; STEPS "Answer 10 fresh questions" + random-draw copy; "eight minutes"->"six minutes"; 5th trust bullet "A fresh set of 10 every attempt"; test-faq-data.ts rewritten to 6 FAQs (new #1: "Are the questions the same every time?" answer detailing random draw + reshuffled options; updated timing 4-8 min; retake answer now promotes new sets) - visible FAQ and FAQPage JSON-LD stay in parity via the single source.
- Verification: bun scripts/verify-quizset.ts (500 trials): 500/500 all-7-category coverage, 500/500 exact 3/4/3 difficulty mix, 500/500 unique set fingerprints, 0 consecutive-build collisions, correct-option text preserved through every option shuffle. bun run lint clean (after useMemo dep fix). Playwright scripts/verify-iq-flow.js (desktop ctx): title/desc/canonical/5 JSON-LD types/6-item FAQ parity/h1/badge all correct; robots.txt + sitemap.xml 200; clicked through 2 full attempts - "Question 1 of 10" progress, results score + 10 review items + 61-bank note, retake served a DIFFERENT set (3/10 overlap, different first question); 375px no overflow in intro/test/results; zero console/page errors; screenshots /tmp/iq-mobile.png, /tmp/iq-results-2.png (skill breakdown shows 7 categories summing to 10). dev.log GET /test 200. Note: browser-verification scripts' own two initial assertion bugs fixed (canonical resolves to production domain; main details selector caught FAQ items too - now #test-app scoped).
- No stale "12 questions"/"twelve" references anywhere in src (grep clean).

Stage Summary:
- /test now serves a unique 10-question test on every attempt: stratified random draw from a 61-question bank (7 categories, 3 difficulty tiers), shuffled question order AND shuffled answer options, category coverage guaranteed - retake always yields a genuinely different test, while the 3/4/3 difficulty mix keeps estimated scores comparable between attempts. All SEO surfaces (metadata, OG/Twitter, hero copy, steps, FAQ, FAQPage JSON-LD) updated in parity and re-verified.
- Files: src/components/test/iq-questions.ts (rebuilt), src/components/test/full-iq-test.tsx, src/app/test/page.tsx, src/components/test/test-faq-data.ts; new verification scripts scripts/verify-quizset.ts, scripts/verify-iq-flow.js.

---
Task ID: 11
Agent: Main agent (Z.ai)
Task: Age-group IQ test with question sets ("kam se kam 10 set questions, har ek set mein 12 questions, har baar page open karte hi naya set, 3 age groups - kids/teens/adults; pehle kids ke 10 sets") + full rebuild after workspace rollback.

Work Log:
- CRITICAL INCIDENT: workspace rolled back between sessions - src/app/test/ and src/components/test/ (all Task 9+10 files) vanished and were never in git (see root cause below); /test 404'd. All content rebuilt from worklog + in-session context.
- ROOT CAUSE FOUND (affects everything since Task 9): .gitignore line 49 had a bare `test` pattern matching ANY dir/file named test -> src/app/test/ + src/components/test/ were gitignored (why checkpoints never captured them) AND Tailwind v4 automatic content detection skipped them (it respects .gitignore) -> utilities unique to the test page (sm:grid-cols-3, lg:grid-cols-3, hover:-translate-y-px etc.) were never compiled; shared utilities masked the gap. Fixed by root-anchoring: `test` -> `/test`, `prompt` -> `/prompt` (git check-ignore now clean; verified computed grid-template-columns went 672px -> 216px 216px 216px). .next purged + dev restarted.
- New architecture: quiz-core.ts (types: QuestionCategory/IqQuestion/RawQuestion/RawSet/IqSet/AgeGroup; SET_SIZE=12; CATEGORY_LABELS; AGE_GROUPS meta; shuffle/withShuffledOptions/expandRawSet/expandRawQuestions; estimateIq/estimatePercentile/scoreLabel).
- age-sets-kids.ts: 10 authored Kids sets (Rocket, Panda, Dolphin, Tiger, Rainbow, Comet, Turtle, Penguin, Lion, Starfish) x 12 questions = 120 questions in compact tuple format, every set keeps the 2 logic / 2 verbal / 2 numeric / 2 pattern / 1 attention / 2 memory / 1 spatial mix, ages 7-12 tone, explanations reference no option letters (safe under shuffling).
- iq-questions.ts: re-exports quiz-core; 61-question general bank in tuples (teens/adults fallback) + buildQuizSet (stratified 4/4/4 easy/medium/hard for 12, all-7-category coverage via difficulty-matched swaps, order+options shuffled) + AUTHORED_SETS {kids: 10 sets, teens: [], adults: []} + pickSetFor(group, excludeId) - serves a random authored set (never repeating the previous one when an alternative exists, options reshuffled per serve) or a fresh mixed draw for groups without sets yet. Adding teen/adult sets later = just append files to AUTHORED_SETS.
- full-iq-test.tsx rebuilt: intro is now a 3-card age-group picker (Baby/GraduationCap/Users icons, ages, blurb, "10 question sets ready" vs "Fresh mixed set every time"); choosing a group instantly deals a fresh 12-question set; active/results phases unchanged (timer, progressbar, AnimatePresence slide, option buttons, CountUp score, skill breakdown, 12-item review); results show age group + set name ("Kids set 'Tiger'"); buttons: "Retake - new 12 questions" (new set, excludes last), "Change age group" (back to picker), "Explore all cognitive tests".
- /test page.tsx rebuilt: metadata/description ("Free IQ test for kids, teens and adults. 12 questions per set with a fresh set every visit...", 146c), keywords for kids/teens/adults + randomized, canonical, OG/Twitter, 3 JSON-LD (WebApplication, BreadcrumbList, FAQPage x7); hero badge "3 age groups · 12 questions per set · new set every visit"; hero copy mentions 10 kids sets/120 questions; STEPS: Pick your age group -> Answer 12 questions -> Get your estimate; trust bullet "A new set of 12 every attempt".
- test-faq-data.ts: 7 FAQs (age groups mechanics, fresh-set-every-visit, scoring, timing, retake/switch groups, what it measures, professional comparability with WISC/WAIS) - visible FAQ + FAQPage JSON-LD stay in parity via single source.
- Verification: bun run lint clean; scripts/verify-quizset.ts (21 checks): 10 sets x 12 = 120 unique-id questions, exact 2/2/2/2/1/2/1 mix in every set, 4 valid options + explanation each, no duplicate prompts, correct-option text preserved across 50 serves, options genuinely shuffle, back-to-back set exclusion holds, teens/adults fallbacks serve 12 with 7-category coverage + 4/4/4 mix, consecutive draws differ; scripts/verify-iq-flow.js: title/desc/canonical/5 JSON-LD types/7-item FAQ parity/h1/badge/robots+sitemap 200; 3 picker cards; Kids flow "1 of 12" -> results with set name; retake dealt DIFFERENT set (Starfish -> Panda, 0/12 overlap); Change-age-group returns to picker and Teens track works; 375px zero overflow on picker + in-test; zero console/page errors; picker grid verified 3 columns at 1440px (screenshot /tmp/iq-picker-final.png).
- Note: dev server needs `setsid nohup` to survive between tool calls; Tailwind requires .next purge + restart when new directories' classes are missing.

Stage Summary:
- /test is now an age-group IQ test: Kids (7-12) gets 10 hand-built sets of 12 questions (120 total, balanced 7-skill mix), Teens (13-17) and Adults (18+) work today via balanced random draws from the 61-question general bank with dedicated sets slotting in later. Every page open/attempt deals a new set with reshuffled options. SEO surfaces (metadata, OG/Twitter, canonical, JSON-LD x3, hero, steps, FAQ x7) updated in parity.
- Files: src/components/test/{quiz-core.ts, age-sets-kids.ts, iq-questions.ts, full-iq-test.tsx, test-faq-data.ts}, src/app/test/page.tsx, .gitignore (root-anchored /test + /prompt), scripts/{verify-quizset.ts, verify-iq-flow.js}.

---
Task ID: 11 (phase 2 + 3)
Agent: Main agent (Z.ai)
Task: User order — kids sets pehle (done), phir TEENS ke apne 10 sets, last mein ADULTS ke apne 10 sets. Har group ka bank completely separate; kids sets teens/adults mein kabhi na dikhna chahiye.

Work Log:
- Authored src/components/test/age-sets-teens.ts: 10 sets (Circuit, Nova, Pixel, Vector, Cipher, Quasar, Matrix, Photon, Zenith, Cascade) x 12 = 120 brand-new teen-level questions (school-smart: percentages, syllogisms, letter/number series, Fibonacci, speed/discount problems, mirror/rotation, working-memory spans). Same 2 logic/2 verbal/2 numeric/2 pattern/1 attention/2 memory/1 spatial mix per set.
- Authored src/components/test/age-sets-adults.ts: 10 sets (Sage, Oracle, Enigma, Apex, Prism, Vertex, Axiom, Lumen, Onyx, Meridian) x 12 = 120 brand-new adult-level questions (modus tollens, family-relation riddles, painted-cube/net/angle items, train speeds, compound reasoning, n^n series, trap attention items). Same per-set mix.
- Rewrote iq-questions.ts: AUTHORED_SETS now wires all three banks (idBases kids=0, teens=100, adults=200 -> globally unique ids, reserved ranges per group); REMOVED the 61-question GENERAL_BANK_RAW + IQ_QUESTIONS + GENERAL_BANK_SIZE + buildQuizSet fallback entirely (dead code, "sab ka alag alag set" guaranteed at data layer); pickSetFor simplified to authored-only with back-to-back exclusion; added TOTAL_SET_COUNT (30) and TOTAL_QUESTION_COUNT (360) exports.
- Copy parity: page.tsx hero now states "Each group has its own bank of 10 hand-built sets — 30 sets and 360 questions in total — and no two groups share a single question"; STEPS step 1 rewritten (separate banks per group); trust bullet "10 unique sets per age group"; PAGE_DESCRIPTION updated ("Each age group gets its own 10 hand-built sets of 12 questions"). test-faq-data.ts FAQ #1/#2/#5 rewritten — no more "general bank" mention; FAQPage JSON-LD stays in parity via single source.
- Rewrote scripts/verify-quizset.ts: 54 checks across all 3 groups — 10 sets x 12 each, exact 2/2/2/2/1/2/1 mix, valid answers/4 options/explanations, unique ids within reserved ranges, no duplicate prompts, CROSS-GROUP SEPARATION (0 shared prompts kids<->teens, kids<->adults, teens<->adults; 360 globally unique), option shuffle integrity x50 serves per group, back-to-back exclusion, all 10 sets reached in 400 draws per group, 400 teen/adult serves contain zero kids sets.
- Extended scripts/verify-iq-flow.js: all 3 cards show "10 question sets ready"; full 12-question Teens run + full Adults run in browser; served set names validated against each group's list; browser-level leak checks (0 kids questions in teens run, 0 kids/teens questions in adults run); results label "Teens set"/"Adults set" asserted.
- Results: bun verify-quizset.ts = 54/54 PASS; node verify-iq-flow.js = ALL PASS (SEO title/desc/canonical/5 JSON-LD/7 FAQ parity, Kids attempt + retake Dolphin->Lion 0/12 overlap, Teens served Photon, Adults served Oracle, 375px zero overflow, zero console errors); bun run lint clean; dev.log clean (GET /test 200, fast compiles).

Stage Summary:
- Task 11 COMPLETE: all three age groups now run on their own dedicated hand-built banks — Kids 10 sets / Teens 10 sets / Adults 10 sets, 12 questions each, 360 questions total, zero question sharing between any two groups (verified in unit + browser). Random set per page open/attempt, no immediate repeat on retake, options reshuffled every serve.
- Files: src/components/test/{age-sets-teens.ts (new), age-sets-adults.ts (new), iq-questions.ts (rewritten), test-faq-data.ts}, src/app/test/page.tsx, scripts/{verify-quizset.ts, verify-iq-flow.js}.

---
Task ID: 23
Agent: Main agent (Z.ai)
Task: Build the Processing Speed Test page (/test/processing-speed) - "Abhi 'Processing speed test' Page banaye".

Work Log:
- VERIFY-BEFORE-BUILD revealed a MAJOR workspace rollback: all 8 cognitive test pages from Tasks 12-22 (matrix, digit-span, reaction-time, visual-memory, stroop, chimp-test, mental-rotation, n-back) are gone from BOTH disk and git history (history now = Initial commit + UUID checkpoint commits only; worklog reset to Task 11 era). Survived: src/config/tools.ts (26-tool registry intact, processing-speed already in POPULAR_TOOL_IDS -> homepage card linked to a 404), homepage components, motion.tsx, and the concurrent session's active IQ-test work (uncommitted - left untouched throughout).
- Built src/components/test/processing-speed-core.ts: Symbol-Digit Coding engine (WAIS Processing Speed paradigm). buildCodingKey (6 distinct digits 1-9 x shuffled glyphs, pad order shuffled independently, mapping re-randomised every attempt), mulberry32+shuffle deterministic RNG, nextSymbol (no 3x consecutive repeats), recordTrial, computeEpochs (6 x 15s buckets), bestStreakOf, erf/normalCdf, rateToPsi (rate=correct/min, mean 25 SD 6 -> PSI 100+15z, soft rate clamp 0-60, PSI clamp 55-145), psiToPercentile, gradeForPsi (5 tiers), scoreSession with anti-gaming validity rules (<10 attempts invalid, <60% accuracy invalid - chance is ~17%), formatClock.
- Anchor honesty fix: initial RATE_MEAN 28 failed population simulation (median casual clicker ~2.4s/item = 24/min) -> recalibrated to 25; sim now yields mean rate 24.15/min, mean PSI 97.96, SD 14.68.
- Built src/components/test/processing-speed.tsx (client): intro (example key, rules) -> countdown (key visible, 3-2-1) -> 90s sprint (live timer+bar, key strip, big symbol stage, 6-button pad grid-cols-3 mobile/6 desktop, flash feedback, keyboard digits, advance-on-every-response so errors cost time only) -> results (PSI CountUp, grade chip, percentile, 6-stat grid, animated throughput bars, pace insight, retake/full-IQ CTAs, invalid-card path with raw stats). ?quick=1 -> 15s sprint for automated tests (documented hook). data-testids ps-*.
- Built processing-speed-faq-data.ts (6 FAQs, single source) + src/app/test/processing-speed/page.tsx (server): metadata (49c title, 154c description, 10 keywords, canonical), JSON-LD x3 (WebApplication free offer, BreadcrumbList BrainMetrics>Processing Speed Test, FAQPage parity), hero, Suspense-wrapped test, science cards, steps, tips, FAQ accordion, final CTA. Fixed: root <motion.div> in a server component -> 500 (createMotionComponent from server) -> plain <div>.
- UX fixes found via browser verification: (1) after the sprint the user's scroll stayed mid-card so the PSI header was ABOVE the viewport (CountUp never fired) -> scrollToApp helper (sticky-nav clearance -88px, reduced-motion aware) on start + finish; (2) countdown key was off-screen (scroll happened only at sprint start) -> moved alignment to start(); (3) throughput bars invisible (height % inside auto-height flex column collapses) -> pixel heights.
- Verification: scripts/verify-processing-speed-core.ts 107/107 ALL PASS (key invariants x300 seeds, stream no-triple/uniform, scoring paths, 60% boundary exactly valid/59% invalid, PSI/percentile math+monotonicity, grades, 500-user population sim, 3-profile pipeline coherence). scripts/verify-processing-speed-flow.js ALL PASS TWICE: SEO surface (title/desc/canonical/JSON-LD x3/FAQ 6+6 parity/h1), Run1 valid sprint (193 pad + 4 keyboard answers, PSI 145, accuracy 100%, 6 epoch bars, insight), Run2 retake (key mapping changed = anti-memorisation), Run3 random mash -> invalid + "not scored" + accuracy reason (anti-gaming), 375px no overflow intro/active/results, zero console/page errors. bun run lint clean. Routes 200: /, /test, /test/processing-speed, robots.txt, sitemap.xml. Homepage renders the processing-speed card (2 links). Sitemap +0.8 entry added. Screenshots /tmp/ps-{intro,countdown,active,results,full,375-intro,375-active,375-results}.png reviewed.
- NOTE for future tasks: scripts/audit-internal-links.js is gone with the rollback; cross-links on this page intentionally point only to live routes (/, /test). The other 7 tool pages + related-tests wiring + audit script need rebuilding in future tasks.

Stage Summary:
- /test/processing-speed is LIVE: a complete 90-second Symbol-Digit Coding sprint (randomised key each attempt, pad + keyboard input, accuracy-safe throughput scoring anchored to a PSI 100/SD 15 population model, 6-slice pace profile) wrapped in SEO-optimised server content with 3 JSON-LD schemas, canonical, sitemap entry and homepage card wiring. All gates green: 107/107 unit, flow ALL PASS x2 (incl. mash-rejection proof), lint clean, 375px clean, zero console errors.
- Files: src/components/test/{processing-speed-core.ts, processing-speed.tsx, processing-speed-faq-data.ts}, src/app/test/processing-speed/page.tsx, src/app/sitemap.ts, scripts/{verify-processing-speed-core.ts, verify-processing-speed-flow.js, screenshot-processing-speed.js}.

---
Task ID: 23-closure
Agent: main (session continuation)
Task: "Abhi preview dijiye" - verify live state and hand over preview for the Processing Speed page built by a concurrent session.

Work Log:
- VERIFY-BEFORE-BUILD: Task 23 was already completed and committed by a concurrent session (dbc5631 "Processing Speed Test page..." + newer UUID checkpoint b277f89). No rebuild needed.
- Found 7 processing-speed files flagged M with 0 insertions/0 deletions = mode-only changes (100644 -> 100755). Committed as 3e9cb96 to keep the tree clean; content identical to dbc5631.
- Runtime checks: routes /, /test, /test/processing-speed, /sitemap.xml, /robots.txt all 200; dev server auto-managed (Ready, dev.log clean).
- Re-ran scripts/verify-processing-speed-flow.js on the current build: ALL PASS (valid sprint PSI 145 + 100% accuracy + 6 epoch bars + pace insight; retake key re-randomised; mash -> invalid + "not scored"; 375px no overflow; zero console errors).
- Preview link discovery: bot-id not present in env, process environ, filesystem, or worklog; DNS wildcard confirmed (all candidate ids -> same ALB) and HTTP probes of session/chat/hostname-derived preview hosts all 404. Conclusion: direct preview URL not derivable from inside the sandbox - user directed to the Preview Panel (right side) + "Open in New Tab".

Stage Summary:
- Task 23 remains CLOSED with all original gates green; current-build re-verification ALL PASS, tree clean at 3e9cb96.
- Workspace still in post-rollback state: only /, /test, /test/processing-speed live; other tool pages + related-tests wiring + audit-internal-links.js need rebuilding in future tasks.

---
Task ID: 24
Agent: main (+ subagents 24-a chimp UI, 24-b n-back UI)
Task: "Kal aapne sab popular pages create kiye, aaj sab 404 error aa rha hai, please check carefully" - diagnose and fix the mass 404s on popular tool pages.

Work Log:
- Diagnosed: workspace rollback had wiped Tasks 12-22 pages; a concurrent rebuild session restored batch 1 (commit 48f6f06: matrix-reasoning, digit-span, reaction-time, visual-memory + infra 3d10249: related-tests/audit) and left untracked stroop-test + mental-rotation rebuilds, then went silent ~8 min (dead) with cores-only for n-back/chimp/full-iq.
- Verified live 9 routes (Playwright smoke: ALL PASS, zero console errors, 375px clean) while polling the concurrent session; after 3 polls with zero file/commit activity, declared it dead and took over the remaining 3 pages.
- 24-a (subagent, full-stack-developer): audited + completed src/components/test/chimp-test.tsx (648L, ct-* testids, quick prop, TapTiming into applyTap, bot-flag honest chip), chimp-test-faq-data.ts (6 FAQs), src/app/test/chimp-test/page.tsx (364L SEO, JSON-LD x3), scripts/verify-chimp-test-flow.js (314L). Flow: solved-run IQ 100/accuracy 95%, wrong-tap run IQ 59 non-NaN, 375px clean, zero console errors - ALL PASS.
- 24-b (subagent, full-stack-developer): audited + fixed n-back.tsx (896L, added NBackTestFromQuery useSearchParams wrapper), page.tsx (360L, sync server + Suspense), verified faq-data (6 FAQs) + verify-n-back-flow.js (309L). Flow: valid run IQ 99, mash run IQ 67 (anti-gaming), 375px clean, zero console errors - ALL PASS. n-back core unit suite: 95 PASS.
- Main agent: built src/app/test/full-iq/page.tsx (364L - hero, Suspense-wrapped FullIqTest, science/steps/tips/FAQ from TEST_FAQ_ITEMS single source, RelatedTests, CTA, JSON-LD x3, canonical). Full-iq kit (full-iq-test.tsx 476L + iq-questions + age-sets x3 + quiz-core 152L) verified via verify-quizset.ts ALL PASS.
- Wiring completed: sitemap.ts 5->10 tool entries; related-tests.tsx LIVE_TOOL_IDS 5->10; audit-internal-links.js LIVE_PAGES 7->12. .gitignore + tool-results/.
- Lint gate: 16 react-hooks/refs errors in n-back.tsx (blocksRef/blocksIdxRef/responsesRef read during render) -> fixed with render-readable state mirrors (blocks state + responseLog) in 7 edits -> lint CLEAN. Flow re-run ALL PASS after fix.
- Gates final: 12/12 routes 200; unit (n-back 95 PASS, quizset ALL PASS); flows chimp+n-back ALL PASS; lint CLEAN; audit MESH COMPLETE; browser smoke 12/12 ALL PASS (200, h1, JSON-LD, 375px zero overflow, zero console errors).

Stage Summary:
- ALL 10 popular tool pages now LIVE: /test/{full-iq, matrix-reasoning, digit-span, reaction-time, visual-memory, stroop-test, mental-rotation, chimp-test, n-back, processing-speed} + / + /test. The user-reported mass 404 is fixed.
- Link mesh closed: every internal link on every live page resolves (MESH COMPLETE). Sitemap 12 entries. RelatedTests shows 10-tool registry.
- tool-results/ is system junk - gitignored, not committed.

---
Task ID: 25
Agent: main
Task: "Abhi aisa kijiye jisse, jitna bhi pages aapne create kiya hai woh kisi bhi karan se delete na ho jaye" - build a multi-layer protection system so created pages can never be lost again.

Work Log:
- State check: Task 24 commit d7dba75 intact, all 10 tool pages on disk; 58 tracked files had mode-only changes (100644->100755, 0 insertions/deletions) + tool-results/ junk was tracked despite .gitignore. Fixed: untracked tool-results/, committed as clean baseline 88d76b4 (then auto-snapshot 817fe7d).
- Built scripts/backup-project.sh (Layer 2+3): auto-commits dirty tree first (never bundle uncommitted work) -> git bundle create --all (FULL history in one file) -> git bundle verify -> in-project copy to /home/z/my-project/backups/ -> full working-tree tarball (excl node_modules/.next/.git/backups/tool-results) -> OUT-of-project copies in /home/z/brainmetrics-backups/ (survives a project-dir-level workspace rollback) -> LATEST pointer -> retention newest 10 per kind per location.
- Built scripts/restore-project.sh: --list, --from-bundle [stamp] [--in-place], --from-tree [stamp] [--in-place]. Default restore is ALWAYS non-destructive (staging dir /home/z/restore-<stamp>/); --in-place is the explicit dangerous flag (rsync --delete over working files + .git replaced from bundle, keeps node_modules/.next).
- Wrote BACKUP-RESTORE.md: 5-layer protection table, what a backup contains, 3 restore scenarios (single file deletion / project-dir rollback / files-only), automation health checks, and the recommended final layer (external git remote - needs user-provided GitHub private repo + token for full sandbox-loss protection).
- Automation (Layer 4): .git/hooks/post-commit now bundles history to /home/z/brainmetrics-backups/repo-latest-commit.bundle on EVERY commit (proven: fired on 817fe7d); 30-min background auto-backup loop started (PID in /home/z/brainmetrics-backups/loop.pid, logs to auto-backup.log).
- backups/ added to .gitignore (bundles must not nest inside themselves).
- First full backup 20261022-063810: repo bundle 5.5MB + tree tarball 45MB, verified via git bundle verify.
- RESTORE VERIFICATION both PASS: git clone from bundle -> all 10 test pages + latest commit restored; tarball extract -> all pages + worklog + backup scripts present. Verify dirs cleaned up.
- Live sanity after all changes: 12/12 routes 200 (/, /test + 9 tool pages... full-iq, matrix-reasoning, digit-span, reaction-time, visual-memory, stroop-test, mental-rotation, chimp-test, n-back, processing-speed).

Stage Summary:
- Pages are now protected by 4 active layers: (1) git commits, (2) in-project bundles, (3) OUT-of-project bundles+tree in /home/z/brainmetrics-backups/, (4) automation (post-commit hook + 30-min loop). Layer 5 (off-site git remote) documented, awaits user credentials.
- Recovery command if anything ever breaks: bash /home/z/my-project/scripts/restore-project.sh --from-bundle --in-place (or --from-tree --in-place).
- Files: scripts/{backup-project.sh, restore-project.sh}, BACKUP-RESTORE.md, .git/hooks/post-commit, .gitignore (+backups/).

---
Task ID: 26
Agent: main
Task: "Abhi aap 'working memory test' Page banaye" - build the Working Memory Test page at /test/working-memory.

Work Log:
- VERIFY-BEFORE-BUILD: no concurrent session had touched working-memory (git log clean, no files, registry entry at tools.ts:147 unused). Chose the WAIS Letter-Number Sequencing paradigm after checking siblings - visual-memory=Corsi, digit-span=fwd/bwd digits, n-back=letter updating - so "hold + mentally re-sort" juggling is genuinely distinct.
- Built src/components/test/working-memory-core.ts: mixed digit+letter sequences (letters C F H K L Q R S T, digits 1-9, all distinct within a sequence), mixForLevel (even levels balanced, odd 50/50 extra), display order shuffled to NEVER equal the sorted answer (anti-parrot), two-stream grading (digits ascending, letters alphabetical), submitAttempt anti-gaming (submit-before-show / empty -> invalid, numbers-only valid but letter stream failed), span + 0.5 partial-credit bonus (one-stream save at the discontinue level; flawless full clear of level 9 also earns +0.5), erf-based normal CDF -> IQ 100/SD 15 clamp 55-145, 5-tier grades, mulberry32+shuffle deterministic RNG, quick mode (start level 5, 1 attempt/level, 450/120ms).
- Calibration journey (verify script's 1000-user sim, capacity-based logistic model): initial constants produced sim IQ 113-115 -> steepened the psychometric curve (sigmoid slope 0.55->0.3, capacity SD 1.2->1.0) and discovered the top-scale bug: a perfect run (span 9, no boundary above) could only reach IQ 125, leaving "Exceptional" unreachable -> added the flawless-full-clear +0.5 rule (max IQ now 131) and set SPAN_MEAN 7.0 / SPAN_SD 1.2 (sim now: mean IQ ~100, median 100, SD ~17). Two test-script bugs also fixed (double rng consumption on mixForLevel; string-vs-number JSON compare).
- Built src/components/test/working-memory.tsx (~700L): intro with worked example (R 7 C 2 -> 2 7 / C R), countdown, display stage (engine-paced elements, progress dots), two-stage input with BOTH pads always mounted (numbers 1-9 row, letters alphabetical row), chips rows per stream with empty slots, undo/clear/submit, keyboard auto-switching (digit/letter keys land on their own pad, Backspace undoes active stream, Enter submits), feedback with per-stream notes, results (IQ CountUp, grade, percentile, span/levels/one-stream-saves grid, +0.5 bonus note, colour-coded ladder incl. amber one-stream saves, quick note, retake/CTA). Fixed config.attemptsPerLength -> attemptsPerLevel typo pre-lint.
- Built working-memory-faq-data.ts (6 FAQs single source) + src/app/test/working-memory/page.tsx (metadata 77c title/159c desc? (checked in flow), canonical, JSON-LD x3 from single source, hero, Suspense-wrapped test, 3 science cards, 3 steps, 4 tips, FAQ accordion, CTA, RelatedTests).
- Wired: sitemap.ts +1 entry (11 tool entries), related-tests.tsx LIVE_TOOL_IDS 10->11, audit-internal-links.js LIVE_PAGES 12->13.
- Gates: bun scripts/verify-working-memory-core.ts = 77/77 ALL PASS (structure 2400 seqs, anti-parrot, grading, anti-gaming, span/bonus boundaries, IQ anchors/clamps/monotonicity, grades, floor honesty, 1000-user calibration sim, seeded pipeline). node scripts/verify-working-memory-flow.js = ALL PASS TWICE (SEO surface, golden path IQ 131/Exceptional/span 9/bonus note/ladder, undo exercise, retake re-randomised, nines-only -> span 0 + IQ 55 + percentile 1 + Building, 375px clean intro/display/results, zero console errors). bun run lint CLEAN. node scripts/audit-internal-links.js = MESH COMPLETE. Routes: 13 pages + sitemap.xml all 200.
- Committed fdd5524; protected backup 20261022-070307 (bundle 6MB + tree 45MB) per the Task 25 protection system.

Stage Summary:
- /test/working-memory is LIVE: WAIS-style letter-number sequencing with honest two-stream scoring, partial credit, calibrated IQ scale and full anti-gaming. 11 tool pages + / + /test = 13 live routes; link mesh closed; sitemap 13 entries.
- Files: src/components/test/{working-memory-core.ts, working-memory.tsx, working-memory-faq-data.ts}, src/app/test/working-memory/page.tsx, scripts/{verify-working-memory-core.ts, verify-working-memory-flow.js}, sitemap.ts, related-tests.tsx, audit-internal-links.js.

---
Task ID: 26-closure
Agent: main
Task: Re-verify Working Memory Test page (built by concurrent session, commit fdd5524) after session continuation; clean residual mode-noise.

Work Log:
- VERIFY-BEFORE-BUILD found Task 26 already complete: commit fdd5524 (page) + a42837b (worklog). Uncommitted diff was mode-only (100644->100755, 0 content change) on 7 files - known sandbox artifact.
- Re-ran all gates fresh: core verify 77/77 ALL PASS; flow verify ALL PASS (fresh run; 2x recorded pre-commit by builder); bun run lint CLEAN; audit-internal-links MESH COMPLETE; 13 pages + sitemap.xml all HTTP 200.
- Committed mode-noise cleanup as cd2e9e5 (post-commit hook fired, project-external bundle refreshed).

Stage Summary:
- Task 26 CLOSED: /test/working-memory live and verified, 13 pages + sitemap all 200. Note: flow run 2 was interrupted by user's next instruction (canceled); gate satisfied by builder's recorded 2x ALL PASS + 1 fresh run.

---
Task ID: 27
Agent: main
Task: "Abhi 'sequence memory test' page banaye" - build the Sequence Memory Test page at /test/sequence-memory.

Work Log:
- VERIFY-BEFORE-BUILD: no concurrent session had touched sequence-memory (no files, no worklog entry). Registry entry pre-existed at tools.ts:157 (same pattern as working-memory) - no tools.ts edit needed since it is not a POPULAR_TOOL_ID.
- Differentiated from siblings deliberately: visual-memory (Corsi) = new pattern every level + 2 lives + speed-weighted composite; sequence-memory = ONE prefix-stable run sequence growing +1 tile per level, single life (one wrong click ends), PURE span scoring (no speed/luck component), doubles allowed but triples never.
- Built src/components/test/sequence-memory-core.ts: appendTile/buildRunSequence (prefix-stable, no-triple invariant), gradeClick, speedForLevel (620->320ms floor), erf-based spanIq (anchor 7.4/SD 1.5, clamp 55-145, span 11 -> IQ 136 Exceptional reachable, span 0 -> floor 55), 5 grades, scoreRun (span/deepest/tilesCorrect/tilesShown/ladder).
- Calibration journey (1000-user sim, single-life logistic model, k=0.65): initial MU_BASE 7.9/K 0.9 gave sim IQ 94.04/SD 19.09 (span offset misestimated) -> MU_BASE 8.1 + steeper K 0.65 + slope 1.4 -> sim mean IQ 99.34, SD 17.50, median 100, mean span 7.33, 13 distinct spans. Two test-expectation bugs fixed (spanIq(8)=106 not 104, spanIq(10)=126 not 124 - engine was right; quick-contract test data needed a cleared L1 before failed L2).
- Built sequence-memory.tsx (~600L): intro with growth preview, countdown, engine-paced playback with progress chip + placed/N, keyboard 1-9 tile mapping (a11y), success ring -> appendTile -> next level, wrong click reveals expected tile then results (span/iq CountUp, grade, percentile, wrapped ladder, 4-stat grid incl. run time, retake/CTA). ?quick=1 = timing-only test mode.
- Built sequence-memory-faq-data.ts (6 FAQs, incl. explicit "how is this different from Visual Memory" answer) + page.tsx (metadata 140c desc, canonical, JSON-LD x3 single-source, hero, Suspense test, 3 science cards, 3 steps, 4 tips, FAQ accordion, RelatedTests, CTA).
- Wired: sitemap.ts +1 (13 tool entries), related-tests.tsx LIVE_TOOL_IDS 11->12, audit-internal-links.js LIVE_PAGES 13->14.
- Flow-script robustness lessons (2 debugging rounds): (1) quick-mode lit window (150ms) was uncatchable by 2-roundtrip polling + AnimatePresence mount lag -> single-evaluate watcher (~30ms/iter) + widened quick timings (220/80ms); (2) retake click keeps sm-results in DOM during its 400ms exit -> watcher broke on results immediately; fixed by waiting for unmount before watching. Watcher starts immediately after click (polls through countdown) rather than after waitForSelector.
- Gates: bun scripts/verify-sequence-memory-core.ts = 112/112 ALL PASS (constants, RNG, prefix-stability 500 seeds, doubles-allowed/no-triples, distribution, grading, timing, anchors, percentile, grades, golden/floor/deep scoreRun paths, pipeline coherence, 1000-user sim, quick contract). node scripts/verify-sequence-memory-flow.js = ALL PASS x3 (SEO surface, golden path via KEYBOARD level-1 recall -> span 5/IQ 76/Building/ladder 1-5+6F, retake fresh tile, playback input-lock ignored + prefix-stable + floor IQ 55 percentile 1, 375px x3 phases, zero console errors). bun run lint CLEAN. audit MESH COMPLETE. 14 pages + sitemap.xml all 200.
- Committed 4685d68; post-commit hook fired (repo-latest-commit.bundle refreshed) per Task 25 protection system.

Stage Summary:
- /test/sequence-memory is LIVE: classic growing-sequence game with prefix-stable staircase, single-life honesty, pure span scoring and calibrated IQ scale. 12 tool pages + / + /test = 14 live routes; link mesh closed; sitemap 14 entries.
- Files: src/components/test/{sequence-memory-core.ts, sequence-memory.tsx, sequence-memory-faq-data.ts}, src/app/test/sequence-memory/page.tsx, scripts/{verify-sequence-memory-core.ts, verify-sequence-memory-flow.js}, sitemap.ts, related-tests.tsx, audit-internal-links.js.

---
Task ID: 28
Agent: main (Z.ai)
Task: "Word memory" - build the Word Memory Test page at /test/word-memory (old/new verbal recognition paradigm)

Work Log:
- Verify-before-build: word-memory absent everywhere (git log, ls, worklog) - genuine new build; noted concurrent session had already landed Task 27 sequence-memory (4685d68) and its closure (b98c8b9).
- Built src/components/test/word-memory-core.ts: pure recognition engine - 200+ curated word pool (prefix/plural-safe stems), mulberry32 + Fisher-Yates, buildWordMemorySession (3 rounds 8/12/16, balanced targets+foils, all 72 words unique per session), Acklam probit, log-linear dPrime, memoryIndex (accuracy-only, ACC_MEAN 0.76/SD 0.08 -> IQ scale clamp 55-145), iqToPercentile, 5 grades, scoreSession (item-weighted aggregates + per-round stats + avg RT).
- Anti-gaming by design: balanced streams mean mash-OLD and mash-NEW both land exactly at 50% -> IQ 55 floor; d' reported as science stat but deliberately NOT the score; no speed component.
- Built word-memory.tsx (~640L): intro with static judgement preview, 3-2-1 countdown, engine-paced STUDY (word cards, fixed timing), interlude countdown (filled delay), RECOGNIZE stream with I-saw-it / It's-new buttons + A/L keyboard, per-response feedback flash, results (accuracy + verbal memory index CountUps with data-final, grade, percentile, round-by-round bars, 4-stat grid, d' line, retake/CTA). ?quick=1 = timing-only test mode. Fixed react-hooks/refs lint: session mirrored into state for render-time reads; fixed advance/beginStudy declaration order.
- Built word-memory-faq-data.ts (6 FAQs single-source) + app/test/word-memory/page.tsx (metadata 152c desc, canonical, JSON-LD x3 parity, hero, Suspense test, 3 science cards, 3 steps, 4 tips, FAQ accordion, RelatedTests, CTA).
- Unit gate: bun scripts/verify-word-memory-core.ts = 125/125 ALL PASS (constants, RNG, pool integrity incl. prefix/plural scans, session invariants x400 seeds, probit anchors, erf/normalCdf, dPrime properties, memoryIndex calibration, grades, perfect/mash/half-forget scorings, empty+null-rt edges, 1000-user sim, sensitivity-drives-score sanity, pipeline coherence x50 seeds). Fixed TDZ shadowing bug (local const dPrime) found by the harness.
- Flow gate: node scripts/verify-word-memory-flow.js ALL PASS x2 (SEO surface incl. JSON-LD x3 + FAQ parity; golden path @375px via CONTINUOUS study watcher -> acc 100/IQ 145/Exceptional/pct 99/d'=4.4/bars 100x3/hits 36 CR 36 FA 0; rogue-input lock during study; retake fresh-word check; mash-NEW -> acc 50/IQ 55/Building/pct 1/d'=0; zero console errors). Debug journey: watcher initially missed round-1 first word (late waitForSelector) and cross-round contamination from exiting wm-word elements - fixed with a continuous wm-study-word-only watcher started at CTA click; app itself was verified correct (all 8 study words play).
- Wiring: sitemap.ts + related-tests.tsx LIVE_TOOL_IDS + audit-internal-links.js LIVE_PAGES (tools.ts catalog entry pre-existed with icon Type).
- Gates: bun run lint CLEAN. audit MESH COMPLETE. 15 routes + sitemap.xml all 200 (word-memory included). Screenshots reviewed @375 + 1440 (intro/study/recognize/results).
- Committed; post-commit hook fired (repo-latest-commit.bundle refreshed) per Task 25 protection system.

Stage Summary:
- /test/word-memory is LIVE: classic old/new word-recognition test with balanced streams, accuracy-only honest scoring, d' science stat and calibrated IQ scale. 13 tool pages + / + /test = 15 live routes; link mesh closed; sitemap 15 entries.
- Files: src/components/test/{word-memory-core.ts, word-memory.tsx, word-memory-faq-data.ts}, src/app/test/word-memory/page.tsx, scripts/{verify-word-memory-core.ts, verify-word-memory-flow.js, screenshot-word-memory.js}, sitemap.ts, related-tests.tsx, audit-internal-links.js.

---
Task ID: 33
Agent: main
Task: Static export build + Hostinger deployment package (user chose "Option 1" for WordPress publishing)

Work Log:
- Feasibility checks: no middleware, no next/image, no server-only APIs; 5 useSearchParams components all Suspense-wrapped; test pages have zero db/api dependencies
- Adapted next.config.ts: BUILD_STATIC=1 env switches to output:"export" + trailingSlash:true + images.unoptimized (default build stays standalone)
- Added export const dynamic="force-static" to api/route.ts, robots.ts, sitemap.ts for export compatibility
- Wrote scripts/build-static.sh; BUILD_STATIC=1 bunx next build -> out/ (14 index.html: / + /test + 12 subtests)
- DISCOVERED ENVIRONMENT ROLLBACK: repo rewound to Task 28 (word-memory) — commits d04c457 (sustained-attention), f65ed9f (go-no-go), short-term-memory, spatial-memory GONE from git objects + reflog ends at Task 28 amend; verify scripts for those 4 tasks also gone. Built ZIP from current consistent 13-page state
- Verified static site via python http.server: 9 routes 200, assets resolve
- Wrote scripts/verify-static-export.js (Playwright): 7/7 PASS incl. mobile 375px overflow=0 and client-side Link navigation with RSC payloads
- Packaged download/brainmetrics-static.zip (1.6MB, 84 files, includes RSC .txt payloads) + download/HOSTINGER-UPLOAD-GUIDE.txt (hPanel steps, subdomain strategy, WordPress iframe embed code)
- Killed temp server; committing static-export infra

Stage Summary:
- DELIVERABLE: download/brainmetrics-static.zip + HOSTINGER-UPLOAD-GUIDE.txt — user uploads via hPanel File Manager to subdomain public_html, extract, live
- Static export infra is permanent: BUILD_STATIC=1 bash scripts/build-static.sh regenerates anytime
- OPEN ISSUE: environment rollback lost Tasks 29-32 (4 test pages: spatial-memory, short-term-memory, sustained-attention SART, go-no-go). Rebuild needed if user wants them in the static package. SART full spec survives in conversation summary

---
Task ID: 34 (Task A of 5-page rebuild)
Agent: main
Task: Rebuild Pattern Memory Test page at /test/pattern-memory (lost in environment rollback)

Work Log:
- Built pattern-memory-core.ts: 6 independent rounds on 5x5 board, patterns grow 3->8 tiles while flash shrinks 1400->700ms and peek budget drains [2,2,1,1,0,0]; drawPattern uses randomized BACKTRACKING (rejection sampling cannot find size-8 min-spacing-2 patterns - found during verify) + 3x3 anchor-grid fallback; quality rules: no two cells chebyshev-adjacent, no single-line patterns; scoring = per-round (hits-wrong)/size floored 0, mean of 6 vs anchors 0.60/0.13, IQ 55-145, grades Fading/Average/Sharp/Very sharp/Photographic
- Built pattern-memory.tsx (~770L): intro w/ board preview, countdown, show/recall/feedback states, peek re-flash, submit grading w/ hit/missed/wrong colors, results w/ CountUp IQ + 6 round bars + 4-stat grid + retake; data-on="1" ONLY during show (anti-cheat), data-phase machine hooks, quick=1 timings; fixed react-hooks/immutability by reordering callbacks (beginShow before beginFeedback)
- Built faq-data (6 FAQs) + page.tsx (metadata, canonical, JSON-LD x3, hero, 3 science cards, 3 steps, 4 tips, FAQ, RelatedTests, CTA)
- Wiring: sitemap.ts, related-tests.tsx LIVE_TOOL_IDS, audit-internal-links.js LIVE_PAGES
- Verify: core 70/70 ALL PASS; flow x3 ALL PASS (fixed: canonical check, text parsing readFirstInt/readPercentile, waitForRunStart gate for retake path - AnimatePresence exit race, double-submit guard, progress in snapshot); lint clean; MESH COMPLETE (18 live routes); screenshots pm-{intro,board,results}.png reviewed
- Distinct positioning: visual-memory = cumulative survival ladder w/ speeding clock; pattern-memory = independent rounds w/ decaying peek budget; spatial-memory = symbol-location binding (next)

Stage Summary:
- /test/pattern-memory LIVE: 14 live tool pages (15 live routes incl. / + /test). 4 pages remain: spatial-memory, short-term-memory, sustained-attention, go-no-go

---
Task ID: 35 (Task B of 5-page rebuild)
Agent: main
Task: Rebuild Spatial Memory Test page at /test/spatial-memory (lost in environment rollback)

Work Log:
- Built spatial-memory-core.ts: symbol-location PAIRED ASSOCIATES - 5 rounds, grids grow 3x3->5x5, symbols 3->7 (TOTAL_ITEMS 25); cells drawn via backtracking with pairwise manhattan >= 2; 26-glyph BMP symbol pool (no emoji plane, no repeats per session); scoring = per-round exact placements/items, mean vs anchors 0.62/0.12 (SD tuned from 0.14 so perfect run reaches 145), IQ 55-145, grades Scattered/Average/Anchored/Very sharp/Cartographer; re-place semantics (last placement wins)
- Built spatial-memory.tsx (~640L): intro w/ pair preview, countdown, study (one symbol at a time, data-symbol hook on occupied cell ONLY during study - anti-cheat), recall (tray tap -> cell tap, re-pick placed symbols, remove by tapping occupied cell), feedback (green/amber/red reveal), results w/ CountUp + 5 round bars + 4-stat grid; session-wide placementsRef keyed by unique symbols (found + fixed round-wipe bug via flow run A: rounds 1-4 scored 0 because ref was reset each round)
- Built faq-data (6 FAQs) + page.tsx (metadata, canonical, JSON-LD x3, hero, 3 science cards, 3 steps, 4 tips, FAQ, RelatedTests, CTA)
- Wiring: sitemap.ts, related-tests.tsx, audit-internal-links.js
- Verify: core 67/67 ALL PASS (incl. random-placement sanity far below anchor); flow x2 ALL PASS after fix (perfect path 100%/145/Cartographer/25-of-25; distinct-wrong-cell anti-gaming floors to 0/55; retake rebinding check; 375px overflow 0; zero console errors); lint clean; MESH COMPLETE; screenshots sm-intro.png sm-board.png reviewed
- Distinct positioning: pattern-memory = pure form, no symbols; spatial-memory = WHAT+WHERE binding, all-or-nothing exact placement
- Screenshot script simplified to intro+board (perfect-play capture loop hung; results verified numerically by flow)

Stage Summary:
- /test/spatial-memory LIVE: 15 live tool pages (16 live routes). 3 pages remain: short-term-memory, sustained-attention, go-no-go

---
Task ID: 36 (Task C of 5-page rebuild)
Agent: main
Task: Rebuild Short-Term Memory Test page at /test/short-term-memory (Brown-Peterson filled-delay recall; lost in rollback)

Work Log:
- Built short-term-memory-core.ts: Brown-Peterson paradigm - 9 trials, consonant trigram flash 900ms, engine-owned filled delays cycling 3s/9s/15s (x3 each), backwards-subtraction chain (expectedCount helper) fills retention interval; letter pool 18 consonants with Q EXCLUDED (anti-gaming: fixed QQQ strategy scores exactly 0); scoring = position-wise letters correct /27 vs anchors 0.52/0.13, IQ 55-145, grades Evaporated/Average/Holding/Very sharp/Steel trap; byDuration decay curve per delay level; normaliseAnswer uppercases + strips non-letters + truncates 3
- Built short-term-memory.tsx (~830L): intro w/ 3-beat preview, countdown, show/delay/recall/feedback states; delay UI = big subtraction prompt + input + chain chips (green/red) + countdown bar (recall opens at delay end regardless of typing - clock absolute); feedback shows trigram vs typed per-position; results w/ CountUp IQ + decay bars + 9 trial chips + 4-stat grid; data-letters hook ONLY during show (anti-cheat verified in flow)
- Built faq-data (6 FAQs incl. "why counting backwards" + decay curve explainer) + page.tsx (metadata, canonical, JSON-LD x3, hero, 3 science cards, 3 steps, 4 tips, FAQ, RelatedTests, CTA)
- Wiring: sitemap.ts, related-tests.tsx, audit-internal-links.js
- Fixed during gates: lint react-hooks/immutability (quickRef.current read in render -> quick state; callback reorder beginDelay->beginShow->beginFeedback); dev server restart mid-gates (connection refused)
- Verify: core 77/77 ALL PASS; flow x2 ALL PASS (perfect 100%/145/27-of-27/chips 3-3/decay 100s; QQQ floors 0/55/Evaporated; retake LMC->XTZ; anti-cheat no leak; 375px 0; zero console errors); lint clean; MESH COMPLETE; screenshots stm-intro/stm-delay reviewed
- Distinct positioning: digit-span = growing load, no interference; word-memory = recognition; STM = fixed 3-letter load + growing interference TIME (decay curve diagnosis)

Stage Summary:
- /test/short-term-memory LIVE: 16 live tool pages (17 live routes). 2 pages remain: sustained-attention (SART full spec in hand), go-no-go
