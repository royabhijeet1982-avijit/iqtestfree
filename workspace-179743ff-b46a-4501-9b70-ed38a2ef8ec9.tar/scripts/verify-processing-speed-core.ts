/* ------------------------------------------------------------------ */
/*  Unit verification for processing-speed-core.ts                     */
/*  Run: bun scripts/verify-processing-speed-core.ts                   */
/* ------------------------------------------------------------------ */

import {
  ACCURACY_FLOOR,
  CODE_SYMBOLS,
  DURATION_MS,
  EPOCH_COUNT,
  MIN_ATTEMPTS,
  PSI_MAX,
  PSI_MIN,
  RATE_MEAN,
  RATE_SD,
  bestStreakOf,
  buildCodingKey,
  computeEpochs,
  digitForSymbol,
  erf,
  formatClock,
  gradeForPsi,
  keyDigits,
  mulberry32,
  nextSymbol,
  normalCdf,
  psiToPercentile,
  rateToPsi,
  recordTrial,
  scoreSession,
  shuffle,
  type CodingKey,
  type TrialRecord,
} from "../src/components/test/processing-speed-core";

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("DURATION_MS is 90s", DURATION_MS === 90_000, String(DURATION_MS));
check("6 code symbols", CODE_SYMBOLS.length === 6);
check("symbols all distinct", new Set(CODE_SYMBOLS).size === 6);
check("MIN_ATTEMPTS is 10", MIN_ATTEMPTS === 10);
check("accuracy floor is 0.6", ACCURACY_FLOOR === 0.6);
check("EPOCH_COUNT is 6", EPOCH_COUNT === 6);
check(
  "population model sane",
  RATE_MEAN === 25 && RATE_SD === 6,
  `mean=${RATE_MEAN} sd=${RATE_SD}`
);

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));

  const arr = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = shuffle(arr, mulberry32(7));
  check(
    "shuffle preserves multiset",
    shuffled.slice().sort((a, b) => a - b).join(",") === "1,2,3,4,5,6,7,8"
  );
  check("shuffle does not mutate input", arr.join(",") === "1,2,3,4,5,6,7,8");
  check(
    "shuffle actually reorders sometimes across seeds",
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].some(
      (seed) => shuffle(arr, mulberry32(seed)).join(",") !== arr.join(",")
    )
  );
}

section("buildCodingKey invariants (300 seeds)");
{
  let allOk = true;
  let distinctKeyMaps = new Set<string>();
  let padIsPermutation = true;
  let padDiffersFromKeyOrder = false;
  for (let seed = 0; seed < 300; seed++) {
    const key = buildCodingKey(mulberry32(seed));
    // 6 pairs, digits unique and within 1..9, symbols unique
    if (key.pairs.length !== 6) allOk = false;
    const digits = key.pairs.map((p) => p.digit);
    if (new Set(digits).size !== 6) allOk = false;
    if (!digits.every((d) => Number.isInteger(d) && d >= 1 && d <= 9)) allOk = false;
    if (new Set(key.pairs.map((p) => p.symbol)).size !== 6) allOk = false;
    if (CODE_SYMBOLS.some((s) => digitForSymbol(key, s) === null)) allOk = false;
    // bijection symbol<->digit
    if (key.pairs.some((p) => key.byDigit[p.digit] !== p.symbol)) allOk = false;
    // pad is a permutation of the key digits
    const sortedKey = keyDigits(key);
    const sortedPad = key.padDigits.slice().sort((a, b) => a - b);
    if (sortedKey.join(",") !== sortedPad.join(",")) padIsPermutation = false;
    if (sortedKey.join(",") !== key.padDigits.join(",")) padDiffersFromKeyOrder = true;
    distinctKeyMaps.add(key.pairs.map((p) => `${p.symbol}>${p.digit}`).join("|"));
  }
  check("all 300 keys structurally valid", allOk);
  check("pad digits are a permutation of key digits", padIsPermutation);
  check("pad order not always equal to key order", padDiffersFromKeyOrder);
  check(
    "key mapping genuinely re-randomises across attempts",
    distinctKeyMaps.size > 280,
    `distinct maps = ${distinctKeyMaps.size}/300`
  );
}

section("nextSymbol stream (no triple repeats, roughly uniform)");
{
  const key = buildCodingKey(mulberry32(99));
  const rng = mulberry32(1000);
  const counts: Record<string, number> = {};
  let lastTwo: [string | null, string | null] = [null, null];
  let tripleRepeat = false;
  const N = 6000;
  for (let i = 0; i < N; i++) {
    const s = nextSymbol(key, rng, lastTwo);
    counts[s] = (counts[s] ?? 0) + 1;
    if (lastTwo[0] === s && lastTwo[1] === s) tripleRepeat = true;
    lastTwo = [lastTwo[1], s];
  }
  check("no symbol appears 3x in a row", !tripleRepeat);
  const expected = N / 6;
  const balanced = Object.values(counts).every(
    (c) => c > expected * 0.8 && c < expected * 1.2
  );
  check(
    "distribution roughly uniform (each 80%-120% of 1/6)",
    balanced,
    JSON.stringify(counts)
  );
}

section("recordTrial correctness");
{
  const key: CodingKey = {
    pairs: [
      { symbol: "\u25C6", digit: 3 },
      { symbol: "\u25CF", digit: 7 },
      { symbol: "\u25B2", digit: 1 },
      { symbol: "\u25A0", digit: 9 },
      { symbol: "\u25CB", digit: 4 },
      { symbol: "\u271A", digit: 6 },
    ],
    padDigits: [3, 7, 1, 9, 4, 6],
    byDigit: { 3: "\u25C6", 7: "\u25CF", 1: "\u25B2", 9: "\u25A0", 4: "\u25CB", 6: "\u271A" },
  };
  const t1 = recordTrial(key, "\u25C6", 3, 820, 1500);
  check("correct response flagged", t1.correct === true);
  const t2 = recordTrial(key, "\u25C6", 4, 900, 2400);
  check("wrong response flagged", t2.correct === false);
  const t3 = recordTrial(key, "\u2600", 3, 900, 3000);
  check("unknown symbol never scores correct", t3.correct === false);
  check("rt/time passthrough", t2.rtMs === 900 && t2.timeMs === 2400);
}

section("computeEpochs bucketing");
{
  const trials: TrialRecord[] = [];
  // 90s sprint, 6 epochs of 15s. Put 3 correct at 5s, 2 wrong at 20s,
  // 4 correct at 89.9s, and one exactly at the 90s boundary (clamps into last).
  const mk = (correct: boolean, timeMs: number): TrialRecord => ({
    symbol: "x",
    response: 1,
    correct,
    rtMs: 700,
    timeMs,
  });
  trials.push(mk(true, 5_000), mk(true, 6_000), mk(true, 14_999));
  trials.push(mk(false, 20_000), mk(false, 25_000));
  trials.push(mk(true, 80_000), mk(true, 85_000), mk(true, 89_900), mk(true, 90_000));
  const epochs = computeEpochs(trials, DURATION_MS);
  check("6 epochs returned", epochs.length === 6);
  check("epoch 0 has 3 correct / 3 attempts", epochs[0]!.correct === 3 && epochs[0]!.attempts === 3);
  check("epoch 1 has 0 correct / 2 attempts", epochs[1]!.correct === 0 && epochs[1]!.attempts === 2);
  check("epoch 5 absorbs 80s..90s (4 correct)", epochs[5]!.correct === 4);
  check(
    "epoch rate math (epoch 0: 3 correct in 15s = 12/min)",
    Math.abs(epochs[0]!.ratePerMin - 12) < 1e-9,
    String(epochs[0]!.ratePerMin)
  );
  const totalAttempts = epochs.reduce((a, e) => a + e.attempts, 0);
  check("epoch attempts sum to trial count", totalAttempts === trials.length);
}

section("bestStreakOf");
{
  const mk = (correct: boolean): TrialRecord => ({
    symbol: "x",
    response: 1,
    correct,
    rtMs: 500,
    timeMs: 0,
  });
  check("empty = 0", bestStreakOf([]) === 0);
  check("all wrong = 0", bestStreakOf([mk(false), mk(false)]) === 0);
  check("all correct = length", bestStreakOf([mk(true), mk(true), mk(true)]) === 3);
  check(
    "mixed finds longest run",
    bestStreakOf([mk(true), mk(true), mk(false), mk(true), mk(false), mk(true), mk(true), mk(true)]) === 3
  );
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(RATE_MEAN, RATE_MEAN, RATE_SD) - 0.5) < 1e-9);
  check(
    "normalCdf(+1sd) ~ 0.8413",
    Math.abs(normalCdf(RATE_MEAN + RATE_SD, RATE_MEAN, RATE_SD) - 0.8413447) < 1e-6
  );
}

section("rateToPsi / psiToPercentile mapping");
{
  check("rate at mean 25 -> PSI 100", rateToPsi(25) === 100, String(rateToPsi(25)));
  check("rate mean+sd 31 -> PSI 115", rateToPsi(31) === 115, String(rateToPsi(31)));
  check("rate mean-sd 19 -> PSI 85", rateToPsi(19) === 85, String(rateToPsi(19)));
  check("rate 0 -> clamped PSI floor", rateToPsi(0) === PSI_MIN, String(rateToPsi(0)));
  check("rate 7 -> exactly PSI floor (soft-clamp boundary)", rateToPsi(7) === 55, String(rateToPsi(7)));
  check("rate 6 -> clamped PSI floor", rateToPsi(6) === PSI_MIN, String(rateToPsi(6)));
  check("absurd rate 500 -> PSI ceiling", rateToPsi(500) === PSI_MAX, String(rateToPsi(500)));
  check("PSI 100 -> ~50th percentile", psiToPercentile(100) === 50, String(psiToPercentile(100)));
  check("PSI 115 -> ~84th", psiToPercentile(115) === 84, String(psiToPercentile(115)));
  check("PSI 85 -> ~16th", psiToPercentile(85) === 16, String(psiToPercentile(85)));
  check("percentile clamped 1..99 low", psiToPercentile(PSI_MIN) === 1, String(psiToPercentile(PSI_MIN)));
  check("percentile clamped 1..99 high", psiToPercentile(PSI_MAX) === 99, String(psiToPercentile(PSI_MAX)));
  // monotonicity across the whole working range
  let monotonic = true;
  for (let rate = 0; rate <= 60; rate += 0.5) {
    const a = psiToPercentile(rateToPsi(rate));
    const b = psiToPercentile(rateToPsi(rate + 0.5));
    if (b < a) monotonic = false;
  }
  check("percentile monotonic non-decreasing in rate", monotonic);
}

section("gradeForPsi tiers");
{
  check("PSI 70 -> Deliberate", gradeForPsi(70).label === "Deliberate");
  check("PSI 84 -> Deliberate (boundary)", gradeForPsi(84.9).label === "Deliberate");
  check("PSI 85 -> Average", gradeForPsi(85).label === "Average");
  check("PSI 99.4 -> Average", gradeForPsi(99.4).label === "Average");
  check("PSI 100 -> Quick", gradeForPsi(100).label === "Quick");
  check("PSI 114.6 -> Quick", gradeForPsi(114.6).label === "Quick");
  check("PSI 115 -> Very quick", gradeForPsi(115).label === "Very quick");
  check("PSI 129 -> Very quick", gradeForPsi(129).label === "Very quick");
  check("PSI 130 -> Exceptional", gradeForPsi(130).label === "Exceptional");
  check("every grade has blurb + class", [70, 90, 105, 120, 135].every((p) => {
    const g = gradeForPsi(p);
    return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("scoreSession - validity paths");
{
  const mk = (correct: boolean, rtMs = 800, timeMs = 0): TrialRecord => ({
    symbol: "x",
    response: 1,
    correct,
    rtMs,
    timeMs,
  });
  // 0 attempts
  const empty = scoreSession([], DURATION_MS);
  check("empty session invalid", empty.valid === false && empty.invalidReason !== null);
  // too few attempts
  const sparse = scoreSession([mk(true), mk(true), mk(true)], DURATION_MS);
  check("sparse session invalid", sparse.valid === false);
  check("sparse reason mentions count", (sparse.invalidReason ?? "").includes("3"));
  check("sparse preserves attempts", sparse.attempts === 3);
  // mash: 60 attempts, 10 correct (16.7%)
  const mashTrials = Array.from({ length: 60 }, (_, i) => mk(i < 10, 350, i * 1500));
  const mash = scoreSession(mashTrials, DURATION_MS);
  check("mash session invalid", mash.valid === false);
  check("mash accuracy below floor", mash.accuracy < ACCURACY_FLOOR, String(mash.accuracy));
  check("mash reason mentions accuracy", (mash.invalidReason ?? "").toLowerCase().includes("accuracy"));
  check("mash preserves raw stats", mash.attempts === 60 && mash.correct === 10 && mash.errors === 50);
  // boundary: exactly 60% accuracy with enough attempts is VALID
  const boundaryTrials = Array.from({ length: 20 }, (_, i) => mk(i < 12, 900, i * 4500));
  const boundary = scoreSession(boundaryTrials, DURATION_MS);
  check("60.0% accuracy exactly is valid", boundary.valid === true, JSON.stringify({ acc: boundary.accuracy }));
  // 59% is invalid
  const subTrials = Array.from({ length: 100 }, (_, i) => mk(i < 59, 900, i * 900));
  const sub = scoreSession(subTrials, DURATION_MS);
  check("59% accuracy invalid", sub.valid === false);
}

section("scoreSession - valid scoring math");
{
  // Perfect-ish run: 45 correct, 0 errors, uniform 2s RTs over 90s
  const goodTrials: TrialRecord[] = Array.from({ length: 45 }, (_, i) => ({
    symbol: "x",
    response: 1,
    correct: true,
    rtMs: 2000,
    timeMs: i * 2000,
  }));
  const good = scoreSession(goodTrials, DURATION_MS);
  check("valid session flagged", good.valid === true && good.invalidReason === null);
  check("correct = 45", good.correct === 45);
  check("errors = 0", good.errors === 0);
  check("accuracy = 1", good.accuracy === 1);
  check(
    "rate = 45 per 90s = 30/min",
    Math.abs(good.ratePerMin - 30) < 1e-9,
    String(good.ratePerMin)
  );
  check("PSI for 30/min = 113 (100+15*5/6 rounds up)", good.psi === 113, String(good.psi));
  check("percentile matches PSI", good.percentile === psiToPercentile(113));
  check("mean RT = 2000ms", good.meanRtMs === 2000);
  check("sd RT = 0 for constant RTs", good.sdRtMs === 0);
  check("cv = 0", good.cv === 0);
  check("best streak = 45", good.bestStreak === 45);
  check("6 epochs", good.epochs.length === 6);
  check(
    "epoch rates sum ~ correct/min",
    Math.abs(good.epochs.reduce((a, e) => a + e.ratePerMin, 0) - 45 * (6 / 1.5)) < 1e-6
  );
  check("grade for 113 = Quick", good.grade.label === "Quick");

  // With errors: 40 correct + 5 wrong in 90s
  const mixedTrials: TrialRecord[] = [
    ...Array.from({ length: 40 }, (_, i) => ({ symbol: "x", response: 1, correct: true, rtMs: 1800, timeMs: i * 2000 })),
    ...Array.from({ length: 5 }, (_, i) => ({ symbol: "y", response: 2, correct: false, rtMs: 1500, timeMs: 80_000 + i })),
  ];
  const mixed = scoreSession(mixedTrials, DURATION_MS);
  check("mixed valid (80% acc)", mixed.valid === true);
  check("mixed correct = 40", mixed.correct === 40);
  check("mixed rate uses correct only (26.67/min)", Math.abs(mixed.ratePerMin - 40 * 60_000 / 90_000) < 1e-9);
  check("mixed accuracy = 40/45", Math.abs(mixed.accuracy - 40 / 45) < 1e-9);
  check("mixed RT stats ignore wrong trials", Math.abs(mixed.meanRtMs - 1800) < 1e-9);
}

section("Population simulation (N=500 realistic profiles)");
{
  // Simulate users whose per-item time is lognormal-ish around a skill
  // parameter, with small error probability. Skilled users answer faster.
  const iqSamples: number[] = [];
  const rateSamples: number[] = [];
  let allValid = true;
  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(10_000 + user);
    const skill = randn(rng); // -1 slow .. +1 fast
    const baseMs = 2400 * Math.exp(-0.22 * skill); // ~2.4s average user
    const errP = 0.045 - 0.02 * skill; // fast users slightly sloppier but ~2.5-6.5%
    const trials: TrialRecord[] = [];
    let t = 0;
    while (t < DURATION_MS) {
      const rt = Math.max(450, baseMs * Math.exp(0.18 * randn(rng)));
      t += rt;
      if (t >= DURATION_MS) break;
      trials.push({
        symbol: "x",
        response: 1,
        correct: rng() > errP,
        rtMs: rt,
        timeMs: t,
      });
    }
    const score = scoreSession(trials, DURATION_MS);
    if (!score.valid) allValid = false;
    iqSamples.push(score.psi);
    rateSamples.push(score.ratePerMin);
  }
  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
  };
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanRate = mean(rateSamples);
  check(
    "all realistic users produce valid scores",
    allValid,
    `some invalid`
  );
  check(
    "mean rate near population mean (23-27/min)",
    meanRate > 23 && meanRate < 27,
    String(meanRate.toFixed(2))
  );
  check(
    "mean PSI near 100 (96-104)",
    meanIq > 96 && meanIq < 104,
    String(meanIq.toFixed(2))
  );
  check(
    "PSI SD in plausible band (9-21)",
    sdIq > 9 && sdIq < 21,
    String(sdIq.toFixed(2))
  );
  console.log(`  info   simulated mean rate=${meanRate.toFixed(2)}/min mean PSI=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)}`);
}

section("End-to-end pipeline coherence (3 profiles, full key/stream simulation)");
{
  const runProfile = (seed: number, skill: number) => {
    const rng = mulberry32(seed);
    const key = buildCodingKey(rng);
    const symbols = key.pairs.map((p) => p.symbol);
    let lastTwo: [string | null, string | null] = [null, null];
    const trials: TrialRecord[] = [];
    const baseMs = 2600 * Math.exp(-0.35 * skill);
    let t = 0;
    while (true) {
      const symbol = nextSymbol(key, rng, lastTwo);
      lastTwo = [lastTwo[1], symbol];
      const rt = Math.max(380, baseMs * Math.exp(0.15 * randn(rng)));
      t += rt;
      if (t >= DURATION_MS) break;
      // correct with skill-dependent probability; wrong picks a random pad digit
      const correct = rng() < 0.96 - 0.02 * skill;
      const response = correct
        ? digitForSymbol(key, symbol)!
        : key.padDigits[Math.floor(rng() * key.padDigits.length)]!;
      trials.push(recordTrial(key, symbol, response, rt, t));
    }
    return scoreSession(trials, DURATION_MS);
  };
  const slow = runProfile(7, -1.2);
  const avg = runProfile(8, 0);
  const fast = runProfile(9, 1.4);
  check("all three profiles valid", slow.valid && avg.valid && fast.valid);
  check("slow < avg < fast rate", slow.ratePerMin < avg.ratePerMin && avg.ratePerMin < fast.ratePerMin,
    `${slow.ratePerMin.toFixed(1)} < ${avg.ratePerMin.toFixed(1)} < ${fast.ratePerMin.toFixed(1)}`);
  check("slow < avg < fast PSI", slow.psi < avg.psi && avg.psi < fast.psi,
    `${slow.psi} < ${avg.psi} < ${fast.psi}`);
  check("slow accuracy >= floor", slow.accuracy >= ACCURACY_FLOOR, String(slow.accuracy));
  check("avg accuracy >= floor", avg.accuracy >= ACCURACY_FLOOR);
  check("fast accuracy >= floor", fast.accuracy >= ACCURACY_FLOOR);
  check("fast grades at or above avg", gradeForPsi(fast.psi).label !== gradeForPsi(slow.psi).label);
  console.log(`  info   slow=${slow.ratePerMin.toFixed(1)}/min PSI ${slow.psi} (${slow.grade.label}), avg=${avg.ratePerMin.toFixed(1)} PSI ${avg.psi} (${avg.grade.label}), fast=${fast.ratePerMin.toFixed(1)} PSI ${fast.psi} (${fast.grade.label})`);
}

section("formatClock");
{
  check("90000 -> 1:30", formatClock(90_000) === "1:30");
  check("83450 -> 1:24 (ceil)", formatClock(83_450) === "1:24");
  check("15000 -> 0:15", formatClock(15_000) === "0:15");
  check("0 -> 0:00", formatClock(0) === "0:00");
  check("negative clamps to 0:00", formatClock(-5) === "0:00");
  check("9500 -> 0:10 (ceil)", formatClock(9_500) === "0:10");
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
