/**
 * Task 27 verification: Sequence Memory test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-sequence-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1): the script WATCHES the playback by polling tile
 *    classes every 40ms (repeat-aware: resets on the dark gap, so doubled
 *    tiles are recorded twice), then during RECALL repeats the watched
 *    sequence - level 1 recall is played via KEYBOARD (keys 1-9). Clears
 *    levels 1..5, then deliberately misses at level 6 -> results (span 5,
 *    IQ 76, Building, ladder, stats)
 *  - Retake: second run's first playback differs from run 1
 *  - Anti-gaming (default timing): a DOM click during PLAYBACK is ignored
 *    (tiles disabled, engine owns timing) and corrupts nothing; afterwards a
 *    deliberate wrong click at level 2 ends the run with span 1 -> honest
 *    floor IQ 55, percentile 1, Building - no crash
 *  - 375px: no horizontal overflow on intro / active / results
 *  - zero console/page errors
 *
 * NOTE: the anti-gaming section runs WITHOUT ?quick=1 on purpose: the
 * slow default playback gives a wide window to prove input is locked.
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll a CountUp testid until the visible number matches its final value.
 *  The component exposes data-final, so animation frames cannot fool us. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.trim()),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.final >= 0 && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/**
 * WATCH a playback: single-evaluate polling (~30ms/iter). Whenever exactly
 * one tile carries is-lit / data-lit="true" and it differs from the previous
 * lit tile, record it. The watcher RESETS on the dark gap between flashes,
 * so the same tile flashing twice in a row is recorded twice (doubles are a
 * real event in this test). Returns the ordered sequence once the stage
 * leaves playback.
 */
async function watchPlayback(p, timeoutMs = 30000) {
  const seq = [];
  const start = Date.now();
  let lastLit = -1;
  let sawPlayback = false;
  while (Date.now() - start < timeoutMs) {
    const state = await p
      .evaluate(() => {
        const results = !!document.querySelector('[data-testid="sm-results"]');
        const stage = document.querySelector('[data-testid="sm-stage"]');
        const phase = stage ? stage.getAttribute("data-phase") : null;
        if (phase !== "playback") return { results, phase, lit: -2, count: -1 };
        const tiles = Array.from(document.querySelectorAll('[data-testid^="sm-tile-"]'));
        const litIdxs = [];
        tiles.forEach((el, i) => {
          if (el.classList.contains("is-lit") || el.getAttribute("data-lit") === "true") litIdxs.push(i);
        });
        return { results, phase, lit: litIdxs.length === 1 ? litIdxs[0] : litIdxs.length === 0 ? -1 : -3, count: litIdxs.length };
      })
      .catch(() => null);
    if (!state || state.results) break;
    if (state.phase === "playback") {
      sawPlayback = true;
      if (state.count === 0) {
        lastLit = -1; // dark gap - a repeated tile can be detected next
      } else if (state.count === 1 && state.lit !== lastLit) {
        seq.push(state.lit);
        lastLit = state.lit;
      }
    } else if (sawPlayback) {
      break; // recall or feedback reached - playback over
    }
    await sleep(30);
  }
  return seq;
}

/** Wait until the stage is in the recall phase (clickable). */
async function waitRecall(p, timeoutMs = 12000) {
  await p
    .waitForFunction(
      () => {
        const el = document.querySelector('[data-testid="sm-stage"]');
        return !!el && el.getAttribute("data-phase") === "recall";
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/** DOM-level click on a tile button (skips actionability waits). */
async function clickTile(p, tile) {
  const btn = await p.$(`[data-testid="sm-tile-${tile}"]`);
  if (!btn) throw new Error(`sm-tile-${tile} not found`);
  await btn.evaluate((el) => el.click());
}

/** Keyboard tap for a tile (keys 1-9 map to tiles 0-8 during recall). */
async function keyTile(p, tile) {
  await p.keyboard.press(String(tile + 1));
}

/** Atomic snapshot of the active phase (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => ({
      results: !!document.querySelector('[data-testid="sm-results"]'),
      active: !!document.querySelector('[data-testid="sm-active"]'),
      phase: document.querySelector('[data-testid="sm-stage"]')?.getAttribute("data-phase") ?? null,
      levelText: document.querySelector('[data-testid="sm-level"]')?.textContent ?? null,
      statusText: document.querySelector('[data-testid="sm-status"]')?.textContent ?? null,
    }))
    .catch(() => null);
}

/** Click the whole recorded sequence back, one tile at a time. */
async function recallAll(p, seq) {
  for (const tile of seq) {
    const snap = await snapshot(p);
    if (!snap || snap.results) return false; // run ended early - abort quietly
    await waitRecall(p);
    await clickTile(p, tile);
    await sleep(50);
  }
  return true;
}

/** A tile that is guaranteed NOT to be the expected first tile. */
const wrongTileFor = (seq) => (seq[0] + 1) % 9;

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test/sequence-memory`, { waitUntil: "networkidle" });
  console.log("- SEO checks -");
  const title = await p.title();
  title === "Free Sequence Memory Test Online | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("sequence memory test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/sequence-memory"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/sequence-memory"
    ? ok("BreadcrumbList: BrainMetrics > Sequence Memory Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="sm-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok("FAQPage JSON-LD has 6 questions")
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok("visible FAQ has 6 items")
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Sequence") && h1.includes("Memory Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const related = await p.$eval("#related-tests-heading", (el) => el.textContent.trim()).catch(() => null);
  related === "Try another test" ? ok("RelatedTests band renders") : fail(`RelatedTests: ${related}`);

  /* ---------------- Golden path (quick mode) ---------------- */
  console.log("- Run 1: golden path (?quick=1) -");
  await p.goto(`${BASE}/test/sequence-memory?quick=1`, { waitUntil: "networkidle" });
  const intro = await p.$('[data-testid="sm-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  const startBtn = await p.$('[data-testid="sm-intro-cta"]');
  if (!startBtn) { fail("start button missing"); return finish(browser, errors); }
  await startBtn.click();
  // Watch IMMEDIATELY: AnimatePresence mount lag can delay the sm-active
  // DOM node past the short quick-mode playback, but the engine timers are
  // already running - the watcher polls through the countdown instead.

  const MAX_CLEAR = 5;
  let firstSeqRun1 = null;
  let keyboardUsed = false;
  let goldenGuard = 0;
  let earlyEnd = null;
  while (goldenGuard < 10) {
    const seq = await watchPlayback(p, 45000);
    await p.waitForSelector('[data-testid="sm-active"]', { timeout: 12000 }).catch(() => {});
    const snap = await snapshot(p);
    if (!snap || snap.results) {
      earlyEnd = `run ended during/after level-${1 + goldenGuard} playback (watched [${seq.join(", ")}])`;
      break;
    }
    if (!snap.levelText) {
      fail(`sm-level missing while active (phase=${snap.phase}, status=${snap.statusText})`);
      break;
    }
    const level = Number(snap.levelText.replace(/[^0-9]/g, ""));
    if (seq.length !== level) {
      fail(`playback watch captured ${seq.length}/${level} tiles (phase=${snap.phase})`);
      break;
    }
    if (!firstSeqRun1) {
      firstSeqRun1 = seq;
      ok(`watched level-1 playback: tile ${seq[0]} (observed via is-lit)`);
    }
    if (level <= MAX_CLEAR) {
      await waitRecall(p);
      const status = await p.$eval('[data-testid="sm-status"]', (el) => el.textContent.trim());
      status.includes("Your turn") ? ok(`level ${level} recall status ok`) : fail(`status: ${status}`);
      if (level === 1) {
        const prog = await p.$eval('[data-testid="sm-progress"]', (el) => el.textContent.trim());
        prog === "0 / 1" ? ok("progress chip: 0 / 1") : fail(`progress: ${prog}`);
      }
      let completed;
      if (level === 1) {
        // keyboard path: key n maps to tile n-1
        await keyTile(p, seq[0]);
        keyboardUsed = true;
        completed = true;
        await sleep(150);
      } else {
        completed = await recallAll(p, seq);
      }
      if (!completed) { earlyEnd = `a recall click failed at level ${level} (run over)`; break; }
    } else {
      // deliberate first-position miss at level 6 -> run ends by design
      await waitRecall(p);
      await clickTile(p, wrongTileFor(seq));
      break;
    }
  }
  keyboardUsed ? ok("level-1 recall played via keyboard key (1-9 mapping)") : fail("keyboard recall not exercised");
  if (earlyEnd) fail(`golden path ended early: ${earlyEnd}`);
  await p.waitForSelector('[data-testid="sm-results"]', { timeout: 15000 });
  ok("results screen reached");

  const span = await readStable(p, "sm-span");
  span === MAX_CLEAR ? ok(`sequence span: ${span} (cleared 1..${MAX_CLEAR})`) : fail(`span: ${span}`);
  const iq = await readStable(p, "sm-iq");
  iq === 76 ? ok(`memory IQ: ${iq} (span 5 -> 100+15*(5-7.4)/1.5)`) : fail(`IQ: ${iq} (expected 76)`);
  const grade = await p.$eval('[data-testid="sm-grade"]', (el) => el.textContent.trim());
  grade === "Building" ? ok(`grade chip: ${grade}`) : fail(`grade: ${grade}`);
  const percentile = await p.$eval('[data-testid="sm-percentile"]', (el) => el.textContent.trim());
  percentile.includes("Better than") ? ok(`percentile line: ${percentile}`) : fail(`percentile: ${percentile}`);
  const ladder = await p.$$eval('[data-testid="sm-ladder"] [data-status]', (els) =>
    els.map((el) => ({ id: el.getAttribute("data-testid"), status: el.getAttribute("data-status") }))
  );
  const clearedOk =
    ladder.length === 6 &&
    ["1", "2", "3", "4", "5"].every((lv, i) => ladder[i].id === `sm-ladder-level-${lv}` && ladder[i].status === "cleared") &&
    ladder[5].id === "sm-ladder-level-6" && ladder[5].status === "failed";
  clearedOk ? ok("level ladder: 1-5 cleared, 6 failed") : fail(`ladder: ${JSON.stringify(ladder)}`);
  const recalled = await p.$eval('[data-testid="sm-stat-recalled"] p', (el) => el.textContent.trim());
  Number(recalled) === 15 ? ok(`tiles recalled: ${recalled}`) : fail(`tiles recalled: ${recalled}`);
  const shown = await p.$eval('[data-testid="sm-stat-shown"] p', (el) => el.textContent.trim());
  Number(shown) === 21 ? ok(`tiles played: ${shown} (1+2+..+6)`) : fail(`tiles played: ${shown}`);
  const deepest = await p.$eval('[data-testid="sm-stat-deepest"] p', (el) => el.textContent.trim());
  Number(deepest) === 6 ? ok(`deepest level: ${deepest}`) : fail(`deepest: ${deepest}`);
  const runTime = await p.$eval('[data-testid="sm-stat-time"] p', (el) => el.textContent.trim());
  /^\d+\.\ds$/.test(runTime) ? ok(`run time: ${runTime}`) : fail(`run time: ${runTime}`);
  const retakeBtn = await p.$('[data-testid="sm-retake"]');
  retakeBtn ? ok("retake button present") : fail("retake button missing");

  /* ---------------- Run 2: retake, new sequence ---------------- */
  console.log("- Run 2: retake -> first playback differs -");
  let seq2 = null;
  let retakeAttempts = 0;
  while (retakeAttempts < 3 && !seq2) {
    retakeAttempts++;
    const btn = await p.$('[data-testid="sm-retake"]');
    if (!btn) { fail("retake button missing (run 2)"); break; }
    await btn.click();
    // AnimatePresence keeps sm-results in the DOM during its ~400ms exit;
    // wait for it to unmount or the watcher breaks on it immediately.
    await p
      .waitForFunction(() => !document.querySelector('[data-testid="sm-results"]'), undefined, { timeout: 5000 })
      .catch(() => {});
    const s = await watchPlayback(p, 45000);
    await p.waitForSelector('[data-testid="sm-active"]', { timeout: 12000 }).catch(() => {});
    const snap = await snapshot(p);
    if (!snap || snap.results || s.length !== 1) {
      fail(`run-2 playback capture failed (tiles=${s.length}, results=${snap ? snap.results : "n/a"})`);
      break;
    }
    if (s.join(",") !== firstSeqRun1.join(",")) {
      seq2 = s;
      ok(`run-2 first tile ${s[0]} differs from run-1 tile ${firstSeqRun1[0]} (anti-memorisation)`);
    } else {
      // astronomically unlikely collision - end and retake again
      ok(`run-2 first tile collided (${s[0]}) - retaking`);
    }
    await waitRecall(p);
    await keyTile(p, s[0]); // clear level 1 by keyboard
    await sleep(120);
    const snap2 = await snapshot(p);
    if (snap2 && !snap2.results) {
      const s3 = await watchPlayback(p, 30000);
      if (s3.length === 2) {
        await waitRecall(p);
        await clickTile(p, wrongTileFor(s3)); // end run 2 at level 2
      }
    }
    await p.waitForSelector('[data-testid="sm-results"]', { timeout: 15000 });
  }
  seq2 ? ok("retake dealt a fresh sequence") : fail("retake replayed the same first tile");

  /* ---------------- Anti-gaming: playback input lock + floor score ---------------- */
  console.log("- Run 3: anti-gaming (default timing) -");
  await p.goto(`${BASE}/test/sequence-memory`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="sm-intro-cta"]')).click();
  ok("run 3 started (default mode, slow playback)");

  const seqA = await watchPlayback(p, 45000);
  await p.waitForSelector('[data-testid="sm-active"]', { timeout: 12000 }).catch(() => {});
  if (seqA.length !== 1) fail(`run-3 level-1 playback captured ${seqA.length}/1 tiles`);
  await waitRecall(p);
  await clickTile(p, seqA[0]); // clear level 1
  await sleep(300);

  // During LEVEL 2 playback, fire a DOM click on a tile. Tiles are
  // disabled and the engine owns timing, so the click must be ignored.
  let phaseAfter = null;
  for (let i = 0; i < 20; i++) {
    const snap = await snapshot(p);
    if (!snap || snap.results) break;
    if (snap.phase === "playback" && snap.levelText === "Level 2") {
      await clickTile(p, (seqA[0] + 3) % 9);
      await sleep(80);
      const snap2 = await snapshot(p);
      phaseAfter = snap2 ? snap2.phase : null;
      break;
    }
    await sleep(60);
  }
  phaseAfter === "playback"
    ? ok("click during playback IGNORED (phase stayed playback, engine owns timing)")
    : fail(`click during playback changed state (phase=${phaseAfter})`);
  const seqB = await watchPlayback(p, 30000);
  if (seqB.length !== 2) {
    fail(`run-3 level-2 playback captured ${seqB.length}/2 tiles`);
  } else {
    ok(`level-2 playback intact after ignored click: [${seqB.join(", ")}] (prefix-stable: starts with ${seqA[0]})`);
    seqB[0] === seqA[0]
      ? ok("prefix-stable growth confirmed (level-2 starts with the level-1 tile)")
      : fail("prefix-stable growth BROKEN (level-2 first tile differs)");
  }
  await waitRecall(p);
  const prog = await p.$eval('[data-testid="sm-progress"]', (el) => el.textContent.trim());
  prog === "0 / 2" ? ok("progress chip clean after ignored click: 0 / 2") : fail(`progress: ${prog}`);
  await clickTile(p, wrongTileFor(seqB)); // deliberate miss -> run over
  await p.waitForSelector('[data-testid="sm-results"]', { timeout: 15000 });
  ok("run ended after the miss (single life, no crash)");
  const floorSpan = await readStable(p, "sm-span");
  floorSpan === 1 ? ok(`span recorded: ${floorSpan} (only level 1 cleared)`) : fail(`floor span: ${floorSpan}`);
  const lowIq = await readStable(p, "sm-iq");
  lowIq === 55 ? ok(`honest floor IQ: ${lowIq}`) : fail(`low IQ: ${lowIq} (expected clamped 55)`);
  const lowPct = await p.$eval('[data-testid="sm-percentile"]', (el) => el.textContent.trim());
  lowPct.includes("Better than 1") ? ok(`floor percentile line: ${lowPct}`) : fail(`percentile: ${lowPct}`);
  const failLadder = await p.$$eval('[data-testid="sm-ladder"] [data-status]', (els) =>
    els.map((el) => el.getAttribute("data-status"))
  );
  failLadder.length === 2 && failLadder[0] === "cleared" && failLadder[1] === "failed"
    ? ok("ladder: level 1 cleared, level 2 failed")
    : fail(`ladder: ${JSON.stringify(failLadder)}`);

  /* ---------------- Mobile 375px ---------------- */
  console.log("- Mobile 375px -");
  const mp = await ctx.newPage();
  const merrors = [];
  mp.on("pageerror", (e) => merrors.push("pageerror: " + e.message));
  mp.on("console", (m) => { if (m.type() === "error") merrors.push("console: " + m.text()); });
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/sequence-memory?quick=1`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="sm-intro-cta"]')).click();
  const mseq = await watchPlayback(mp, 45000);
  await mp.waitForSelector('[data-testid="sm-active"]', { timeout: 12000 }).catch(() => {});
  await waitRecall(mp);
  await noHorizontalOverflow(mp, "active (recall)");
  await clickTile(mp, wrongTileFor(mseq)); // 1st miss -> results
  await mp.waitForSelector('[data-testid="sm-results"]', { timeout: 15000 });
  await noHorizontalOverflow(mp, "results");
  await mp.close();
  merrors.forEach((e) => errors.push("mobile " + e));

  /* ---------------- Console errors ---------------- */
  console.log("- Console -");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
