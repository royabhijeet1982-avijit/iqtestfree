/* ------------------------------------------------------------------ */
/*  Unit verification for matrix-reasoning-core.ts                     */
/*  Run: bun scripts/verify-matrix-reasoning-core.ts                   */
/* ------------------------------------------------------------------ */

import {
  FILLS,
  IQ_MAX,
  IQ_MIN,
  ITEM_COUNT,
  MIN_RUSHED_N,
  POPULATION_RAW_MEAN,
  POPULATION_RAW_SD,
  QUICK_ITEM_COUNT,
  RULE_LABELS,
  RULE_ORDER,
  SHAPES,
  cellKey,
  elementKey,
  erf,
  generateItems,
  gradeAnswer,
  gradeForIq,
  iqToPercentile,
  itemFingerprint,
  medianOf,
  mulberry32,
  normalCdf,
  rawToIq,
  scoreMatrixSession,
  shuffle,
  solveItem,
  type Cell,
  type ElementSpec,
  type MatrixItem,
} from "../src/components/test/matrix-reasoning-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function sd(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
}

/**
 * Full-grid consistency per declared spec: rebuilds the missing cell
 * with solveItem, then proves every row/column obeys the declared rule.
 */
function gridConsistent(item: MatrixItem): boolean {
  const solved = solveItem(item);
  if (!solved) return false;
  const full: Cell[] = [
    ...(item.cells.slice(0, -1) as Cell[]),
    solved,
  ];
  const key = (c: Cell) => cellKey(c);
  const spec = item.spec;

  if (spec.kind === "diag") {
    // [A, adv(A), adv(A), adv^2(A)]
    // Period-2 toggle rules (fill) legally return to A after two steps,
    // so adv^2(A) === A is expected for them and must not fail.
    const period2 = spec.rule === "fill";
    return (
      key(full[1]!) === key(full[2]!) &&
      key(full[3]!) !== key(full[1]!) &&
      (period2 || key(full[3]!) !== key(full[0]!))
    );
  }
  if (spec.kind === "across") {
    // Rows are identical triples [v0, v1, v2]; answer == row0 col3.
    return (
      key(full[8]!) === key(full[2]!) &&
      key(full[2]!) === key(full[5]!) &&
      key(full[2]!) !== key(full[1]!)
    );
  }
  if (spec.kind === "rotXY") {
    // rot(r,c) = b + (r+c)*delta
    const rot = (c: Cell) => c.elements[0]!.rotation;
    const d01 = rot(full[1]!) - rot(full[0]!);
    const d12 = rot(full[2]!) - rot(full[1]!);
    if (d01 <= 0 || d01 !== d12) return false;
    for (let r = 0; r < 3; r++) {
      if (
        rot(full[r * 3 + 1]!) - rot(full[r * 3]!) !== d01 ||
        rot(full[r * 3 + 2]!) - rot(full[r * 3 + 1]!) !== d01
      )
        return false;
    }
    for (let c = 0; c < 3; c++) {
      if (rot(full[3 + c]!) - rot(full[c]!) !== d01) return false;
    }
    return true;
  }
  if (spec.kind === "super") {
    // Each row is [A, B, A u B]; rows differ from each other.
    const unionKey = (r: number) => {
      const els: ElementSpec[] = [
        ...full[r * 3]!.elements,
        ...full[r * 3 + 1]!.elements.filter(
          (e) => !full[r * 3]!.elements.some((x) => elementKey(x) === elementKey(e))
        ),
      ];
      return els.map(elementKey).join(";");
    };
    return (
      unionKey(0) === key(full[2]!) &&
      unionKey(1) === key(full[5]!) &&
      unionKey(2) === key(full[8]!) &&
      full[8]!.elements.length === 2 &&
      key(full[2]!) !== key(full[5]!)
    );
  }
  // dual
  const p0 = full[0]!.elements[0]!;
  const p1 = full[1]!.elements[0]!;
  let get: (e: ElementSpec) => number;
  if (p1.count !== p0.count) get = (e) => e.count;
  else if (Math.abs(p1.scale - p0.scale) > 1e-9) get = (e) => e.scale;
  else get = (e) => e.rotation;
  const step = get(p1) - get(p0);
  if (step === 0) return false;
  for (let r = 0; r < 3; r++) {
    const a = get(full[r * 3]!.elements[0]!);
    const b = get(full[r * 3 + 1]!.elements[0]!);
    const c = get(full[r * 3 + 2]!.elements[0]!);
    if (Math.abs(b - a - step) > 1e-9 || Math.abs(c - b - step) > 1e-9) return false;
  }
  for (let c = 0; c < 3; c++) {
    // across-attr is constant down each column
    if (Math.abs(get(full[3 + c]!.elements[0]!) - get(full[c]!.elements[0]!)) > 1e-9)
      return false;
  }
  if (spec.down === "shape") {
    for (let c = 0; c < 3; c++) {
      const s0 = SHAPES.indexOf(full[c]!.elements[0]!.shape);
      const s1 = SHAPES.indexOf(full[3 + c]!.elements[0]!.shape);
      const s2 = SHAPES.indexOf(full[6 + c]!.elements[0]!.shape);
      if (s1 !== (s0 + 1) % SHAPES.length || s2 !== (s1 + 1) % SHAPES.length) return false;
    }
  } else {
    for (let c = 0; c < 3; c++) {
      const f0 = full[c]!.elements[0]!.fill;
      const f1 = full[3 + c]!.elements[0]!.fill;
      const f2 = full[6 + c]!.elements[0]!.fill;
      if (f1 === f0 || f2 !== f0) return false;
    }
  }
  return true;
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("ITEM_COUNT is 20", ITEM_COUNT === 20, String(ITEM_COUNT));
check("QUICK_ITEM_COUNT is 8", QUICK_ITEM_COUNT === 8, String(QUICK_ITEM_COUNT));
check("8 shapes, 4 fills available", SHAPES.length === 8 && FILLS.length === 4);
check("5 rule categories with labels", RULE_ORDER.length === 5 && RULE_ORDER.every((r) => RULE_LABELS[r].length > 3));
check("IQ clamp band 55..145", IQ_MIN === 55 && IQ_MAX === 145);
check(
  "population calibration constants positive",
  POPULATION_RAW_MEAN > 5 && POPULATION_RAW_MEAN < 15 && POPULATION_RAW_SD > 2 && POPULATION_RAW_SD < 5,
  `mean=${POPULATION_RAW_MEAN} sd=${POPULATION_RAW_SD}`
);

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(mulberry32(43) && Array.from({ length: 20 }, () => mulberry32(43)())));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
  const arr = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = shuffle(arr, mulberry32(7));
  check(
    "shuffle preserves multiset",
    shuffled.slice().sort((a, b) => a - b).join(",") === "1,2,3,4,5,6,7,8"
  );
  check("shuffle does not mutate input", arr.join(",") === "1,2,3,4,5,6,7,8");
}

section("generateItems invariants (150 seeds x 20 items)");
{
  let structural = true;
  let solveOk = true;
  let exactlyOneCorrect = true;
  let optionsUnique = true;
  let correctIndexValid = true;
  let tierMonotonic = true;
  let sizeMatchesTier = true;
  let rulesMatchTier = true;
  let cellsSolvable = true;
  let lastCellMissing = true;
  for (let seed = 0; seed < 150; seed++) {
    const items = generateItems(seed);
    if (items.length !== ITEM_COUNT) structural = false;
    let prevTier = -1;
    for (const item of items) {
      const gridLen = item.size * item.size;
      if (item.cells.length !== gridLen) structural = false;
      if (item.cells[gridLen - 1] !== null) lastCellMissing = false;
      if (item.cells.slice(0, -1).some((c) => c === null)) lastCellMissing = false;
      if (item.options.length !== 6) structural = false;
      const keys = item.options.map(cellKey);
      if (new Set(keys).size !== 6) optionsUnique = false;
      if (item.correctIndex < 0 || item.correctIndex > 5) correctIndexValid = false;
      const solved = solveItem(item);
      if (!solved) solveOk = false;
      else {
        const solvedKey = cellKey(solved);
        const matches = keys.filter((k) => k === solvedKey);
        if (matches.length !== 1) exactlyOneCorrect = false;
        if (keys[item.correctIndex] !== solvedKey) solveOk = false;
      }
      // every given cell must render (non-empty element list)
      if (item.cells.slice(0, -1).some((c) => !c || c.elements.length === 0)) cellsSolvable = false;
      if (item.tier < prevTier) tierMonotonic = false;
      prevTier = item.tier;
      if ((item.size === 2) !== (item.tier === 0)) sizeMatchesTier = false;
      if (item.tier === 2 && item.rules.length !== 2) rulesMatchTier = false;
      if (item.tier < 2 && item.rules.length !== 1) rulesMatchTier = false;
      if (!gridConsistent(item)) solveOk = false;
    }
    if (items[0]!.tier !== 0 || items[ITEM_COUNT - 1]!.tier !== 2) tierMonotonic = false;
  }
  check("all 150 sessions have 20 structurally valid items", structural);
  check("last cell always missing, all others present", lastCellMissing && cellsSolvable);
  check("6 options per item, all unique", optionsUnique);
  check("correctIndex always in range", correctIndexValid);
  check("solveItem always returns a cell", solveOk);
  check("exactly ONE option matches the solved answer", exactlyOneCorrect);
  check("stored correctIndex matches solved answer", solveOk && exactlyOneCorrect);
  check("difficulty tier never goes backwards; starts 0 ends 2", tierMonotonic);
  check("2x2 iff tier 0", sizeMatchesTier);
  check("dual-rule items only in tier 2", rulesMatchTier);
}

section("Plan coverage: rule categories across a session");
{
  const items = generateItems(20240607);
  const counts = new Map<string, number>();
  for (const item of items) counts.set(item.category, (counts.get(item.category) ?? 0) + 1);
  const allCovered = RULE_ORDER.every((r) => (counts.get(r) ?? 0) >= 2);
  const total = RULE_ORDER.reduce((a, r) => a + (counts.get(r) ?? 0), 0);
  check("every one of the 5 categories appears at least twice", allCovered, JSON.stringify([...counts]));
  check("category counts sum to 20", total === 20, String(total));
  const quick = generateItems(20240607, QUICK_ITEM_COUNT);
  const quickCats = new Set(quick.map((i) => i.category));
  check("quick mode still covers all 5 categories", quickCats.size === 5, JSON.stringify([...quickCats]));
}

section("Quick mode + seed freshness");
{
  const full = generateItems(999);
  const quick = generateItems(999, QUICK_ITEM_COUNT);
  const quickFps = quick.map(itemFingerprint).join("|");
  const fullHeadFps = full.slice(0, 8).map(itemFingerprint).join("|");
  check("quick session = first 8 of the full session", quickFps === fullHeadFps);
  const sessionFps = new Set<string>();
  for (let seed = 0; seed < 150; seed++) {
    sessionFps.add(generateItems(seed).map(itemFingerprint).join("|"));
  }
  check(
    "fresh seed -> genuinely different session (>= 145/150 unique)",
    sessionFps.size >= 145,
    `${sessionFps.size}/150`
  );
  const fpSame = itemFingerprint(generateItems(12345)[0]!) === itemFingerprint(generateItems(12345)[0]!);
  const fpDiff = itemFingerprint(generateItems(12345)[0]!) !== itemFingerprint(generateItems(12346)[0]!);
  check("item fingerprint stable + content-sensitive", fpSame && fpDiff);
}

section("Distractor quality");
{
  let allDiffer = true;
  let plausible = true;
  let superstructure = true;
  for (let seed = 0; seed < 100; seed++) {
    for (const item of generateItems(seed)) {
      const correct = item.options[item.correctIndex]!;
      const solvedKey = cellKey(solveItem(item)!);
      if (cellKey(correct) !== solvedKey) allDiffer = false;
      for (let i = 0; i < 6; i++) {
        if (i === item.correctIndex) continue;
        const d = item.options[i]!;
        if (cellKey(d) === solvedKey) allDiffer = false;
        // plausibility: shares structure with the correct tile
        const dp = d.elements[0]!;
        const cp = correct.elements[0]!;
        const shares =
          dp.shape === cp.shape ||
          dp.fill === cp.fill ||
          dp.count === cp.count ||
          d.elements.length === correct.elements.length;
        if (!shares) plausible = false;
      }
      if (item.category === "superposition") {
        const solved = solveItem(item)!;
        if (solved.elements.length !== 2) superstructure = false;
        const dropDistractors = item.options.filter(
          (o) => cellKey(o) !== solvedKey && o.elements.length === 1
        ).length;
        if (dropDistractors < 1) superstructure = false; // "forgot to combine" lure must exist
      }
    }
  }
  check("no distractor equals the correct tile (100 seeds)", allDiffer);
  check("distractors share features with the correct tile", plausible);
  check("superposition items include a drop-an-element lure", superstructure);
}

section("gradeAnswer");
{
  const item = generateItems(7)[0]!;
  check("gradeAnswer(correctIndex) true", gradeAnswer(item, item.correctIndex) === true);
  check(
    "gradeAnswer(wrong) false",
    item.options.every(
      (_, i) => i === item.correctIndex || gradeAnswer(item, i) === false
    )
  );
  check("gradeAnswer(null) false", gradeAnswer(item, null) === false);
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check("normalCdf(+1sd) ~ 0.8413", Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6);
}

section("rawToIq / iqToPercentile mapping");
{
  check("raw at population mean -> IQ 100", rawToIq(POPULATION_RAW_MEAN) === 100, String(rawToIq(POPULATION_RAW_MEAN)));
  check("raw mean+SD -> IQ 115", Math.abs(rawToIq(POPULATION_RAW_MEAN + POPULATION_RAW_SD) - 115) <= 1);
  check("raw mean-SD -> IQ 85", Math.abs(rawToIq(POPULATION_RAW_MEAN - POPULATION_RAW_SD) - 85) <= 1);
  check("raw 0 -> clamped IQ floor 55", rawToIq(0) === IQ_MIN, String(rawToIq(0)));
  check("raw 20 -> IQ ceiling band (140..145)", rawToIq(20) >= 140 && rawToIq(20) <= IQ_MAX, String(rawToIq(20)));
  let monotonic = true;
  for (let raw = 0; raw < 20; raw++) {
    if (rawToIq(raw + 1) < rawToIq(raw)) monotonic = false;
  }
  check("IQ strictly increasing in raw over 0..20", monotonic);
  check("IQ 100 -> 50th percentile", iqToPercentile(100) === 50, String(iqToPercentile(100)));
  check("IQ 115 -> ~84th", iqToPercentile(115) === 84, String(iqToPercentile(115)));
  check("IQ 85 -> ~16th", iqToPercentile(85) === 16, String(iqToPercentile(85)));
  check("percentile clamped 1..99 low", iqToPercentile(IQ_MIN) === 1);
  check("percentile clamped 1..99 high", iqToPercentile(IQ_MAX) === 99);
}

section("gradeForIq tiers");
{
  check("IQ 70 -> Developing", gradeForIq(70).label === "Developing");
  check("IQ 84.9 -> Developing (boundary)", gradeForIq(84.9).label === "Developing");
  check("IQ 85 -> Average", gradeForIq(85).label === "Average");
  check("IQ 99.4 -> Average", gradeForIq(99.4).label === "Average");
  check("IQ 100 -> Sharp", gradeForIq(100).label === "Sharp");
  check("IQ 114.6 -> Sharp", gradeForIq(114.6).label === "Sharp");
  check("IQ 115 -> Very sharp", gradeForIq(115).label === "Very sharp");
  check("IQ 129 -> Very sharp", gradeForIq(129).label === "Very sharp");
  check("IQ 130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check(
    "every grade has blurb + class",
    [70, 90, 105, 120, 135].every((q) => {
      const g = gradeForIq(q);
      return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
    })
  );
}

section("medianOf");
{
  check("empty -> 0", medianOf([]) === 0);
  check("odd sample", medianOf([3, 1, 2]) === 2);
  check("even sample averages middles", medianOf([1, 2, 3, 4]) === 2.5);
  check("unsorted input handled", medianOf([9, 1, 5, 3]) === 4);
}

section("scoreMatrixSession - validity + scoring paths");
{
  const items = generateItems(31337);
  const honestRts = items.map(() => 6000);

  const empty = scoreMatrixSession(items, items.map(() => null), items.map(() => null));
  check("empty session invalid", empty.valid === false && empty.invalidReason !== null);
  check("empty session IQ 0 / percentile 0", empty.iq === 0 && empty.percentile === 0);

  const perfect = scoreMatrixSession(
    items,
    items.map((i) => i.correctIndex),
    honestRts
  );
  check("perfect session valid", perfect.valid === true && perfect.invalidReason === null);
  check("perfect raw = 20", perfect.raw === 20 && perfect.correct === 20);
  check("perfect IQ = ceiling band", perfect.iq >= 140 && perfect.iq <= IQ_MAX, String(perfect.iq));
  check("perfect percentile 99", perfect.percentile === 99);
  check("perfect not rushed", perfect.rushed === false);
  check(
    "perfect rule bars all full",
    perfect.ruleAccuracy.every((r) => r.correct === r.total && r.total > 0),
    JSON.stringify(perfect.ruleAccuracy)
  );

  const allWrong = scoreMatrixSession(
    items,
    items.map((i) => (i.correctIndex + 1) % 6),
    honestRts
  );
  check("all-wrong raw = 0", allWrong.raw === 0);
  check("all-wrong IQ = floor 55", allWrong.iq === IQ_MIN, String(allWrong.iq));
  check("all-wrong percentile 1", allWrong.percentile === 1);
  check("all-wrong still valid (honest floor score)", allWrong.valid === true);

  const half = scoreMatrixSession(
    items,
    items.map((i, idx) => (idx < 10 ? i.correctIndex : ((i.correctIndex + 2) % 6))),
    honestRts
  );
  check("half session raw = 10", half.raw === 10);
  check("half IQ matches rawToIq(10)", half.iq === rawToIq(10), `${half.iq} vs ${rawToIq(10)}`);
  check("half percentile matches map", half.percentile === iqToPercentile(half.iq));

  // Only quantity-category items correct
  const qAnswers = items.map((i) =>
    i.category === "quantity" ? i.correctIndex : ((i.correctIndex + 1) % 6)
  );
  const qScore = scoreMatrixSession(items, qAnswers, honestRts);
  const qRule = qScore.ruleAccuracy.find((r) => r.category === "quantity")!;
  const others = qScore.ruleAccuracy.filter((r) => r.category !== "quantity");
  check(
    "quantity-only run: quantity bar full",
    qRule.correct === qRule.total && qRule.total === 6,
    JSON.stringify(qRule)
  );
  check("quantity-only run: all other bars zero", others.every((r) => r.correct === 0));
  check("rule bars cover all 5 categories", qScore.ruleAccuracy.length === 5);
}

section("scoreMatrixSession - rushed honesty logic");
{
  const items = generateItems(31337);
  const answers = items.map((i) => i.correctIndex);

  const fast = scoreMatrixSession(items, answers, items.map(() => 400));
  check("median 400ms -> rushed", fast.rushed === true, String(fast.medianRtMs));
  check("fastCount = 20", fast.fastCount === 20);
  check("rushed session still valid + scored", fast.valid === true && fast.iq === rawToIq(20));

  const slow = scoreMatrixSession(items, answers, items.map(() => 3000));
  check("median 3000ms -> not rushed", slow.rushed === false);
  check("fastCount = 0", slow.fastCount === 0);

  // Even count: [1900, 1900, 2100, 2100...] median exactly 2000 -> NOT rushed (strict <)
  const boundaryRts = items.map((_, i) => (i % 2 === 0 ? 1900 : 2100));
  const boundary = scoreMatrixSession(items, answers, boundaryRts);
  check("median exactly 2000ms -> not rushed (strict <)", boundary.rushed === false, String(boundary.medianRtMs));

  const subRts = items.map((_, i) => (i % 2 === 0 ? 1800 : 2100));
  const sub = scoreMatrixSession(items, answers, subRts);
  check("median 1950ms -> rushed", sub.rushed === true, String(sub.medianRtMs));

  // Too few answered: rushing does not apply
  const sparseAnswers: (number | null)[] = items.map((i, idx) => (idx < MIN_RUSHED_N - 1 ? i.correctIndex : null));
  const sparseRts: (number | null)[] = items.map(() => 300);
  const sparse = scoreMatrixSession(items, sparseAnswers, sparseRts);
  check(
    `fewer than ${MIN_RUSHED_N} answers -> never rushed`,
    sparse.rushed === false && sparse.answered === MIN_RUSHED_N - 1
  );
  check("sparse raw counts only answered items", sparse.raw === MIN_RUSHED_N - 1);

  // Median RT passthrough on a mixed even-count sample (12 answered)
  const mixedAnswers: (number | null)[] = items.map((i, idx) => (idx < 12 ? i.correctIndex : null));
  const mixedRts: (number | null)[] = [
    1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000,
    ...items.slice(12).map(() => null),
  ];
  const mixed = scoreMatrixSession(items, mixedAnswers, mixedRts);
  check("mixed median = 6500ms (even avg of 6000/7000)", mixed.medianRtMs === 6500, String(mixed.medianRtMs));
}

section("Population simulation (N=500 realistic profiles)");
{
  const TIER_D = [-0.85, -0.05, 0.55];
  const K = 1.3;
  const calItems = generateItems(12345);
  const iqSamples: number[] = [];
  const rawSamples: number[] = [];
  let allValid = true;
  let anyRushed = false;
  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(50_000 + user);
    const ability = randn(rng) * 0.45;
    const answers = calItems.map((it) => {
      const p = 1 / (1 + Math.exp(-K * (ability - TIER_D[it.tier]!)));
      return rng() < p ? it.correctIndex : (it.correctIndex + 1 + Math.floor(rng() * 5)) % 6;
    });
    const rts = calItems.map(() => 6000);
    const score = scoreMatrixSession(calItems, answers, rts);
    if (!score.valid) allValid = false;
    if (score.rushed) anyRushed = true;
    iqSamples.push(score.iq);
    rawSamples.push(score.raw);
  }
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanRaw = mean(rawSamples);
  check("all realistic users produce valid scores", allValid);
  check("no honest-pace user flagged rushed", !anyRushed);
  check(
    "simulated raw mean matches calibration constants (+/- 0.3)",
    Math.abs(meanRaw - POPULATION_RAW_MEAN) < 0.3,
    `raw mean ${meanRaw.toFixed(2)} vs constant ${POPULATION_RAW_MEAN}`
  );
  check(
    "simulated raw SD matches calibration constants (+/- 0.3)",
    Math.abs(sd(rawSamples) - POPULATION_RAW_SD) < 0.3,
    `raw sd ${sd(rawSamples).toFixed(2)} vs constant ${POPULATION_RAW_SD}`
  );
  check("mean IQ in 100 +/- 2", meanIq >= 98 && meanIq <= 102, String(meanIq.toFixed(2)));
  check("IQ SD ~ 15 (12.5..17.5)", sdIq >= 12.5 && sdIq <= 17.5, String(sdIq.toFixed(2)));
  console.log(`  info   simulated mean raw=${meanRaw.toFixed(2)} mean IQ=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)}`);
}

section("Anti-gaming: random guessers land near the floor");
{
  const calItems = generateItems(12345);
  const iqSamples: number[] = [];
  const rawSamples: number[] = [];
  for (let user = 0; user < 200; user++) {
    const rng = mulberry32(900_000 + user);
    const answers = calItems.map(() => Math.floor(rng() * 6));
    const score = scoreMatrixSession(calItems, answers, calItems.map(() => 6000));
    iqSamples.push(score.iq);
    rawSamples.push(score.raw);
  }
  const meanIq = mean(iqSamples);
  const maxIq = Math.max(...iqSamples);
  check("guesser mean IQ < 80", meanIq < 80, String(meanIq.toFixed(1)));
  check("no guesser reaches above-average IQ (>100)", maxIq <= 100, String(maxIq));
  check("guesser mean raw near chance (~2-5)", mean(rawSamples) > 2 && mean(rawSamples) < 5, mean(rawSamples).toFixed(2));
  console.log(`  info   guesser mean raw=${mean(rawSamples).toFixed(2)} mean IQ=${meanIq.toFixed(1)} max IQ=${maxIq}`);
}

section("End-to-end pipeline coherence (3 ability profiles)");
{
  const runProfile = (seed: number, ability: number) => {
    const TIER_D = [-0.85, -0.05, 0.55];
    const K = 1.3;
    const rng = mulberry32(seed);
    const calItems = generateItems(seed + 1);
    const answers = calItems.map((it) => {
      const p = 1 / (1 + Math.exp(-K * (ability - TIER_D[it.tier]!)));
      return rng() < p ? it.correctIndex : (it.correctIndex + 1 + Math.floor(rng() * 5)) % 6;
    });
    const rts = calItems.map((_, i) => (ability < 0 ? 9000 + i : 4000 + i));
    return scoreMatrixSession(calItems, answers, rts);
  };
  const weak = runProfile(7, -1.2);
  const avg = runProfile(8, 0);
  const strong = runProfile(9, 1.4);
  check("all three profiles valid", weak.valid && avg.valid && strong.valid);
  check(
    "weak < avg < strong raw",
    weak.raw < avg.raw && avg.raw < strong.raw,
    `${weak.raw} < ${avg.raw} < ${strong.raw}`
  );
  check(
    "weak < avg < strong IQ",
    weak.iq < avg.iq && avg.iq < strong.iq,
    `${weak.iq} < ${avg.iq} < ${strong.iq}`
  );
  check(
    "weak < avg < strong percentile",
    weak.percentile < avg.percentile && avg.percentile < strong.percentile
  );
  check("strong not rushed, weak not rushed (honest RTs)", !strong.rushed && !weak.rushed);
  check(
    "grades ordered",
    gradeForIq(weak.iq).label !== gradeForIq(strong.iq).label
  );
  console.log(`  info   weak IQ ${weak.iq} (${weak.grade.label}), avg IQ ${avg.iq} (${avg.grade.label}), strong IQ ${strong.iq} (${strong.grade.label})`);
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
