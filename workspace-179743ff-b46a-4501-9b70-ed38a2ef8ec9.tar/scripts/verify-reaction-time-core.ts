/* ------------------------------------------------------------------ */
/*  Unit verification for reaction-time-core.ts                        */
/*  Run: bun scripts/verify-reaction-time-core.ts                      */
/* ------------------------------------------------------------------ */

import {
  ACCURACY_MEAN,
  ACCURACY_SD,
  ANTICIPATION_MS,
  CHOICE_RT_MEDIAN,
  CHOICE_RT_SD,
  CHOICE_TRIALS,
  FOREPERIOD_MAX_MS,
  FOREPERIOD_MIN_MS,
  INDEX_MAX,
  INDEX_MIN,
  INVALID_RATE_THRESHOLD,
  LAPSE_MS,
  MAX_ANTICIPATION_RETRIES,
  MIN_VALID_PER_KIND,
  QUICK_CHOICE_TRIALS,
  QUICK_SIMPLE_TRIALS,
  SIMPLE_RT_MEDIAN,
  SIMPLE_RT_SD,
  SIMPLE_TRIALS,
  VARIABILITY_MEDIAN,
  VARIABILITY_SD,
  WEIGHT_ACCURACY,
  WEIGHT_CHOICE,
  WEIGHT_SIMPLE,
  WEIGHT_VARIABILITY,
  classifyRt,
  compositeToIndex,
  erf,
  gradeForIndex,
  indexToPercentile,
  median,
  mulberry32,
  normalCdf,
  randomForeperiod,
  sampleSd,
  scoreSession,
  shuffle,
  type RtTrial,
} from "../src/components/test/reaction-time-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const clampMs = (x: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, x));

function mkTrial(
  kind: "simple" | "choice",
  outcome: "valid" | "lapse" | "skipped",
  rtMs: number,
  correct = true,
  anticipationAttempts = 0
): RtTrial {
  return {
    kind,
    outcome,
    rtMs,
    correct,
    litPad: kind === "choice" ? 1 : -1,
    responsePad: kind === "choice" ? (correct ? 1 : 2) : -1,
    anticipationAttempts,
  };
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("5 simple trials by default", SIMPLE_TRIALS === 5, String(SIMPLE_TRIALS));
check("10 choice trials by default", CHOICE_TRIALS === 10, String(CHOICE_TRIALS));
check("quick mode: 3 simple", QUICK_SIMPLE_TRIALS === 3, String(QUICK_SIMPLE_TRIALS));
check("quick mode: 6 choice", QUICK_CHOICE_TRIALS === 6, String(QUICK_CHOICE_TRIALS));
check(
  "foreperiod window 1500-4500ms",
  FOREPERIOD_MIN_MS === 1500 && FOREPERIOD_MAX_MS === 4500,
  `${FOREPERIOD_MIN_MS}-${FOREPERIOD_MAX_MS}`
);
check("anticipation floor 150ms", ANTICIPATION_MS === 150, String(ANTICIPATION_MS));
check("lapse ceiling 1500ms", LAPSE_MS === 1500, String(LAPSE_MS));
check("max anticipation retries is 2", MAX_ANTICIPATION_RETRIES === 2);
check("invalid-rate threshold 0.30", INVALID_RATE_THRESHOLD === 0.3);
check("min valid per kind is 2", MIN_VALID_PER_KIND === 2);
check(
  "composite weights 0.55/0.35/0.10 + accuracy",
  WEIGHT_SIMPLE === 0.55 && WEIGHT_CHOICE === 0.35 && WEIGHT_VARIABILITY === 0.1 && WEIGHT_ACCURACY === 0.1,
  `${WEIGHT_SIMPLE}/${WEIGHT_CHOICE}/${WEIGHT_VARIABILITY}`
);
check(
  "population anchors 300/55 and 500/80",
  SIMPLE_RT_MEDIAN === 300 && SIMPLE_RT_SD === 55 && CHOICE_RT_MEDIAN === 500 && CHOICE_RT_SD === 80,
  `${SIMPLE_RT_MEDIAN}/${SIMPLE_RT_SD} ${CHOICE_RT_MEDIAN}/${CHOICE_RT_SD}`
);
check(
  "variability + accuracy anchors sane",
  VARIABILITY_MEDIAN === 45 && VARIABILITY_SD === 20 && ACCURACY_MEAN === 0.94 && ACCURACY_SD === 0.06
);
check("index scale 55-145", INDEX_MIN === 55 && INDEX_MAX === 145);

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const seqC = Array.from({ length: 20 }, () => mulberry32(43)());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));

  const arr = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = shuffle(arr, mulberry32(7));
  check(
    "shuffle preserves multiset",
    shuffled.slice().sort((a, b) => a - b).join(",") === "1,2,3,4,5,6,7,8"
  );
  check("shuffle does not mutate input", arr.join(",") === "1,2,3,4,5,6,7,8");
  check(
    "shuffle actually reorders sometimes across seeds",
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].some(
      (seed) => shuffle(arr, mulberry32(seed)).join(",") !== arr.join(",")
    )
  );
}

section("Foreperiod bounds over 200 seeds");
{
  let allInWindow = true;
  let allInteger = true;
  let sawNearMin = false;
  let sawNearMax = false;
  let sum = 0;
  for (let seed = 0; seed < 200; seed++) {
    const fp = randomForeperiod(mulberry32(seed));
    if (fp < FOREPERIOD_MIN_MS || fp >= FOREPERIOD_MAX_MS) allInWindow = false;
    if (!Number.isInteger(fp)) allInteger = false;
    if (fp < 1800) sawNearMin = true;
    if (fp > 4200) sawNearMax = true;
    sum += fp;
  }
  const mean = sum / 200;
  check("all foreperiods within [1500, 4500)", allInWindow);
  check("all foreperiods are integers", allInteger);
  check("foreperiods reach near the bottom of the window", sawNearMin);
  check("foreperiods reach near the top of the window", sawNearMax);
  check(
    "foreperiod mean near midpoint of uniform range",
    mean > 2800 && mean < 3200,
    String(mean.toFixed(1))
  );
  check(
    "foreperiod genuinely differs across seeds",
    randomForeperiod(mulberry32(1)) !== randomForeperiod(mulberry32(2)) ||
      randomForeperiod(mulberry32(2)) !== randomForeperiod(mulberry32(3))
  );
}

section("classifyRt windows (149/150/1500/1501)");
{
  check("0ms -> anticipation", classifyRt(0) === "anticipation");
  check("100ms -> anticipation", classifyRt(100) === "anticipation");
  check("149ms -> anticipation", classifyRt(149) === "anticipation", classifyRt(149));
  check("150ms -> valid (boundary)", classifyRt(150) === "valid", classifyRt(150));
  check("151ms -> valid", classifyRt(151) === "valid");
  check("300ms -> valid", classifyRt(300) === "valid");
  check("1500ms -> valid (boundary)", classifyRt(1500) === "valid", classifyRt(1500));
  check("1501ms -> lapse (boundary)", classifyRt(1501) === "lapse", classifyRt(1501));
  check("4000ms -> lapse", classifyRt(4000) === "lapse");
}

section("median / sampleSd math");
{
  check("median empty = 0", median([]) === 0);
  check("median single = value", median([5]) === 5);
  check("median odd count", median([3, 1, 2]) === 2);
  check("median even count = mean of middles", median([4, 1, 3, 2]) === 2.5);
  check("median ignores order", median([9, 1, 8, 2, 7]) === 7);
  check("sd empty = 0", sampleSd([]) === 0);
  check("sd single = 0", sampleSd([300]) === 0);
  check("sd constant = 0", sampleSd([300, 300, 300, 300, 300]) === 0);
  check(
    "sd known sample (sqrt(250) ~ 15.81)",
    Math.abs(sampleSd([280, 300, 320, 290, 310]) - Math.sqrt(250)) < 1e-9,
    String(sampleSd([280, 300, 320, 290, 310]))
  );
  check("sd two values", Math.abs(sampleSd([2, 4]) - Math.SQRT2) < 1e-12);
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check(
    "normalCdf(+1sd) ~ 0.8413",
    Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6
  );
}

section("compositeToIndex / indexToPercentile clamps");
{
  check("composite 0 -> index 100", compositeToIndex(0) === 100);
  check("composite +1 -> index 115", compositeToIndex(1) === 115);
  check("composite -1 -> index 85", compositeToIndex(-1) === 85);
  check("huge composite clamps to 145", compositeToIndex(10) === INDEX_MAX);
  check("tiny composite clamps to 55", compositeToIndex(-10) === INDEX_MIN);
  check("percentile 100 -> 50", indexToPercentile(100) === 50);
  check("percentile 115 -> 84", indexToPercentile(115) === 84, String(indexToPercentile(115)));
  check("percentile 85 -> 16", indexToPercentile(85) === 16, String(indexToPercentile(85)));
  check("percentile clamps low", indexToPercentile(INDEX_MIN) === 1);
  check("percentile clamps high", indexToPercentile(INDEX_MAX) === 99);
  let monotonic = true;
  for (let idx = INDEX_MIN; idx < INDEX_MAX; idx++) {
    if (indexToPercentile(idx + 1) < indexToPercentile(idx)) monotonic = false;
  }
  check("percentile monotonic non-decreasing in index", monotonic);
}

section("gradeForIndex tiers");
{
  check("80 -> Steady", gradeForIndex(80).label === "Steady");
  check("84.9 -> Steady (boundary)", gradeForIndex(84.9).label === "Steady");
  check("85 -> Average", gradeForIndex(85).label === "Average");
  check("99.9 -> Average", gradeForIndex(99.9).label === "Average");
  check("100 -> Quick", gradeForIndex(100).label === "Quick");
  check("114.9 -> Quick", gradeForIndex(114.9).label === "Quick");
  check("115 -> Very quick", gradeForIndex(115).label === "Very quick");
  check("129.9 -> Very quick", gradeForIndex(129.9).label === "Very quick");
  check("130 -> Elite", gradeForIndex(130).label === "Elite");
  check("Elite uses the black accent", gradeForIndex(135).className.includes("neutral-900"));
  check("every grade has blurb + class", [70, 90, 105, 120, 135].every((p) => {
    const g = gradeForIndex(p);
    return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("scoreSession - hand-computed scoring paths");
{
  // Case A: anchor session - everything exactly on the population medians.
  const anchor = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 500, true)),
  ]);
  check("anchor session valid", anchor.valid === true && anchor.invalidReason === null);
  check("anchor median simple = 300ms", anchor.medianSimpleMs === 300);
  check("anchor median choice = 500ms", anchor.medianChoiceMs === 500);
  check("anchor accuracy = 1", anchor.choiceAccuracy === 1);
  // zS=0, zC=0, zV=-2.25 -> +0.225, zA=+1 -> +0.10 => composite 0.325 => 104.875 -> 105
  check("anchor RT Index = 105", anchor.rtIndex === 105, String(anchor.rtIndex));
  check("anchor percentile = 63", anchor.percentile === 63, String(anchor.percentile));
  check("anchor grade = Quick", anchor.grade.label === "Quick");
  check("anchor validity clean", anchor.validTrials === 15 && anchor.anticipationCount === 0 && anchor.lapseCount === 0);

  // Case B: fast session.
  const fast = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 240)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 400, true)),
  ]);
  // composite = 0.6 + 0.4375 + 0.225 + 0.10 = 1.3625 => 120.4375 -> 120
  check("fast RT Index = 120", fast.rtIndex === 120, String(fast.rtIndex));
  check("fast percentile = 91", fast.percentile === 91, String(fast.percentile));
  check("fast grade = Very quick", fast.grade.label === "Very quick");

  // Case C: slow session.
  const slow = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 400)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 650, true)),
  ]);
  // composite = -1.0 - 0.65625 + 0.225 + 0.10 = -1.33125 => 80.03 -> 80
  check("slow RT Index = 80", slow.rtIndex === 80, String(slow.rtIndex));
  check("slow percentile = 9", slow.percentile === 9, String(slow.percentile));
  check("slow grade = Steady", slow.grade.label === "Steady");

  // Case D: mixed medians incl. even-count choice median.
  const mixed = scoreSession([
    ...[280, 300, 320, 290, 310].map((rt) => mkTrial("simple", "valid", rt)),
    ...[480, 490, 500, 510, 520, 495, 505, 515, 485, 525].map((rt) =>
      mkTrial("choice", "valid", rt, true)
    ),
  ]);
  // medianSimple 300 (zS=0), medianChoice 502.5 (zC=-0.01094), sd 15.81
  // (zV=-1.45943 -> +0.14594), zA +0.10 => composite 0.235 => 103.53 -> 104
  check("mixed RT Index = 104", mixed.rtIndex === 104, String(mixed.rtIndex));
  check("mixed median choice = 502.5", mixed.medianChoiceMs === 502.5);
  check(
    "mixed variability = sqrt(250)",
    Math.abs(mixed.variabilityMs - Math.sqrt(250)) < 1e-9,
    String(mixed.variabilityMs)
  );

  // Extreme fast/slow clamps.
  const extremeFast = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 151)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 260, true)),
  ]);
  check("extreme fast = 143 (within clamp)", extremeFast.rtIndex === 143, String(extremeFast.rtIndex));
  const extremeSlow = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 1400)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 1400, true)),
  ]);
  check("extreme slow clamps to 55", extremeSlow.rtIndex === INDEX_MIN, String(extremeSlow.rtIndex));
  check("extreme slow percentile clamps to 1", extremeSlow.percentile === 1);
}

section("Composite monotonicity (faster -> higher index)");
{
  let simpleMonotonic = true;
  for (let ms = 200; ms <= 500; ms += 5) {
    const a = scoreSession([
      ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", ms)),
      ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 500, true)),
    ]);
    const b = scoreSession([
      ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", ms + 5)),
      ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 500, true)),
    ]);
    if (b.rtIndex > a.rtIndex) simpleMonotonic = false;
  }
  check("index non-increasing as simple RT grows", simpleMonotonic);

  let choiceMonotonic = true;
  for (let ms = 300; ms <= 800; ms += 10) {
    const a = scoreSession([
      ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
      ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", ms, true)),
    ]);
    const b = scoreSession([
      ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
      ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", ms + 10, true)),
    ]);
    if (b.rtIndex > a.rtIndex) choiceMonotonic = false;
  }
  check("index non-increasing as choice RT grows", choiceMonotonic);

  // Higher accuracy should never lower the index (zA clamped at +1.5).
  const acc90 = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 10 }, (_, i) => mkTrial("choice", "valid", 500, i < 9)),
  ]);
  const acc100 = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 500, true)),
  ]);
  check("higher accuracy -> equal or higher index", acc100.rtIndex >= acc90.rtIndex,
    `${acc90.rtIndex} vs ${acc100.rtIndex}`);
}

section("scoreSession - validity paths");
{
  const empty = scoreSession([]);
  check("empty session invalid", empty.valid === false && empty.invalidReason !== null);
  check("empty reason mentions no responses", (empty.invalidReason ?? "").includes("No responses"));

  // Mash: every slot burned by anticipations (3 attempts each), all skipped.
  const mash = scoreSession(
    Array.from({ length: 9 }, () => mkTrial("choice", "skipped", 0, false, 3))
  );
  check("mash session invalid", mash.valid === false);
  check("mash flagged low validity", mash.lowValidity === true);
  check("mash invalid rate = 1", Math.abs(mash.invalidRate - 1) < 1e-9);
  check("mash reason mentions anticipations", (mash.invalidReason ?? "").toLowerCase().includes("anticipation"));
  check("mash anticipation count aggregated", mash.anticipationCount === 27, String(mash.anticipationCount));
  check("mash produces no index (no IQ inflation)", mash.rtIndex === 0 && mash.percentile === 0);
  check("mash grade = Not scored", mash.grade.label === "Not scored");
  check("mash preserves raw counts", mash.totalTrials === 9 && mash.validTrials === 0);

  // 15 trials, 5 skipped => 33.3% invalid -> flagged.
  const overThreshold = scoreSession([
    ...Array.from({ length: 5 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 5 }, () => mkTrial("choice", "valid", 500, true)),
    ...Array.from({ length: 5 }, () => mkTrial("choice", "skipped", 0, false, 3)),
  ]);
  check("33% invalid -> low validity", overThreshold.valid === false && overThreshold.lowValidity === true,
    String(overThreshold.invalidRate));

  // Boundary: exactly 30% invalid is still scoreable.
  const atThreshold = scoreSession([
    ...Array.from({ length: 4 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 3 }, () => mkTrial("choice", "valid", 500, true)),
    ...Array.from({ length: 3 }, () => mkTrial("choice", "skipped", 0, false, 3)),
  ]);
  check(
    "exactly 30% invalid is NOT flagged (strict >)",
    atThreshold.valid === true,
    `rate=${atThreshold.invalidRate} valid=${atThreshold.valid}`
  );

  // 31..40% invalid via lapses -> flagged.
  const lapseHeavy = scoreSession([
    ...Array.from({ length: 4 }, () => mkTrial("simple", "valid", 300)),
    ...Array.from({ length: 2 }, () => mkTrial("choice", "valid", 500, true)),
    ...Array.from({ length: 4 }, () => mkTrial("choice", "lapse", 1600, false, 0)),
  ]);
  check("40% invalid (lapses) -> low validity", lapseHeavy.valid === false && lapseHeavy.lowValidity === true,
    String(lapseHeavy.invalidRate));
  check("lapse trials excluded from medians", lapseHeavy.medianChoiceMs === 500);

  // Not enough valid simple trials, but invalid rate below threshold.
  const sparse = scoreSession([
    mkTrial("simple", "valid", 300),
    ...Array.from({ length: 4 }, () => mkTrial("simple", "skipped", 0, false, 3)),
    ...Array.from({ length: 10 }, () => mkTrial("choice", "valid", 500, true)),
  ]);
  check(
    "insufficient valid simple trials -> invalid with distinct reason",
    sparse.valid === false && (sparse.invalidReason ?? "").includes("Not enough valid trials"),
    sparse.invalidReason ?? "none"
  );
  check("sparse not flagged as low validity", sparse.lowValidity === false);

  // A fully valid quick-mode session (3 + 6) is scoreable.
  const quickSession = scoreSession([
    ...Array.from({ length: 3 }, () => mkTrial("simple", "valid", 280)),
    ...Array.from({ length: 6 }, () => mkTrial("choice", "valid", 460, true)),
  ]);
  check("quick-mode session valid", quickSession.valid === true);
  check("quick-mode index in scale range", quickSession.rtIndex >= INDEX_MIN && quickSession.rtIndex <= INDEX_MAX,
    String(quickSession.rtIndex));
  check("quick-mode valid counts", quickSession.validSimpleCount === 3 && quickSession.validChoiceCount === 6);
}

/* ------------------------------------------------------------------ */
/*  Population simulation (N=500 realistic profiles)                   */
/* ------------------------------------------------------------------ */

section("Population simulation (N=500)");
{
  const iqSamples: number[] = [];
  const simpleSamples: number[] = [];
  const choiceSamples: number[] = [];
  let allValid = true;
  let flaggedCount = 0;

  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(70_000 + user);
    const z = randn(rng); // shared latent speed factor
    const e1 = randn(rng);
    const e2 = randn(rng);
    const ev = randn(rng);
    const e3 = randn(rng);

    // True per-user levels: shared factor + specific noise, calibrated so
    // the OBSERVED 5/10-trial medians match the 300/55 and 500/80 anchors
    // (sampling noise of a median is folded into the decomposition).
    const tSimple = 300 - 48.9 * z + 9 * e1;
    const tChoice = 500 - 74 * z + 16 * e2;
    const sdW = clampMs(45 - 6 * z + 8 * ev, 20, 80); // within-user trial noise

    const trials: RtTrial[] = [];
    for (let i = 0; i < SIMPLE_TRIALS; i++) {
      const rt = clampMs(Math.round(tSimple + sdW * randn(rng)), 160, 1200);
      trials.push(mkTrial("simple", "valid", rt));
    }
    const acc = clampMs(0.93 + 0.03 * z + 0.025 * e3, 0.5, 1);
    for (let i = 0; i < CHOICE_TRIALS; i++) {
      const rt = clampMs(Math.round(tChoice + 56 * randn(rng)), 260, 1300);
      const correct = rng() < acc;
      trials.push({
        kind: "choice",
        outcome: "valid",
        rtMs: rt,
        correct,
        litPad: i % 4,
        responsePad: correct ? i % 4 : (i % 4 + 1) % 4,
        anticipationAttempts: 0,
      });
    }

    const score = scoreSession(trials);
    if (!score.valid) {
      allValid = false;
      flaggedCount++;
    }
    iqSamples.push(score.rtIndex);
    simpleSamples.push(score.medianSimpleMs);
    choiceSamples.push(score.medianChoiceMs);
  }

  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
  };
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanSimple = mean(simpleSamples);
  const sdSimple = sd(simpleSamples);
  const meanChoice = mean(choiceSamples);
  const sdChoice = sd(choiceSamples);

  check("all 500 realistic users produce valid scores", allValid, `${flaggedCount} flagged`);
  check(
    "mean observed simple RT median ~ 300 (290-310)",
    meanSimple > 290 && meanSimple < 310,
    `${meanSimple.toFixed(1)} (SD ${sdSimple.toFixed(1)})`
  );
  check(
    "observed simple median SD matches anchor ~55 (48-62)",
    sdSimple > 48 && sdSimple < 62,
    sdSimple.toFixed(1)
  );
  check(
    "mean observed choice RT median ~ 500 (488-512)",
    meanChoice > 488 && meanChoice < 512,
    `${meanChoice.toFixed(1)} (SD ${sdChoice.toFixed(1)})`
  );
  check(
    "observed choice median SD matches anchor ~80 (70-92)",
    sdChoice > 70 && sdChoice < 92,
    sdChoice.toFixed(1)
  );
  check(
    "mean RT Index near 100 (98-102)",
    meanIq > 98 && meanIq < 102,
    meanIq.toFixed(2)
  );
  check(
    "RT Index SD near 15 (12-18)",
    sdIq > 12 && sdIq < 18,
    sdIq.toFixed(2)
  );
  check(
    "index values within scale bounds",
    iqSamples.every((v) => v >= INDEX_MIN && v <= INDEX_MAX)
  );
  console.log(
    `  info   simulated N=500: mean index=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)} | simple ${meanSimple.toFixed(0)}ms (SD ${sdSimple.toFixed(0)}) | choice ${meanChoice.toFixed(0)}ms (SD ${sdChoice.toFixed(0)})`
  );
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
