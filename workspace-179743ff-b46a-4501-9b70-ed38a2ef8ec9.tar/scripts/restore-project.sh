#!/usr/bin/env bash
# ============================================================
# BrainMetrics Restore Script
# ------------------------------------------------------------
# Non-destructive preview restore by default.
#   bash scripts/restore-project.sh --list
#       -> show available backups
#
#   bash scripts/restore-project.sh --from-bundle [stamp]
#       -> clone FULL git history from a bundle into
#          /home/z/restore-<stamp>/  (safe, nothing overwritten)
#
#   bash scripts/restore-project.sh --from-tree [stamp]
#       -> extract working-tree snapshot into
#          /home/z/restore-<stamp>/  (safe, nothing overwritten)
#
#   bash scripts/restore-project.sh --from-bundle [stamp] --in-place
#       -> DANGEROUS: restore committed state over /home/z/my-project
#          (rsync --delete over working files, .git replaced from bundle)
# ============================================================
set -euo pipefail

PROJECT="/home/z/my-project"
OUT_PROJ="/home/z/brainmetrics-backups"
MODE="${1:-}"
STAMP="${2:-}"
IN_PLACE="no"
[ "${3:-}" = "--in-place" ] && IN_PLACE="yes"

usage() { grep '^#' "$0" | head -22; exit 1; }
[ -z "$MODE" ] && usage

# resolve stamp (default = LATEST)
if [ -z "$STAMP" ] && [ -f "$OUT_PROJ/LATEST" ]; then
  STAMP="$(cat "$OUT_PROJ/LATEST")"
fi

case "$MODE" in
  --list)
    echo "== LATEST pointer: $(cat "$OUT_PROJ/LATEST" 2>/dev/null || echo none)"
    echo "-- Bundles (full history) --"
    ls -1t "$OUT_PROJ"/repo-*.bundle 2>/dev/null | head -10 || echo "  none"
    echo "-- Tree snapshots --"
    ls -1t "$OUT_PROJ"/tree-*.tar.gz 2>/dev/null | head -10 || echo "  none"
    ;;

  --from-bundle)
    BUNDLE="$OUT_PROJ/repo-$STAMP.bundle"
    [ -f "$BUNDLE" ] || { echo "ERROR: $BUNDLE not found (--list to see)"; exit 1; }
    git bundle verify "$BUNDLE" > /dev/null
    if [ "$IN_PLACE" = "yes" ]; then
      echo "[restore] IN-PLACE restore from $BUNDLE"
      TMP="/home/z/.restore-tmp-$$"
      git clone --quiet "$BUNDLE" "$TMP"
      cd "$TMP"
      git checkout -- . 2>/dev/null || true
      # replace project working files (keep runtime dirs)
      rsync -a --delete --exclude '.git' --exclude 'node_modules' --exclude '.next' \
            --exclude 'backups' --exclude 'tool-results' "$TMP"/ "$PROJECT"/
      # replace git history so nothing is lost going forward
      rm -rf "$PROJECT/.git"
      mv "$TMP/.git" "$PROJECT/.git"
      rm -rf "$TMP"
      echo "[restore] DONE: project restored to bundle state ($STAMP). Run: cd $PROJECT && bun install && bun run dev"
    else
      DEST="/home/z/restore-$STAMP"
      rm -rf "$DEST"
      git clone --quiet "$BUNDLE" "$DEST"
      echo "[restore] SAFE restore -> $DEST (nothing overwritten)"
      echo "  pages: $(ls "$DEST/src/app/test" 2>/dev/null | tr '\n' ' ')"
    fi
    ;;

  --from-tree)
    TREE="$OUT_PROJ/tree-$STAMP.tar.gz"
    [ -f "$TREE" ] || { echo "ERROR: $TREE not found (--list to see)"; exit 1; }
    if [ "$IN_PLACE" = "yes" ]; then
      echo "[restore] IN-PLACE tree extract over $PROJECT"
      tar -xzf "$TREE" -C "$PROJECT"
      echo "[restore] DONE. Run: cd $PROJECT && bun install && bun run dev"
    else
      DEST="/home/z/restore-tree-$STAMP"
      rm -rf "$DEST" && mkdir -p "$DEST"
      tar -xzf "$TREE" -C "$DEST"
      echo "[restore] SAFE extract -> $DEST (nothing overwritten)"
      echo "  pages: $(ls "$DEST/src/app/test" 2>/dev/null | tr '\n' ' ')"
    fi
    ;;

  *)
    usage
    ;;
esac
