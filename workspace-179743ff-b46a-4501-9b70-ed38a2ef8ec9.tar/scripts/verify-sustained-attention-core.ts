/* ------------------------------------------------------------------ */
/*  Unit verification for sustained-attention-core.ts                  */
/*  Run: bun scripts/verify-sustained-attention-core.ts                */
/* ------------------------------------------------------------------ */

import {
  BLOCK_COUNT,
  BREAK_MS,
  BREAK_MS_QUICK,
  COMM_MEAN,
  COMM_SD,
  COMMISSION_GATE,
  COMPOSITE_MAX,
  DIGIT_ON_MS,
  DIGIT_ON_MS_QUICK,
  ISI_MS,
  ISI_MS_QUICK,
  IQ_MAX,
  IQ_MIN,
  MIN_VALID_RT_MS,
  NO_GO_DIGIT,
  OMIT_GATE,
  OMIT_MEAN,
  OMIT_SD,
  RTCV_MEAN,
  RTCV_SD,
  SART_DIGITS,
  TOTAL_NO_GO,
  TOTAL_TRIALS,
  TRIALS_PER_BLOCK,
  W_COMMISSION,
  W_OMISSION,
  W_RTCV,
  Z_CLAMP,
  buildSaSession,
  clampZ,
  gradeForIq,
  iqToPercentile,
  mean,
  mulberry32,
  rtCv,
  sampleSd,
  scoreSession,
  shuffled,
  saIndex,
  type SaResponse,
} from "../src/components/test/sustained-attention-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("6 blocks x 30 trials", BLOCK_COUNT === 6 && TRIALS_PER_BLOCK === 30);
check("TOTAL_TRIALS is 180", TOTAL_TRIALS === 180);
check("TOTAL_NO_GO is exactly 20", TOTAL_NO_GO === 20);
check("no-go digit is 3", NO_GO_DIGIT === 3);
check("digits are 1..9", JSON.stringify(SART_DIGITS) === "[1,2,3,4,5,6,7,8,9]");
check("DIGIT_ON_MS 250 / ISI_MS 900", DIGIT_ON_MS === 250 && ISI_MS === 900);
check("BREAK_MS is 2000", BREAK_MS === 2000);
check(
  "quick timings all shorter than normal",
  DIGIT_ON_MS_QUICK < DIGIT_ON_MS &&
    ISI_MS_QUICK < ISI_MS &&
    BREAK_MS_QUICK < BREAK_MS
);
check("MIN_VALID_RT_MS is 100", MIN_VALID_RT_MS === 100);
check(
  "anchors: commission 0.45/0.15, omission 0.03/0.05, rtcv 0.18/0.06",
  COMM_MEAN === 0.45 && COMM_SD === 0.15 &&
    OMIT_MEAN === 0.03 && OMIT_SD === 0.05 &&
    RTCV_MEAN === 0.18 && RTCV_SD === 0.06
);
check("weights 0.65 / 0.15 / 0.20", W_COMMISSION === 0.65 && W_OMISSION === 0.15 && W_RTCV === 0.2);
check("participation gates 0.4 / 0.75, z-clamp 3", OMIT_GATE === 0.4 && COMMISSION_GATE === 0.75 && Z_CLAMP === 3);
check(
  "COMPOSITE_MAX = 0.65*3 + 0.15*0.6 + 0.2*3",
  Math.abs(COMPOSITE_MAX - (0.65 * 3 + 0.15 * 0.6 + 0.2 * 3)) < 1e-12
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("Session building: the exact-balance promise");
{
  // The core structural promise: every seed gives 180 trials with
  // EXACTLY 20 threes and 160 others, cut into 6 blocks of 30.
  let balanceFailure: string | null = null;
  let blockShapeFailure: string | null = null;
  for (let seed = 1; seed <= 300 && !balanceFailure; seed++) {
    const s = buildSaSession(seed);
    if (s.blocks.length !== 6) blockShapeFailure = `seed ${seed}: ${s.blocks.length} blocks`;
    for (const b of s.blocks) {
      if (b.length !== 30) blockShapeFailure = `seed ${seed}: block of ${b.length}`;
    }
    const flat = s.blocks.flat();
    const threes = flat.filter((d) => d === 3).length;
    const digitsOk = flat.every((d) => d >= 1 && d <= 9);
    if (threes !== 20 || flat.length !== 180 || !digitsOk) {
      balanceFailure = `seed ${seed}: threes=${threes} len=${flat.length}`;
    }
  }
  check("every seed: 180 digits, exactly 20 no-gos", balanceFailure === null, balanceFailure ?? "");
  check("every seed: 6 blocks of exactly 30", blockShapeFailure === null, blockShapeFailure ?? "");
  const a = buildSaSession(1).blocks.flat().join(",");
  const b = buildSaSession(2).blocks.flat().join(",");
  const a2 = buildSaSession(777).blocks.flat().join(",");
  const a3 = buildSaSession(777).blocks.flat().join(",");
  check("same seed reproduces exactly", a2 === a3);
  check("different seeds reshuffle", a !== b || a !== a2);
}

section("Stat helpers");
{
  check("mean empty -> null", mean([]) === null);
  check("mean [1,2,3] = 2", mean([1, 2, 3]) === 2);
  check("sampleSd of single value -> null", sampleSd([5]) === null);
  check("sampleSd [2,4] = sqrt2", Math.abs(sampleSd([2, 4])! - Math.SQRT2) < 1e-12);
  check("rtCv constant series -> 0 (needs >=2)", rtCv([300, 300, 300]) === 0);
  check("rtCv single value -> null", rtCv([300]) === null);
  check("rtCv [200,400] = sqrt(20000)/300", Math.abs(rtCv([200, 400])! - Math.sqrt(20000) / 300) < 1e-9);
  check("clampZ +5 -> 3, -9 -> -3", clampZ(5) === 3 && clampZ(-9) === -3);
}

section("Scoring: perfect run (respond to all go, withhold all 3s)");
{
  const session = buildSaSession(500);
  const flat = session.blocks.flat();
  const responses: SaResponse[] = flat.map((digit, trial) => ({
    trial,
    pressed: digit !== NO_GO_DIGIT,
    rtMs: digit !== NO_GO_DIGIT ? 380 : null,
  }));
  const score = scoreSession(responses, session);
  check("zero commissions", score.commissions === 0);
  check("zero omissions", score.omissions === 0);
  check("commissionRate 0 / omissionRate 0", score.commissionRate === 0 && score.omissionRate === 0);
  check("IQ 145 (z_comm = +3 alone hits ceiling)", score.iq === 145, String(score.iq));
  check("percentile 99", score.percentile === 99);
  check("grade Laser", score.grade.label === "Laser");
  check("not gated", score.gated === false);
  check("valid go responses 160", score.validGoResponses === 160);
  check("meanRtMs = 380", Math.abs(score.meanRtMs! - 380) < 1e-9);
  check("rtCv 0 for constant RTs", score.rtCv === 0);
  check("6 block stats present", score.blocks.length === 6);
  check("block sums match totals", score.blocks.reduce((a, s) => a + s.commissions, 0) === 0);
}

section("Scoring: press-everything anti-gaming");
{
  const session = buildSaSession(500);
  const responses: SaResponse[] = Array.from({ length: 180 }, (_, trial) => ({
    trial,
    pressed: true,
    rtMs: 350,
  }));
  const score = scoreSession(responses, session);
  check("all 20 threes become commissions", score.commissions === 20);
  check("commissionRate 1.0", score.commissionRate === 1);
  check("IQ pinned to 55 (z_comm = -3)", score.iq === 55, String(score.iq));
  check("percentile 1", score.percentile === 1);
  check("grade Drifting", score.grade.label === "Drifting");
}

section("Scoring: press-nothing participation gate");
{
  const session = buildSaSession(500);
  const score = scoreSession([], session);
  check("omissionRate 1.0", score.omissionRate === 1);
  check("gate triggered", score.gated === true);
  check("IQ floored to 55", score.iq === 55);
  check("grade Drifting", score.grade.label === "Drifting");
  check("zero valid RTs", score.validGoResponses === 0 && score.rtCv === null);
}

section("Scoring: 50/50 mashing cannot win");
{
  // Respond on odd trials only: half the go trials missed, half the 3s caught.
  const session = buildSaSession(600);
  const responses: SaResponse[] = Array.from({ length: 180 }, (_, trial) => ({
    trial,
    pressed: trial % 2 === 0,
    rtMs: trial % 2 === 0 ? 400 : null,
  }));
  const score = scoreSession(responses, session);
  check("mash-50 omission ~0.5 (well above anchor)", score.omissionRate > 0.4, String(score.omissionRate.toFixed(2)));
  check("gate triggers on 50% omissions", score.gated === true && score.iq === 55);
}

section("Scoring: RT stats and validity floor");
{
  const session = buildSaSession(700);
  const flat = session.blocks.flat();
  const responses: SaResponse[] = flat.map((digit, trial) => {
    if (digit === NO_GO_DIGIT) return { trial, pressed: false, rtMs: null };
    // alternate valid 400ms and impossible 50ms responses
    return { trial, pressed: true, rtMs: trial % 2 === 0 ? 400 : 50 };
  });
  const expectedValid = flat.filter(
    (d, t) => d !== NO_GO_DIGIT && t % 2 === 0
  ).length;
  const score = scoreSession(responses, session);
  check("impossible <100ms RTs excluded from stats", score.validGoResponses === expectedValid, `${score.validGoResponses} vs ${expectedValid}`);
  check("meanRtMs = 400 over valid only", Math.abs(score.meanRtMs! - 400) < 1e-9);
  check("rtCv 0 over constant valid RTs", score.rtCv === 0);
  check("still no omissions (press counted regardless of RT)", score.omissions === 0);
}

section("Scoring: block-level accounting");
{
  const session = buildSaSession(800);
  const flat = session.blocks.flat();
  // Commission exactly on every 3 in block 0 and 5, omissions in block 2.
  const responses: SaResponse[] = flat.map((digit, trial) => {
    const block = Math.floor(trial / 30);
    if (digit === NO_GO_DIGIT) return { trial, pressed: block === 0 || block === 5, rtMs: null };
    return { trial, pressed: block !== 2, rtMs: 420 };
  });
  const score = scoreSession(responses, session);
  const blockThrees = session.blocks.map((b) => b.filter((d) => d === 3).length);
  check(
    "commissions per block sum to total",
    score.blocks.reduce((a, s) => a + s.commissions, 0) === score.commissions
  );
  check(
    "block 0 commissions equal its threes",
    score.blocks[0]!.commissions === blockThrees[0]
  );
  check(
    "omissions per block sum to total",
    score.blocks.reduce((a, s) => a + s.omissions, 0) === score.omissions
  );
  check("block 2 meanRt null (all omitted)", score.blocks[2]!.meanRtMs === null);
  check("block 1 meanRt = 420", Math.abs(score.blocks[1]!.meanRtMs! - 420) < 1e-9);
}

section("Index + percentile coherence");
{
  // All anchor rates: z components 0 -> IQ 100.
  check("all-anchors rates map to IQ 100", saIndex(0.45, 0.03, 0.18) === 100);
  check("perfect rates map to IQ 145", saIndex(0, 0, 0) === 145);
  check("worst rates map to IQ 55 (commission gate)", saIndex(1, 1, 1) === 55);
  check("omission gate floors: saIndex(0, 0.5, 0) = 55", saIndex(0, 0.5, 0) === 55);
  check("commission gate floors: saIndex(0.8, 0, 0.18) = 55", saIndex(0.8, 0.03, 0.18) === 55);
  let clamps = true;
  for (let c = 0; c <= 1.001; c += 0.05) {
    for (let o = 0; o <= 1.001; o += 0.1) {
      const iq = saIndex(c, o, 0.3);
      if (iq < IQ_MIN || iq > IQ_MAX) clamps = false;
    }
  }
  check("sweep stays within bounds", clamps);
  check("iqToPercentile(55) = 1", iqToPercentile(55) === 1);
  check("iqToPercentile(145) = 99", iqToPercentile(145) === 99);
  check("percentile midpoint ~50", iqToPercentile(100) >= 49 && iqToPercentile(100) <= 51);
}

section("Grading ladder");
{
  check("gradeForIq(60) Drifting", gradeForIq(60).label === "Drifting");
  check("gradeForIq(90) Average", gradeForIq(90).label === "Average");
  check("gradeForIq(105) Steady", gradeForIq(105).label === "Steady");
  check("gradeForIq(120) Locked-in", gradeForIq(120).label === "Locked-in");
  check("gradeForIq(140) Laser", gradeForIq(140).label === "Laser");
}

section("Statistical sanity: shuffled() keeps digit multisets");
{
  const rng = mulberry32(9);
  const sh = shuffled(SART_DIGITS, rng);
  check("shuffle of 1..9 keeps all 9 digits", [...sh].sort().join(",") === "1,2,3,4,5,6,7,8,9");
}

console.log(`\n----------------------------------------`);
console.log(`TOTAL: ${pass + fail}  PASS: ${pass}  FAIL: ${fail}`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
