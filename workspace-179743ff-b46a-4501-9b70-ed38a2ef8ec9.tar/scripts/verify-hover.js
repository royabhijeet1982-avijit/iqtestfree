/* Hover-effect verification with a hover-capable desktop context.
 * agent-browser's headless env reports (hover: none), so Tailwind 4's
 * @media (hover: hover) gated styles never apply there. This script
 * launches Chromium with a standard desktop context (hover: hover) and
 * verifies computed styles + captures proof screenshots.
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });

  const caps = await page.evaluate(() => ({
    hoverHover: matchMedia("(hover: hover)").matches,
    pointerFine: matchMedia("(pointer: fine)").matches,
  }));
  console.log("env:", JSON.stringify(caps));

  const results = {};

  // 1. Footer link: translate slide + color shift
  const footerLink = page.locator("footer nav[aria-label='Tests'] a").first();
  await footerLink.scrollIntoViewIfNeeded();
  await footerLink.hover();
  await page.waitForTimeout(400);
  results.footerLink = await footerLink.evaluate((el) => {
    const cs = getComputedStyle(el);
    return { hovered: el.matches(":hover"), translate: cs.translate, color: cs.color };
  });

  // 2. Tool card: lift + title color
  const card = page.locator("#popular-tests article").first();
  await card.scrollIntoViewIfNeeded();
  await page.waitForTimeout(300);
  await card.hover();
  await page.waitForTimeout(400);
  results.toolCard = await card.evaluate((el) => {
    const cs = getComputedStyle(el);
    const title = el.querySelector("h4");
    return {
      hovered: el.matches(":hover"),
      translate: cs.translate,
      boxShadow: cs.boxShadow.slice(0, 60),
      titleColor: getComputedStyle(title).color,
    };
  });

  // 3. Quick stats row: lift + icon scale
  const stat = page.locator("section[aria-label='Why BrainMetrics'] li").first();
  await stat.scrollIntoViewIfNeeded();
  await page.waitForTimeout(300);
  await stat.hover();
  await page.waitForTimeout(400);
  results.quickStat = await stat.evaluate((el) => {
    const cs = getComputedStyle(el);
    const icon = el.querySelector("span span") || el.querySelector("span");
    return {
      hovered: el.matches(":hover"),
      translate: cs.translate,
      iconTransform: getComputedStyle(icon).transform,
    };
  });

  // 4. FAQ trigger: text color shift
  const faqBtn = page.locator("#faq button").first();
  await faqBtn.scrollIntoViewIfNeeded();
  await page.waitForTimeout(300);
  await faqBtn.hover();
  await page.waitForTimeout(400);
  results.faqTrigger = await faqBtn.evaluate((el) => ({
    hovered: el.matches(":hover"),
    color: getComputedStyle(el).color,
  }));

  // 5. Navbar logo scale
  const logo = page.locator("header nav a").first();
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await page.waitForTimeout(300);
  await logo.hover();
  await page.waitForTimeout(400);
  results.navLogo = await logo.evaluate((el) => ({
    hovered: el.matches(":hover"),
    transform: getComputedStyle(el).transform,
  }));

  console.log(JSON.stringify(results, null, 2));

  // Proof screenshots (hover states active)
  await card.scrollIntoViewIfNeeded();
  await card.hover();
  await page.waitForTimeout(350);
  await page.screenshot({ path: "/tmp/pw-hover-card.png" });

  await footerLink.scrollIntoViewIfNeeded();
  await footerLink.hover();
  await page.waitForTimeout(350);
  await page.screenshot({ path: "/tmp/pw-hover-footer.png" });

  await browser.close();
})();
