/**
 * Task B verification: Spatial Memory test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-spatial-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1, 375px viewport): a CONTINUOUS background watcher
 *    polls sm-cell-* data-symbol during every STUDY phase (through countdown
 *    -> study -> recall -> feedback, all 5 rounds) building the truth map.
 *    During each RECALL the script taps each tray symbol then its true cell,
 *    submits -> accuracy 100%, IQ 145, Cartographer, percentile 99, correct
 *    25/25, all five round bars 100
 *  - Input lock: cell clicks during STUDY are ignored (disabled buttons,
 *    recall still opens at 0 placements)
 *  - Re-place semantics: placing then re-placing a symbol keeps exactly one
 *    placement (implicit in golden path - final placements win)
 *  - Retake: second run's round-1 bindings differ from run 1 (fresh draw)
 *  - Anti-gaming (?quick=1): every symbol placed into a DISTINCT WRONG cell
 *    -> accuracy 0, IQ 55 floor, percentile 1, Scattered
 *  - 375px: no horizontal overflow on intro / recall / results
 *  - zero console/page errors across all runs
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Read a CountUp testid until the visible number matches data-final. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.replace(/[^0-9.-]/g, "")),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/** First integer embedded in an element's text. */
async function readFirstInt(p, testid) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval(`[data-testid="${testid}"]`, (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/\d+/);
      if (m) return Number(m[0]);
    }
    await sleep(150);
  }
  return -1;
}

/** "Better than 99 in 100 adults" -> 99. */
async function readPercentile(p) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval('[data-testid="sm-percentile"]', (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/Better than (\d+)/);
      if (m) return Number(m[1]);
    }
    await sleep(150);
  }
  return -1;
}

/** Atomic snapshot (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => {
      const stage = document.querySelector('[data-testid="sm-stage"]');
      return {
        results: !!document.querySelector('[data-testid="sm-results"]'),
        active: !!document.querySelector('[data-testid="sm-active"]'),
        intro: !!document.querySelector('[data-testid="sm-intro"]'),
        countdown: !!document.querySelector('[data-testid="sm-countdown"]'),
        phase: stage ? stage.getAttribute("data-phase") : null,
        round: (() => {
          const chip = document.querySelector('[data-testid="sm-round-chip"]');
          return chip ? parseInt(chip.textContent.replace(/[^0-9]/g, ""), 10) : 0;
        })(),
        progress:
          document.querySelector('[data-testid="sm-progress"]')?.textContent ?? "",
        studyPairs: [...document.querySelectorAll('[data-testid^="sm-cell-"][data-symbol]')].map(
          (c) => ({
            cell: parseInt(c.getAttribute("data-testid").slice(8), 10),
            symbol: c.getAttribute("data-symbol"),
          })
        ),
        submitEnabled: (() => {
          const b = document.querySelector('[data-testid="sm-submit"]');
          return !!b && !b.disabled;
        })(),
      };
    })
    .catch(() => null);
}

/**
 * Wait until a run has ACTUALLY begun (intro / countdown / stage, no
 * results). Critical for the retake path where the old results panel is
 * still mid-exit (~400ms AnimatePresence).
 */
async function waitForRunStart(p, timeoutMs = 15000) {
  await p
    .waitForFunction(
      () => {
        const intro = document.querySelector('[data-testid="sm-intro"]');
        const countdown = document.querySelector('[data-testid="sm-countdown"]');
        const results = document.querySelector('[data-testid="sm-results"]');
        const stage = document.querySelector('[data-testid="sm-stage"]');
        return !!intro || !!countdown || (!!stage && !results);
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/**
 * CONTINUOUS truth watcher: polls study-phase data-symbol pairs per round.
 * Returns { truth: { roundNum: Map(cell -> symbol) }, state }.
 */
function startTruthWatcher(p) {
  const truth = { 1: {}, 2: {}, 3: {}, 4: {}, 5: {} };
  const state = { done: false };
  (async () => {
    const start = Date.now();
    while (!state.done && Date.now() - start < 150000) {
      const st = await snapshot(p);
      if (st) {
        if (st.results) break;
        if (st.phase === "study" && st.round >= 1 && st.round <= 5) {
          for (const pair of st.studyPairs) {
            truth[st.round][pair.cell] = pair.symbol;
          }
        }
      }
      await sleep(10);
    }
    state.done = true;
  })();
  return { truth, state };
}

/** Play one full session. mode: "perfect" | "wrong". */
async function playSession(p, mode) {
  await waitForRunStart(p);
  const watcher = startTruthWatcher(p);
  const hasIntro = await p.$('[data-testid="sm-intro"]');
  if (hasIntro) await p.click('[data-testid="sm-intro-cta"]');
  const t0 = Date.now();

  let roundsPlayed = 0;
  let lastRoundSubmitted = 0;
  let firstRecallProgress = null;

  while (Date.now() - t0 < 150000) {
    const st = await snapshot(p);
    if (!st) { await sleep(40); continue; }
    if (st.results) break;
    if (st.phase === "recall" && st.round > lastRoundSubmitted) {
      roundsPlayed++;
      lastRoundSubmitted = st.round;
      if (firstRecallProgress === null) firstRecallProgress = st.progress || null;

      // Tray symbols in DOM order with their glyphs.
      const tray = await p
        .evaluate(() =>
          [...document.querySelectorAll('[data-testid^="sm-tray-"]')].map((el) => ({
            idx: parseInt(el.getAttribute("data-testid").slice(8), 10),
            symbol: el.getAttribute("data-symbol"),
          }))
        )
        .catch(() => []);

      const truthMap = watcher.truth[st.round] || {};
      const truthCells = Object.keys(truthMap).map(Number);

      for (const t of tray) {
        let target;
        if (mode === "perfect") {
          target = truthCells.find((c) => truthMap[c] === t.symbol);
        } else {
          // distinct WRONG cell: first board cell not a true home and not
          // already used as a wrong target this round
        }
        if (target === undefined) continue;
        await p.click(`[data-testid="sm-tray-${t.idx}"]`).catch(() => {});
        await sleep(40);
        await p.click(`[data-testid="sm-cell-${target}"]`).catch(() => {});
        await sleep(40);
      }
      // submit (enabled only when all placed)
      for (let i = 0; i < 40 && !(await snapshot(p)).submitEnabled; i++) await sleep(50);
      await p.click('[data-testid="sm-submit"]').catch(() => {});
      await sleep(80);
    } else {
      await sleep(25);
    }
  }
  await sleep(400);
  return { watcher, roundsPlayed, firstRecallProgress };
}

/** Wrong-mode driver: distinct wrong cells per round. */
async function playWrongSession(p) {
  await waitForRunStart(p);
  const watcher = startTruthWatcher(p);
  const hasIntro = await p.$('[data-testid="sm-intro"]');
  if (hasIntro) await p.click('[data-testid="sm-intro-cta"]');
  const t0 = Date.now();

  let roundsPlayed = 0;
  let lastRoundSubmitted = 0;

  while (Date.now() - t0 < 150000) {
    const st = await snapshot(p);
    if (!st) { await sleep(40); continue; }
    if (st.results) break;
    if (st.phase === "recall" && st.round > lastRoundSubmitted) {
      roundsPlayed++;
      lastRoundSubmitted = st.round;

      const dim = [3, 3, 4, 4, 5][st.round - 1];
      const tray = await p
        .evaluate(() =>
          [...document.querySelectorAll('[data-testid^="sm-tray-"]')].map((el) => ({
            idx: parseInt(el.getAttribute("data-testid").slice(8), 10),
            symbol: el.getAttribute("data-symbol"),
          }))
        )
        .catch(() => []);

      const truthMap = watcher.truth[st.round] || {};
      const truthCells = new Set(Object.keys(truthMap).map(Number));
      const wrongCells = [];
      for (let c = 0; c < dim * dim && wrongCells.length < tray.length; c++) {
        if (!truthCells.has(c)) wrongCells.push(c);
      }

      for (let i = 0; i < tray.length; i++) {
        const t = tray[i];
        const target = wrongCells[i];
        if (target === undefined) continue;
        await p.click(`[data-testid="sm-tray-${t.idx}"]`).catch(() => {});
        await sleep(40);
        await p.click(`[data-testid="sm-cell-${target}"]`).catch(() => {});
        await sleep(40);
      }
      for (let i = 0; i < 40 && !(await snapshot(p)).submitEnabled; i++) await sleep(50);
      await p.click('[data-testid="sm-submit"]').catch(() => {});
      await sleep(80);
    } else {
      await sleep(25);
    }
  }
  await sleep(400);
  return { roundsPlayed };
}

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 375, height: 667 } });
  const page = await context.newPage();

  const consoleErrors = [];
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });
  page.on("pageerror", (e) => consoleErrors.push(String(e)));

  /* ------------------------- SEO surface ------------------------- */
  console.log("SEO surface:");
  await page.goto(`${BASE}/test/spatial-memory`, { waitUntil: "networkidle", timeout: 30000 });

  const title = await page.title();
  if (/spatial memory test/i.test(title)) ok(`title: ${title}`); else fail(`title: ${title}`);

  const desc = await page
    .$eval('meta[name="description"]', (el) => el.getAttribute("content"))
    .catch(() => null);
  if (desc && desc.length > 80) ok(`description (${desc.length} chars)`); else fail("description missing/short");

  const canonical = await page
    .$eval('link[rel="canonical"]', (el) => el.getAttribute("href"))
    .catch(() => null);
  if (canonical && canonical.includes("/test/spatial-memory")) ok(`canonical: ${canonical}`);
  else fail(`canonical: ${canonical}`);

  const jsonLdTypes = await page
    .$$eval('script[type="application/ld+json"]', (els) =>
      els.map((el) => {
        try { return JSON.parse(el.textContent)["@type"]; } catch { return "PARSE_ERROR"; }
      })
    )
    .catch(() => []);
  if (
    jsonLdTypes.includes("WebApplication") &&
    jsonLdTypes.includes("BreadcrumbList") &&
    jsonLdTypes.includes("FAQPage")
  )
    ok(`JSON-LD x3: ${jsonLdTypes.join(", ")}`);
  else fail(`JSON-LD types: ${jsonLdTypes.join(", ")}`);

  const h1 = await page.$eval("h1", (el) => el.textContent.trim()).catch(() => null);
  if (h1 && /spatial/i.test(h1)) ok(`h1: ${h1}`); else fail(`h1: ${h1}`);

  const faqCount = await page.$$eval('[data-testid^="sm-faq-item-"]', (els) => els.length).catch(() => 0);
  if (faqCount === 6) ok(`FAQ parity: 6 items rendered`); else fail(`FAQ items: ${faqCount} (expected 6)`);

  /* ------------------------- golden path ------------------------- */
  console.log("\nGolden path (?quick=1, 375px):");
  await page.goto(`${BASE}/test/spatial-memory?quick=1`, { waitUntil: "networkidle" });
  await page.waitForSelector('[data-testid="sm-intro"]', { timeout: 15000 });

  const run1 = await playSession(page, "perfect");

  const acc1 = await readStable(page, "sm-accuracy");
  const iq1 = await readStable(page, "sm-iq");
  const grade1 = await page.$eval('[data-testid="sm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct1 = await readPercentile(page);
  const correct1 = await readFirstInt(page, "sm-stat-correct");

  if (acc1 === 100) ok(`accuracy 100%`); else fail(`accuracy ${acc1} (expected 100)`);
  if (iq1 === 145) ok(`IQ 145`); else fail(`IQ ${iq1} (expected 145)`);
  if (grade1.includes("Cartographer")) ok(`grade Cartographer`); else fail(`grade: ${grade1}`);
  if (pct1 === 99) ok(`percentile 99`); else fail(`percentile ${pct1}`);
  if (correct1 === 25) ok(`correct 25/25`); else fail(`correct ${correct1} (expected 25)`);

  const roundScores = [];
  for (let r = 0; r < 5; r++) {
    const v = await page
      .$eval(`[data-testid="sm-round-score-${r}"]`, (el) => Number(el.getAttribute("data-final")))
      .catch(() => -1);
    roundScores.push(v);
  }
  if (roundScores.every((v) => v === 100)) ok(`all five round bars 100%`); else fail(`round bars: ${roundScores.join(",")}`);

  const truthCount1 = Object.keys(run1.watcher.truth[1] || {}).length;
  if (truthCount1 === 3 && run1.roundsPlayed >= 5)
    ok(`rounds played: ${run1.roundsPlayed}, round-1 truth captured: ${truthCount1} pairs`);
  else fail(`watcher capture incomplete: rounds=${run1.roundsPlayed} r1Pairs=${truthCount1}`);

  if (run1.firstRecallProgress && /^0 \/ 3$/.test(run1.firstRecallProgress.trim()))
    ok(`input lock: round-1 recall opened at 0/3 placed (study-phase clicks ignored)`);
  else fail(`input lock probe: first recall progress = ${run1.firstRecallProgress}`);

  /* ---------------------------- retake ---------------------------- */
  console.log("\nRetake (fresh bindings):");
  await page.click('[data-testid="sm-retake"]');
  await sleep(300);
  const run2 = await playSession(page, "perfect");
  const binding1 = JSON.stringify(run1.watcher.truth[1]);
  const binding2 = JSON.stringify(run2.watcher.truth[1]);
  if (binding2 && binding1 !== "{}" && binding1 !== binding2)
    ok(`round-1 bindings changed between runs`);
  else fail(`retake bindings identical or missing: ${binding1} vs ${binding2}`);
  const iq2 = await readStable(page, "sm-iq");
  if (iq2 === 145) ok(`retake IQ also 145`); else fail(`retake IQ ${iq2}`);

  /* -------------------------- anti-gaming -------------------------- */
  console.log("\nAnti-gaming (every symbol into a distinct wrong cell):");
  await page.click('[data-testid="sm-retake"]');
  await sleep(300);
  const run3 = await playWrongSession(page);
  const acc3 = await readStable(page, "sm-accuracy");
  const iq3 = await readStable(page, "sm-iq");
  const grade3 = await page.$eval('[data-testid="sm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct3 = await readPercentile(page);
  if (acc3 === 0) ok(`accuracy floored to 0`); else fail(`wrong-cell accuracy ${acc3} (expected 0)`);
  if (iq3 === 55) ok(`IQ pinned to 55 floor`); else fail(`wrong IQ ${iq3} (expected 55)`);
  if (grade3.includes("Scattered")) ok(`grade Scattered`); else fail(`wrong grade: ${grade3}`);
  if (pct3 === 1) ok(`percentile 1`); else fail(`wrong percentile ${pct3}`);
  if (run3.roundsPlayed >= 5) ok(`wrong-mode rounds played: ${run3.roundsPlayed}`);
  else fail(`wrong-mode rounds played: ${run3.roundsPlayed}`);

  /* ------------------------- 375px overflow ------------------------- */
  console.log("\n375px overflow:");
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth
  );
  if (overflow <= 0) ok(`no horizontal overflow (${overflow}px)`);
  else fail(`horizontal overflow ${overflow}px`);

  /* --------------------------- console errors --------------------------- */
  console.log("\nConsole:");
  if (consoleErrors.length === 0) ok("zero console/page errors across all runs");
  else {
    fail(`${consoleErrors.length} console error(s):`);
    consoleErrors.slice(0, 5).forEach((e) => console.error("    " + e.slice(0, 200)));
  }

  await browser.close();
  console.log(`\n----------------------------------------`);
  console.log(`TOTAL CHECKS FAILED: ${failures}`);
  if (failures > 0) process.exit(1);
  console.log("ALL PASS");
})();
