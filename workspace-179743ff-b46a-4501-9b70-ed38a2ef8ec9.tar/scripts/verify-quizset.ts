/**
 * Unit verification for the age-group set engine (Task 11 — all 3 groups).
 * Run: bun /home/z/my-project/scripts/verify-quizset.ts
 */
import {
  AGE_SETS,
  AGE_GROUPS,
  KIDS_QUESTION_COUNT,
  pickSetFor,
  SET_SIZE,
  TOTAL_QUESTION_COUNT,
  TOTAL_SET_COUNT,
  type IqQuestion,
  type IqSet,
} from "../src/components/test/iq-questions";

let failures = 0;
const fail = (m: string) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m: string) => console.log(`  ✓ ${m}`);

const EXPECTED_SET_NAMES: Record<string, string[]> = {
  kids: ["Rocket", "Panda", "Dolphin", "Tiger", "Rainbow", "Comet", "Turtle", "Penguin", "Lion", "Starfish"],
  teens: ["Circuit", "Nova", "Pixel", "Vector", "Cipher", "Quasar", "Matrix", "Photon", "Zenith", "Cascade"],
  adults: ["Sage", "Oracle", "Enigma", "Apex", "Prism", "Vertex", "Axiom", "Lumen", "Onyx", "Meridian"],
};

/* ---- 1. Every group ships 10 sets x 12 questions ---- */
for (const g of AGE_GROUPS) {
  const pool: IqSet[] = AGE_SETS[g.id];
  pool.length === 10
    ? ok(`${g.label}: ${pool.length} hand-built sets`)
    : fail(`${g.label} sets: ${pool.length}`);
  pool.every((s) => s.questions.length === SET_SIZE)
    ? ok(`${g.label}: every set has exactly ${SET_SIZE} questions`)
    : fail(`${g.label}: some set has wrong question count`);
  JSON.stringify(pool.map((s) => s.name)) === JSON.stringify(EXPECTED_SET_NAMES[g.id])
    ? ok(`${g.label}: set names match (${pool[0].name} … ${pool[9].name})`)
    : fail(`${g.label}: unexpected set names — ${pool.map((s) => s.name).join(", ")}`);
}

KIDS_QUESTION_COUNT === 120 ? ok(`kids bank = ${KIDS_QUESTION_COUNT} questions`) : fail(`kids bank: ${KIDS_QUESTION_COUNT}`);
TOTAL_SET_COUNT === 30 ? ok(`total authored sets = ${TOTAL_SET_COUNT}`) : fail(`total sets: ${TOTAL_SET_COUNT}`);
TOTAL_QUESTION_COUNT === 360 ? ok(`total authored questions = ${TOTAL_QUESTION_COUNT}`) : fail(`total questions: ${TOTAL_QUESTION_COUNT}`);

/* ---- 2. Unique ids, valid answers, per-set category mix (each group) ---- */
const MIX: Record<string, number> = { logic: 2, verbal: 2, numeric: 2, pattern: 2, attention: 1, memory: 2, spatial: 1 };
for (const g of AGE_GROUPS) {
  const pool = AGE_SETS[g.id];
  const allQ = pool.flatMap((s) => s.questions);
  const ids = allQ.map((q) => q.id);
  new Set(ids).size === ids.length ? ok(`${g.label}: ${ids.length} question ids all unique`) : fail(`${g.label}: duplicate question ids`);

  const idBase = g.id === "kids" ? 0 : g.id === "teens" ? 100 : 200;
  ids.every((id) => id > idBase * 100 && id < (idBase + 100) * 100)
    ? ok(`${g.label}: id range isolated (${ids[0]} … ${ids[ids.length - 1]})`)
    : fail(`${g.label}: ids outside reserved range`);

  let mixOk = true, ansOk = true, expOk = true;
  for (const s of pool) {
    const counts: Record<string, number> = {};
    for (const q of s.questions) {
      counts[q.category] = (counts[q.category] ?? 0) + 1;
      if (q.answer < 0 || q.answer >= q.options.length) ansOk = false;
      if (q.options.length !== 4) ansOk = false;
      if (!q.explanation || q.explanation.length < 10) expOk = false;
      if (![1, 2, 3].includes(q.difficulty)) ansOk = false;
    }
    for (const [cat, n] of Object.entries(MIX)) {
      if ((counts[cat] ?? 0) !== n) {
        mixOk = false;
        fail(`[${g.label}] set "${s.name}" category ${cat}: ${counts[cat] ?? 0} (expected ${n})`);
      }
    }
  }
  mixOk ? ok(`${g.label}: every set has the 2/2/2/2/1/2/1 category mix`) : fail(`${g.label}: category mix broken`);
  ansOk ? ok(`${g.label}: all answers valid, 4 options each`) : fail(`${g.label}: invalid answers/options`);
  expOk ? ok(`${g.label}: every question carries an explanation`) : fail(`${g.label}: missing explanations`);

  const prompts = allQ.map((q) => q.prompt);
  new Set(prompts).size === prompts.length
    ? ok(`${g.label}: no duplicate prompts across the ${prompts.length} questions`)
    : fail(`${g.label}: duplicate prompts found`);
}

/* ---- 3. Cross-group separation: no shared prompt between any two groups ---- */
const [kidsQ, teensQ, adultsQ] = (["kids", "teens", "adults"] as const).map(
  (g) => AGE_SETS[g].flatMap((s) => s.questions.map((q) => q.prompt))
);
const pairName = (a: string, b: string) => `${a}↔${b}`;
const overlap = (a: string[], b: string[], name: string) => {
  const shared = a.filter((p) => b.includes(p));
  shared.length === 0
    ? ok(`separation ${name}: 0 shared questions (${a.length} vs ${b.length})`)
    : fail(`${name}: ${shared.length} shared — ${shared.slice(0, 2).join(" | ")}`);
};
overlap(kidsQ, teensQ, pairName("kids", "teens"));
overlap(kidsQ, adultsQ, pairName("kids", "adults"));
overlap(teensQ, adultsQ, pairName("teens", "adults"));

const all360 = [...kidsQ, ...teensQ, ...adultsQ];
new Set(all360).size === 360 ? ok("all 360 questions across groups are globally unique") : fail("global duplicate prompts exist");

/* ---- 4. pickSetFor: authored set, respects exclusion, shuffles options ---- */
for (const g of AGE_GROUPS) {
  const pool = AGE_SETS[g.id];
  const served = pickSetFor(g.id);
  EXPECTED_SET_NAMES[g.id].includes(served.name)
    ? ok(`pickSetFor(${g.id}) served authored set "${served.name}"`)
    : fail(`[${g.id}] unexpected set name: ${served.name}`);
  served.questions.length === SET_SIZE ? ok(`[${g.id}] served set has 12 questions`) : fail(`[${g.id}] served: ${served.questions.length}`);

  let shufflePreserved = true, shufflesAtAll = false;
  for (let t = 0; t < 50; t++) {
    const s = pickSetFor(g.id);
    const orig = pool.find((k) => k.name === s.name)!;
    for (let i = 0; i < s.questions.length; i++) {
      const sq: IqQuestion = s.questions[i];
      const oq = orig.questions[i];
      if (sq.options[sq.answer] !== oq.options[oq.answer]) shufflePreserved = false;
      if (sq.options.join("|") !== oq.options.join("|")) shufflesAtAll = true;
    }
  }
  shufflePreserved ? ok(`[${g.id}] correct option text preserved through 50 serves`) : fail(`[${g.id}] answer text corrupted by shuffle`);
  shufflesAtAll ? ok(`[${g.id}] option order actually shuffles between serves`) : fail(`[${g.id}] options never shuffled`);

  let exclusionOk = true;
  for (let t = 0; t < 60; t++) {
    const a = pickSetFor(g.id);
    const b = pickSetFor(g.id, a.id);
    if (b.id === a.id) exclusionOk = false;
  }
  exclusionOk ? ok(`[${g.id}] never repeats the same set back-to-back`) : fail(`[${g.id}] exclusion broken`);

  /* Serving rotation: every set gets hit over many draws */
  const hits = new Set<string>();
  for (let t = 0; t < 400; t++) hits.add(pickSetFor(g.id).name);
  hits.size === 10 ? ok(`[${g.id}] all 10 sets reached over 400 random draws`) : fail(`[${g.id}] only ${hits.size}/10 sets reached`);
}

/* ---- 5. Group isolation at serve time: kids sets never served to teens/adults ---- */
const kidsNames = new Set(EXPECTED_SET_NAMES.kids);
let leak = false;
for (const g of ["teens", "adults"] as const) {
  for (let t = 0; t < 200; t++) {
    const s = pickSetFor(g);
    if (kidsNames.has(s.name)) leak = true;
    if (s.ageGroup !== g) leak = true;
  }
}
leak ? fail("kids sets leaked into teen/adult serving!") : ok("teens/adults serving never touches kids sets (400 draws)");

AGE_GROUPS.length === 3 ? ok("3 age groups defined (kids, teens, adults)") : fail(`groups: ${AGE_GROUPS.length}`);

console.log(failures === 0 ? "\n✓ ALL SET-ENGINE CHECKS PASSED" : `\n✗ ${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
