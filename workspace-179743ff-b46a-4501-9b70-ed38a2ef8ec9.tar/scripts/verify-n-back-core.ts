/* ------------------------------------------------------------------ */
/*  Unit verification for n-back-core.ts                               */
/*  Run: bun scripts/verify-n-back-core.ts                             */
/* ------------------------------------------------------------------ */

import {
  BASE_TRIALS_PER_BLOCK,
  BLOCK_N_VALUES,
  IQ_MAX,
  IQ_MIN,
  LURE_RATE,
  NBACK_LETTERS,
  PASS_THRESHOLD,
  QUICK_BLOCK_N_VALUES,
  QUICK_TRIALS_PER_BLOCK,
  SPAN_IQ_ANCHORS,
  SPAN_MEAN,
  SPAN_SD,
  STIMULUS_VISIBLE_MS,
  TARGET_RATE,
  TRIAL_MS,
  buildBlock,
  buildBlocks,
  computeResults,
  erf,
  gradeForSpan,
  mulberry32,
  normalCdf,
  percentileForSpan,
  scoreBlock,
  scoreTrial,
  shuffle,
  spanToIq,
  summarizeResults,
  targetCountFor,
  type BlockScore,
  type NBackBlock,
  type NBackTrial,
  type TrialResponse,
} from "../src/components/test/n-back-core";

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / Math.max(1, xs.length);
}

function sd(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / Math.max(1, xs.length - 1));
}

const noTriple = (letters: string[]) => {
  for (let i = 2; i < letters.length; i++) {
    if (letters[i] === letters[i - 1] && letters[i] === letters[i - 2]) return false;
  }
  return true;
};

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("TRIAL_MS is 2800", TRIAL_MS === 2800, String(TRIAL_MS));
check("STIMULUS_VISIBLE_MS is 1500", STIMULUS_VISIBLE_MS === 1500, String(STIMULUS_VISIBLE_MS));
check("8 possible letters", NBACK_LETTERS.length === 8);
check("letters distinct", new Set(NBACK_LETTERS).size === 8);
check("TARGET_RATE is 0.3", TARGET_RATE === 0.3);
check("LURE_RATE is 0.28", LURE_RATE === 0.28);
check("PASS_THRESHOLD is 0.7", PASS_THRESHOLD === 0.7);
check(
  "block ladder is 1..5",
  BLOCK_N_VALUES.length === 5 && BLOCK_N_VALUES.every((n, i) => n === i + 1)
);
check("quick ladder is 1..2", QUICK_BLOCK_N_VALUES.join(",") === "1,2");
check("base block size is 20+N", BASE_TRIALS_PER_BLOCK === 20);
check("quick block size is 12", QUICK_TRIALS_PER_BLOCK === 12);
check(
  "SPAN_IQ_ANCHORS exact",
  JSON.stringify(SPAN_IQ_ANCHORS) === JSON.stringify({ 0: 64, 1: 77, 2: 90, 3: 102, 4: 116, 5: 130 }),
  JSON.stringify(SPAN_IQ_ANCHORS)
);
check("span population model N(2.3, 1.05)", SPAN_MEAN === 2.3 && SPAN_SD === 1.05);
check("targetCountFor exact rounding", [21, 22, 23, 24, 25, 12].map(targetCountFor).join(",") === "6,7,7,7,8,4");

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const seqC = Array.from({ length: 20 }, () => mulberry32(43)());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
  const arr = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = shuffle(arr, mulberry32(7));
  check("shuffle preserves multiset", shuffled.slice().sort((a, b) => a - b).join(",") === "1,2,3,4,5,6,7,8");
  check("shuffle does not mutate input", arr.join(",") === "1,2,3,4,5,6,7,8");
}

section("buildBlock invariants (100 seeds x all N, normal + quick sizes)");
{
  let okCount = 0;
  let failures: string[] = [];
  const totalBuilds: NBackBlock[] = [];
  for (let seed = 0; seed < 100; seed++) {
    const rng = mulberry32(1000 + seed);
    for (const n of BLOCK_N_VALUES) {
      const block = buildBlock(n, rng);
      totalBuilds.push(block);
      const letters = block.trials.map((t) => t.letter);
      const expectedTotal = BASE_TRIALS_PER_BLOCK + n;
      const expectedTargets = Math.round(0.3 * expectedTotal);
      let ok =
        block.n === n &&
        block.trials.length === expectedTotal &&
        block.targetCount === expectedTargets &&
        noTriple(letters) &&
        letters.every((l) => (NBACK_LETTERS as readonly string[]).includes(l));
      // warm-up: first N trials never targets
      if (block.trials.slice(0, n).some((t) => t.isTarget)) ok = false;
      // biconditional: target <=> letter equals letter N steps back
      for (let i = n; i < block.trials.length; i++) {
        const isTargetByData = block.trials[i]!.isTarget;
        const isTargetByLetter = letters[i] === letters[i - n];
        if (isTargetByData !== isTargetByLetter) ok = false;
      }
      if (!ok && failures.length < 5) failures.push(`seed=${seed} n=${n}`);
      if (ok) okCount++;
    }
    // quick-sized blocks (12 trials) for N = 1..5 must also be valid
    for (const n of BLOCK_N_VALUES) {
      const block = buildBlock(n, rng, { trials: QUICK_TRIALS_PER_BLOCK });
      totalBuilds.push(block);
      const letters = block.trials.map((t) => t.letter);
      const ok =
        block.trials.length === QUICK_TRIALS_PER_BLOCK &&
        block.targetCount === Math.round(0.3 * QUICK_TRIALS_PER_BLOCK) &&
        noTriple(letters) &&
        block.trials.slice(0, n).every((t) => !t.isTarget);
      if (!ok && failures.length < 5) failures.push(`quick seed=${seed} n=${n}`);
      if (ok) okCount++;
    }
  }
  const expectedBuilds = 100 * (BLOCK_N_VALUES.length * 2);
  check(`all ${expectedBuilds} builds satisfy every invariant`, okCount === expectedBuilds, failures.join("; "));
  check(
    "target counts match round(0.3*(20+N)) exactly",
    totalBuilds.every((b) => b.trials.filter((t) => t.isTarget).length === b.targetCount)
  );
}

section("Lure machinery (N >= 2 blocks always carry real lures)");
{
  let blocksWithLures = 0;
  let blockCount = 0;
  let lureDefsOk = true;
  let lureCountsSane = true;
  for (let seed = 0; seed < 100; seed++) {
    const rng = mulberry32(5000 + seed);
    for (const n of [2, 3, 4, 5]) {
      const block = buildBlock(n, rng);
      blockCount++;
      const letters = block.trials.map((t) => t.letter);
      if (block.lureCount >= 1) blocksWithLures++;
      if (block.lureCount < 1 || block.lureCount > 8) lureCountsSane = false;
      // every advertised lure is a genuine lag-(N-1)-but-not-lag-N match
      for (const t of block.trials) {
        const genuine =
          !t.isTarget &&
          t.letter === letters[t.index - (n - 1)] &&
          t.letter !== letters[t.index - n];
        if (t.isLure && !genuine) lureDefsOk = false;
      }
      const actualLures = block.trials.filter(
        (t, i) => i >= n && !t.isTarget && t.letter === letters[i - (n - 1)]
      ).length;
      if (actualLures !== block.lureCount) lureCountsSane = false;
    }
  }
  check(`every N>=2 block has at least one lure (${blocksWithLures}/${blockCount})`, blocksWithLures === blockCount);
  check("lure definitions match lag-(N-1) but not lag-N", lureDefsOk);
  check("lure counts recounted correctly and sane", lureCountsSane);
  // N = 1 has no lures by definition (0-back is meaningless)
  const n1 = buildBlock(1, mulberry32(123));
  check("N=1 block has no lures", n1.trials.every((t) => !t.isLure) && n1.lureCount === 0);
}

section("buildBlocks shapes (full + quick)");
{
  for (let seed = 0; seed < 20; seed++) {
    const rng = mulberry32(9000 + seed);
    const full = buildBlocks(rng);
    if (
      full.length !== 5 ||
      full.some((b, i) => b.n !== i + 1 || b.trials.length !== BASE_TRIALS_PER_BLOCK + b.n)
    ) {
      check("full run: 5 blocks, N=1..5, sizes 20+N", false);
      break;
    }
    const quick = buildBlocks(rng, { quick: true });
    if (
      quick.length !== 2 ||
      quick.some((b) => b.n !== quick.indexOf(b) + 1 || b.trials.length !== QUICK_TRIALS_PER_BLOCK)
    ) {
      check("quick run: 2 blocks, N=1..2, 12 trials", false);
      break;
    }
    if (seed === 19) {
      check("full run: 5 blocks, N=1..5, sizes 20+N", true);
      check("quick run: 2 blocks, N=1..2, 12 trials", true);
    }
  }
}

section("Letter distribution roughly balanced (no dominant letter)");
{
  const counts: Record<string, number> = {};
  for (let seed = 0; seed < 120; seed++) {
    const block = buildBlock(2, mulberry32(20_000 + seed));
    for (const t of block.trials) counts[t.letter] = (counts[t.letter] ?? 0) + 1;
  }
  const values = Object.values(counts);
  const ratio = Math.max(...values) / Math.max(1, Math.min(...values));
  check(
    `all 8 letters used, max/min ratio ${ratio.toFixed(2)} < 2`,
    Object.keys(counts).length === 8 && ratio < 2,
    JSON.stringify(counts)
  );
}

section("scoreTrial truth table");
{
  const target: NBackTrial = { index: 5, letter: "F", isTarget: true, isLure: false };
  const plain: NBackTrial = { index: 6, letter: "Q", isTarget: false, isLure: false };
  const lure: NBackTrial = { index: 7, letter: "H", isTarget: false, isLure: true };
  check("target + respond = hit", scoreTrial(target, true) === "hit");
  check("target + silence = miss", scoreTrial(target, false) === "miss");
  check("plain + respond = false alarm", scoreTrial(plain, true) === "false-alarm");
  check("plain + silence = correct rejection", scoreTrial(plain, false) === "correct-rejection");
  check("lure + respond = false alarm", scoreTrial(lure, true) === "false-alarm");
  check("lure + silence = correct rejection", scoreTrial(lure, false) === "correct-rejection");
}

section("scoreBlock partition math (50 seeds x random response patterns)");
{
  let partitionOk = true;
  let ratesOk = true;
  let balancedOk = true;
  for (let seed = 0; seed < 50; seed++) {
    const rng = mulberry32(30_000 + seed);
    const block = buildBlock(3, rng);
    const responses: TrialResponse[] = block.trials.map(() => ({
      responded: rng() < 0.4,
      rtMs: rng() < 0.4 ? 400 + Math.floor(rng() * 1200) : null,
    }));
    const score = scoreBlock(block, responses);
    if (score.hits + score.misses + score.falseAlarms + score.correctRejections !== block.trials.length) {
      partitionOk = false;
    }
    if (
      score.hitRate < 0 || score.hitRate > 1 ||
      score.correctRejectionRate < 0 || score.correctRejectionRate > 1 ||
      score.balancedScore < 0 || score.balancedScore > 1
    ) {
      ratesOk = false;
    }
    if (
      Math.abs(score.hitRate - score.hits / score.targetCount) > 1e-9 ||
      Math.abs(score.correctRejectionRate - score.correctRejections / score.nonTargetCount) > 1e-9 ||
      Math.abs(score.balancedScore - (score.hitRate + score.correctRejectionRate) / 2) > 1e-9
    ) {
      balancedOk = false;
    }
    if (score.passed !== (score.balancedScore >= PASS_THRESHOLD)) ratesOk = false;
  }
  check("hits+misses+FA+CR = trials for every block", partitionOk);
  check("all rates within [0,1], passed flag consistent", ratesOk);
  check("balanced = mean(hitRate, correctRejectionRate) exactly", balancedOk);
}

section("Anti-gaming: mash and never-respond both collapse to 0.5");
{
  let mashOk = true;
  let idleOk = true;
  for (let seed = 0; seed < 50; seed++) {
    const rng = mulberry32(40_000 + seed);
    const blocks = buildBlocks(rng);
    const mash = blocks.map((b) => b.trials.map(() => ({ responded: true, rtMs: 300 })));
    const mashResults = computeResults(blocks, mash);
    if (
      mashResults.blocks.some((s) => Math.abs(s.balancedScore - 0.5) > 1e-9) ||
      mashResults.effectiveSpan !== 0 ||
      Math.abs(mashResults.composite - 0.5) > 1e-9
    ) {
      mashOk = false;
    }
    const idle = blocks.map((b) => b.trials.map(() => ({ responded: false, rtMs: null })));
    const idleResults = computeResults(blocks, idle);
    if (
      idleResults.blocks.some((s) => Math.abs(s.balancedScore - 0.5) > 1e-9) ||
      idleResults.effectiveSpan !== 0 ||
      Math.abs(idleResults.composite - 0.5) > 1e-9
    ) {
      idleOk = false;
    }
  }
  check("mash-everything: balanced 0.5 per block, span 0, composite 0.5", mashOk);
  check("never-respond: balanced 0.5 per block, span 0, composite 0.5", idleOk);
}

section("Perfect play reaches the ceiling honestly");
{
  const rng = mulberry32(777);
  const blocks = buildBlocks(rng);
  const perfect = blocks.map((b) =>
    b.trials.map((t) => ({ responded: t.isTarget, rtMs: t.isTarget ? 800 : null }))
  );
  const results = computeResults(blocks, perfect);
  check("every block balanced 1.0", results.blocks.every((s) => s.balancedScore === 1));
  check("span 5", results.effectiveSpan === 5);
  check("composite 1.0", Math.abs(results.composite - 1) < 1e-9);
  check("no false alarms, no misses", results.blocks.every((s) => s.falseAlarms === 0 && s.misses === 0));
  check("IQ at ceiling 140 (137 anchor + 3 composite nudge)", results.iq === 140, String(results.iq));
  check("percentile 99", results.percentile === 99);
  check("grade Exceptional", results.grade.label === "Exceptional");
}

section("Effective span thresholds");
{
  // Engineered run: pass blocks 1-3 perfectly, fail 4 and 5 sloppily.
  const rng = mulberry32(888);
  const blocks = buildBlocks(rng);
  const responses = blocks.map((block, i) =>
    block.trials.map((t) => {
      if (i < 3) return { responded: t.isTarget, rtMs: t.isTarget ? 700 : null };
      // 60% of targets answered, 60% of non-targets answered -> 0.5 balanced
      const idx = t.index;
      return { responded: idx % 5 === 0 || idx % 5 === 1 || idx % 5 === 4, rtMs: 500 };
    })
  );
  const results = computeResults(blocks, responses);
  check("blocks 1-3 passed", results.blocks.slice(0, 3).every((s) => s.passed));
  check("blocks 4-5 not passed", results.blocks.slice(3).every((s) => !s.passed));
  check("span = 3", results.effectiveSpan === 3, String(results.effectiveSpan));

  // Boundary via synthetic scores: 0.6999 fails, 0.7 passes.
  const mk = (n: number, balanced: number): BlockScore => ({
    n,
    trialCount: 20 + n,
    targetCount: Math.round(0.3 * (20 + n)),
    nonTargetCount: 20 + n - Math.round(0.3 * (20 + n)),
    lureCount: 2,
    lureErrors: 0,
    hits: 0,
    misses: 0,
    falseAlarms: 0,
    correctRejections: 0,
    hitRate: balanced,
    correctRejectionRate: balanced,
    balancedScore: balanced,
    passed: balanced >= PASS_THRESHOLD,
    meanHitRtMs: null,
  });
  const justBelow = summarizeResults([mk(1, 0.6999), mk(2, 0.6999)]);
  check("balanced 0.6999 does not pass", justBelow.effectiveSpan === 0);
  const exactlyAt = summarizeResults([mk(1, 0.7), mk(2, 0.7)]);
  check("balanced 0.7000 passes (>= threshold)", exactlyAt.effectiveSpan === 2);
  // Span is the HIGHEST passed N even if a lower block failed.
  const gappy = summarizeResults([mk(1, 0.5), mk(2, 0.4), mk(3, 0.5), mk(4, 0.9), mk(5, 0.5)]);
  check("span picks highest passed N (4)", gappy.effectiveSpan === 4);
}

section("IQ anchor interpolation, nudges and clamps");
{
  check("span 0 floor -> 64 (neutral composite)", spanToIq(0, 0, 0.72) === 64, String(spanToIq(0, 0, 0.72)));
  check("span 1 at threshold -> 77", spanToIq(1, PASS_THRESHOLD, 0.72) === 77, String(spanToIq(1, PASS_THRESHOLD, 0.72)));
  check("span 2 at threshold -> 90", spanToIq(2, PASS_THRESHOLD, 0.72) === 90);
  check("span 3 at threshold -> 102", spanToIq(3, PASS_THRESHOLD, 0.72) === 102);
  check("span 4 at threshold -> 116", spanToIq(4, PASS_THRESHOLD, 0.72) === 116);
  check("span 5 at threshold -> 130", spanToIq(5, PASS_THRESHOLD, 0.72) === 130);
  check("span 2 aced -> 90 + 6 = 96", spanToIq(2, 1, 0.72) === 96, String(spanToIq(2, 1, 0.72)));
  check("span 5 aced -> 137 (extrapolated half level)", spanToIq(5, 1, 0.72) === 137, String(spanToIq(5, 1, 0.72)));
  check("span 0 near-miss nudged up (0.35/0.7 -> +3.25 -> 67)", spanToIq(0, 0.35, 0.72) === 67, String(spanToIq(0, 0.35, 0.72)));
  check("span 0 near-pass (0.7) -> 64 + 6.5 = 71", spanToIq(0, PASS_THRESHOLD, 0.72) === 71, String(spanToIq(0, PASS_THRESHOLD, 0.72)));
  check("strong composite nudges up (+3 max)", spanToIq(2, 1, 1) === 99, String(spanToIq(2, 1, 1)));
  check("weak composite nudges down (-3 max)", spanToIq(2, 1, 0.4) === 93, String(spanToIq(2, 1, 0.4)));
  // monotonic in level balance and never leaves the clamp range
  let monotonic = true;
  for (const s of [0, 1, 2, 3, 4, 5]) {
    let prev = -Infinity;
    for (let b = 0; b <= 1.0001; b += 0.05) {
      const iq = spanToIq(s, b, 0.72);
      if (iq < prev) monotonic = false;
      if (iq < IQ_MIN || iq > IQ_MAX) monotonic = false;
      prev = iq;
    }
  }
  check("IQ monotonic in level balance, clamped 55..145", monotonic);
}

section("Percentile model (erf-based, N(2.3, 1.05))");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf at mean = 0.5", Math.abs(normalCdf(SPAN_MEAN, SPAN_MEAN, SPAN_SD) - 0.5) < 1e-9);
  const p = [0, 1, 2, 3, 4, 5].map(percentileForSpan);
  check("percentiles exact", p.join(",") === "1,11,39,75,95,99", p.join(","));
  check("strictly increasing", p.every((v, i) => i === 0 || v > p[i - 1]!));
  check("clamped to 1..99", p[0] === 1 && p[5] === 99);
  // monotonicity across the fine-grained span axis
  let monotonic = true;
  for (let s = 0; s <= 5; s += 0.1) {
    const a = normalCdf(s, SPAN_MEAN, SPAN_SD);
    const b = normalCdf(s + 0.1, SPAN_MEAN, SPAN_SD);
    if (b < a) monotonic = false;
  }
  check("normal CDF monotonic non-decreasing in span", monotonic);
}

section("Grades");
{
  check("span 0 -> Warming up", gradeForSpan(0).label === "Warming up");
  check("span 1 -> Emerging", gradeForSpan(1).label === "Emerging");
  check("span 2 -> Solid", gradeForSpan(2).label === "Solid");
  check("span 3 -> Strong", gradeForSpan(3).label === "Strong");
  check("span 4 -> Very strong", gradeForSpan(4).label === "Very strong");
  check("span 5 -> Exceptional", gradeForSpan(5).label === "Exceptional");
  check("every grade has blurb + class", [0, 1, 2, 3, 4, 5].every((s) => {
    const g = gradeForSpan(s);
    return g.blurb.length > 20 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("Mean hit RT plumbing");
{
  const block = buildBlock(1, mulberry32(31415));
  const responses: TrialResponse[] = block.trials.map((t) =>
    t.isTarget ? { responded: true, rtMs: 500 + t.index * 100 } : { responded: false, rtMs: null }
  );
  const score = scoreBlock(block, responses);
  const targets = block.trials.filter((t) => t.isTarget);
  const expectedMean = targets.reduce((acc, t) => acc + 500 + t.index * 100, 0) / targets.length;
  check("mean hit RT = mean of hit RTs", Math.abs(score.meanHitRtMs! - expectedMean) < 1e-9, `${score.meanHitRtMs} vs ${expectedMean}`);
  const noHits = scoreBlock(block, block.trials.map(() => ({ responded: false, rtMs: null })));
  check("no hits -> mean RT null", noHits.meanHitRtMs === null);
}

section("Population simulation (N=500 realistic profiles)");
{
  // Simulate users with varying skill and attentiveness playing the full
  // 5-block run. Skilled users detect more targets and bite on fewer
  // lures; everyone's attention lapses now and then.
  const simulateUser = (rng: () => number, skill: number): { iq: number; span: number; percentile: number; composite: number } => {
    const blocks = buildBlocks(rng);
    const attentiveness = clamp(0.84 + 0.09 * skill, 0.45, 0.995);
    const responsesPerBlock = blocks.map((block) => {
      const n = block.n;
      const hitBase = clamp(0.945 - 0.152 * (n - 1) + 0.09 * skill, 0.05, 0.99);
      const faBase = clamp(0.105 - 0.035 * skill + 0.032 * (n - 1), 0.008, 0.6);
      return block.trials.map((trial): TrialResponse => {
        if (rng() > attentiveness) {
          // attention lapse: usually idle, occasionally a stray press
          return { responded: rng() < 0.1, rtMs: null };
        }
        if (trial.isTarget) {
          return { responded: rng() < hitBase, rtMs: 650 + Math.floor(rng() * 900) };
        }
        const faP = trial.isLure ? Math.min(0.72, faBase * 2.4) : faBase;
        return { responded: rng() < faP, rtMs: 550 + Math.floor(rng() * 1100) };
      });
    });
    const results = computeResults(blocks, responsesPerBlock);
    return { iq: results.iq, span: results.effectiveSpan, percentile: results.percentile, composite: results.composite };
  };

  const iqSamples: number[] = [];
  const spanSamples: number[] = [];
  const percentileSamples: number[] = [];
  let structurallyValid = true;
  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(60_000 + user);
    const skill = randn(rng);
    const r = simulateUser(rng, skill);
    iqSamples.push(r.iq);
    spanSamples.push(r.span);
    percentileSamples.push(r.percentile);
    if (!(r.iq >= IQ_MIN && r.iq <= IQ_MAX && r.percentile >= 1 && r.percentile <= 99 && r.composite >= 0 && r.composite <= 1)) {
      structurallyValid = false;
    }
  }
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanSpan = mean(spanSamples);
  const sdSpan = sd(spanSamples);
  const meanPct = mean(percentileSamples);
  check("all 500 users produce structurally valid results", structurallyValid);
  check("mean IQ near 100 (97-103)", meanIq > 97 && meanIq < 103, meanIq.toFixed(2));
  check("IQ SD plausible (8-20)", sdIq > 8 && sdIq < 20, sdIq.toFixed(2));
  check("mean span near population model (1.9-2.9)", meanSpan > 1.9 && meanSpan < 2.9, meanSpan.toFixed(2));
  check("span SD plausible (0.8-1.7)", sdSpan > 0.8 && sdSpan < 1.7, sdSpan.toFixed(2));
  check("mean percentile sane (35-65)", meanPct > 35 && meanPct < 65, meanPct.toFixed(2));
  check(
    "span spread covers low and high (min 0, max >= 4)",
    Math.min(...spanSamples) === 0 && Math.max(...spanSamples) >= 4,
    `min=${Math.min(...spanSamples)} max=${Math.max(...spanSamples)}`
  );
  console.log(
    `  info   population: mean IQ=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)} | mean span=${meanSpan.toFixed(2)} SD=${sdSpan.toFixed(2)} | mean percentile=${meanPct.toFixed(1)}`
  );
}

section("Quick mode end-to-end");
{
  const rng = mulberry32(31337);
  const blocks = buildBlocks(rng, { quick: true });
  check("quick run: 2 blocks of 12", blocks.length === 2 && blocks.every((b) => b.trials.length === 12));
  const perfect = blocks.map((b) => b.trials.map((t) => ({ responded: t.isTarget, rtMs: 750 })));
  const results = computeResults(blocks, perfect);
  check("quick perfect play: span 2", results.effectiveSpan === 2);
  check("quick perfect play: composite 1", Math.abs(results.composite - 1) < 1e-9);
  check("quick perfect play: IQ 99 (96 anchor +3 nudge)", results.iq === 99, String(results.iq));
  check("quick perfect play: percentile 39", results.percentile === 39);
  const mash = blocks.map((b) => b.trials.map(() => ({ responded: true, rtMs: 200 })));
  const mashResults = computeResults(blocks, mash);
  check("quick mash: span 0, composite 0.5", mashResults.effectiveSpan === 0 && Math.abs(mashResults.composite - 0.5) < 1e-9);
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
