/* Screenshot word-memory: intro / study / recognize / results @375 & 1440 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");
const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();

  for (const vp of [{ w: 375, h: 812 }, { w: 1440, h: 900 }]) {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const p = await ctx.newPage();
    const tag = `${vp.w}`;

    await p.goto(`${BASE}/test/word-memory?quick=1`, { waitUntil: "domcontentloaded", timeout: 60000 });
    await p.waitForSelector('[data-testid="wm-intro"]', { timeout: 60000 });
    await sleep(500);
    await p.screenshot({ path: `scripts/wm-${tag}-intro.png`, fullPage: false });

    await p.$eval('[data-testid="wm-intro-cta"]', (el) => el.click());

    // study phase
    await p
      .waitForFunction(() => document.querySelector('[data-testid="wm-stage"]')?.getAttribute("data-phase") === "study", undefined, { timeout: 20000 })
      .catch(() => {});
    await sleep(400);
    await p.screenshot({ path: `scripts/wm-${tag}-study.png`, fullPage: false });

    // recognize phase
    await p
      .waitForFunction(() => document.querySelector('[data-testid="wm-stage"]')?.getAttribute("data-phase") === "recognize", undefined, { timeout: 20000 })
      .catch(() => {});
    await sleep(400);
    await p.screenshot({ path: `scripts/wm-${tag}-recognize.png`, fullPage: false });

    // mash through all rounds to reach results (quick timings still need ~30s)
    const deadline = Date.now() + 90000;
    while (Date.now() < deadline) {
      const st = await p.evaluate(() => ({
        results: !!document.querySelector('[data-testid="wm-results"]'),
        recognize: document.querySelector('[data-testid="wm-stage"]')?.getAttribute("data-phase") === "recognize",
      })).catch(() => null);
      if (!st) break;
      if (st.results) break;
      if (st.recognize) {
        const btn = await p.$('[data-testid="wm-btn-new"]');
        if (btn) await btn.evaluate((el) => el.click());
      }
      await sleep(40);
    }
    await p.waitForSelector('[data-testid="wm-results"]', { timeout: 60000 });
    await sleep(1800);
    await p.$eval('[data-testid="wm-results"]', (el) => el.scrollIntoView()).catch(() => {});
    await sleep(400);
    await p.screenshot({ path: `scripts/wm-${tag}-results.png`, fullPage: false });
    await ctx.close();
  }

  await browser.close();
  console.log("screenshots done");
})();
