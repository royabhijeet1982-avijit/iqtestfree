/**
 * Quick screenshots for Spatial Memory Test page (intro + recall board).
 * Run: node scripts/screenshot-spatial-memory.js
 * Outputs: scripts/sm-intro.png, scripts/sm-board.png
 * (Results view is verified numerically by verify-spatial-memory-flow.js)
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();

  // Desktop intro
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const dpage = await desktop.newPage();
  await dpage.goto(`${BASE}/test/spatial-memory`, { waitUntil: "networkidle" });
  await dpage.waitForTimeout(600);
  await dpage.screenshot({ path: "scripts/sm-intro.png", fullPage: false });
  console.log("saved scripts/sm-intro.png");
  await desktop.close();

  // Mobile recall phase (quick mode)
  const mobile = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const mpage = await mobile.newPage();
  await mpage.goto(`${BASE}/test/spatial-memory?quick=1`, { waitUntil: "networkidle" });
  await mpage.click('[data-testid="sm-intro-cta"]');
  let reached = false;
  for (let i = 0; i < 300; i++) {
    const phase = await mpage
      .$eval('[data-testid="sm-stage"]', (el) => el.getAttribute("data-phase"))
      .catch(() => null);
    if (phase === "recall") { reached = true; break; }
    await sleep(20);
  }
  if (reached) {
    await mpage.waitForTimeout(300);
    await mpage.screenshot({ path: "scripts/sm-board.png", fullPage: false });
    console.log("saved scripts/sm-board.png");
  } else {
    console.log("recall phase not reached in time - board screenshot skipped");
  }
  await mobile.close();

  await browser.close();
  console.log("done");
})();
