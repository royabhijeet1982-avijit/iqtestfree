/**
 * Screenshot capture for Pattern Memory Test page.
 * Run: node scripts/screenshot-pattern-memory.js
 * Outputs: scripts/pm-intro.png, scripts/pm-board.png, scripts/pm-results.png
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();

  // Desktop intro
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const dpage = await desktop.newPage();
  await dpage.goto(`${BASE}/test/pattern-memory`, { waitUntil: "networkidle" });
  await dpage.screenshot({ path: "scripts/pm-intro.png", fullPage: false });
  console.log("saved scripts/pm-intro.png");

  // Mobile board mid-round (quick mode: catch the recall phase)
  const mobile = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const mpage = await mobile.newPage();
  await mpage.goto(`${BASE}/test/pattern-memory?quick=1`, { waitUntil: "networkidle" });
  await mpage.click('[data-testid="pm-intro-cta"]');
  // poll until recall phase on round 1
  for (let i = 0; i < 200; i++) {
    const phase = await mpage
      .$eval('[data-testid="pm-stage"]', (el) => el.getAttribute("data-phase"))
      .catch(() => null);
    if (phase === "recall") break;
    await sleep(25);
  }
  await mpage.waitForTimeout(250);
  await mpage.screenshot({ path: "scripts/pm-board.png", fullPage: false });
  console.log("saved scripts/pm-board.png");

  // Play through with perfect recall to reach results
  const picked = new Set();
  // capture pattern during show phases
  for (let round = 1; round <= 6; round++) {
    // wait show, collect lit
    let lit = [];
    for (let i = 0; i < 400; i++) {
      const st = await mpage
        .evaluate(() => {
          const stage = document.querySelector('[data-testid="pm-stage"]');
          const cells = document.querySelectorAll('[data-testid^="pm-cell-"][data-on="1"]');
          return {
            phase: stage ? stage.getAttribute("data-phase") : null,
            round: (() => {
              const chip = document.querySelector('[data-testid="pm-round-chip"]');
              return chip ? parseInt(chip.textContent.replace(/[^0-9]/g, ""), 10) : 0;
            })(),
            lit: [...cells].map((c) => parseInt(c.getAttribute("data-testid").slice(8), 10)),
          };
        })
        .catch(() => null);
      if (st && st.phase === "show" && st.round === round && st.lit.length > 0) {
        lit = st.lit;
        break;
      }
      await sleep(15);
    }
    // wait recall, click, submit
    for (let i = 0; i < 400; i++) {
      const phase = await mpage
        .$eval('[data-testid="pm-stage"]', (el) => el.getAttribute("data-phase"))
        .catch(() => null);
      if (phase === "recall") break;
      await sleep(20);
    }
    for (const c of lit) {
      await mpage.click(`[data-testid="pm-cell-${c}"]`).catch(() => {});
    }
    await mpage.click('[data-testid="pm-submit"]').catch(() => {});
    await sleep(150);
  }
  await mpage.waitForTimeout(2200);
  await mpage.screenshot({ path: "scripts/pm-results.png", fullPage: false });
  console.log("saved scripts/pm-results.png");

  await browser.close();
})();
