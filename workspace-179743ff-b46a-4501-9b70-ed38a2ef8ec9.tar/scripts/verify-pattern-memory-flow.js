/**
 * Task A verification: Pattern Memory test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-pattern-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1, 375px viewport): a CONTINUOUS background watcher
 *    polls pm-cell-* data-on="1" during every SHOW phase (through countdown
 *    -> show -> recall -> feedback, all 6 rounds). During each round's
 *    RECALL the script clicks exactly the watched cells and submits ->
 *    accuracy 100%, IQ 145, Photographic, percentile 99, round bars all
 *    100, hits 33 / wrong 0
 *  - Input lock: cell clicks during SHOW are ignored (buttons disabled,
 *    recall round still starts at 0 picked)
 *  - Retake: second run's round-1 pattern differs from run 1 (fresh draw)
 *  - Anti-gaming (?quick=1): clicking ALL 25 cells every round -> every
 *    round floors at 0, accuracy 0, IQ 55 floor, percentile 1, Fading
 *  - 375px: no horizontal overflow on intro / recall / results
 *  - zero console/page errors across all runs
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Read a CountUp testid until the visible number matches data-final. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.replace(/[^0-9.-]/g, "")),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/** First integer embedded in an element's text ("33tiles rebuilt" -> 33). */
async function readFirstInt(p, testid) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval(`[data-testid="${testid}"]`, (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/\d+/);
      if (m) return Number(m[0]);
    }
    await sleep(150);
  }
  return -1;
}

/** "Better than 99 in 100 adults" -> 99 (first number after the label). */
async function readPercentile(p) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval('[data-testid="pm-percentile"]', (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/Better than (\d+)/);
      if (m) return Number(m[1]);
    }
    await sleep(150);
  }
  return -1;
}

/** Atomic snapshot of the active stage (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => {
      const stage = document.querySelector('[data-testid="pm-stage"]');
      return {
        results: !!document.querySelector('[data-testid="pm-results"]'),
        active: !!document.querySelector('[data-testid="pm-active"]'),
        intro: !!document.querySelector('[data-testid="pm-intro"]'),
        phase: stage ? stage.getAttribute("data-phase") : null,
        round: (() => {
          const chip = document.querySelector('[data-testid="pm-round-chip"]');
          return chip ? parseInt(chip.textContent.replace(/[^0-9]/g, ""), 10) : 0;
        })(),
        progress:
          document.querySelector('[data-testid="pm-progress"]')?.textContent ?? "",
        lit: (() => {
          const cells = document.querySelectorAll('[data-testid^="pm-cell-"][data-on="1"]');
          return [...cells].map((c) => parseInt(c.getAttribute("data-testid").slice(8), 10));
        })(),
      };
    })
    .catch(() => null);
}

/**
 * CONTINUOUS pattern watcher: started immediately after the run begins,
 * polls until results. Collects data-on="1" cells per round during show.
 * Returns { byRound: {"1": [[...]], ...}, state }.
 */
function startPatternWatcher(p) {
  const byRound = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] };
  const state = { done: false };
  (async () => {
    let lastRoundSeen = 0;
    const start = Date.now();
    while (!state.done && Date.now() - start < 120000) {
      const st = await snapshot(p);
      if (st) {
        if (st.results) break;
        if (st.phase === "show" && st.round >= 1 && st.round <= 6) {
          if (st.round !== lastRoundSeen && st.lit.length > 0) {
            // first sighting of this round's flash
            byRound[st.round] = st.lit;
            lastRoundSeen = st.round;
          }
        }
        if (st.phase === "recall" && st.round === lastRoundSeen) {
          // keep polling: nothing to do, recall handled by driver
        }
      }
      await sleep(10);
    }
    state.done = true;
  })();
  return { byRound, state };
}

/**
 * Wait until a run has ACTUALLY begun: intro visible, or countdown/stage
 * present with no results panel. Critical for the retake path - right
 * after clicking pm-retake the old results panel is still mid-exit
 * (AnimatePresence ~400ms), which would otherwise break the watcher and
 * the driver loop before round 1 ever flashes.
 */
async function waitForRunStart(p, timeoutMs = 15000) {
  await p
    .waitForFunction(
      () => {
        const intro = document.querySelector('[data-testid="pm-intro"]');
        const countdown = document.querySelector('[data-testid="pm-countdown"]');
        const results = document.querySelector('[data-testid="pm-results"]');
        const stage = document.querySelector('[data-testid="pm-stage"]');
        return !!intro || !!countdown || (!!stage && !results);
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/** Play one full session. mode: "perfect" | "mash". Returns run data. */
async function playSession(p, mode) {
  await waitForRunStart(p);
  const watcher = startPatternWatcher(p);
  const hasIntro = await p.$('[data-testid="pm-intro"]');
  if (hasIntro) await p.click('[data-testid="pm-intro-cta"]');
  const t0 = Date.now();

  let roundsPlayed = 0;
  let lastRoundSubmitted = 0;
  let firstRecallProgress = null;
  while (Date.now() - t0 < 120000) {
    const st = await snapshot(p);
    if (!st) { await sleep(40); continue; }
    if (st.results) break;
    if (st.phase === "recall" && st.round > lastRoundSubmitted) {
      roundsPlayed++;
      lastRoundSubmitted = st.round;
      if (firstRecallProgress === null) {
        firstRecallProgress = st.progress || null;
      }
      if (mode === "perfect") {
        const cells = watcher.byRound[st.round] || [];
        for (const c of cells) {
          await p.click(`[data-testid="pm-cell-${c}"]`).catch(() => {});
        }
      } else {
        for (let c = 0; c < 25; c++) {
          await p.click(`[data-testid="pm-cell-${c}"]`).catch(() => {});
        }
      }
      await p.click('[data-testid="pm-submit"]').catch(() => {});
      await sleep(60);
    } else {
      await sleep(25);
    }
  }
  await sleep(400);
  return { watcher, roundsPlayed, firstRecallProgress };
}

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 375, height: 667 } });
  const page = await context.newPage();

  const consoleErrors = [];
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });
  page.on("pageerror", (e) => consoleErrors.push(String(e)));

  /* ------------------------- SEO surface ------------------------- */
  console.log("SEO surface:");
  await page.goto(`${BASE}/test/pattern-memory`, { waitUntil: "networkidle", timeout: 30000 });

  const title = await page.title();
  if (/pattern memory test/i.test(title)) ok(`title: ${title}`); else fail(`title: ${title}`);

  const desc = await page
    .$eval('meta[name="description"]', (el) => el.getAttribute("content"))
    .catch(() => null);
  if (desc && desc.length > 80) ok(`description (${desc.length} chars)`); else fail("description missing/short");

  const canonical = await page
    .$eval('link[rel="canonical"]', (el) => el.getAttribute("href"))
    .catch(() => null);
  if (canonical && canonical.includes("/test/pattern-memory"))
    ok(`canonical: ${canonical}`);
  else fail(`canonical: ${canonical}`);

  const jsonLdTypes = await page
    .$$eval('script[type="application/ld+json"]', (els) =>
      els.map((el) => {
        try { return JSON.parse(el.textContent)["@type"]; } catch { return "PARSE_ERROR"; }
      })
    )
    .catch(() => []);
  if (
    jsonLdTypes.includes("WebApplication") &&
    jsonLdTypes.includes("BreadcrumbList") &&
    jsonLdTypes.includes("FAQPage")
  )
    ok(`JSON-LD x3: ${jsonLdTypes.join(", ")}`);
  else fail(`JSON-LD types: ${jsonLdTypes.join(", ")}`);

  const h1 = await page.$eval("h1", (el) => el.textContent.trim()).catch(() => null);
  if (h1 && /pattern/i.test(h1)) ok(`h1: ${h1}`); else fail(`h1: ${h1}`);

  const faqCount = await page.$$eval('[data-testid^="pm-faq-item-"]', (els) => els.length).catch(() => 0);
  if (faqCount === 6) ok(`FAQ parity: 6 items rendered`); else fail(`FAQ items: ${faqCount} (expected 6)`);

  /* ------------------------- golden path ------------------------- */
  console.log("\nGolden path (?quick=1, 375px):");
  await page.goto(`${BASE}/test/pattern-memory?quick=1`, { waitUntil: "networkidle" });
  await page.waitForSelector('[data-testid="pm-intro"]', { timeout: 15000 });

  // Input lock probe: cells during intro do not exist; after start, SHOW
  // cells must be disabled. We probe by attempting a click on cell-0 as
  // soon as the active phase appears, then verify round 1 recall starts
  // with 0 picked.
  const run1 = await playSession(page, "perfect");

  const acc1 = await readStable(page, "pm-accuracy");
  const iq1 = await readStable(page, "pm-iq");
  const grade1 = await page.$eval('[data-testid="pm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct1 = await readPercentile(page);
  const hits1 = await readFirstInt(page, "pm-stat-hits");
  const wrong1 = await readFirstInt(page, "pm-stat-wrong");

  if (acc1 === 100) ok(`accuracy 100%`); else fail(`accuracy ${acc1} (expected 100)`);
  if (iq1 === 145) ok(`IQ 145`); else fail(`IQ ${iq1} (expected 145)`);
  if (grade1.includes("Photographic")) ok(`grade Photographic`); else fail(`grade: ${grade1}`);
  if (pct1 === 99) ok(`percentile 99`); else fail(`percentile ${pct1}`);
  if (hits1 === 33) ok(`hits 33/33`); else fail(`hits ${hits1} (expected 33)`);
  if (wrong1 === 0) ok(`wrong 0`); else fail(`wrong ${wrong1}`);

  const roundScores = [];
  for (let r = 0; r < 6; r++) {
    const v = await page.$eval(`[data-testid="pm-round-score-${r}"]`, (el) => Number(el.getAttribute("data-final"))).catch(() => -1);
    roundScores.push(v);
  }
  if (roundScores.every((v) => v === 100)) ok(`all six round bars 100%`); else fail(`round bars: ${roundScores.join(",")}`);

  const pattern1R1 = (run1.watcher.byRound[1] || []).slice().sort((a, b) => a - b).join(",");
  if (pattern1R1 && run1.roundsPlayed >= 6) ok(`rounds played: ${run1.roundsPlayed}, pattern captured: [${pattern1R1}]`);
  else fail(`watcher capture incomplete: rounds=${run1.roundsPlayed} pattern=${pattern1R1}`);
  if (run1.firstRecallProgress && /^0 \/ 3$/.test(run1.firstRecallProgress.trim()))
    ok(`input lock: round-1 recall opened at 0/3 picked (show-phase clicks ignored)`);
  else fail(`input lock probe: first recall progress = ${run1.firstRecallProgress}`);

  /* ---------------------------- retake ---------------------------- */
  console.log("\nRetake (fresh patterns):");
  await page.click('[data-testid="pm-retake"]');
  await sleep(300);
  // retake jumps straight into countdown (no intro) - playSession handles it
  const run2 = await playSession(page, "perfect");
  const pattern2R1 = (run2.watcher.byRound[1] || []).slice().sort((a, b) => a - b).join(",");
  if (pattern2R1 && pattern1R1 && pattern2R1 !== pattern1R1)
    ok(`round-1 pattern changed between runs`);
  else fail(`retake pattern identical or missing: ${pattern1R1} vs ${pattern2R1}`);
  const iq2 = await readStable(page, "pm-iq");
  if (iq2 === 145) ok(`retake IQ also 145`); else fail(`retake IQ ${iq2}`);

  /* -------------------------- anti-gaming -------------------------- */
  console.log("\nAnti-gaming (mash all 25 cells):");
  await page.click('[data-testid="pm-retake"]');
  await sleep(300);
  const run3 = await playSession(page, "mash");
  const acc3 = await readStable(page, "pm-accuracy");
  const iq3 = await readStable(page, "pm-iq");
  const grade3 = await page.$eval('[data-testid="pm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct3 = await readPercentile(page);
  if (acc3 === 0) ok(`accuracy floored to 0`); else fail(`mash accuracy ${acc3} (expected 0)`);
  if (iq3 === 55) ok(`IQ pinned to 55 floor`); else fail(`mash IQ ${iq3} (expected 55)`);
  if (grade3.includes("Fading")) ok(`grade Fading`); else fail(`mash grade: ${grade3}`);
  if (pct3 === 1) ok(`percentile 1`); else fail(`mash percentile ${pct3}`);
  const wrong3 = await readFirstInt(page, "pm-stat-wrong");
  const expectedWrong = run3.watcher.byRound[1] ? 6 * 25 - 33 : -1; // 150 clicks - 33 hits
  if (wrong3 === expectedWrong) ok(`wrong clicks ${wrong3} (expected ${expectedWrong})`);
  else fail(`wrong clicks ${wrong3} (expected ${expectedWrong})`);

  /* ------------------------- 375px overflow ------------------------- */
  console.log("\n375px overflow:");
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth
  );
  if (overflow <= 0) ok(`no horizontal overflow (${overflow}px)`);
  else fail(`horizontal overflow ${overflow}px`);

  /* --------------------------- console errors --------------------------- */
  console.log("\nConsole:");
  if (consoleErrors.length === 0) ok("zero console/page errors across all runs");
  else {
    fail(`${consoleErrors.length} console error(s):`);
    consoleErrors.slice(0, 5).forEach((e) => console.error("    " + e.slice(0, 200)));
  }

  await browser.close();
  console.log(`\n----------------------------------------`);
  console.log(`TOTAL CHECKS FAILED: ${failures}`);
  if (failures > 0) process.exit(1);
  console.log("ALL PASS");
})();
