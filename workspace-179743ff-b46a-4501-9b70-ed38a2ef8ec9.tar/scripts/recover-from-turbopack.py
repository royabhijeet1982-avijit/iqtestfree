#!/usr/bin/env python3
"""Probe Turbopack SST cache for recoverable raw sources of lost test pages."""
import glob
import os
import re
import sys

CACHE = "/home/z/my-project/.next/dev/cache/turbopack"
OUT = "/home/z/my-project/.recovery"
os.makedirs(OUT, exist_ok=True)

MARKERS = [
    # distinctive raw-source identifiers per lost page
    "n-back-core", "nBack", "N-BACK",
    "stroop-core", "STROOP",
    "chimp-core", "chimp-test",
    "mental-rotation-core",
    "digit-span-core", "digitSpan",
    "reaction-time-core", "reactionTime",
    "visual-memory-core", "visualMemory",
    "matrix-reasoning-core", "matrixReasoning",
    # raw-source-only signatures (never in compiled output URLs)
    "SPAN_IQ_ANCHORS", "buildCodingKey", "rateToPsi",
]

sst_files = sorted(glob.glob(f"{CACHE}/*/*.sst"))
print(f"Found {len(sst_files)} sst files, total {sum(os.path.getsize(f) for f in sst_files)/1e6:.1f} MB")

for f in sst_files:
    data = open(f, "rb").read()
    hits = []
    for m in MARKERS:
        n = data.count(m.encode())
        if n:
            hits.append(f"{m}x{n}")
    if hits:
        print(f"{os.path.basename(f):16s} {os.path.getsize(f)/1e6:8.2f}MB  {'  '.join(hits)}")
