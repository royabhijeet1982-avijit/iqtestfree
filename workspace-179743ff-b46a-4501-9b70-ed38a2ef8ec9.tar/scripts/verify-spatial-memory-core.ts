/* ------------------------------------------------------------------ */
/*  Unit verification for spatial-memory-core.ts                       */
/*  Run: bun scripts/verify-spatial-memory-core.ts                     */
/* ------------------------------------------------------------------ */

import {
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  IQ_MAX,
  IQ_MIN,
  PRE_STUDY_MS,
  PRE_STUDY_MS_QUICK,
  ROUND_GRID_DIMS,
  ROUND_ITEM_COUNTS,
  SCORE_MEAN,
  SCORE_SD,
  STUDY_GAP_MS,
  STUDY_GAP_MS_QUICK,
  STUDY_ON_MS,
  STUDY_ON_MS_QUICK,
  SYMBOL_POOL,
  TOTAL_ITEMS,
  buildSpatialMemorySession,
  colOf,
  gradeForIq,
  iqToPercentile,
  manhattan,
  mulberry32,
  rowOf,
  scoreSession,
  shuffled,
  spatialIndex,
  type Placement,
} from "../src/components/test/spatial-memory-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check(
  "ROUND_GRID_DIMS is [3,3,4,4,5]",
  JSON.stringify(ROUND_GRID_DIMS) === "[3,3,4,4,5]"
);
check(
  "ROUND_ITEM_COUNTS is [3,4,5,6,7]",
  JSON.stringify(ROUND_ITEM_COUNTS) === "[3,4,5,6,7]"
);
check("TOTAL_ITEMS is 25", TOTAL_ITEMS === 25, String(TOTAL_ITEMS));
check("STUDY_ON_MS is 1150", STUDY_ON_MS === 1150);
check("STUDY_GAP_MS is 250", STUDY_GAP_MS === 250);
check("FEEDBACK_MS is 950", FEEDBACK_MS === 950);
check(
  "quick timings all shorter than normal",
  STUDY_ON_MS_QUICK < STUDY_ON_MS &&
    STUDY_GAP_MS_QUICK < STUDY_GAP_MS &&
    PRE_STUDY_MS_QUICK < PRE_STUDY_MS &&
    FEEDBACK_MS_QUICK < FEEDBACK_MS
);
check(
  "population anchor 0.62 / 0.12",
  SCORE_MEAN === 0.62 && SCORE_SD === 0.12,
  `mean=${SCORE_MEAN} sd=${SCORE_SD}`
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("Symbol pool integrity");
{
  check("pool size is 26 (>= 25 needed)", SYMBOL_POOL.length === 26, String(SYMBOL_POOL.length));
  const unique = new Set(SYMBOL_POOL).size === SYMBOL_POOL.length;
  check("no duplicate symbols", unique);
  const allSingle = SYMBOL_POOL.every((s) => [...s].length === 1);
  check("every symbol is a single grapheme", allSingle);
  const noEmoji = SYMBOL_POOL.every((s) => s.codePointAt(0)! < 0x1f000);
  check("all BMP glyphs (no emoji plane)", noEmoji);
}

section("Geometry helpers");
{
  check("rowOf/colOf corners on 3x3", rowOf(0, 3) === 0 && colOf(0, 3) === 0 && rowOf(8, 3) === 2 && colOf(8, 3) === 2);
  check("manhattan same cell 0", manhattan(4, 4, 3) === 0);
  check("manhattan orthogonal neighbours 1", manhattan(1, 4, 3) === 1);
  check("manhattan diagonal neighbours 2", manhattan(0, 4, 3) === 2);
  check("manhattan opposite corners 4", manhattan(0, 8, 3) === 4);
}

section("Session building: structure");
{
  const s = buildSpatialMemorySession(12345);
  check("5 rounds", s.rounds.length === 5);
  check(
    "grid dims match ROUND_GRID_DIMS",
    JSON.stringify(s.rounds.map((r) => r.gridDim)) === JSON.stringify([3, 3, 4, 4, 5])
  );
  check(
    "item counts match ROUND_ITEM_COUNTS",
    JSON.stringify(s.rounds.map((r) => r.pairs.length)) === JSON.stringify([3, 4, 5, 6, 7])
  );
  const allCellsValid = s.rounds.every((r) =>
    r.pairs.every((p) => Number.isInteger(p.cell) && p.cell >= 0 && p.cell < r.gridDim * r.gridDim)
  );
  check("all cells inside their board", allCellsValid);
  const distinctCellsPerRound = s.rounds.every(
    (r) => new Set(r.pairs.map((p) => p.cell)).size === r.pairs.length
  );
  check("no two symbols share a cell (per round)", distinctCellsPerRound);
  const allSymbols = s.rounds.flatMap((r) => r.pairs.map((p) => p.symbol));
  const uniqueSymbols = new Set(allSymbols).size === allSymbols.length;
  check("no symbol repeats across the whole session", uniqueSymbols);
  const traysCorrect = s.rounds.every(
    (r) =>
      r.tray.length === r.pairs.length &&
      JSON.stringify([...r.tray].sort()) === JSON.stringify(r.pairs.map((p) => p.symbol).sort())
  );
  check("tray is a permutation of the round's symbols", traysCorrect);
  const trayShuffled = s.rounds.some(
    (r) => JSON.stringify(r.tray) !== JSON.stringify(r.pairs.map((p) => p.symbol))
  );
  check("tray is actually shuffled (not identity)", trayShuffled);
}

section("Session building: placement spread rule");
{
  let violation: string | null = null;
  for (let seed = 1; seed <= 300 && !violation; seed++) {
    const s = buildSpatialMemorySession(seed);
    for (const r of s.rounds) {
      for (let i = 0; i < r.pairs.length && !violation; i++) {
        for (let j = i + 1; j < r.pairs.length && !violation; j++) {
          if (manhattan(r.pairs[i]!.cell, r.pairs[j]!.cell, r.gridDim) < 2) {
            violation = `seed ${seed} round ${r.round}: cells ${r.pairs[i]!.cell},${r.pairs[j]!.cell}`;
          }
        }
      }
    }
  }
  check("pairwise manhattan >= 2 across 300 seeds", violation === null, violation ?? "");
}

section("Session building: reshuffle across seeds");
{
  const a = buildSpatialMemorySession(1).rounds[0]!.pairs.map((p) => `${p.symbol}@${p.cell}`).join("|");
  const b = buildSpatialMemorySession(2).rounds[0]!.pairs.map((p) => `${p.symbol}@${p.cell}`).join("|");
  check("different seeds give different bindings", a !== b);
  const c = buildSpatialMemorySession(777).rounds[3]!.pairs.map((p) => `${p.symbol}@${p.cell}`).join("|");
  const c2 = buildSpatialMemorySession(777).rounds[3]!.pairs.map((p) => `${p.symbol}@${p.cell}`).join("|");
  check("same seed reproduces exactly", c === c2);
}

section("Scoring: perfect run");
{
  const session = buildSpatialMemorySession(500);
  const placements: Placement[] = [];
  for (const r of session.rounds) {
    for (const p of r.pairs) {
      placements.push({ round: r.round, symbol: p.symbol, cell: p.cell, rtMs: 1400 });
    }
  }
  const score = scoreSession(placements, session);
  check("perfect accuracy 1.0", score.accuracy === 1, String(score.accuracy));
  check("perfect IQ is 145", score.iq === 145, String(score.iq));
  check("correct equals total items 25", score.correct === 25 && score.totalItems === 25);
  check("percentile 99", score.percentile === 99);
  check("grade is Cartographer", score.grade.label === "Cartographer");
  check("avgRtMs present", score.avgRtMs !== null);
  check("all five round scores 1", score.rounds.every((s) => s.score === 1));
}

section("Scoring: all-wrong anti-gaming");
{
  const session = buildSpatialMemorySession(600);
  const placements: Placement[] = [];
  for (const r of session.rounds) {
    for (let i = 0; i < r.pairs.length; i++) {
      const p = r.pairs[i]!;
      // shift every symbol one cell to the right (wrapping in its row)
      const row = rowOf(p.cell, r.gridDim);
      const col = colOf(p.cell, r.gridDim);
      const wrongCell = row * r.gridDim + ((col + 1) % r.gridDim);
      placements.push({ round: r.round, symbol: p.symbol, cell: wrongCell, rtMs: 800 });
    }
  }
  const score = scoreSession(placements, session);
  check("all-wrong accuracy 0", score.accuracy === 0, String(score.accuracy));
  check("IQ pinned to 55", score.iq === 55, String(score.iq));
  check("percentile 1", score.percentile === 1);
  check("grade is Scattered", score.grade.label === "Scattered");
  check("zero correct", score.correct === 0);
}

section("Scoring: partial + re-place semantics");
{
  const session = buildSpatialMemorySession(700);
  const r0 = session.rounds[0]!;
  const p0 = r0.pairs[0]!;
  const p1 = r0.pairs[1]!;
  // symbol 0 correct, symbol 1 wrong, symbol 2 absent; then re-place symbol 0 WRONG
  const placements: Placement[] = [
    { round: 0, symbol: p0.symbol, cell: p0.cell, rtMs: 900 },
    { round: 0, symbol: p1.symbol, cell: p1.cell, rtMs: 900 },
    { round: 0, symbol: p0.symbol, cell: (p0.cell + 1) % (r0.gridDim * r0.gridDim), rtMs: 1100 },
  ];
  const score = scoreSession(placements, session);
  check("last placement wins (correct -> wrong = 1 correct)", score.rounds[0]!.correct === 1, String(score.rounds[0]!.correct));
  check("round 0 score 1/3", Math.abs(score.rounds[0]!.score - 1 / 3) < 1e-12);
  check("absent rounds score 0", score.rounds[1]!.score === 0 && score.rounds[4]!.score === 0);
  check("accuracy = mean of five round scores", Math.abs(score.accuracy - score.rounds.reduce((a, s) => a + s.score, 0) / 5) < 1e-12);
  // re-place wrong -> correct upgrades
  const placements2: Placement[] = [
    { round: 0, symbol: p0.symbol, cell: (p0.cell + 1) % (r0.gridDim * r0.gridDim), rtMs: 900 },
    { round: 0, symbol: p0.symbol, cell: p0.cell, rtMs: 1100 },
  ];
  const score2 = scoreSession(placements2, session);
  check("re-place upgrade counts once (not twice)", score2.rounds[0]!.correct === 1);
}

section("Scoring: degenerate sessions");
{
  const score = scoreSession([], null);
  check("null session -> IQ 55", score.iq === 55 && score.accuracy === 0);
  const session = buildSpatialMemorySession(800);
  const empty = scoreSession([], session);
  check("no placements -> all rounds 0, IQ 55", empty.iq === 55 && empty.rounds.length === 5);
  const foreign = scoreSession(
    [{ round: 0, symbol: "X", cell: 0, rtMs: 100 }],
    session
  );
  check("unknown symbol ignored safely", foreign.rounds[0]!.correct === 0);
  check("avgRtMs null with no timed placements", empty.avgRtMs === null);
}

section("Index + percentile coherence");
{
  check("anchor mean 0.62 maps to IQ 100", spatialIndex(0.62) === 100);
  check("0 gives IQ 55", spatialIndex(0) === 55);
  check("1 gives IQ 145", spatialIndex(1) === 145);
  let clamps = true;
  for (let i = -20; i <= 120; i++) {
    const iq = spatialIndex(i / 100);
    if (iq < IQ_MIN || iq > IQ_MAX) clamps = false;
  }
  check("sweep stays within bounds", clamps);
  check("iqToPercentile(55) = 1", iqToPercentile(55) === 1);
  check("iqToPercentile(145) = 99", iqToPercentile(145) === 99);
  check("percentile midpoint ~50", iqToPercentile(100) >= 49 && iqToPercentile(100) <= 51);
}

section("Grading ladder");
{
  check("gradeForIq(60) Scattered", gradeForIq(60).label === "Scattered");
  check("gradeForIq(90) Average", gradeForIq(90).label === "Average");
  check("gradeForIq(105) Anchored", gradeForIq(105).label === "Anchored");
  check("gradeForIq(120) Very sharp", gradeForIq(120).label === "Very sharp");
  check("gradeForIq(140) Cartographer", gradeForIq(140).label === "Cartographer");
}

section("Statistical sanity: random placement cannot reach the anchor");
{
  let sum = 0;
  const n = 300;
  for (let seed = 1; seed <= n; seed++) {
    const rng = mulberry32(seed * 7919);
    const session = buildSpatialMemorySession(seed);
    const placements: Placement[] = [];
    for (const r of session.rounds) {
      const cells = shuffled(
        Array.from({ length: r.gridDim * r.gridDim }, (_, i) => i),
        rng
      );
      r.pairs.forEach((p, i) => {
        placements.push({ round: r.round, symbol: p.symbol, cell: cells[i]!, rtMs: null });
      });
    }
    sum += scoreSession(placements, session).accuracy;
  }
  const randomMean = sum / n;
  check("random placement mean far below anchor 0.62", randomMean < 0.35, String(randomMean.toFixed(3)));
  check("random placement mean above absolute 0", randomMean > 0.0, String(randomMean.toFixed(3)));
}

console.log(`\n----------------------------------------`);
console.log(`TOTAL: ${pass + fail}  PASS: ${pass}  FAIL: ${fail}`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
