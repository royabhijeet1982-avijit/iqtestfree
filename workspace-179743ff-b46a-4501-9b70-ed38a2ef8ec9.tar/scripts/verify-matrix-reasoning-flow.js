/**
 * Task 24-a verification: Matrix Reasoning test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-matrix-reasoning-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1, 8 items): the script reads data-answer from the
 *    current item and clicks the matching option -> perfect run -> results
 *    (IQ, grade, percentile, 8/8 correct, per-rule bars)
 *  - Retake: new seed -> first item fingerprint differs
 *  - Anti-gaming: clicking options 1-2 instantly on every item -> mr-rushed
 *    honesty panel appears (fast median RT)
 *  - 375px: no horizontal overflow on intro / active / results
 *  - zero console/page errors
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll an element's numeric text until it stops changing twice in a row. */
async function readStable(p, testid, timeoutMs = 8000) {
  const start = Date.now();
  let last = null;
  let stable = 0;
  while (Date.now() - start < timeoutMs) {
    const t = await p
      .$eval(`[data-testid="${testid}"]`, (el) => el.textContent.trim())
      .catch(() => null);
    if (t !== null && t === last) {
      stable++;
      if (stable >= 2) return t;
    } else {
      stable = 0;
      last = t;
    }
    await sleep(150);
  }
  return last;
}

/** Wait for the CURRENT item (data-index==idx) to be mounted - AnimatePresence
 *  keeps the exiting item in the DOM briefly, so testid alone is ambiguous. */
async function waitForItem(p, idx, timeoutMs = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const el = await p.$(`[data-testid="mr-item"][data-index="${idx}"]`);
    if (el) return el;
    await sleep(60);
  }
  throw new Error(`item ${idx} never mounted`);
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    inner: window.innerWidth,
  }));
  if (overflow.scroll <= overflow.inner + 1) ok(`375px ${label}: no horizontal overflow (${overflow.scroll}<=${overflow.inner})`);
  else fail(`375px ${label}: horizontal overflow ${overflow.scroll}>${overflow.inner}`);
}

async function checkSeo(p) {
  const title = await p.title();
  if (/matrix reasoning test/i.test(title)) ok(`title: ${title}`);
  else fail(`title: ${title}`);

  const desc = await p.$eval('meta[name="description"]', (el) => el.content).catch(() => null);
  if (desc && desc.length >= 120 && desc.length <= 170) ok(`description: ${desc.length} chars`);
  else fail(`description missing/bad length: ${desc ? desc.length : "none"}`);

  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href).catch(() => null);
  if (canonical === `${BASE}/test/matrix-reasoning` || canonical === "https://brainmetrics.app/test/matrix-reasoning") ok(`canonical: ${canonical}`);
  else fail(`canonical: ${canonical}`);

  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => {
      try { return JSON.parse(e.textContent); } catch { return null; }
    })
  );
  const kinds = jsonld.map((j) => (j && j["@type"]) || "bad").join(",");
  const hasWebApp = jsonld.some((j) => j && j["@type"] === "WebApplication");
  const hasBread = jsonld.some((j) => j && j["@type"] === "BreadcrumbList");
  const hasFaq = jsonld.some((j) => j && j["@type"] === "FAQPage");
  if (hasWebApp && hasBread && hasFaq) ok(`JSON-LD x3: ${kinds}`);
  else fail(`JSON-LD: ${kinds}`);

  const faqJson = jsonld.find((j) => j && j["@type"] === "FAQPage");
  const faqDom = await p.$$eval('[data-testid^="mr-faq-item-"]', (els) => els.length);
  if (faqJson && faqJson.mainEntity && faqJson.mainEntity.length === faqDom) ok(`FAQ parity: ${faqDom} == JSON-LD`);
  else fail(`FAQ parity broken: DOM ${faqDom} vs JSON-LD ${faqJson && faqJson.mainEntity ? faqJson.mainEntity.length : "?"}`);

  const h1 = await p.$eval("h1", (el) => el.textContent.trim()).catch(() => null);
  if (h1 && /matrix reasoning/i.test(h1)) ok(`h1: ${h1}`);
  else fail(`h1: ${h1}`);
}

/** Play one full quick session. mode: "perfect" (human pace, correct answers)
 *  or "mash" (instant alternated clicks). Returns item fingerprints. */
async function playSession(p, mode) {
  const fingerprints = [];
  await p.waitForSelector('[data-testid="mr-intro-cta"]', { timeout: 15000 });
  await p.click('[data-testid="mr-intro-cta"]');

  for (let i = 0; i < 8; i++) {
    await waitForItem(p, i);
    const info = await p.$eval(`[data-testid="mr-item"][data-index="${i}"]`, (el) => ({
      answer: Number(el.getAttribute("data-answer")),
      fp: el.getAttribute("data-fingerprint"),
    }));
    fingerprints.push(info.fp);
    const pick = mode === "perfect" ? info.answer : i % 2; // mash: alternate 0/1 fast
    const opt = await p.$(`[data-testid="mr-option-${pick}"]`);
    if (!opt) { fail(`option ${pick} not found on item ${i}`); return fingerprints; }
    await opt.evaluate((el) => el.click());
    if (mode === "mash") { /* instant, no delay -> rushed */ }
    else { await sleep(2250); } // human pace: median RT above the 2000ms rushed line
  }
  return fingerprints;
}

/** Answer the CURRENT visible item correctly (used after retake / on mobile). */
async function answerCurrentCorrect(p, idx) {
  await waitForItem(p, idx);
  const a = await p.$eval(`[data-testid="mr-item"][data-index="${idx}"]`, (el) =>
    Number(el.getAttribute("data-answer"))
  );
  const opt = await p.$(`[data-testid="mr-option-${a}"]`);
  if (!opt) throw new Error(`option ${a} missing`);
  await opt.evaluate((el) => el.click());
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p = await ctx.newPage();
  const consoleErrors = [];
  p.on("console", (msg) => { if (msg.type() === "error") consoleErrors.push(msg.text()); });
  p.on("pageerror", (e) => consoleErrors.push(String(e)));

  // ---------------- SEO ----------------
  console.log("— SEO surface —");
  await p.goto(`${BASE}/test/matrix-reasoning`, { waitUntil: "networkidle" });
  await checkSeo(p);
  await noHorizontalOverflow(p, "intro");

  // ---------------- Run 1: perfect ----------------
  console.log("— Run 1: perfect quick session (8 items) —");
  const url = `${BASE}/test/matrix-reasoning?quick=1`;
  await p.goto(url, { waitUntil: "networkidle" });
  const fps1 = await playSession(p, "perfect");

  await p.waitForSelector('[data-testid="mr-results"]', { timeout: 15000 });
  ok("results render");

  const iq = await readStable(p, "mr-iq");
  const iqNum = Number(iq);
  // Quick 8-item session on the 20-item population anchor: 8/8 -> rawToIq(8) = 89
  if (Number.isFinite(iqNum) && iqNum >= 55 && iqNum <= 145) ok(`IQ score: ${iq} (8/8 quick -> 89 expected)`);
  else fail(`IQ out of range: ${iq}`);

  const correct = await p.$eval('[data-testid="mr-correct"]', (el) => el.textContent.trim()).catch(() => null);
  if (correct && /8\s*\/\s*8/.test(correct)) ok(`correct count: ${correct}`);
  else fail(`correct count: ${correct}`);

  const pct = await p.$eval('[data-testid="mr-percentile"]', (el) => el.textContent.trim()).catch(() => null);
  if (pct && pct.length > 0) ok(`percentile line: ${pct.slice(0, 60)}`);
  else fail("percentile missing");

  const grade = await p.$eval('[data-testid="mr-grade"]', (el) => el.textContent.trim()).catch(() => null);
  if (grade) ok(`grade chip: ${grade.slice(0, 40)}`);
  else fail("grade chip missing");

  const ruleBars = await p.$$eval('[data-testid^="mr-rule-"]', (els) => els.length);
  if (ruleBars >= 5) ok(`per-rule accuracy bars: ${ruleBars}`);
  else fail(`per-rule bars: ${ruleBars} (expected >=5)`);

  const rushed1 = await p.$('[data-testid="mr-rushed"]');
  if (!rushed1) ok("no rushed flag on honest pace");
  else fail("rushed flag shown despite 120ms+ pace?");

  // ---------------- Retake: seed differs ----------------
  console.log("— Retake: new seed -> items differ —");
  await p.click('[data-testid="mr-retake"]'); // retake calls start() -> straight to active
  await waitForItem(p, 0);
  const fp2 = await p.$eval('[data-testid="mr-item"][data-index="0"]', (el) => el.getAttribute("data-fingerprint"));
  if (fp2 && fp2 !== fps1[0]) ok("first item fingerprint changed on retake (anti-memorisation)");
  else fail(`fingerprint unchanged: ${fp2}`);
  // finish this retake correctly to clear state
  for (let i = 0; i < 8; i++) {
    await answerCurrentCorrect(p, i);
    await sleep(60);
  }
  await p.waitForSelector('[data-testid="mr-results"]', { timeout: 15000 });

  // ---------------- Anti-gaming: instant clicking ----------------
  console.log("— Anti-gaming: instant clicking -> rushed flag —");
  await p.click('[data-testid="mr-retake"]'); // straight to active; play another full session
  await p.goto(`${BASE}/test/matrix-reasoning?quick=1`, { waitUntil: "networkidle" }); // reset to intro cleanly
  const fps3 = await playSession(p, "mash");
  await p.waitForSelector('[data-testid="mr-results"]', { timeout: 15000 });
  const rushed3 = await p.$('[data-testid="mr-rushed"]');
  if (rushed3) {
    const txt = await rushed3.evaluate((el) => el.textContent.trim().slice(0, 70));
    ok(`rushed panel shown: ${txt}`);
  } else fail("mash session NOT flagged rushed");
  const iq3 = await readStable(p, "mr-iq");
  ok(`mash IQ honest/floor: ${iq3}`);

  // ---------------- 375px ----------------
  console.log("— Mobile 375px —");
  const mob = await browser.newContext({ viewport: { width: 375, height: 720 } });
  const mp = await mob.newPage();
  mp.on("pageerror", (e) => consoleErrors.push(String(e)));
  await mp.goto(`${BASE}/test/matrix-reasoning?quick=1`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await mp.click('[data-testid="mr-intro-cta"]');
  await mp.waitForSelector('[data-testid="mr-item"]', { timeout: 15000 });
  await noHorizontalOverflow(mp, "active");
  // finish instantly
  for (let i = 0; i < 8; i++) {
    await mp.waitForSelector(`[data-testid="mr-item"][data-index="${i}"]`, { timeout: 15000 });
    const a = await mp.$eval(`[data-testid="mr-item"][data-index="${i}"]`, (el) => Number(el.getAttribute("data-answer")));
    const opt = await mp.$(`[data-testid="mr-option-${a}"]`);
    await opt.evaluate((el) => el.click());
    await sleep(60);
  }
  await mp.waitForSelector('[data-testid="mr-results"]', { timeout: 15000 });
  await noHorizontalOverflow(mp, "results");
  await mob.close();

  // ---------------- Console ----------------
  console.log("— Console —");
  const realErrors = consoleErrors.filter(
    (e) => !/favicon|Download the React DevTools/i.test(e)
  );
  if (realErrors.length === 0) ok("zero console/page errors");
  else { fail(`${realErrors.length} console errors:`); realErrors.slice(0, 5).forEach((e) => console.error(`    ${e.slice(0, 140)}`)); }

  await browser.close();
  console.log("");
  if (failures === 0) { console.log("RESULTS: ALL PASS"); process.exit(0); }
  else { console.log(`RESULTS: ${failures} FAIL`); process.exit(1); }
})();
