/**
 * Task 24-a verification: Chimp Test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-chimp-test-flow.js
 *
 * Covers:
 *  - SEO surface (route 200, title, description, canonical, JSON-LD x3,
 *    FAQ parity visible vs JSON-LD, h1)
 *  - Run 1 (?quick=1): solve rounds by reading chip positions from the DOM
 *    while the numbers are visible (chip 1 tapped fast, others ~250ms apart),
 *    climbing several levels, then burning the remaining lives -> results
 *    with IQ, percentile, grade, accuracy, no false bot flag
 *  - Run 2 (retake): deliberately wrong tap every round -> lives run out
 *    fast, accuracy 0%, IQ still a valid finite number
 *  - Run 3: 375px viewport - intro, board and results have zero horizontal
 *    overflow
 *  - zero console/page errors throughout
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** goto with retries - the dev server occasionally bounces while other
 *  files in the workspace are recompiled (transient connection refusal). */
async function gotoRetry(page, url, attempts = 10) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      return await page.goto(url, { waitUntil: "networkidle", timeout: 30_000 });
    } catch (e) {
      lastErr = e;
      if (!/ERR_CONNECTION_REFUSED|ECONNRESET|net::ERR/.test(String(e))) throw e;
      await sleep(3000);
    }
  }
  throw lastErr;
}

/** Read every cell whose number is currently visible in the DOM. */
async function readVisibleChips(page) {
  return page.$$eval('[data-testid^="ct-cell-"]', (els) =>
    els
      .map((el) => ({
        cell: Number(el.getAttribute("data-cell")),
        n: Number((el.textContent || "").trim()),
      }))
      .filter((c) => Number.isFinite(c.n) && c.n > 0)
  );
}

/** Poll until chips are visible (a fresh deal), or results appear (null). */
async function waitVisibleChips(page, timeout = 6000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await page.$('[data-testid="ct-results"]')) return null;
    const chips = await readVisibleChips(page);
    if (chips.length >= 3) return chips;
    await sleep(60);
  }
  return null;
}

/** DOM-level click on a cell: skips actionability waits, React still fires. */
async function tapCell(page, cell) {
  await page.$eval(`[data-cell="${cell}"]`, (el) => el.click());
}

/**
 * Solve one round from already-read chip positions:
 * tap chip 1 fast, then the rest with ~250ms gaps (human-paced, no bot flag).
 */
async function solveRound(page, chips) {
  const ordered = [...chips].sort((a, b) => a.n - b.n);
  await tapCell(page, ordered[0].cell);
  for (let i = 1; i < ordered.length; i++) {
    await sleep(250);
    await tapCell(page, ordered[i].cell);
  }
  return ordered.length;
}

/** Deliberately tap an EMPTY cell to burn a life as fast as possible. */
async function failRound(page, chips) {
  const used = new Set(chips.map((c) => c.cell));
  let empty = -1;
  for (let c = 0; c < 48; c++) {
    if (!used.has(c)) { empty = c; break; }
  }
  if (empty < 0) return false;
  await tapCell(page, empty);
  return true;
}

/** Poll the IQ CountUp until it settles (starts at 0). */
async function readIq(page) {
  let prev = -1;
  for (let i = 0; i < 40; i++) {
    const t = await page.$eval('[data-testid="ct-iq"]', (el) => el.textContent.trim()).catch(() => "0");
    const n = Number(t);
    if (Number.isFinite(n) && n > 0 && n === prev) return n; // stable across two reads
    prev = n;
    await sleep(150);
  }
  return 0;
}

/** Burn lives with immediate wrong taps until the results screen appears. */
async function failUntilResults(page, maxRounds = 8) {
  let burned = 0;
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline && burned < maxRounds) {
    if (await page.$('[data-testid="ct-results"]')) return burned;
    const chips = await waitVisibleChips(page, 4000);
    if (!chips) break;
    if (await failRound(page, chips)) burned++;
    await sleep(150);
  }
  return burned;
}

async function noHorizontalOverflow(page, label) {
  const overflow = await page.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  const resp = await gotoRetry(p, `${BASE}/test/chimp-test`);
  console.log("— SEO checks —");
  resp && resp.status() === 200 ? ok("route returns 200") : fail(`route status: ${resp ? resp.status() : "no response"}`);
  const title = await p.title();
  title === "Free Chimp Memory Test Online | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("chimp test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/chimp-test"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/chimp-test" &&
    breadcrumb.itemListElement[1].name === "Chimp Test"
    ? ok("BreadcrumbList: BrainMetrics > Chimp Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="ct-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok("FAQPage JSON-LD has 6 questions")
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok("visible FAQ has 6 items")
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Chimp") && h1.includes("Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);

  /* ---------------- Run 1: solve rounds (quick mode) ---------------- */
  console.log("— Run 1: solve rounds (?quick=1) —");
  await gotoRetry(p, `${BASE}/test/chimp-test?quick=1`);
  const intro = await p.$('[data-testid="ct-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  const startBtn = await p.$('[data-testid="ct-start"]');
  if (!startBtn) { fail("start button missing"); return finish(browser, errors); }
  await startBtn.click();

  await p.waitForSelector('[data-testid="ct-countdown"]', { timeout: 5000 });
  ok("countdown shows");
  await p.waitForSelector('[data-testid="ct-board"]', { timeout: 8000 });
  ok("board live (run phase)");
  const cellCount = await p.$$eval('[data-testid^="ct-cell-"]', (els) => els.length);
  cellCount === 48 ? ok("board has 48 cells") : fail(`cell count: ${cellCount}`);
  const levelText = await p.$eval('[data-testid="ct-level"]', (el) => el.textContent.trim());
  levelText.includes("3") ? ok(`level HUD: ${levelText}`) : fail(`level HUD: ${levelText}`);
  const livesHud = await p.$('[data-testid="ct-lives"]');
  livesHud ? ok("lives HUD present") : fail("lives HUD missing");
  const streakHud = await p.$('[data-testid="ct-streak"]');
  streakHud ? ok("streak HUD present") : fail("streak HUD missing");

  // Solve round by round: read positions while numbers are visible, tap in
  // order (chip 1 fast, others ~250ms apart). Stop once the board reaches
  // 6 chips (several levels cleared), then burn the remaining lives.
  const levelsCleared = [];
  let safety = 0;
  while (safety++ < 15) {
    if (await p.$('[data-testid="ct-results"]')) break;
    const chips = await waitVisibleChips(p, 4000);
    if (!chips) break;
    if (chips.length >= 6) break;
    const n = await solveRound(p, chips);
    levelsCleared.push(n);
    await sleep(120);
  }
  levelsCleared.length >= 3
    ? ok(`solved ${levelsCleared.length} rounds across levels [${levelsCleared.join(", ")}]`)
    : fail(`only solved ${levelsCleared.length} rounds: [${levelsCleared.join(", ")}]`);

  const burned = await failUntilResults(p);
  ok(`burned ${burned} lives with deliberate wrong taps`);
  await p.waitForSelector('[data-testid="ct-results"]', { timeout: 8000 });
  ok("results screen reached");

  const iq = await readIq(p);
  Number.isFinite(iq) && iq >= 55 && iq <= 145 ? ok(`IQ: ${iq} (finite, in range)`) : fail(`IQ: ${iq}`);
  const percentile = await p.$eval('[data-testid="ct-percentile"]', (el) => el.textContent.trim());
  percentile.includes("Better than") ? ok(`percentile line: ${percentile}`) : fail(`percentile: ${percentile}`);
  const grade = await p.$eval('[data-testid="ct-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const accuracyText = await p.$eval('[data-testid="ct-accuracy"] p', (el) => el.textContent.trim());
  const accuracyNum = Number(accuracyText.replace("%", ""));
  Number.isFinite(accuracyNum) && accuracyNum > 50
    ? ok(`accuracy: ${accuracyText} (solve-heavy run)`)
    : fail(`accuracy: ${accuracyText}`);
  const levelReached = Number(await p.$eval('[data-testid="ct-stat-level"] p', (el) => el.textContent.trim()));
  levelReached >= 4
    ? ok(`level reached: ${levelReached} (multi-level climb)`)
    : fail(`level reached: ${levelReached}`);
  const botFlag = await p.$('[data-testid="ct-botflag"]');
  !botFlag ? ok("no bot-like flag on human-paced taps (correct)") : fail("bot flag shown for 250ms-paced taps");
  const retake = await p.$('[data-testid="ct-retake"]');
  retake ? ok("retake button present") : fail("retake button missing");

  /* ---------------- Run 2: retake, fail every round fast ---------------- */
  console.log("— Run 2: retake -> wrong tap every round —");
  await retake.click();
  await p.waitForSelector('[data-testid="ct-countdown"]', { timeout: 6000 });
  ok("retake shows countdown (fresh run)");
  await p.waitForSelector('[data-testid="ct-board"]', { timeout: 8000 });
  const burned2 = await failUntilResults(p);
  burned2 >= 2 ? ok(`lives exhausted in ${burned2} wrong-tap rounds`) : fail(`burned only ${burned2} rounds`);
  await p.waitForSelector('[data-testid="ct-results"]', { timeout: 8000 });
  ok("results reached after all-lives-lost run");
  const accuracy2 = await p.$eval('[data-testid="ct-accuracy"] p', (el) => el.textContent.trim());
  accuracy2 === "0%" ? ok(`accuracy: ${accuracy2} (all taps wrong)`) : fail(`accuracy: ${accuracy2}`);
  const iq2 = await readIq(p);
  Number.isFinite(iq2) && iq2 >= 55 && iq2 <= 145
    ? ok(`run-2 IQ: ${iq2} (valid, non-NaN)`)
    : fail(`run-2 IQ: ${iq2}`);
  const percentile2 = await p.$eval('[data-testid="ct-percentile"]', (el) => el.textContent.trim());
  percentile2.includes("Better than") ? ok(`run-2 percentile line: ${percentile2}`) : fail(`run-2 percentile: ${percentile2}`);

  /* ---------------- Run 3: 375px mobile ---------------- */
  console.log("— Mobile 375px —");
  const mp = await ctx.newPage();
  mp.on("pageerror", (e) => errors.push("mp pageerror: " + e.message));
  mp.on("console", (m) => { if (m.type() === "error") errors.push("mp console: " + m.text()); });
  await mp.setViewportSize({ width: 375, height: 740 });
  await gotoRetry(mp, `${BASE}/test/chimp-test?quick=1`);
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="ct-start"]')).click();
  await mp.waitForSelector('[data-testid="ct-board"]', { timeout: 8000 });
  await noHorizontalOverflow(mp, "board");
  await failUntilResults(mp, 4);
  await mp.waitForSelector('[data-testid="ct-results"]', { timeout: 8000 });
  await noHorizontalOverflow(mp, "results");
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
