// Task 24 smoke sweep: verify all live test routes render + no console errors + 375px overflow
const { chromium } = require('playwright');

const ROUTES = [
  '/',
  '/test',
  '/test/full-iq',
  '/test/matrix-reasoning',
  '/test/digit-span',
  '/test/reaction-time',
  '/test/visual-memory',
  '/test/stroop-test',
  '/test/mental-rotation',
  '/test/chimp-test',
  '/test/n-back',
  '/test/processing-speed',
];

(async () => {
  const browser = await chromium.launch();
  let failures = 0;

  for (const route of ROUTES) {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    const page = await ctx.newPage();
    const consoleErrors = [];
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
    page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + e.message));

    let status = 'ERR';
    try {
      const resp = await page.goto('http://localhost:3000' + route, { waitUntil: 'domcontentloaded', timeout: 30000 });
      status = resp ? resp.status() : 'NO-RESP';
      await page.waitForTimeout(1200);
    } catch (e) {
      consoleErrors.push('GOTO-FAIL: ' + e.message);
    }

    const h1 = await page.locator('h1').first().textContent().catch(() => null);
    const jsonld = await page.locator('script[type="application/ld+json"]').count();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

    const ok = status === 200 && !!h1 && overflow <= 0;
    if (!ok) failures++;
    console.log(`${ok ? 'PASS' : 'FAIL'} ${route} status=${status} h1="${(h1 || '').slice(0, 50)}" jsonld=${jsonld} overflowPx=${overflow} consoleErrors=${consoleErrors.length}`);
    if (consoleErrors.length) console.log('   errors:', consoleErrors.slice(0, 3).join(' | ').slice(0, 300));

    // 375px check
    await page.setViewportSize({ width: 375, height: 720 });
    await page.waitForTimeout(500);
    const overflowM = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (overflowM > 0) { failures++; console.log(`   FAIL 375px overflow=${overflowM}px`); }
    else console.log(`   375px ok`);

    await ctx.close();
  }

  await browser.close();
  console.log(failures === 0 ? '\nSWEEP: ALL PASS' : `\nSWEEP: ${failures} FAILURES`);
  process.exit(failures === 0 ? 0 : 1);
})();
