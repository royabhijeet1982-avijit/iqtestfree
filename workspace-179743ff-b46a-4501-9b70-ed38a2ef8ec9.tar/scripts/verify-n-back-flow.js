/**
 * Task 24-b verification: N-Back test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-n-back-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Run 1 (?quick=1): full quick run answering true matches via SPACE,
 *    the "A" key and the on-screen MATCH button; block summary beat;
 *    results with sane IQ, grade, percentile, per-block hit/FA rates
 *  - Run 2: continuous SPACE mashing -> results still render but the
 *    balanced-score anti-gaming anchors the index LOW (< 90)
 *  - Run 3: 375px viewport, full quick run: no horizontal overflow on
 *    intro / active / results
 *  - zero console/page errors throughout
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll the IQ chip until CountUp finishes animating (starts at 0). */
async function readIq(p) {
  let prev = -1;
  for (let i = 0; i < 40; i++) {
    const t = await p.$eval('[data-testid="nb-iq"]', (el) => el.textContent.trim()).catch(() => "0");
    const n = Number(t);
    if (Number.isFinite(n) && n > 0 && n === prev) return n; // stable across two reads
    prev = n;
    await sleep(150);
  }
  return 0;
}

/**
 * Play one block by responding to TRUE matches (read from the stimulus
 * history exposed via data-letter / data-trial-index / data-n).
 * Mixes SPACE, the "A" key and the MATCH button. Returns when the block
 * summary or the results screen appears.
 */
async function playBlock(p, stats) {
  const letters = new Map(); // trialIndex -> letter
  let lastPressed = -1;
  const deadline = Date.now() + 70_000; // block = 12 trials x 2.8s
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="nb-block-summary"]')) return "summary";
    if (await p.$('[data-testid="nb-results"]')) return "results";
    const info = await p.$eval('[data-testid="nb-stimulus"]', (el) => ({
      letter: el.getAttribute("data-letter") || "",
      trial: Number(el.getAttribute("data-trial-index")),
      n: Number(el.getAttribute("data-n")),
    })).catch(() => null);
    if (info && info.letter && info.trial >= 0) {
      if (!letters.has(info.trial)) letters.set(info.trial, info.letter);
      if (info.trial > lastPressed && info.trial >= info.n) {
        const back = letters.get(info.trial - info.n);
        if (back === info.letter) {
          lastPressed = info.trial;
          try {
            if (stats.keyboard < 4) {
              await p.keyboard.press("Space");
              stats.keyboard++;
            } else if (stats.keyboard === 4) {
              await p.keyboard.press("a"); // the "A" key must register too
              stats.keyboard++;
            } else {
              const btn = await p.$('[data-testid="nb-match-btn"]');
              if (btn) {
                await btn.evaluate((el) => el.click());
                stats.button++;
              }
            }
          } catch {
            // phase unmounted mid-press - loop re-checks state
          }
        }
      }
    }
    await sleep(90);
  }
  return "timeout";
}

/** Mash SPACE continuously (clicking through block summaries) until results. */
async function mashRun(p) {
  const deadline = Date.now() + 150_000;
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="nb-results"]')) return;
    const next = await p.$('[data-testid="nb-next-block"]');
    if (next) {
      try { await next.evaluate((el) => el.click()); } catch { /* detached */ }
      await sleep(250);
      continue;
    }
    try { await p.keyboard.press("Space"); } catch { /* page busy */ }
    await sleep(110);
  }
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

async function readPercent(p, testid) {
  const t = await p.$eval(`[data-testid="${testid}"]`, (el) => el.textContent.trim()).catch(() => "");
  const n = Number(t.replace("%", ""));
  return Number.isFinite(n) ? n : null;
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test/n-back`, { waitUntil: "networkidle" });
  console.log("— SEO checks —");
  const title = await p.title();
  title === "Free N-Back Working Memory Test | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("N-Back")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/n-back"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/n-back"
    ? ok("BreadcrumbList: BrainMetrics > N-Back Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="nb-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok("FAQPage JSON-LD has 6 questions")
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok("visible FAQ has 6 items")
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("N-Back") && h1.includes("Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);

  /* ---------------- Run 1: real play (quick mode) ---------------- */
  console.log("— Run 1: answering true matches (?quick=1) —");
  await p.goto(`${BASE}/test/n-back?quick=1`, { waitUntil: "networkidle" });
  const intro = await p.$('[data-testid="nb-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  const startBtn = await p.$('[data-testid="nb-start"]');
  if (!startBtn) { fail("start button missing"); return finish(browser, errors); }
  await startBtn.click();

  await p.waitForSelector('[data-testid="nb-countdown"]', { timeout: 5000 });
  ok("countdown renders");
  await p.waitForSelector('[data-testid="nb-active"]', { timeout: 6000 });
  ok("block 1 started (active phase)");

  const nlabel1 = await p.$eval('[data-testid="nb-nlabel"]', (el) => el.textContent.trim());
  nlabel1 === "N = 1" ? ok(`block-1 N label: ${nlabel1}`) : fail(`nlabel: ${nlabel1}`);
  const dots = await p.$$eval('[data-testid="nb-trial-progress"] span', (els) => els.length);
  dots === 12 ? ok("12 trial-progress dots") : fail(`progress dots: ${dots}`);
  const btnBox = await p.$eval('[data-testid="nb-match-btn"]', (el) => {
    const r = el.getBoundingClientRect();
    return { h: r.height, w: r.width };
  });
  btnBox.h >= 44 && btnBox.w >= 44
    ? ok(`MATCH button touch target ${Math.round(btnBox.w)}x${Math.round(btnBox.h)}px (>=44)`)
    : fail(`MATCH button too small: ${Math.round(btnBox.w)}x${Math.round(btnBox.h)}`);

  const stats = { keyboard: 0, button: 0 };
  let end = await playBlock(p, stats);
  if (end !== "summary") fail(`block 1 did not reach summary (end=${end})`);
  else ok("block 1 complete -> block summary beat");
  await p.waitForSelector('[data-testid="nb-block-summary"]', { timeout: 10_000 }).catch(() => null);

  const nextBtn = await p.$('[data-testid="nb-next-block"]');
  if (!nextBtn) { fail("next-block button missing"); return finish(browser, errors); }
  await nextBtn.evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="nb-active"]', { timeout: 8000 });
  const nlabel2 = await p.$eval('[data-testid="nb-nlabel"]', (el) => el.textContent.trim());
  nlabel2 === "N = 2" ? ok(`block-2 N label: ${nlabel2}`) : fail(`nlabel: ${nlabel2}`);

  end = await playBlock(p, stats);
  if (end === "summary") {
    // Last block shows the summary beat first, then auto-advances.
    await p.waitForSelector('[data-testid="nb-results"]', { timeout: 15_000 });
    end = "results";
  }
  if (end !== "results") fail(`block 2 did not reach results (end=${end})`);
  ok(`played via SPACE/A x${stats.keyboard} + MATCH button x${stats.button}`);

  await p.waitForSelector('[data-testid="nb-results"]', { timeout: 30_000 });
  ok("results screen reached");
  const iq = await readIq(p);
  iq >= 55 && iq <= 145 ? ok(`IQ index: ${iq} (in range)`) : fail(`IQ: ${iq}`);
  const grade = await p.$eval('[data-testid="nb-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const percentile = await p.$eval('[data-testid="nb-percentile"]', (el) => el.textContent.trim());
  percentile.includes("Better than") && percentile.includes("in 100 adults")
    ? ok(`percentile line: ${percentile}`)
    : fail(`percentile: ${percentile}`);
  const hr1 = await readPercent(p, "nb-hitrate-1");
  hr1 !== null && hr1 >= 25
    ? ok(`block-1 hit rate: ${hr1}% (bot pressed real matches)`)
    : fail(`block-1 hit rate: ${hr1}`);
  const fa1 = await readPercent(p, "nb-farate-1");
  fa1 !== null && fa1 <= 50
    ? ok(`block-1 false-alarm rate: ${fa1}%`)
    : fail(`block-1 false-alarm rate: ${fa1}`);
  const hr2 = await readPercent(p, "nb-hitrate-2");
  hr2 !== null ? ok(`block-2 hit rate renders: ${hr2}%`) : fail("nb-hitrate-2 missing");
  const fa2 = await readPercent(p, "nb-farate-2");
  fa2 !== null ? ok(`block-2 false-alarm rate renders: ${fa2}%`) : fail("nb-farate-2 missing");
  const retake = await p.$('[data-testid="nb-retake"]');
  retake ? ok("retake button present") : fail("retake button missing");
  const fairness = await p.$eval('[data-testid="nb-fairness"]', (el) => el.textContent).catch(() => "");
  fairness.includes("mash") ? ok("anti-gaming note shown") : fail("fairness note missing");
  const spanText = await p.$eval('[data-testid="nb-span"]', (el) => el.textContent.trim()).catch(() => "");
  /^N = \d$/.test(spanText) ? ok(`effective span: ${spanText}`) : fail(`span: ${spanText}`);

  /* ---------------- Run 2: mash (anti-gaming) ---------------- */
  console.log("— Run 2: continuous SPACE mashing -> must score LOW —");
  await p.goto(`${BASE}/test/n-back?quick=1`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="nb-start"]')).click();
  await p.waitForSelector('[data-testid="nb-active"]', { timeout: 8000 });
  await mashRun(p);
  await p.waitForSelector('[data-testid="nb-results"]', { timeout: 30_000 });
  ok("mash run reached results (still scored, never stuck)");
  const mashIq = await readIq(p);
  mashIq >= 55 && mashIq <= 145
    ? ok(`mash IQ index: ${mashIq} (in range)`)
    : fail(`mash IQ: ${mashIq}`);
  mashIq < 90
    ? ok(`mash anchors LOW (${mashIq} < 90) - anti-gaming works`)
    : fail(`mash scored too high (${mashIq}) - anti-gaming FAILED`);
  const mashFair = await p.$eval('[data-testid="nb-fairness"]', (el) => el.textContent).catch(() => "");
  mashFair.includes("mash") ? ok("anti-gaming note shown on mash run") : fail("fairness note missing");

  /* ---------------- Run 3: mobile 375px full run ---------------- */
  console.log("— Run 3: 375px viewport (intro + active + results) —");
  const mp = await ctx.newPage();
  mp.on("pageerror", (e) => errors.push("mobile pageerror: " + e.message));
  mp.on("console", (m) => { if (m.type() === "error") errors.push("mobile console: " + m.text()); });
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/n-back?quick=1`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="nb-start"]')).click();
  await mp.waitForSelector('[data-testid="nb-active"]', { timeout: 8000 });
  await noHorizontalOverflow(mp, "active");
  await mashRun(mp);
  await mp.waitForSelector('[data-testid="nb-results"]', { timeout: 30_000 });
  const mIq = await readIq(mp);
  mIq >= 55 && mIq <= 145 ? ok(`mobile run IQ: ${mIq}`) : fail(`mobile IQ: ${mIq}`);
  await noHorizontalOverflow(mp, "results");
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
