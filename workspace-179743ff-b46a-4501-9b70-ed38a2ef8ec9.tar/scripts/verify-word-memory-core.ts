/* ------------------------------------------------------------------ */
/*  Unit verification for word-memory-core.ts                          */
/*  Run: bun scripts/verify-word-memory-core.ts                        */
/* ------------------------------------------------------------------ */

import {
  ACC_MEAN,
  ACC_SD,
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  INTERLUDE_STEP_MS,
  INTERLUDE_STEP_MS_QUICK,
  IQ_MAX,
  IQ_MIN,
  RESPONSE_GAP_MS,
  RESPONSE_GAP_MS_QUICK,
  ROUND_LIST_LENS,
  STUDY_GAP_MS,
  STUDY_GAP_MS_QUICK,
  STUDY_ON_MS,
  STUDY_ON_MS_QUICK,
  TOTAL_TARGETS,
  WORD_POOL,
  buildWordMemorySession,
  dPrime,
  erf,
  gradeForIq,
  iqToPercentile,
  memoryIndex,
  mulberry32,
  normalCdf,
  probit,
  scoreSession,
  shuffled,
  type Judgement,
} from "../src/components/test/word-memory-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

function near(a: number, b: number, tol: number): boolean {
  return Math.abs(a - b) <= tol;
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("ROUND_LIST_LENS is [8, 12, 16]", JSON.stringify(ROUND_LIST_LENS) === "[8,12,16]");
check("TOTAL_TARGETS is 36", TOTAL_TARGETS === 36, String(TOTAL_TARGETS));
check("STUDY_ON_MS is 1250", STUDY_ON_MS === 1250, String(STUDY_ON_MS));
check("STUDY_GAP_MS is 350", STUDY_GAP_MS === 350, String(STUDY_GAP_MS));
check("INTERLUDE_STEP_MS is 750", INTERLUDE_STEP_MS === 750);
check("FEEDBACK_MS is 260", FEEDBACK_MS === 260);
check("RESPONSE_GAP_MS is 120", RESPONSE_GAP_MS === 120);
check(
  "quick timings all shorter than normal",
  STUDY_ON_MS_QUICK < STUDY_ON_MS &&
    STUDY_GAP_MS_QUICK < STUDY_GAP_MS &&
    INTERLUDE_STEP_MS_QUICK < INTERLUDE_STEP_MS &&
    FEEDBACK_MS_QUICK < FEEDBACK_MS &&
    RESPONSE_GAP_MS_QUICK < RESPONSE_GAP_MS
);
check(
  "population anchor 0.76 / 0.08",
  ACC_MEAN === 0.76 && ACC_SD === 0.08,
  `mean=${ACC_MEAN} sd=${ACC_SD}`
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("Word pool integrity");
{
  check("pool size >= 180", WORD_POOL.length >= 180, String(WORD_POOL.length));
  const allLowerAlpha = WORD_POOL.every((w) => /^[a-z]{3,10}$/.test(w));
  check("all words lowercase a-z, length 3..10", allLowerAlpha);
  const unique = new Set(WORD_POOL).size === WORD_POOL.length;
  check("no duplicate words", unique);
  let prefixCollision: string | null = null;
  for (const a of WORD_POOL) {
    for (const b of WORD_POOL) {
      if (a !== b && b.startsWith(a)) {
        prefixCollision = `${a} -> ${b}`;
        break;
      }
    }
    if (prefixCollision) break;
  }
  check("no word is a prefix of another (stem safety)", prefixCollision === null, prefixCollision ?? "");
  let pluralCollision: string | null = null;
  const set = new Set(WORD_POOL);
  for (const w of WORD_POOL) {
    if (set.has(`${w}s`) || set.has(`${w}es`)) {
      pluralCollision = w;
      break;
    }
  }
  check("no plural/singular pairs", pluralCollision === null, pluralCollision ?? "");
  check(
    "expected words present",
    set.has("apple") && set.has("lantern") && set.has("zebra") && set.has("teapot")
  );
  check(
    "known exclusions honored",
    !set.has("tea") && !set.has("wren") && !set.has("map") && !set.has("pen")
  );
}

section("shuffled() invariants");
{
  const base = Array.from({ length: 50 }, (_, i) => i);
  const rngA = mulberry32(7);
  const a = shuffled(base, rngA);
  const rngB = mulberry32(7);
  const b = shuffled(base, rngB);
  check("deterministic per seed", JSON.stringify(a) === JSON.stringify(b));
  check("is a permutation", JSON.stringify([...a].sort((x, y) => x - y)) === JSON.stringify(base));
  check("does not mutate input", base[0] === 0 && base[49] === 49);
  const identity = shuffled([1, 2, 3], mulberry32(1));
  check("returns same-length array", identity.length === 3);
}

section("buildWordMemorySession invariants (400 seeds)");
{
  let lensOk = true;
  let globalUnique = true;
  let streamShapeOk = true;
  let permutationOk = true;
  let deterministicOk = true;
  let freshAcrossSeeds = true;

  const firstStudySeen = new Set<string>();

  for (let seed = 0; seed < 400; seed++) {
    const session = buildWordMemorySession(seed);

    // lengths
    if (
      session.rounds.length !== 3 ||
      session.rounds[0]!.listLen !== 8 ||
      session.rounds[1]!.listLen !== 12 ||
      session.rounds[2]!.listLen !== 16
    ) {
      lensOk = false;
    }

    // every word in the whole session is unique; streams are balanced
    const seen = new Set<string>();
    for (const r of session.rounds) {
      if (r.testWords.length !== r.listLen * 2) streamShapeOk = false;
      const targets = r.testWords.filter((t) => t.isTarget);
      const foils = r.testWords.filter((t) => !t.isTarget);
      if (targets.length !== r.listLen || foils.length !== r.listLen) streamShapeOk = false;
      if (targets.some((t) => t.round !== r.round)) streamShapeOk = false;
      for (const item of r.testWords) {
        if (seen.has(item.word)) globalUnique = false;
        seen.add(item.word);
      }
    }
    if (seen.size !== 72) globalUnique = false;

    // stream is a permutation of study + foils: every study word appears
    for (const r of session.rounds) {
      const streamWords = new Set(r.testWords.map((t) => t.word));
      for (const w of r.studyWords) {
        if (!streamWords.has(w)) permutationOk = false;
      }
      const targetWords = r.testWords.filter((t) => t.isTarget).map((t) => t.word).sort();
      if (JSON.stringify(targetWords) !== JSON.stringify([...r.studyWords].sort())) {
        permutationOk = false;
      }
    }

    // determinism
    const again = buildWordMemorySession(seed);
    if (JSON.stringify(again) !== JSON.stringify(session)) deterministicOk = false;

    firstStudySeen.add(session.rounds[0]!.studyWords[0]!);
  }

  check("round lengths 8/12/16 across 400 seeds", lensOk);
  check("all 72 words unique within every session (targets + foils)", globalUnique);
  check("streams balanced: listLen targets + listLen foils, all round-tagged", streamShapeOk);
  check("test stream is a permutation of study list + foils", permutationOk);
  check("session fully deterministic per seed", deterministicOk);
  check("seed 0 study list differs from seed 1", buildWordMemorySession(0).rounds[0]!.studyWords.join(",") !== buildWordMemorySession(1).rounds[0]!.studyWords.join(","));
  check("first study words spread across seeds (retake freshness possible)", firstStudySeen.size > 50, `distinct=${firstStudySeen.size}`);
  void freshAcrossSeeds;
}

section("probit (inverse normal CDF)");
{
  check("probit(0.5) = 0", near(probit(0.5), 0, 1e-9), String(probit(0.5)));
  check("probit(0.975) ~ 1.95996", near(probit(0.975), 1.959964, 1e-4), String(probit(0.975)));
  check("probit(0.8413447) ~ 1", near(probit(0.8413447460685429), 1, 1e-4), String(probit(0.8413447460685429)));
  check("probit(0.9772499) ~ 2", near(probit(0.9772498680518208), 2, 1e-4), String(probit(0.9772498680518208)));
  check("probit(0.9986501) ~ 3", near(probit(0.9986501019683699), 3, 1e-4), String(probit(0.9986501019683699)));
  check("probit(-1) = -Infinity (outside domain)", probit(-1) === -Infinity, String(probit(-1)));
  check("probit(2) = +Infinity (outside domain)", probit(2) === Infinity, String(probit(2)));
  check("probit(NaN) is NaN", Number.isNaN(probit(NaN)));
  let symmetric = true;
  for (let i = 1; i < 50; i++) {
    const p = i / 100;
    if (!near(probit(p), -probit(1 - p), 1e-8)) {
      symmetric = false;
      break;
    }
  }
  check("symmetry probit(p) = -probit(1-p)", symmetric);
  let monotonic = true;
  let prev = -Infinity;
  for (let i = 1; i < 100; i++) {
    const v = probit(i / 100);
    if (v <= prev) {
      monotonic = false;
      break;
    }
    prev = v;
  }
  check("strictly increasing", monotonic);
}

section("erf / normalCdf");
{
  check("erf(0) = 0", near(erf(0), 0, 1e-9));
  check("erf(1) ~ 0.8427", near(erf(1), 0.8427008, 1e-3), String(erf(1)));
  check("erf symmetric", near(erf(0.7), -erf(-0.7), 1e-9));
  check("normalCdf at mean = 0.5", near(normalCdf(100, 100, 15), 0.5, 1e-9));
  check("normalCdf(121,100,15) ~ 0.9192", near(normalCdf(121, 100, 15), 0.91924, 1e-3), String(normalCdf(121, 100, 15)));
  check("normalCdf(55,100,15) ~ 0.00135", near(normalCdf(55, 100, 15), 0.00135, 1e-4), String(normalCdf(55, 100, 15)));
}

section("dPrime (log-linear signal detection)");
{
  const perfect = dPrime(36, 36, 0, 36);
  check("perfect balanced ~ 4.41", near(perfect, 4.4146, 0.01), String(perfect));
  check("mash NEW (0 hits, 0 fa) = 0", near(dPrime(0, 36, 0, 36), 0, 1e-9), String(dPrime(0, 36, 0, 36)));
  check("mash OLD (all hits, all fa) = 0", near(dPrime(36, 36, 36, 36), 0, 1e-9), String(dPrime(36, 36, 36, 36)));
  const half = dPrime(18, 36, 0, 36);
  check("half hits / no fa ~ 2.21", near(half, 2.2073, 0.01), String(half));
  // sensitivity increases with hits (fa fixed)
  check(
    "increases with hits (fa fixed)",
    dPrime(20, 36, 4, 36) < dPrime(28, 36, 4, 36) && dPrime(28, 36, 4, 36) < dPrime(34, 36, 4, 36)
  );
  // sensitivity decreases with false alarms (hits fixed)
  check(
    "decreases with false alarms (hits fixed)",
    dPrime(30, 36, 2, 36) > dPrime(30, 36, 10, 36) && dPrime(30, 36, 10, 36) > dPrime(30, 36, 20, 36)
  );
  check("empty session (0,0,0,0) = 0", near(dPrime(0, 0, 0, 0), 0, 1e-9));
}

section("memoryIndex (accuracy -> IQ scale)");
{
  check("acc 0.76 (population mean) -> 100", memoryIndex(0.76) === 100, String(memoryIndex(0.76)));
  check("acc 1.0 -> 145 (ceiling)", memoryIndex(1.0) === 145, String(memoryIndex(1.0)));
  check("acc 0.5 (mash) -> 55 (floor)", memoryIndex(0.5) === 55, String(memoryIndex(0.5)));
  check("acc 0.6 -> 70", memoryIndex(0.6) === 70, String(memoryIndex(0.6)));
  check("acc 0.84 -> 115", memoryIndex(0.84) === 115, String(memoryIndex(0.84)));
  let monotonic = true;
  for (let acc = 0.5; acc < 1; acc += 0.01) {
    if (memoryIndex(acc) > memoryIndex(acc + 0.01)) {
      monotonic = false;
      break;
    }
  }
  check("monotonic over 0.5..1.0 grid", monotonic);
  let clamped = true;
  for (let acc = 0; acc <= 1.001; acc += 0.05) {
    const iq = memoryIndex(acc);
    if (iq < 55 || iq > 145) {
      clamped = false;
      break;
    }
  }
  check("always within 55..145", clamped);
}

section("iqToPercentile");
{
  check("iq 100 -> 50", iqToPercentile(100) === 50, String(iqToPercentile(100)));
  check("iq 55 -> 1 (floor)", iqToPercentile(55) === 1, String(iqToPercentile(55)));
  check("iq 145 -> 99 (ceiling)", iqToPercentile(145) === 99, String(iqToPercentile(145)));
  check("iq 121 -> 92", iqToPercentile(121) === 92, String(iqToPercentile(121)));
  check("iq 85 -> 16", iqToPercentile(85) === 16, String(iqToPercentile(85)));
}

section("gradeForIq tiers");
{
  check("84 -> Building", gradeForIq(84).label === "Building");
  check("85 -> Average", gradeForIq(85).label === "Average");
  check("99 -> Average", gradeForIq(99).label === "Average");
  check("100 -> Sharp", gradeForIq(100).label === "Sharp");
  check("114 -> Sharp", gradeForIq(114).label === "Sharp");
  check("115 -> Very sharp", gradeForIq(115).label === "Very sharp");
  check("129 -> Very sharp", gradeForIq(129).label === "Very sharp");
  check("130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check("145 -> Exceptional", gradeForIq(145).label === "Exceptional");
  check("55 -> Building", gradeForIq(55).label === "Building");
  check("all grades carry a blurb", gradeForIq(55).blurb.length > 20 && gradeForIq(145).blurb.length > 20);
}

/* ---------------------------------------------------------------- */
/*  scoreSession helpers                                             */
/* ---------------------------------------------------------------- */

function judgementsFromSession(
  seed: number,
  mode: "perfect" | "mash-new" | "mash-old" | "half-forget",
  rtBase = 800
): Judgement[] {
  const session = buildWordMemorySession(seed);
  const out: Judgement[] = [];
  let targetSeen = 0;
  for (const r of session.rounds) {
    r.testWords.forEach((item, i) => {
      void i;
      let saidOld: boolean;
      if (mode === "perfect") saidOld = item.isTarget;
      else if (mode === "mash-new") saidOld = false;
      else if (mode === "mash-old") saidOld = true;
      else if (item.isTarget) saidOld = targetSeen++ % 2 === 0; // half-forget: every other target claimed
      else saidOld = false;
      out.push({
        word: item.word,
        isTarget: item.isTarget,
        round: r.round,
        saidOld,
        rtMs: rtBase + ((i * 37) % 400),
      });
    });
  }
  return out;
}

section("scoreSession - perfect run");
{
  const js = judgementsFromSession(2024, "perfect");
  const s = scoreSession(js);
  check("hits = 36", s.hits === 36, String(s.hits));
  check("misses = 0", s.misses === 0);
  check("falseAlarms = 0", s.falseAlarms === 0);
  check("correctRejections = 36", s.correctRejections === 36, String(s.correctRejections));
  check("targets = 36 / foils = 36", s.targets === 36 && s.foils === 36);
  check("accuracy = 1.0", s.accuracy === 1, String(s.accuracy));
  check("d' > 4.3", s.dPrime > 4.3, String(s.dPrime));
  check("iq = 145", s.iq === 145, String(s.iq));
  check("percentile = 99", s.percentile === 99);
  check("grade Exceptional", s.grade.label === "Exceptional");
  check("3 round stats", s.rounds.length === 3);
  check("all round accuracies 1.0", s.rounds.every((r) => r.accuracy === 1));
  const rtMean = js.reduce((a, j) => a + (j.rtMs ?? 0), 0) / js.length;
  check("avgRtMs matches input mean", near(s.avgRtMs ?? 0, rtMean, 1e-9), `${s.avgRtMs} vs ${rtMean}`);
}

section("scoreSession - mash NEW (anti-gaming floor)");
{
  const s = scoreSession(judgementsFromSession(2024, "mash-new"));
  check("hits = 0", s.hits === 0);
  check("correctRejections = 36", s.correctRejections === 36);
  check("accuracy = 0.5", near(s.accuracy, 0.5, 1e-12), String(s.accuracy));
  check("d' = 0 (pure bias, no sensitivity)", near(s.dPrime, 0, 1e-9), String(s.dPrime));
  check("iq = 55 floor", s.iq === 55, String(s.iq));
  check("percentile = 1", s.percentile === 1);
  check("grade Building", s.grade.label === "Building");
}

section("scoreSession - mash OLD (symmetric floor)");
{
  const s = scoreSession(judgementsFromSession(2024, "mash-old"));
  check("hits = 36 but falseAlarms = 36", s.hits === 36 && s.falseAlarms === 36);
  check("accuracy = 0.5", near(s.accuracy, 0.5, 1e-12));
  check("d' = 0", near(s.dPrime, 0, 1e-9));
  check("iq = 55 floor", s.iq === 55);
  check("percentile = 1", s.percentile === 1);
}

section("scoreSession - half-forget (98 expected)");
{
  // Claim the first half of stream positions for targets (as generated),
  // reject everything else: hits = 18, fa = 0, cr = 36, misses = 18
  // -> accuracy = (18 + 36) / 72 = 0.75 -> iq = round(100 + 15*(0.75-0.76)/0.08) = 98
  const s = scoreSession(judgementsFromSession(77, "half-forget"));
  check("hits = 18", s.hits === 18, String(s.hits));
  check("misses = 18", s.misses === 18, String(s.misses));
  check("falseAlarms = 0", s.falseAlarms === 0);
  check("accuracy = 0.75", near(s.accuracy, 0.75, 1e-12), String(s.accuracy));
  check("iq = 98", s.iq === 98, String(s.iq));
  check("grade Average", s.grade.label === "Average", s.grade.label);
}

section("scoreSession - handcrafted mixed case");
{
  const js: Judgement[] = [
    { word: "a", isTarget: true, round: 0, saidOld: true, rtMs: 900 },
    { word: "b", isTarget: true, round: 0, saidOld: false, rtMs: 1100 },
    { word: "c", isTarget: false, round: 0, saidOld: false, rtMs: 700 },
    { word: "d", isTarget: false, round: 0, saidOld: false, rtMs: 500 },
    { word: "e", isTarget: true, round: 1, saidOld: true, rtMs: 1000 },
    { word: "f", isTarget: false, round: 1, saidOld: true, rtMs: 600 },
  ];
  const s = scoreSession(js);
  check("hits = 2 / misses = 1 / fa = 1 / cr = 2", s.hits === 2 && s.misses === 1 && s.falseAlarms === 1 && s.correctRejections === 2);
  check("accuracy = 4/6", near(s.accuracy, 4 / 6, 1e-12), String(s.accuracy));
  check("2 round stats", s.rounds.length === 2);
  check("round 0 accuracy = 3/4", near(s.rounds[0]!.accuracy, 0.75, 1e-12), String(s.rounds[0]!.accuracy));
  check("round 1 accuracy = 1/2", near(s.rounds[1]!.accuracy, 0.5, 1e-12), String(s.rounds[1]!.accuracy));
  check("avgRt = 800", near(s.avgRtMs ?? 0, 800, 1e-9), String(s.avgRtMs));
  check("iq within bounds", s.iq >= 55 && s.iq <= 145, String(s.iq));
}

section("scoreSession - empty input");
{
  const s = scoreSession([]);
  check("accuracy = 0", s.accuracy === 0);
  check("avgRtMs = null", s.avgRtMs === null);
  check("iq floored at 55", s.iq === 55);
  check("no round stats", s.rounds.length === 0);
}

section("scoreSession - null rt tolerated");
{
  const js: Judgement[] = [
    { word: "a", isTarget: true, round: 0, saidOld: true, rtMs: null },
    { word: "b", isTarget: false, round: 0, saidOld: false, rtMs: null },
  ];
  const s = scoreSession(js);
  check("avgRtMs = null when all rt null", s.avgRtMs === null);
  check("accuracy = 1.0", s.accuracy === 1);
}

section("1000-user simulation invariants");
{
  let ok = true;
  let detail = "";
  for (let seed = 0; seed < 1000; seed++) {
    const rng = mulberry32(seed * 7919 + 13);
    const hitProb = 0.55 + rng() * 0.44; // 0.55..0.99
    const faProb = 0.02 + rng() * 0.43; // 0.02..0.45
    const session = buildWordMemorySession(seed);
    const js: Judgement[] = [];
    for (const r of session.rounds) {
      for (const item of r.testWords) {
        const saidOld = item.isTarget ? rng() < hitProb : rng() < faProb;
        js.push({
          word: item.word,
          isTarget: item.isTarget,
          round: r.round,
          saidOld,
          rtMs: 400 + rng() * 2100,
        });
      }
    }
    const s = scoreSession(js);
    if (!(s.accuracy >= 0.3 && s.accuracy <= 1)) { ok = false; detail = `acc ${s.accuracy} seed ${seed}`; break; }
    if (s.iq < 55 || s.iq > 145) { ok = false; detail = `iq ${s.iq} seed ${seed}`; break; }
    if (s.percentile < 1 || s.percentile > 99) { ok = false; detail = `pct ${s.percentile} seed ${seed}`; break; }
    if (s.rounds.length !== 3) { ok = false; detail = `rounds ${s.rounds.length} seed ${seed}`; break; }
    if (s.avgRtMs === null || s.avgRtMs! < 400 || s.avgRtMs! > 2500) { ok = false; detail = `rt ${s.avgRtMs} seed ${seed}`; break; }
    const accSum = s.rounds.reduce((a, r) => a + r.accuracy, 0);
    if (Math.abs(accSum / 3 - s.accuracy) > 0.34) { ok = false; detail = `round agg drift seed ${seed}`; break; }
  }
  check("1000 simulated users: all invariants hold", ok, detail);
}

section("Population sanity - sensitivity drives score");
{
  // Strong memory + honest criterion should systematically beat weak memory.
  const play = (hitProb: number, faProb: number, n: number, seedBase: number) => {
    let accSum = 0;
    for (let seed = seedBase; seed < seedBase + n; seed++) {
      const rng = mulberry32(seed * 104729 + 5);
      const session = buildWordMemorySession(seed);
      const js: Judgement[] = [];
      for (const r of session.rounds) {
        for (const item of r.testWords) {
          js.push({
            word: item.word,
            isTarget: item.isTarget,
            round: r.round,
            saidOld: item.isTarget ? rng() < hitProb : rng() < faProb,
            rtMs: 900,
          });
        }
      }
      accSum += scoreSession(js).accuracy;
    }
    return accSum / n;
  };
  const strong = play(0.95, 0.05, 150, 9000);
  const weak = play(0.6, 0.4, 150, 9000);
  check(
    "strong memory (0.95/0.05) beats weak memory (0.6/0.4) by >0.25 acc",
    strong - weak > 0.25,
    `strong=${strong.toFixed(3)} weak=${weak.toFixed(3)}`
  );
}

section("Pipeline coherence");
{
  // Real session -> perfect play -> exact ceiling, across 50 seeds.
  let allPerfect = true;
  for (let seed = 0; seed < 50; seed++) {
    const s = scoreSession(judgementsFromSession(seed, "perfect"));
    if (s.accuracy !== 1 || s.iq !== 145 || s.percentile !== 99) {
      allPerfect = false;
      break;
    }
  }
  check("50 seeds: perfect play always -> acc 1 / iq 145 / pct 99", allPerfect);

  // Real session -> full mash -> exact floor, across 50 seeds.
  let allFloor = true;
  for (let seed = 0; seed < 50; seed++) {
    const s = scoreSession(judgementsFromSession(seed, "mash-new"));
    if (s.accuracy !== 0.5 || s.iq !== 55 || s.percentile !== 1) {
      allFloor = false;
      break;
    }
  }
  check("50 seeds: mash always -> acc 0.5 / iq 55 / pct 1", allFloor);
}

/* ---------------------------------------------------------------- */

console.log(`\n==== word-memory-core: ${pass} PASS / ${fail} FAIL ====`);
if (fail > 0) process.exit(1);
