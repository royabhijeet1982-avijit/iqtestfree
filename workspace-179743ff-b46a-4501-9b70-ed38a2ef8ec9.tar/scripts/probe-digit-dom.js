/* Debug probe for digit-span forward phase: what does the DOM do? */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");
const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();
  const p = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  p.on("pageerror", (e) => console.log("PAGEERROR:", String(e).slice(0, 120)));
  await p.goto(`${BASE}/test/digit-span?quick=1`, { waitUntil: "networkidle" });
  await p.click('[data-testid="ds-intro-cta"]');
  await p.waitForSelector('[data-testid="ds-phase-forward"]', { timeout: 10000 });

  for (let step = 0; step < 40; step++) {
    const state = await p.evaluate(() => {
      const q = (t) => document.querySelector(`[data-testid="${t}"]`);
      return {
        stage: q("ds-digit-stage") ? q("ds-digit-stage").getAttribute("data-stage") : null,
        stageExists: !!q("ds-digit-stage"),
        input: !!q("ds-input"),
        digit: q("ds-digit") ? q("ds-digit").textContent.trim() : null,
        pos: q("ds-digit") ? q("ds-digit").getAttribute("data-pos") : null,
        total: q("ds-digit-stage") ? q("ds-digit-stage").getAttribute("data-total") : null,
        chips: document.querySelectorAll('[data-testid="ds-chip"]').length,
        feedback: !!q("ds-attempt-feedback"),
        interphase: !!q("ds-interphase"),
        submitDisabled: q("ds-submit") ? q("ds-submit").disabled : null,
      };
    }).catch((e) => ({ err: String(e).slice(0, 80) }));
    console.log(step, JSON.stringify(state));
    if (state.interphase || state.err) break;
    await sleep(400);
  }
  await browser.close();
})();
