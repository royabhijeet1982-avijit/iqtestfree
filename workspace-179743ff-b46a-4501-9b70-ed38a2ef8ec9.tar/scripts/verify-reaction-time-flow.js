/**
 * Reaction Time test - flow + SEO verification (Playwright, chromium).
 * Run: node /home/z/my-project/scripts/verify-reaction-time-flow.js
 *
 * Covers (all runs use ?quick=1 -> 3 simple + 6 choice trials):
 *  - SEO surface: title, description, canonical, JSON-LD x3, h1, FAQ parity
 *  - Golden path: poll the stage/pads at ~30fps, respond to every cue with a
 *    human-like delay, complete BOTH phases, assert medians + IQ + percentile
 *  - Retake: second full run; collected go-cue timestamps differ between runs
 *    and inter-cue intervals within a run are not all identical
 *  - Anti-gaming: blind rapid clicking WITHOUT waiting for cues accumulates
 *    anticipations -> run flagged low validity with the honest "not scored" card
 *  - 375px viewport: zero horizontal overflow on intro / simple / choice / results
 *  - zero console/page errors across every page
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll a text node until it is stable across two reads (CountUp settles). */
async function readStable(p, selector, tries = 40) {
  let prev = null;
  for (let i = 0; i < tries; i++) {
    const t = await p.$eval(selector, (el) => el.textContent.trim()).catch(() => null);
    if (t !== null && t.length > 0 && t === prev) return t;
    prev = t;
    await sleep(150);
  }
  return prev ?? "";
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

/**
 * Golden path: wait for cues via data-testid/data-state polling (30fps),
 * then respond with a human-like 190-300ms delay so reaction times land in
 * the valid 150-1500ms window. Pushes each go-cue detection timestamp.
 */
async function runGolden(p, gos, label) {
  // ---- Round 1: simple RT ----
  await p.waitForSelector('[data-testid="rt-phase-simple"]', { timeout: 20000 });
  ok(`[${label}] round 1 (simple RT) started`);
  let guard = Date.now();
  while (Date.now() - guard < 90000) {
    if (await p.$('[data-testid="rt-phase-choice"]')) break;
    if (await p.$('[data-testid="rt-results"]')) break;
    const stage = await p.$('[data-testid="rt-stage"]');
    if (stage) {
      const state = await stage.getAttribute("data-state");
      if (state === "go") {
        gos.push(Date.now());
        await sleep(190 + Math.floor(Math.random() * 110)); // human-like latency
        await stage.evaluate((el) => el.click());
        await sleep(400); // let feedback + next trial arm
        continue;
      }
    }
    await sleep(33); // ~30fps polling
  }
  if (!(await p.$('[data-testid="rt-phase-choice"]'))) {
    fail(`[${label}] choice round never started`);
    return;
  }
  ok(`[${label}] round 2 (choice RT) started`);

  // ---- Round 2: choice RT ----
  guard = Date.now();
  while (Date.now() - guard < 90000) {
    if (await p.$('[data-testid="rt-results"]')) break;
    const lit = await p.$('[data-testid^="rt-pad-"][data-state="lit"]');
    if (lit) {
      gos.push(Date.now());
      await sleep(190 + Math.floor(Math.random() * 110));
      await lit.evaluate((el) => el.click());
      await sleep(450);
      continue;
    }
    await sleep(33);
  }
  await p.waitForSelector('[data-testid="rt-results"]', { timeout: 10000 });
  ok(`[${label}] results reached after ${gos.length} cues responded to`);
}

/** Assert a valid results screen: medians, IQ, percentile, accuracy. */
async function assertValidResults(p, label) {
  await p.waitForSelector('[data-testid="rt-results"]', { timeout: 10000 });
  const invalidCard = await p.$('[data-testid="rt-invalid"]');
  !invalidCard ? ok(`[${label}] valid path (no low-validity card)`) : fail(`[${label}] low-validity card on a clean run`);

  const indexText = await readStable(p, '[data-testid="rt-index"]');
  const index = Number(indexText);
  index >= 55 && index <= 145 ? ok(`[${label}] RT Index: ${index} (in range)`) : fail(`[${label}] RT Index: ${indexText}`);

  const pctText = await p.$eval('[data-testid="rt-percentile"]', (el) => el.textContent.trim());
  const pctMatch = pctText.match(/Faster than (\d+)% of adults/);
  pctMatch && Number(pctMatch[1]) >= 1 && Number(pctMatch[1]) <= 99
    ? ok(`[${label}] percentile line: ${pctText}`)
    : fail(`[${label}] percentile line: ${pctText}`);

  const simpleText = await readStable(p, '[data-testid="rt-stat-simple"]');
  const simpleMs = Number(simpleText.replace(/[^\d]/g, ""));
  simpleMs >= 150 && simpleMs <= 800 ? ok(`[${label}] median simple RT: ${simpleMs}ms`) : fail(`[${label}] median simple RT: ${simpleText}`);

  const choiceText = await readStable(p, '[data-testid="rt-stat-choice"]');
  const choiceMs = Number(choiceText.replace(/[^\d]/g, ""));
  choiceMs >= 150 && choiceMs <= 800 ? ok(`[${label}] median choice RT: ${choiceMs}ms`) : fail(`[${label}] median choice RT: ${choiceText}`);

  const varText = await readStable(p, '[data-testid="rt-stat-variability"]');
  const varMs = Number(varText.replace(/[^\d]/g, ""));
  Number.isFinite(varMs) && varMs >= 0 ? ok(`[${label}] variability: ${varMs}ms`) : fail(`[${label}] variability: ${varText}`);

  const accText = await readStable(p, '[data-testid="rt-stat-accuracy"] p');
  accText === "100%" ? ok(`[${label}] choice accuracy 100% (perfect run)`) : fail(`[${label}] accuracy: ${accText}`);

  const grade = await p.$eval('[data-testid="rt-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`[${label}] grade chip: ${grade}`) : fail(`[${label}] grade missing`);

  const validityLine = await p.$eval('[data-testid="rt-validity-line"]', (el) => el.textContent.replace(/\s+/g, " ").trim());
  validityLine.includes("9 of 9 trials valid")
    ? ok(`[${label}] validity line: ${validityLine}`)
    : fail(`[${label}] validity line: ${validityLine}`);

  const dist = await p.$('[data-testid="rt-distribution"] svg');
  dist ? ok(`[${label}] population distribution strip renders`) : fail(`[${label}] distribution strip missing`);
}

/** Mash: click blindly in a fixed rapid loop, never waiting for cues. */
async function mashRun(p) {
  const deadline = Date.now() + 90000;
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="rt-results"]')) return true;
    const stage = await p.$('[data-testid="rt-stage"]');
    if (stage) { await stage.evaluate((el) => el.click()); await sleep(40); continue; }
    const pads = await p.$$('[data-testid^="rt-pad-"]');
    if (pads.length > 0) { await pads[0].evaluate((el) => el.click()); await sleep(40); continue; }
    await sleep(50);
  }
  return false;
}

/** Intervals between consecutive go timestamps. */
function intervals(gos) {
  const out = [];
  for (let i = 1; i < gos.length; i++) out.push(gos[i] - gos[i - 1]);
  return out;
}

async function attachErrorCollector(page, errors) {
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  await attachErrorCollector(p, errors);

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test/reaction-time`, { waitUntil: "networkidle" });
  console.log("— SEO checks —");
  const title = await p.title();
  title === "Free Reaction Time Test Online | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.toLowerCase().includes("reaction time test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/reaction-time"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/reaction-time"
    ? ok("BreadcrumbList: BrainMetrics > Reaction Time Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="rt-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok("FAQPage JSON-LD has 6 questions")
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok("visible FAQ has 6 items")
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Reaction") && h1.includes("Time Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const related = await p.$eval("a[href='/test/processing-speed']", (el) => el.textContent.trim()).catch(() => null);
  related ? ok("RelatedTests band links to the live Processing Speed test") : fail("RelatedTests band missing");
  await noHorizontalOverflow(p, "desktop intro");

  /* ---------------- Run 1: golden path (?quick=1) ---------------- */
  console.log("— Run 1: golden path (?quick=1) —");
  await p.goto(`${BASE}/test/reaction-time?quick=1`, { waitUntil: "networkidle" });
  const intro = await p.$('[data-testid="rt-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  await noHorizontalOverflow(p, "intro");
  const startBtn = await p.$('[data-testid="rt-intro-cta"]');
  if (!startBtn) { fail("intro CTA missing"); return finish(browser, errors); }
  await startBtn.click();
  await p.waitForSelector('[data-testid="rt-countdown"]', { timeout: 5000 });
  ok("countdown renders (red/green legend visible)");

  const gos1 = [];
  await runGolden(p, gos1, "run1");
  gos1.length >= 9 ? ok(`run1 collected ${gos1.length} go cues (3 simple + 6 choice, +1 possible retry)`) : fail(`run1 go cues: ${gos1.length}`);
  await assertValidResults(p, "run1");
  await noHorizontalOverflow(p, "results");

  /* ---------------- Run 2: retake, foreperiods differ ---------------- */
  console.log("— Run 2: retake -> foreperiods re-randomised —");
  const retakeBtn = await p.$('[data-testid="rt-retake"]');
  if (!retakeBtn) { fail("retake button missing"); return finish(browser, errors); }
  await retakeBtn.click();
  await p.waitForSelector('[data-testid="rt-countdown"]', { timeout: 5000 });
  const gos2 = [];
  await runGolden(p, gos2, "run2");
  gos2.length >= 9 ? ok(`run2 collected ${gos2.length} go cues`) : fail(`run2 go cues: ${gos2.length}`);
  await assertValidResults(p, "run2");

  const identicalRuns = JSON.stringify(gos1) === JSON.stringify(gos2);
  !identicalRuns ? ok("go timestamps differ between run1 and run2 (foreperiods re-randomised)") : fail("run1 and run2 go timestamps identical!");
  const ints1 = intervals(gos1);
  const notAllSame = new Set(ints1).size > 1;
  notAllSame ? ok(`inter-cue intervals within run1 vary (${ints1.slice(0, 4).map((v) => (v / 1000).toFixed(2) + "s").join(", ")}...)`) : fail("inter-cue intervals all identical -> rhythm exploitable");

  /* ---------------- Run 3: anti-gaming mash ---------------- */
  console.log("— Run 3: blind rapid clicking -> must be flagged low validity —");
  await p.goto(`${BASE}/test/reaction-time?quick=1`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="rt-intro-cta"]')).click();
  await p.waitForSelector('[data-testid="rt-phase-simple"]', { timeout: 15000 });
  const mashDone = await mashRun(p);
  mashDone ? ok("mash loop reached results") : fail("mash loop timed out");
  await p.waitForSelector('[data-testid="rt-invalid"]', { timeout: 5000 }).catch(() => null);
  const invalidCard = await p.$('[data-testid="rt-invalid"]');
  invalidCard ? ok("mash run flagged low validity (honest card)") : fail("mash run was scored (anti-gaming FAILED)");
  const invalidText = invalidCard ? await invalidCard.evaluate((el) => el.textContent) : "";
  invalidText.toLowerCase().includes("not scored") ? ok('"not scored" message shown') : fail("missing not-scored message");
  invalidText.toLowerCase().includes("anticipation") ? ok("reason mentions anticipations") : fail("reason does not mention anticipations");
  const mashIndex = await p.$('[data-testid="rt-index"]');
  !mashIndex ? ok("no RT Index rendered for invalid run (no IQ inflation)") : fail("RT Index rendered despite low validity");
  const mashResults = await p.$eval('[data-testid="rt-results"]', (el) => el.textContent).catch(() => "");
  mashResults.includes("anticipations (too soon)") ? ok("invalid card shows anticipation count") : fail("anticipation count missing on invalid card");
  const mashRetake = await p.$('[data-testid="rt-retake"]');
  mashRetake ? ok("retake CTA available after invalid run") : fail("retake missing after invalid run");

  /* ---------------- Mobile 375px: full golden run ---------------- */
  console.log("— Mobile 375px (full run) —");
  const mp = await ctx.newPage();
  await attachErrorCollector(mp, errors);
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/reaction-time?quick=1`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="rt-intro-cta"]')).click();
  await mp.waitForSelector('[data-testid="rt-phase-simple"]', { timeout: 15000 });
  await noHorizontalOverflow(mp, "simple round");
  const mgos = [];
  await runGolden(mp, mgos, "mobile");
  mgos.length >= 9 ? ok(`mobile run responded to ${mgos.length} cues`) : fail(`mobile go cues: ${mgos.length}`);
  await assertValidResults(mp, "mobile");
  await noHorizontalOverflow(mp, "results");
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
