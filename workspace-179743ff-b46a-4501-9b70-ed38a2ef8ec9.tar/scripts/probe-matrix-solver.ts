/* Probe: replicate the verify's exact solveOk logic to find failing seeds */
import {
  generateItems,
  solveItem,
  cellKey,
  elementKey,
  SHAPES,
  type Cell,
  type MatrixItem,
} from "../src/components/test/matrix-reasoning-core.ts";

function gridConsistent(item: MatrixItem): boolean {
  const solved = solveItem(item);
  if (!solved) return false;
  const full: Cell[] = [...(item.cells.slice(0, -1) as Cell[]), solved];
  const key = (c: Cell) => cellKey(c);
  const spec = item.spec;
  if (spec.kind === "diag") {
    return (
      key(full[1]!) === key(full[2]!) &&
      key(full[3]!) !== key(full[1]!) &&
      key(full[3]!) !== key(full[0]!)
    );
  }
  if (spec.kind === "across") {
    return (
      key(full[8]!) === key(full[2]!) &&
      key(full[2]!) === key(full[5]!) &&
      key(full[2]!) !== key(full[1]!)
    );
  }
  if (spec.kind === "rotXY") {
    const rot = (c: Cell) => c.elements[0]!.rotation;
    const d01 = rot(full[1]!) - rot(full[0]!);
    const d12 = rot(full[2]!) - rot(full[1]!);
    if (d01 <= 0 || d01 !== d12) return false;
    for (let r = 0; r < 3; r++) {
      if (
        rot(full[r * 3 + 1]!) - rot(full[r * 3]!) !== d01 ||
        rot(full[r * 3 + 2]!) - rot(full[r * 3 + 1]!) !== d01
      )
        return false;
    }
    for (let c = 0; c < 3; c++) {
      if (rot(full[3 + c]!) - rot(full[c]!) !== d01) return false;
    }
    return true;
  }
  if (spec.kind === "super") {
    const unionKey = (r: number) => {
      const els = [
        ...full[r * 3]!.elements,
        ...full[r * 3 + 1]!.elements.filter(
          (e) => !full[r * 3]!.elements.some((x) => elementKey(x) === elementKey(e))
        ),
      ];
      return els.map(elementKey).join(";");
    };
    return (
      unionKey(0) === key(full[2]!) &&
      unionKey(1) === key(full[5]!) &&
      unionKey(2) === key(full[8]!) &&
      full[8]!.elements.length === 2 &&
      key(full[2]!) !== key(full[5]!)
    );
  }
  const p0 = full[0]!.elements[0]!;
  const p1 = full[1]!.elements[0]!;
  let get: (e: { count: number; scale: number; rotation: number }) => number;
  if (p1.count !== p0.count) get = (e) => e.count;
  else if (Math.abs(p1.scale - p0.scale) > 1e-9) get = (e) => e.scale;
  else get = (e) => e.rotation;
  const step = get(p1) - get(p0);
  if (step === 0) return false;
  for (let r = 0; r < 3; r++) {
    const a = get(full[r * 3]!.elements[0]!);
    const b = get(full[r * 3 + 1]!.elements[0]!);
    const c = get(full[r * 3 + 2]!.elements[0]!);
    if (Math.abs(b - a - step) > 1e-9 || Math.abs(c - b - step) > 1e-9) return false;
  }
  for (let c = 0; c < 3; c++) {
    if (Math.abs(get(full[3 + c]!.elements[0]!) - get(full[c]!.elements[0]!)) > 1e-9) return false;
  }
  if (spec.down === "shape") {
    for (let c = 0; c < 3; c++) {
      const s0 = SHAPES.indexOf(full[c]!.elements[0]!.shape);
      const s1 = SHAPES.indexOf(full[3 + c]!.elements[0]!.shape);
      const s2 = SHAPES.indexOf(full[6 + c]!.elements[0]!.shape);
      if (s1 !== (s0 + 1) % SHAPES.length || s2 !== (s1 + 1) % SHAPES.length) return false;
    }
  } else {
    for (let c = 0; c < 3; c++) {
      const f0 = full[c]!.elements[0]!.fill;
      const f1 = full[3 + c]!.elements[0]!.fill;
      const f2 = full[6 + c]!.elements[0]!.fill;
      if (f1 === f0 || f2 !== f0) return false;
    }
  }
  return true;
}

for (let seed = 0; seed < 150; seed++) {
  const items = generateItems(seed);
  items.forEach((item, idx) => {
    const solved = solveItem(item);
    let why = "";
    if (!solved) why = "solveItem NULL";
    else {
      const sk = cellKey(solved);
      const keys = item.options.map(cellKey);
      if (keys[item.correctIndex] !== sk) why = `correctIndex mismatch solved=${sk} stored=${keys[item.correctIndex]}`;
      if (!gridConsistent(item)) why += (why ? " + " : "") + "gridConsistent false";
    } 
    if (why) {
      console.log(`seed=${seed} idx=${idx} tier=${item.tier} kind=${item.spec.kind}: ${why}`);
      console.log("  spec:", JSON.stringify(item.spec));
    }
  });
}
console.log("probe done");
