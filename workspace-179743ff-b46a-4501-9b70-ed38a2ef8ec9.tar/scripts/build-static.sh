#!/bin/bash
# Static export build for static hosts (Hostinger WordPress hosting etc.)
# Usage: bash scripts/build-static.sh
# Output: out/ directory + download/brainmetrics-static.zip
set -e
cd /home/z/my-project

echo "==> Cleaning previous export"
rm -rf out

echo "==> Building static export (BUILD_STATIC=1 next build)"
BUILD_STATIC=1 bunx next build

echo ""
echo "==> Export contents (top level)"
ls out/ | head -20

echo ""
echo "==> Route count check"
find out/test -name "index.html" | wc -l
echo "test pages with index.html ^"

echo ""
echo "==> DONE. out/ ready for upload."
