/* ------------------------------------------------------------------ */
/*  Unit verification for digit-span-core.ts                           */
/*  Run: bun scripts/verify-digit-span-core.ts                          */
/* ------------------------------------------------------------------ */

import {
  ATTEMPTS_PER_LENGTH,
  BWD_MEAN,
  BWD_SD,
  BWD_WEIGHT,
  COMPOSITE_SD,
  DIGITS,
  DISPLAY_MS,
  FWD_MEAN,
  FWD_SD,
  FWD_WEIGHT,
  GAP_MS,
  IQ_MAX,
  IQ_MIN,
  MAX_LENGTH,
  QUICK_ATTEMPTS_PER_LENGTH,
  QUICK_DISPLAY_MS,
  QUICK_GAP_MS,
  QUICK_START_LENGTH,
  SPAN_CORRELATION,
  START_LENGTH,
  buildSequence,
  differentSequence,
  erf,
  gradeForIq,
  gradeRecall,
  iqToPercentile,
  mulberry32,
  normalCdf,
  reverseOf,
  scoreSession,
  sessionConfig,
  shuffle,
  spanOfPhase,
  spansToIq,
  submitAttempt,
  type SpanAttempt,
  type SpanDirection,
} from "../src/components/test/digit-span-core";

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function sd(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
}

const mkAttempt = (
  direction: SpanDirection,
  length: number,
  attemptIndex: number,
  correct: boolean,
  valid = true
): SpanAttempt => ({
  direction,
  length,
  attemptIndex,
  target: buildSequence(length, mulberry32(length * 31 + attemptIndex)),
  input: [],
  correct: correct && valid,
  valid,
  invalidReason: valid ? null : "invalid",
});

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("10 digits 0-9", DIGITS.length === 10 && DIGITS[0] === 0 && DIGITS[9] === 9);
check("normal mode: start 3, two attempts", START_LENGTH === 3 && ATTEMPTS_PER_LENGTH === 2);
check("quick mode: start 4, one attempt", QUICK_START_LENGTH === 4 && QUICK_ATTEMPTS_PER_LENGTH === 1);
check("pacing 1000ms display / 250ms gap", DISPLAY_MS === 1000 && GAP_MS === 250);
check("quick pacing faster", QUICK_DISPLAY_MS < DISPLAY_MS && QUICK_GAP_MS < GAP_MS);
check("max length is 10", MAX_LENGTH === 10);
check(
  "population anchors (fwd 7/1.6, bwd 5.5/1.5)",
  FWD_MEAN === 7 && FWD_SD === 1.6 && BWD_MEAN === 5.5 && BWD_SD === 1.5
);
check("backward weighted higher", BWD_WEIGHT > FWD_WEIGHT && Math.abs(FWD_WEIGHT + BWD_WEIGHT - 1) < 1e-12);
check(
  "COMPOSITE_SD matches w^2 + w^2 + 2*w*w*rho",
  Math.abs(COMPOSITE_SD - Math.sqrt(FWD_WEIGHT ** 2 + BWD_WEIGHT ** 2 + 2 * FWD_WEIGHT * BWD_WEIGHT * SPAN_CORRELATION)) < 1e-12
);
check("COMPOSITE_SD below 1 (correlated composite)", COMPOSITE_SD < 1, String(COMPOSITE_SD));
check("IQ clamp 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
  const arr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  const shuffled = shuffle(arr, mulberry32(7));
  check(
    "shuffle preserves multiset",
    shuffled.slice().sort((a, b) => a - b).join(",") === arr.join(",")
  );
  check("shuffle does not mutate input", arr.join(",") === "0,1,2,3,4,5,6,7,8,9");
}

section("buildSequence invariants (300 seeds x lengths 1..10)");
{
  let allOk = true;
  let adjacentRepeat = false;
  let sawRepeatBeyondAdjacent = false;
  for (let seed = 0; seed < 300; seed++) {
    const rng = mulberry32(seed);
    for (let len = 1; len <= 10; len++) {
      const seq = buildSequence(len, rng);
      if (seq.length !== len) allOk = false;
      if (!seq.every((d) => Number.isInteger(d) && d >= 0 && d <= 9)) allOk = false;
      for (let i = 1; i < seq.length; i++) {
        if (seq[i] === seq[i - 1]) adjacentRepeat = true;
      }
      if (len >= 3 && seq[0] === seq[2]) sawRepeatBeyondAdjacent = true;
    }
  }
  check("all sequences have the requested length", allOk);
  check("no adjacent repeats anywhere", !adjacentRepeat);
  check("digits drawn 0-9 (integers)", true);
  check(
    "non-adjacent repeats DO occur (sequences are not over-scrubbed)",
    sawRepeatBeyondAdjacent
  );
  const digitCounts = new Array(10).fill(0);
  for (let seed = 0; seed < 300; seed++) {
    const rng = mulberry32(1000 + seed);
    for (const d of buildSequence(10, rng)) digitCounts[d] += 1;
  }
  const expected = (300 * 10) / 10;
  const balanced = digitCounts.every((c) => c > expected * 0.8 && c < expected * 1.2);
  check("digit usage roughly uniform (80%-120%)", balanced, JSON.stringify(digitCounts));
}

section("differentSequence (anti-retry anti-gaming)");
{
  let differs = true;
  let ran = false;
  for (let seed = 0; seed < 200; seed++) {
    const rng = mulberry32(5000 + seed);
    const prev = buildSequence(5, rng);
    const next = differentSequence(5, rng, [prev]);
    ran = true;
    if (next.length !== 5) differs = false;
    if (next.every((d, i) => d === prev[i])) differs = false;
  }
  check("ran 200 seeds", ran);
  check("retry sequence always differs from the failed one", differs);
  // multiple exclusions (all prior targets at a length) also respected
  const rng = mulberry32(777);
  const history = [buildSequence(4, rng), buildSequence(4, rng), buildSequence(4, rng)];
  const fresh = differentSequence(4, rng, history);
  check(
    "differs from ALL prior targets at the same length",
    !history.some((h) => h.every((d, i) => d === fresh[i]))
  );
}

section("reverseOf + gradeRecall (forward / backward / palindrome)");
{
  check("reverseOf reverses without mutating", JSON.stringify(reverseOf([1, 2, 3])) === "[3,2,1]");
  const fwdSeq = [1, 2, 3];
  check("forward correct when identical", gradeRecall(fwdSeq, [1, 2, 3], "forward") === true);
  check("forward wrong when reversed", gradeRecall(fwdSeq, [3, 2, 1], "forward") === false);
  check("backward correct when reversed", gradeRecall(fwdSeq, [3, 2, 1], "backward") === true);
  check("backward wrong when identical", gradeRecall(fwdSeq, [1, 2, 3], "backward") === false);
  // palindrome edge: reversed target equals target
  const pal = [4, 7, 4];
  check(
    "palindrome backward recall (input equals target) is CORRECT",
    gradeRecall(pal, [4, 7, 4], "backward") === true
  );
  check(
    "palindrome forward recall still requires exact order",
    gradeRecall(pal, [4, 7, 4], "forward") === true
  );
  const other = [1, 2];
  check("backward [2,1] of [1,2] correct", gradeRecall(other, [2, 1], "backward") === true);
  check("short input never grades correct", gradeRecall(fwdSeq, [1, 2], "forward") === false);
  check("long input never grades correct", gradeRecall(fwdSeq, [1, 2, 3, 4], "forward") === false);
  check("empty input never grades correct", gradeRecall(fwdSeq, [], "backward") === false);
}

section("submitAttempt anti-gaming validity");
{
  const target = [1, 2, 3];
  const before = submitAttempt({
    direction: "forward",
    length: 3,
    attemptIndex: 1,
    target,
    input: [1, 2, 3],
    wasShown: false,
  });
  check("submit-before-show is invalid", before.valid === false && before.correct === false);
  check("submit-before-show carries a reason", before.invalidReason !== null);
  const empty = submitAttempt({
    direction: "backward",
    length: 3,
    attemptIndex: 1,
    target,
    input: [],
    wasShown: true,
  });
  check("zero-length input is invalid", empty.valid === false && empty.correct === false);
  check("zero-length input carries a reason", empty.invalidReason !== null);
  const okFwd = submitAttempt({
    direction: "forward",
    length: 3,
    attemptIndex: 1,
    target,
    input: [1, 2, 3],
    wasShown: true,
  });
  check("valid forward attempt grades correctly", okFwd.valid && okFwd.correct);
  const okBwd = submitAttempt({
    direction: "backward",
    length: 3,
    attemptIndex: 1,
    target,
    input: [3, 2, 1],
    wasShown: true,
  });
  check("valid backward attempt grades correctly", okBwd.valid && okBwd.correct);
  const wrong = submitAttempt({
    direction: "forward",
    length: 3,
    attemptIndex: 1,
    target,
    input: [9, 9, 9],
    wasShown: true,
  });
  check("wrong-but-honest attempt is valid and incorrect", wrong.valid && !wrong.correct);
  check("attempt bookkeeping mirrors params", okBwd.length === 3 && okBwd.attemptIndex === 1 && okBwd.direction === "backward");
  check("engine copies target/input arrays (no aliasing)", JSON.stringify(okFwd.target) === "[1,2,3]");
}

section("spanOfPhase + staircase bookkeeping (discontinuation logic)");
{
  check("no attempts -> span 0", spanOfPhase([]) === 0);
  const allFail = [mkAttempt("forward", 3, 1, false), mkAttempt("forward", 3, 2, false)];
  check("both attempts failed at start length -> span 0", spanOfPhase(allFail) === 0);
  const mixed = [
    mkAttempt("forward", 3, 1, false),
    mkAttempt("forward", 3, 2, true),
    mkAttempt("forward", 4, 1, true),
    mkAttempt("forward", 5, 1, false),
    mkAttempt("forward", 5, 2, false),
  ];
  check("fail-then-pass advances; two fails discontinue -> span 4", spanOfPhase(mixed) === 4);
  check(
    "bookkeeping: lengths non-decreasing across a phase",
    mixed.every((a, i) => i === 0 || a.length >= mixed[i - 1]!.length)
  );
  check(
    "bookkeeping: attempt indices restart at 1 per length",
    mixed.every((a, i) => i === 0 || a.length !== mixed[i - 1]!.length || a.attemptIndex === mixed[i - 1]!.attemptIndex + 1)
  );
  const invalidNotCounted = [
    mkAttempt("forward", 3, 1, false, false),
    mkAttempt("forward", 3, 2, false, false),
  ];
  check("invalid attempts never contribute to span", spanOfPhase(invalidNotCounted) === 0);
  const maxReached = [
    mkAttempt("forward", 3, 1, true),
    mkAttempt("forward", 4, 1, true),
    mkAttempt("forward", 5, 1, true),
    mkAttempt("forward", MAX_LENGTH, 1, true),
  ];
  check("passing MAX_LENGTH caps the span at MAX_LENGTH", spanOfPhase(maxReached) === MAX_LENGTH);
  const misordered = [mkAttempt("forward", 5, 1, true), mkAttempt("forward", 3, 1, true)];
  check("span is the HIGHEST passed length (order-independent)", spanOfPhase(misordered) === 5);
}

section("sessionConfig (normal vs quick)");
{
  const normal = sessionConfig(false);
  const quick = sessionConfig(true);
  check(
    "normal: start 3 / 2 attempts / 1000ms / 250ms",
    normal.startLength === 3 &&
      normal.attemptsPerLength === 2 &&
      normal.displayMs === 1000 &&
      normal.gapMs === 250 &&
      normal.quick === false
  );
  check(
    "quick: start 4 / 1 attempt / faster pacing",
    quick.startLength === 4 &&
      quick.attemptsPerLength === 1 &&
      quick.displayMs === 500 &&
      quick.gapMs === 120 &&
      quick.quick === true
  );
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check("normalCdf(+1sd) ~ 0.8413", Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6);
}

section("spansToIq mapping");
{
  check("typical adult (7, 5.5) -> IQ 100", spansToIq(7, 5.5) === 100, String(spansToIq(7, 5.5)));
  // (9,7) is +1.25sd fwd / +1.0sd bwd -> composite z = 1.1125/COMPOSITE_SD
  check("+1sd-ish on both (9, 7) -> IQ 119", spansToIq(9, 7) === 119, String(spansToIq(9, 7)));
  // symmetric move down: (5, 4) -> IQ 81
  check("-1sd-ish on both (5, 4) -> IQ 81", spansToIq(5, 4) === 81, String(spansToIq(5, 4)));
  check("floor spans (0, 0) clamp to IQ_MIN", spansToIq(0, 0) === IQ_MIN, String(spansToIq(0, 0)));
  check("perfect spans (10, 10) stay in range", spansToIq(10, 10) > 115 && spansToIq(10, 10) <= IQ_MAX, String(spansToIq(10, 10)));
  check("absurd inputs clamp to IQ_MAX", spansToIq(99, 99) === IQ_MAX);
  let monoFwd = true;
  for (let b = 0; b <= 10; b++) {
    for (let f = 0; f < 10; f++) {
      if (spansToIq(f + 1, b) < spansToIq(f, b)) monoFwd = false;
    }
  }
  check("IQ monotonic non-decreasing in forward span", monoFwd);
  let monoBwd = true;
  for (let f = 0; f <= 10; f++) {
    for (let b = 0; b < 10; b++) {
      if (spansToIq(f, b + 1) < spansToIq(f, b)) monoBwd = false;
    }
  }
  check("IQ monotonic non-decreasing in backward span", monoBwd);
  const symDiff = Math.abs((spansToIq(8, 5) - 100) - -(spansToIq(6, 6) - 100));
  check("weights roughly balance forward/backward moves", symDiff < 3, String(symDiff));
}

section("iqToPercentile");
{
  check("IQ 100 -> 50th percentile", iqToPercentile(100) === 50);
  check("IQ 115 -> ~84th", iqToPercentile(115) === 84);
  check("IQ 85 -> ~16th", iqToPercentile(85) === 16);
  check("clamped to 1 at the bottom", iqToPercentile(IQ_MIN) === 1);
  check("clamped to 99 at the top", iqToPercentile(IQ_MAX) === 99);
  let mono = true;
  for (let iq = IQ_MIN; iq < IQ_MAX; iq++) {
    if (iqToPercentile(iq + 1) < iqToPercentile(iq)) mono = false;
  }
  check("percentile monotonic non-decreasing in IQ", mono);
}

section("gradeForIq tiers");
{
  check("IQ 70 -> Building", gradeForIq(70).label === "Building");
  check("IQ 84 -> Building (boundary)", gradeForIq(84.9).label === "Building");
  check("IQ 85 -> Average", gradeForIq(85).label === "Average");
  check("IQ 99 -> Average", gradeForIq(99.4).label === "Average");
  check("IQ 100 -> Above average", gradeForIq(100).label === "Above average");
  check("IQ 114 -> Above average", gradeForIq(114.6).label === "Above average");
  check("IQ 115 -> Well above average", gradeForIq(115).label === "Well above average");
  check("IQ 129 -> Well above average", gradeForIq(129).label === "Well above average");
  check("IQ 130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check(
    "every grade has blurb + class",
    [70, 90, 105, 120, 135].every((q) => {
      const g = gradeForIq(q);
      return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
    })
  );
}

section("scoreSession - honest floor paths (anti-gaming)");
{
  const emptyAttempt = (dir: SpanDirection, len: number, idx: number): SpanAttempt =>
    submitAttempt({ direction: dir, length: len, attemptIndex: idx, target: buildSequence(len, mulberry32(len)), input: [], wasShown: true });
  const ghostAttempt = (dir: SpanDirection, len: number, idx: number): SpanAttempt =>
    submitAttempt({ direction: dir, length: len, attemptIndex: idx, target: buildSequence(len, mulberry32(len)), input: buildSequence(len, mulberry32(len + 1)), wasShown: false });

  // Every attempt invalid (empty input / submit-before-show) both phases.
  const fwdInvalid = [emptyAttempt("forward", 3, 1), ghostAttempt("forward", 3, 2)];
  const bwdInvalid = [emptyAttempt("backward", 3, 1), ghostAttempt("backward", 3, 2)];
  const floor = scoreSession(fwdInvalid, bwdInvalid, false);
  check("all-invalid session still scores (terminates cleanly)", floor.forwardSpan === 0 && floor.backwardSpan === 0);
  check("floor spans give honest low IQ (clamped minimum)", floor.iq === IQ_MIN, String(floor.iq));
  check("floor percentile is 1", floor.percentile === 1);
  check("floor session counts attempts", floor.attempts === 4 && floor.correct === 0);

  // Wrong-but-valid inputs (the flow test's mash path): also floor.
  const wrongFwd = [1, 2].map((i) =>
    submitAttempt({
      direction: "forward" as const,
      length: 3,
      attemptIndex: i,
      target: buildSequence(3, mulberry32(i)),
      input: buildSequence(3, mulberry32(i + 50)),
      wasShown: true,
    })
  );
  const wrongBwd = [1].map((i) =>
    submitAttempt({
      direction: "backward" as const,
      length: 3,
      attemptIndex: i,
      target: buildSequence(3, mulberry32(i + 90)),
      input: buildSequence(3, mulberry32(i + 91)),
      wasShown: true,
    })
  );
  const low = scoreSession(wrongFwd, wrongBwd, false);
  check("all-wrong session scores floor spans", low.forwardSpan === 0 && low.backwardSpan === 0);
  check("all-wrong session IQ <= 70 (honest, not inflated)", low.iq <= 70, String(low.iq));
}

section("scoreSession - realistic scoring path");
{
  const fwd = [
    mkAttempt("forward", 3, 1, true),
    mkAttempt("forward", 4, 1, true),
    mkAttempt("forward", 5, 1, true),
    mkAttempt("forward", 6, 1, true),
    mkAttempt("forward", 7, 1, true),
    mkAttempt("forward", 8, 1, false),
    mkAttempt("forward", 8, 2, false),
  ];
  const bwd = [
    mkAttempt("backward", 3, 1, true),
    mkAttempt("backward", 4, 1, true),
    mkAttempt("backward", 5, 1, true),
    mkAttempt("backward", 6, 1, false),
    mkAttempt("backward", 6, 2, false),
  ];
  const result = scoreSession(fwd, bwd, false);
  check("forward span = 7", result.forwardSpan === 7);
  check("backward span = 5", result.backwardSpan === 5);
  check("total span = 12", result.totalSpan === 12);
  check("IQ matches spansToIq(7, 5)", result.iq === spansToIq(7, 5), String(result.iq));
  check("percentile matches iqToPercentile", result.percentile === iqToPercentile(result.iq));
  check("grade matches gradeForIq", result.grade.label === gradeForIq(result.iq).label);
  check("attempt counts (7 + 5 = 12, 8 correct)", result.attempts === 12 && result.correct === 8);
  check("quick flag false for normal session", result.quick === false);
  const quickResult = scoreSession(fwd.slice(0, 5), bwd.slice(0, 3), true);
  check("quick flag carried through", quickResult.quick === true);
}

/* ---------------------------------------------------------------- */

section("Population simulation (N=500, behavioural staircase)");
{
  // Each simulated user gets a latent ability plus per-sequence
  // recall odds that fall with sequence length (normal ogive, slope 1
  // digit). The EXACT product staircase is then played with engine
  // primitives: start at 3, adaptive second attempt after a fail,
  // discontinue when both attempts at a length fail. Forward and
  // backward abilities correlate at SPAN_CORRELATION.
  const P_ITEM_SD = 1.0;
  const BETWEEN_FWD = 1.4;
  const BETWEEN_BWD = 1.3;

  const playPhase = (
    dir: SpanDirection,
    ability: number,
    rng: () => number
  ): { span: number; attempts: SpanAttempt[] } => {
    const attempts: SpanAttempt[] = [];
    let span = 0;
    for (let len = START_LENGTH; len <= MAX_LENGTH; len++) {
      let passed = false;
      for (let idx = 1; idx <= ATTEMPTS_PER_LENGTH; idx++) {
        const target = buildSequence(len, rng);
        const willSucceed = rng() < normalCdf(ability, len, P_ITEM_SD);
        // "Correct" submissions use the truly expected answer
        // (reversed for backward); failures submit a different
        // sequence than the expected one, so grading decides honestly.
        const expected = dir === "backward" ? reverseOf(target) : target;
        const input = willSucceed
          ? expected
          : differentSequence(len, rng, [expected]);
        const attempt = submitAttempt({
          direction: dir,
          length: len,
          attemptIndex: idx,
          target,
          input,
          wasShown: true,
        });
        attempts.push(attempt);
        if (attempt.correct) {
          passed = true;
          break;
        }
      }
      if (passed) span = len;
      else break; // both attempts failed -> discontinue
    }
    return { span, attempts };
  };

  const iqSamples: number[] = [];
  const fwdSpans: number[] = [];
  const bwdSpans: number[] = [];
  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(10_000 + user);
    const a = randn(rng);
    const e = randn(rng);
    const sFwd = FWD_MEAN + BETWEEN_FWD * a;
    const sBwd = BWD_MEAN + BETWEEN_BWD * (SPAN_CORRELATION * a + Math.sqrt(1 - SPAN_CORRELATION ** 2) * e);
    const fwd = playPhase("forward", sFwd, rng);
    const bwd = playPhase("backward", sBwd, rng);
    fwdSpans.push(fwd.span);
    bwdSpans.push(bwd.span);
    const result = scoreSession(fwd.attempts, bwd.attempts, false);
    iqSamples.push(result.iq);
  }

  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanFwd = mean(fwdSpans);
  const meanBwd = mean(bwdSpans);

  check(
    "simulated forward spans centre on 7 (6-8)",
    meanFwd > 6 && meanFwd < 8,
    String(meanFwd.toFixed(3))
  );
  check(
    "simulated backward spans centre on 5.5 (4.5-6.5)",
    meanBwd > 4.5 && meanBwd < 6.5,
    String(meanBwd.toFixed(3))
  );
  check(
    "simulated forward span SD near 1.6 (1.1-2.1)",
    sd(fwdSpans) > 1.1 && sd(fwdSpans) < 2.1,
    String(sd(fwdSpans).toFixed(3))
  );
  check(
    "IQ mean calibrated near 100 (+/- 2)",
    meanIq > 98 && meanIq < 102,
    String(meanIq.toFixed(2))
  );
  check(
    "IQ SD calibrated near 15 (13-17)",
    sdIq > 13 && sdIq < 17,
    String(sdIq.toFixed(2))
  );
  const fwdCorr = (() => {
    const mf = mean(fwdSpans);
    const mb = mean(bwdSpans);
    const cov = mean(fwdSpans.map((f, i) => (f - mf) * (bwdSpans[i]! - mb)));
    return cov / (sd(fwdSpans) * sd(bwdSpans));
  })();
  check(
    "forward/backward spans positively correlated",
    fwdCorr > 0.2,
    String(fwdCorr.toFixed(3))
  );
  const iqFloorRate = iqSamples.filter((q) => q === IQ_MIN).length / 500;
  check("IQ floor rare in the normal population (<5%)", iqFloorRate < 0.05, String(iqFloorRate));
  console.log(
    `  info   500-user sim: mean fwd span=${meanFwd.toFixed(2)}, mean bwd span=${meanBwd.toFixed(2)}, mean IQ=${meanIq.toFixed(2)}, SD=${sdIq.toFixed(2)}, fwd/bwd r=${fwdCorr.toFixed(2)}`
  );
}

section("Quick-mode behaviour");
{
  // Quick mode: start at 4, ONE attempt per length, faster pacing.
  const playQuickPhase = (ability: number, rng: () => number): SpanAttempt[] => {
    const attempts: SpanAttempt[] = [];
    for (let len = QUICK_START_LENGTH; len <= MAX_LENGTH; len++) {
      const target = buildSequence(len, rng);
      const willSucceed = rng() < normalCdf(ability, len, 1.0);
      const input = willSucceed ? target : differentSequence(len, rng, [target]);
      const attempt = submitAttempt({
        direction: "forward",
        length: len,
        attemptIndex: 1,
        target,
        input,
        wasShown: true,
      });
      attempts.push(attempt);
      if (!attempt.correct) break; // single attempt -> instant discontinue
    }
    return attempts;
  };
  let bookkeepingOk = true;
  let spansCapped = true;
  const iqs: number[] = [];
  for (let user = 0; user < 200; user++) {
    const rng = mulberry32(20_000 + user);
    const ability = FWD_MEAN + randn(rng);
    const fwd = playQuickPhase(ability, rng);
    const bwd = playQuickPhase(ability - 1.5, rng);
    for (let i = 0; i < fwd.length; i++) {
      if (fwd[i]!.attemptIndex !== 1) bookkeepingOk = false;
      if (fwd[i]!.length !== QUICK_START_LENGTH + i) bookkeepingOk = false;
    }
    for (let i = 0; i < bwd.length; i++) {
      if (bwd[i]!.attemptIndex !== 1) bookkeepingOk = false;
    }
    const result = scoreSession(fwd, bwd, true);
    if (result.forwardSpan > MAX_LENGTH || result.backwardSpan > MAX_LENGTH) spansCapped = false;
    iqs.push(result.iq);
  }
  check("quick sessions keep 1 attempt per length with rising lengths", bookkeepingOk);
  check("quick spans never exceed MAX_LENGTH", spansCapped);
  const quickIq = mean(iqs);
  // NOTE: one attempt per length makes the staircase strictly harsher
  // than the full test (a length is passed only if EVERY length so far
  // was passed first try), so quick-mode scores run systematically
  // below the full-test scale. This is expected and disclosed in the
  // UI quick-mode note; the gate below pins the calibrated value.
  check(
    "quick-mode IQ mean matches its calibration (88-95, below full test)",
    quickIq > 88 && quickIq < 95,
    String(quickIq.toFixed(2))
  );
  const quickResult = scoreSession(
    [mkAttempt("forward", QUICK_START_LENGTH, 1, true)],
    [mkAttempt("backward", QUICK_START_LENGTH, 1, true)],
    true
  );
  check("quick session flagged quick", quickResult.quick === true);
  check(
    "quick scoring uses the same span->IQ map",
    quickResult.iq === spansToIq(QUICK_START_LENGTH, QUICK_START_LENGTH)
  );
}

section("Full pipeline coherence (3 ability profiles)");
{
  const runProfile = (seed: number, skill: number) => {
    const rng = mulberry32(seed);
    const abilityF = FWD_MEAN + 1.4 * skill;
    const abilityB = BWD_MEAN + 1.3 * skill;
    const play = (dir: SpanDirection, ability: number): SpanAttempt[] => {
      const attempts: SpanAttempt[] = [];
      for (let len = START_LENGTH; len <= MAX_LENGTH; len++) {
        let passed = false;
        for (let idx = 1; idx <= ATTEMPTS_PER_LENGTH; idx++) {
          const target = buildSequence(len, rng);
          const willSucceed = rng() < normalCdf(ability, len, 1.0);
          const expected = dir === "backward" ? reverseOf(target) : target;
          const input = willSucceed ? expected : differentSequence(len, rng, [expected]);
          const attempt = submitAttempt({ direction: dir, length: len, attemptIndex: idx, target, input, wasShown: true });
          attempts.push(attempt);
          if (attempt.correct) {
            passed = true;
            break;
          }
        }
        if (!passed) break;
      }
      return attempts;
    };
    return scoreSession(play("forward", abilityF), play("backward", abilityB), false);
  };
  const PROFILE_SEEDS = 15;
  const avgProfile = (skill: number) => {
    const acc = { forwardSpan: 0, backwardSpan: 0, iq: 0, percentile: 0 };
    for (let s = 0; s < PROFILE_SEEDS; s++) {
      const r = runProfile(1000 + skill * 100 + s, skill);
      acc.forwardSpan += r.forwardSpan;
      acc.backwardSpan += r.backwardSpan;
      acc.iq += r.iq;
      acc.percentile += r.percentile;
    }
    acc.forwardSpan /= PROFILE_SEEDS;
    acc.backwardSpan /= PROFILE_SEEDS;
    acc.iq /= PROFILE_SEEDS;
    acc.percentile /= PROFILE_SEEDS;
    return acc;
  };
  const low = avgProfile(-1.5);
  const mid = avgProfile(0);
  const high = avgProfile(1.5);
  check(
    "profile means in range",
    [low, mid, high].every((r) => r.iq >= IQ_MIN && r.iq <= IQ_MAX)
  );
  check(
    "low < mid < high forward span",
    low.forwardSpan < mid.forwardSpan && mid.forwardSpan < high.forwardSpan,
    `${low.forwardSpan.toFixed(1)} < ${mid.forwardSpan.toFixed(1)} < ${high.forwardSpan.toFixed(1)}`
  );
  check(
    "low <= mid <= high backward span",
    low.backwardSpan <= mid.backwardSpan && mid.backwardSpan <= high.backwardSpan,
    `${low.backwardSpan.toFixed(1)} <= ${mid.backwardSpan.toFixed(1)} <= ${high.backwardSpan.toFixed(1)}`
  );
  check(
    "low < mid < high IQ",
    low.iq < mid.iq && mid.iq < high.iq,
    `${low.iq.toFixed(1)} < ${mid.iq.toFixed(1)} < ${high.iq.toFixed(1)}`
  );
  check("low percentile < high percentile", low.percentile < high.percentile);
  check(
    "grades escalate across profiles",
    gradeForIq(high.iq).label !== gradeForIq(low.iq).label
  );
  console.log(
    `  info   pipeline (15-seed means): low IQ=${low.iq.toFixed(1)}, mid IQ=${mid.iq.toFixed(1)}, high IQ=${high.iq.toFixed(1)}`
  );
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
