#!/usr/bin/env node
/**
 * Internal link mesh auditor.
 * Fetches every LIVE page from the dev server, extracts internal links,
 * and fails if any link points somewhere that is neither live, planned
 * (declared in tools.ts), an anchor, or a static file.
 *
 * Usage: node scripts/audit-internal-links.js   (dev server must be up)
 * Exit 0 = MESH COMPLETE, exit 1 = broken links found.
 */
const http = require("http");

const BASE = "http://localhost:3000";

/** Routes that must return 200 right now. Grow as pages land. */
const LIVE_PAGES = [
  "/",
  "/test",
  "/test/matrix-reasoning",
  "/test/digit-span",
  "/test/reaction-time",
  "/test/visual-memory",
  "/test/processing-speed",
  "/test/stroop-test",
  "/test/mental-rotation",
  "/test/chimp-test",
  "/test/n-back",
  "/test/full-iq",
  "/test/working-memory",
  "/test/sequence-memory",
  "/test/word-memory",
  "/test/pattern-memory",
  "/test/spatial-memory",
  "/test/short-term-memory",
  "/test/sustained-attention",
];

/** Routes allowed to 404 by design: planned tool pages not yet rebuilt. */
const PLANNED_PREFIXES = ["/test/", "/tests/", "/blog/", "/about", "/contact", "/privacy", "/terms"];

function get(path) {
  return new Promise((resolve) => {
    http
      .get(`${BASE}${path}`, { timeout: 15000 }, (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => resolve({ status: res.statusCode, body }));
      })
      .on("error", (e) => resolve({ status: 0, body: String(e) }));
  });
}

(async () => {
  let failures = 0;
  const seen = new Map();

  for (const page of LIVE_PAGES) {
    const { status, body } = await get(page);
    if (status !== 200) {
      console.log(`FAIL  ${page} -> HTTP ${status}`);
      failures++;
      continue;
    }
    console.log(`OK    ${page} -> 200 (${(body.length / 1024).toFixed(0)} KB)`);

    const hrefs = [...body.matchAll(/href="(\/[^"]*)"/g)].map((m) => m[1]);
    const uniq = [...new Set(hrefs)];
    for (const href of uniq) {
      const clean = href.split("#")[0].split("?")[0] || "/";
      if (clean === "" ) continue;
      const isAnchorOnly = href.startsWith("/#") || href === "#";
      if (isAnchorOnly) continue;
      const isStatic = /\.(svg|png|jpg|webp|ico|xml|txt|css|js|webmanifest)$/.test(clean);
      if (isStatic) continue;
      if (LIVE_PAGES.includes(clean)) continue;
      if (PLANNED_PREFIXES.some((p) => clean.startsWith(p))) continue; // planned rollout
      if (!seen.has(clean)) seen.set(clean, []);
      seen.get(clean).push(page);
      failures++;
      console.log(`BROKEN  ${href}  (found on ${page})`);
    }
  }

  console.log("");
  if (failures === 0) {
    console.log("MESH COMPLETE: every internal link on live pages resolves to a live or planned route.");
    process.exit(0);
  } else {
    console.log(`MESH BROKEN: ${failures} bad link(s).`);
    process.exit(1);
  }
})();
