/**
 * Task 23 screenshots: Processing Speed test page.
 * Run: node /home/z/my-project/scripts/screenshot-processing-speed.js
 * Output: /tmp/ps-*.png
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");
const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const step = (m) => console.log(`[step] ${m}`);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const p = await ctx.newPage();

  // intro + full page
  step("intro");
  await p.goto(`${BASE}/test/processing-speed`, { waitUntil: "networkidle" });
  await sleep(1200);
  await p.screenshot({ path: "/tmp/ps-intro.png" });
  step("fullpage");
  await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await sleep(900);
  await p.evaluate(() => window.scrollTo(0, 0));
  await sleep(600);
  await p.screenshot({ path: "/tmp/ps-full.png", fullPage: true });

  // countdown (key visible)
  step("countdown");
  await (await p.$('[data-testid="ps-start"]')).click();
  await p.waitForSelector('[data-testid="ps-countdown"]', { timeout: 5000 });
  await sleep(500);
  await p.screenshot({ path: "/tmp/ps-countdown.png" });

  // active mid-sprint (90s mode: settle, answer a few, capture)
  step("active");
  await p.waitForSelector('[data-testid="ps-active"]', { timeout: 6000 });
  const key = await p.$$eval('[data-testid="ps-key"] [data-symbol]', (els) => {
    const m = {};
    els.forEach((el) => (m[el.getAttribute("data-symbol")] = el.getAttribute("data-digit")));
    return m;
  });
  for (let i = 0; i < 8; i++) {
    const sym = (await (await p.$('[data-testid="ps-symbol"]')).textContent()).trim();
    const btn = await p.$(`[data-testid="ps-pad-${key[sym]}"]`);
    if (btn) await btn.evaluate((el) => el.click());
    await sleep(400);
  }
  await sleep(800);
  await p.screenshot({ path: "/tmp/ps-active.png" });

  // results via a fresh quick run (new key each session)
  step("results (quick run)");
  await p.goto(`${BASE}/test/processing-speed?quick=1`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="ps-start"]')).click();
  await p.waitForSelector('[data-testid="ps-active"]', { timeout: 8000 });
  const key2 = await p.$$eval('[data-testid="ps-key"] [data-symbol]', (els) => {
    const m = {};
    els.forEach((el) => (m[el.getAttribute("data-symbol")] = el.getAttribute("data-digit")));
    return m;
  });
  let guard = 0;
  while (!(await p.$('[data-testid="ps-results"]')) && guard < 600) {
    guard++;
    try {
      const sym = (await (await p.$('[data-testid="ps-symbol"]')).textContent()).trim();
      const btn = await p.$(`[data-testid="ps-pad-${key2[sym]}"]`);
      if (btn) await btn.evaluate((el) => el.click());
    } catch {}
    await sleep(70);
  }
  step("results captured");
  await sleep(2200); // CountUp + bars animate
  await p.screenshot({ path: "/tmp/ps-results.png" });

  // 375px set
  step("mobile");
  const mp = await ctx.newPage();
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/processing-speed?quick=1`, { waitUntil: "networkidle" });
  await sleep(1000);
  await mp.screenshot({ path: "/tmp/ps-375-intro.png" });
  await (await mp.$('[data-testid="ps-start"]')).click();
  await mp.waitForSelector('[data-testid="ps-active"]', { timeout: 8000 });
  await sleep(700);
  await mp.screenshot({ path: "/tmp/ps-375-active.png" });
  const mkey = await mp.$$eval('[data-testid="ps-key"] [data-symbol]', (els) => {
    const m = {};
    els.forEach((el) => (m[el.getAttribute("data-symbol")] = el.getAttribute("data-digit")));
    return m;
  });
  let mguard = 0;
  while (!(await mp.$('[data-testid="ps-results"]')) && mguard < 600) {
    mguard++;
    try {
      const sym = (await (await mp.$('[data-testid="ps-symbol"]')).textContent()).trim();
      const btn = await mp.$(`[data-testid="ps-pad-${mkey[sym]}"]`);
      if (btn) await btn.evaluate((el) => el.click());
    } catch {}
    await sleep(70);
  }
  await sleep(2200);
  await mp.screenshot({ path: "/tmp/ps-375-results.png" });

  await browser.close();
  console.log("screenshots saved: ps-intro, ps-full, ps-countdown, ps-active, ps-results, ps-375-intro, ps-375-active, ps-375-results");
})().catch((e) => { console.error(e); process.exit(1); });
