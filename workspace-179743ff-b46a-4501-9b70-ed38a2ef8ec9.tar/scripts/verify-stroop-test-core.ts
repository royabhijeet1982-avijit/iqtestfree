/* ------------------------------------------------------------------ */
/*  Unit verification for stroop-test-core.ts                          */
/*  Run: bun scripts/verify-stroop-test-core.ts                        */
/* ------------------------------------------------------------------ */

import {
  ACCURACY_FLOOR,
  INT_POP_MEAN,
  INT_POP_SD,
  INT_WEIGHT,
  IQ_MAX,
  IQ_MIN,
  MIN_VALID_RT_MS,
  QUICK_TRIAL_COUNT,
  RT_POP_MEAN,
  RT_POP_SD,
  RT_WEIGHT,
  STROOP_COLORS,
  TRIAL_COUNT,
  Z_NORM,
  buildStimuli,
  erf,
  gradeForIndex,
  indexToPercentile,
  median,
  mulberry32,
  normalCdf,
  recordTrial,
  scoreSession,
  shuffle,
  stroopIndexFrom,
  type SessionScore,
  type StroopColorId,
  type StroopStimulus,
  type StroopTrial,
} from "../src/components/test/stroop-test-core";

const COLOR_IDS = STROOP_COLORS.map((c) => c.id);

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/** Build a full simulated session from per-trial generators. */
function makeTrial(
  stimulus: StroopStimulus,
  response: StroopColorId,
  rtMs: number
): StroopTrial {
  return recordTrial(stimulus, response, rtMs);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("TRIAL_COUNT is 60", TRIAL_COUNT === 60, String(TRIAL_COUNT));
check("QUICK_TRIAL_COUNT is 12", QUICK_TRIAL_COUNT === 12, String(QUICK_TRIAL_COUNT));
check("4 stimulus colours", STROOP_COLORS.length === 4);
check(
  "colour ids distinct",
  new Set(COLOR_IDS).size === 4,
  COLOR_IDS.join(",")
);
check(
  "keyboard keys are R G B Y",
  STROOP_COLORS.map((c) => c.key).join("") === "RGBY"
);
check(
  "hex palette exact (blue allowed as stimulus colour only)",
  STROOP_COLORS.map((c) => c.hex).join(",") === "#dc2626,#16a34a,#2563eb,#ca8a04"
);
check("MIN_VALID_RT_MS is 200", MIN_VALID_RT_MS === 200);
check("accuracy floor is 0.7", ACCURACY_FLOOR === 0.7);
check(
  "population anchors: RT 750/160, interference 120/55",
  RT_POP_MEAN === 750 && RT_POP_SD === 160 && INT_POP_MEAN === 120 && INT_POP_SD === 55
);
check(
  "weights 0.45 RT / 0.55 interference",
  RT_WEIGHT === 0.45 && INT_WEIGHT === 0.55
);
check(
  "Z_NORM normalises composite to unit SD for independent traits",
  Math.abs(Z_NORM - Math.sqrt(0.45 * 0.45 + 0.55 * 0.55)) < 1e-12
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG + shuffle determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));

  const arr = [1, 2, 3, 4, 5, 6, 7, 8];
  const shuffled = shuffle(arr, mulberry32(7));
  check(
    "shuffle preserves multiset",
    shuffled.slice().sort((a, b) => a - b).join(",") === "1,2,3,4,5,6,7,8"
  );
  check("shuffle does not mutate input", arr.join(",") === "1,2,3,4,5,6,7,8");
  check(
    "shuffle actually reorders sometimes across seeds",
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].some(
      (seed) => shuffle(arr, mulberry32(seed)).join(",") !== arr.join(",")
    )
  );
}

section("buildStimuli invariants (200 seeds x 2 lengths)");
{
  let allOk = true;
  let exactHalves = true;
  let noTripleInk = true;
  let incongruentNeverMatches = true;
  let congruentAlwaysMatches = true;
  let idsValid = true;
  const inkCounts: Record<string, number> = {};
  const distinctSequences = new Set<string>();
  let firstTrialCongruentVaries = new Set<boolean>();

  for (let seed = 0; seed < 200; seed++) {
    const rng = mulberry32(seed);
    for (const count of [TRIAL_COUNT, QUICK_TRIAL_COUNT]) {
      const stimuli = buildStimuli(rng, count);
      if (stimuli.length !== count) allOk = false;
      const congruentCount = stimuli.filter((s) => s.congruent).length;
      if (congruentCount !== count / 2) exactHalves = false;
      let streak = 0;
      let prevInk: StroopColorId | null = null;
      for (const s of stimuli) {
        if (!COLOR_IDS.includes(s.word) || !COLOR_IDS.includes(s.ink)) idsValid = false;
        if (s.congruent && s.word !== s.ink) congruentAlwaysMatches = false;
        if (!s.congruent && s.word === s.ink) incongruentNeverMatches = false;
        inkCounts[s.ink] = (inkCounts[s.ink] ?? 0) + 1;
        if (prevInk === s.ink) streak += 1;
        else streak = 1;
        if (streak >= 3) noTripleInk = false;
        prevInk = s.ink;
      }
      distinctSequences.add(stimuli.map((s) => `${s.word}${s.ink ? ">" : "="}${s.ink}`).join("|"));
      firstTrialCongruentVaries.add(stimuli[0]!.congruent);
    }
  }
  check("all sequences have the exact requested length", allOk);
  check("exactly 50/50 congruent/incongruent (30/30 and 6/6)", exactHalves);
  check("no ink colour appears 3x in a row", noTripleInk);
  check("incongruent word never equals ink", incongruentNeverMatches);
  check("congruent word always equals ink", congruentAlwaysMatches);
  check("all words/inks are valid colour ids", idsValid);
  check(
    "ink distribution roughly uniform (each 20%-30% pooled)",
    COLOR_IDS.every((id) => {
      const share = (inkCounts[id] ?? 0) / (200 * 72);
      return share > 0.2 && share < 0.3;
    }),
    JSON.stringify(inkCounts)
  );
  check(
    "sequences genuinely re-randomise across seeds",
    distinctSequences.size > 395,
    `distinct = ${distinctSequences.size}/400`
  );
  check(
    "first trial congruency varies across seeds (order shuffled, not blocked)",
    firstTrialCongruentVaries.size === 2
  );
}

section("recordTrial correctness");
{
  const stim: StroopStimulus = { word: "red", ink: "blue", congruent: false };
  const t1 = recordTrial(stim, "blue", 640);
  check("correct ink response flagged", t1.correct === true);
  check("trial fields copied", t1.word === "red" && t1.ink === "blue" && t1.congruent === false);
  check("rt passthrough", t1.rtMs === 640);
  const t2 = recordTrial(stim, "red", 900);
  check("word-reading response (the trap) is wrong", t2.correct === false);
  const congruentStim: StroopStimulus = { word: "green", ink: "green", congruent: true };
  const t3 = recordTrial(congruentStim, "green", 520);
  check("congruent trial correct on ink", t3.correct === true && t3.congruent === true);
}

section("median helper");
{
  check("odd sample", median([3, 1, 2]) === 2);
  check("even sample averages middle pair", median([4, 1, 3, 2]) === 2.5);
  check("empty is null", median([]) === null);
  check("single value", median([7]) === 7);
  check("input order irrelevant", median([900, 100, 500]) === median([100, 500, 900]));
}

section("scoreSession - anticipation exclusion + interference math");
{
  const mk = (
    word: StroopColorId,
    ink: StroopColorId,
    response: StroopColorId,
    rtMs: number
  ): StroopTrial => makeTrial({ word, ink, congruent: word === ink }, response, rtMs);

  const trials: StroopTrial[] = [
    mk("red", "red", "red", 400), // congruent correct
    mk("green", "green", "green", 480), // congruent correct (median)
    mk("blue", "blue", "blue", 560), // congruent correct
    mk("red", "blue", "blue", 640), // incongruent correct
    mk("red", "green", "green", 720), // incongruent correct (median)
    mk("red", "yellow", "yellow", 800), // incongruent correct
    mk("green", "green", "green", 150), // correct but ANTICIPATION (rt < 200)
    mk("blue", "blue", "red", 5000), // wrong, huge rt - must not touch medians
  ];
  const score = scoreSession(trials);
  check("session valid (7/8 = 87.5% >= 70%)", score.valid === true, String(score.accuracy));
  check("anticipation counted", score.anticipationCount === 1, String(score.anticipationCount));
  check(
    "anticipation excluded from congruent median (480, not 440)",
    score.medianCongruentMs === 480,
    String(score.medianCongruentMs)
  );
  check("incongruent median 720", score.medianIncongruentMs === 720, String(score.medianIncongruentMs));
  check("interference = 720 - 480 = 240", score.interferenceMs === 240, String(score.interferenceMs));
  check(
    "overall median RT = median(400,480,560,640,720,800) = 600",
    score.medianRtMs === 600,
    String(score.medianRtMs)
  );
  check("wrong trial with rt 5000 excluded from RT stats", score.medianRtMs !== 5000);
  check("counts preserved", score.totalResponses === 8 && score.correct === 7 && score.errors === 1);
  check("congruent/incongruent split 5/3", score.congruentTrials === 5 && score.incongruentTrials === 3);
  check("index present on valid session", score.stroopIndex >= IQ_MIN && score.stroopIndex <= IQ_MAX);
  check("percentile in 1..99", score.percentile >= 1 && score.percentile <= 99);
}

section("scoreSession - validity paths");
{
  const mk = (congruent: boolean, correct: boolean, rtMs: number): StroopTrial =>
    makeTrial(
      congruent
        ? { word: "red", ink: "red", congruent: true }
        : { word: "red", ink: "blue", congruent: false },
      correct ? (congruent ? "red" : "blue") : "green",
      rtMs
    );

  // 0 responses
  const empty = scoreSession([]);
  check("empty session invalid", empty.valid === false && empty.invalidReason !== null);

  // Exactly 70.0% accuracy (42/60) -> VALID (exact float boundary)
  const boundaryTrials = Array.from({ length: 60 }, (_, i) => mk(i % 2 === 0, i < 42, 800));
  const boundary = scoreSession(boundaryTrials);
  check(
    "42/60 = 70.0% accuracy exactly is VALID",
    boundary.valid === true,
    JSON.stringify({ acc: boundary.accuracy })
  );
  check("boundary session has 42 congruent + 18 incongruent", boundary.congruentTrials === 42);

  // 41/60 = 68.33% -> invalid
  const subTrials = Array.from({ length: 60 }, (_, i) => mk(i % 2 === 0, i < 41, 800));
  const sub = scoreSession(subTrials);
  check("41/60 = 68.3% accuracy invalid", sub.valid === false);
  check("reason mentions accuracy", (sub.invalidReason ?? "").toLowerCase().includes("accuracy"));

  // quick length: 9/12 = 75% valid, 8/12 = 66.7% invalid
  const qValid = scoreSession(Array.from({ length: 12 }, (_, i) => mk(i % 2 === 0, i < 9, 800)));
  check("9/12 = 75% accuracy valid", qValid.valid === true);
  const qInvalid = scoreSession(Array.from({ length: 12 }, (_, i) => mk(i % 2 === 0, i < 8, 800)));
  check("8/12 = 66.7% accuracy invalid", qInvalid.valid === false);

  // synthetic 69.9% (699/1000) -> invalid
  const almostTrials = Array.from({ length: 1000 }, (_, i) => mk(i % 2 === 0, i < 699, 800));
  const almost = scoreSession(almostTrials);
  check("699/1000 = 69.9% accuracy invalid", almost.valid === false, String(almost.accuracy));

  // perfect run valid
  const perfect = scoreSession(Array.from({ length: 60 }, (_, i) => mk(i % 2 === 0, true, 700)));
  check("60/60 valid", perfect.valid === true && perfect.stroopIndex > 0);

  // all responses are anticipations -> cannot compute interference
  const allAnticip = Array.from({ length: 12 }, (_, i) => mk(i % 2 === 0, true, 150));
  const anticipScore = scoreSession(allAnticip);
  check(
    "all-anticipation session invalid (no usable RTs)",
    anticipScore.valid === false &&
      (anticipScore.invalidReason ?? "").toLowerCase().includes("reaction times"),
    anticipScore.invalidReason ?? ""
  );
  check("all-anticipation count preserved", anticipScore.anticipationCount === 12);
}

section("Anti-gaming: mash + one-button spam simulations");
{
  const runMash = (mode: "random" | "fixed", seed: number) => {
    const rng = mulberry32(seed);
    const stimuli = buildStimuli(rng, TRIAL_COUNT);
    const trials = stimuli.map((s, i) => {
      const response =
        mode === "fixed" ? ("red" as StroopColorId) : COLOR_IDS[Math.floor(rng() * COLOR_IDS.length)]!;
      const rt = 250 + rng() * 650;
      return makeTrial(s, response, rt);
    });
    return scoreSession(trials);
  };

  const mashScores: SessionScore[] = [];
  for (let seed = 0; seed < 50; seed++) mashScores.push(runMash("random", 1000 + seed));
  const allMashInvalid = mashScores.every((s) => !s.valid);
  const meanMashAcc = mashScores.reduce((a, s) => a + s.accuracy, 0) / mashScores.length;
  check("random mash: all 50 sessions invalid", allMashInvalid);
  check(
    "random mash accuracy lands near chance 25%",
    meanMashAcc > 0.18 && meanMashAcc < 0.35,
    String(meanMashAcc.toFixed(3))
  );
  check(
    "mash reason mentions the accuracy floor",
    mashScores.every((s) => (s.invalidReason ?? "").includes("70%"))
  );

  const spamScores: SessionScore[] = [];
  for (let seed = 0; seed < 50; seed++) spamScores.push(runMash("fixed", 2000 + seed));
  const allSpamInvalid = spamScores.every((s) => !s.valid);
  const meanSpamAcc = spamScores.reduce((a, s) => a + s.accuracy, 0) / spamScores.length;
  check("spamming one button: all 50 sessions invalid", allSpamInvalid);
  check(
    "spam accuracy also near 25% (uniform ink)",
    meanSpamAcc > 0.15 && meanSpamAcc < 0.35,
    String(meanSpamAcc.toFixed(3))
  );
  check(
    "invalid sessions expose no index and no percentile",
    [...mashScores, ...spamScores].every((s) => s.stroopIndex === 0 && s.percentile === 0)
  );
}

section("stroopIndexFrom mapping");
{
  check("population-average performance -> index 100", stroopIndexFrom(750, 120) === 100);
  const faster = stroopIndexFrom(590, 120);
  const slower = stroopIndexFrom(910, 120);
  check("faster median RT -> higher index", faster > slower, `${faster} vs ${slower}`);
  const expectedFaster = Math.round(
    100 + (15 * (RT_WEIGHT * ((RT_POP_MEAN - 590) / RT_POP_SD) + INT_WEIGHT * 0)) / Z_NORM
  );
  check("index formula matches weights exactly", faster === expectedFaster, `${faster} vs ${expectedFaster}`);
  const lowInt = stroopIndexFrom(750, 60);
  const highInt = stroopIndexFrom(750, 180);
  check("smaller interference -> higher index", lowInt > highInt, `${lowInt} vs ${highInt}`);
  check(
    "interference soft-clamped at +450",
    stroopIndexFrom(750, 1000) === stroopIndexFrom(750, 450)
  );
  check("interference soft-clamped at -150", stroopIndexFrom(750, -500) === stroopIndexFrom(750, -150));
  check("median RT soft-clamped low", stroopIndexFrom(10, 120) === stroopIndexFrom(200, 120));
  check("median RT soft-clamped high", stroopIndexFrom(9000, 120) === stroopIndexFrom(3000, 120));
  check("absurd session clamps to IQ floor", stroopIndexFrom(3000, 450) === IQ_MIN);
  check("superhuman session clamps to IQ ceiling", stroopIndexFrom(200, -150) === IQ_MAX);
  check(
    "negative interference (reversal) is allowed",
    stroopIndexFrom(750, -40) > 100
  );
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check(
    "normalCdf(+1sd) ~ 0.8413",
    Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6
  );
}

section("indexToPercentile mapping");
{
  check("index 100 -> 50th percentile", indexToPercentile(100) === 50, String(indexToPercentile(100)));
  check("index 115 -> ~84th", indexToPercentile(115) === 84, String(indexToPercentile(115)));
  check("index 85 -> ~16th", indexToPercentile(85) === 16, String(indexToPercentile(85)));
  check("percentile clamped 1..99 low", indexToPercentile(IQ_MIN) === 1);
  check("percentile clamped 1..99 high", indexToPercentile(IQ_MAX) === 99);
  let monotonic = true;
  for (let idx = IQ_MIN; idx < IQ_MAX; idx += 1) {
    if (indexToPercentile(idx + 1) < indexToPercentile(idx)) monotonic = false;
  }
  check("percentile monotonic non-decreasing in index", monotonic);
}

section("gradeForIndex tiers");
{
  check("index 70 -> Deliberate", gradeForIndex(70).label === "Deliberate");
  check("index 84.9 -> Deliberate (boundary)", gradeForIndex(84.9).label === "Deliberate");
  check("index 85 -> Average", gradeForIndex(85).label === "Average");
  check("index 99.4 -> Average", gradeForIndex(99.4).label === "Average");
  check("index 100 -> Focused", gradeForIndex(100).label === "Focused");
  check("index 114.6 -> Focused", gradeForIndex(114.6).label === "Focused");
  check("index 115 -> Highly focused", gradeForIndex(115).label === "Highly focused");
  check("index 129 -> Highly focused", gradeForIndex(129).label === "Highly focused");
  check("index 130 -> Exceptional", gradeForIndex(130).label === "Exceptional");
  check("every grade has blurb + class", [70, 90, 105, 120, 135].every((p) => {
    const g = gradeForIndex(p);
    return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("Index monotonicity through the full pipeline");
{
  // Fixed interference (240ms), sweep congruent speed: faster -> higher index.
  const sessionAt = (congMs: number, incongExtra: number): SessionScore => {
    const trials: StroopTrial[] = [
      makeTrial({ word: "red", ink: "red", congruent: true }, "red", congMs),
      makeTrial({ word: "green", ink: "green", congruent: true }, "green", congMs),
      makeTrial({ word: "blue", ink: "blue", congruent: true }, "blue", congMs),
      makeTrial({ word: "red", ink: "blue", congruent: false }, "blue", congMs + incongExtra),
      makeTrial({ word: "red", ink: "green", congruent: false }, "green", congMs + incongExtra),
      makeTrial({ word: "red", ink: "yellow", congruent: false }, "yellow", congMs + incongExtra),
      makeTrial({ word: "red", ink: "blue", congruent: false }, "red", 900),
      makeTrial({ word: "red", ink: "green", congruent: false }, "red", 900),
    ];
    return scoreSession(trials);
  };
  let speedMonotonic = true;
  for (let cong = 400; cong <= 1000; cong += 100) {
    const a = sessionAt(cong, 240).stroopIndex;
    const b = sessionAt(cong + 100, 240).stroopIndex;
    if (b > a) speedMonotonic = false;
  }
  check("slower congruent RT never raises the index", speedMonotonic);

  // Fixed congruent pace, sweep interference 0 -> 400: bigger gap -> lower index.
  let interferenceMonotonic = true;
  for (let extra = 0; extra <= 400; extra += 100) {
    const a = sessionAt(600, extra).stroopIndex;
    const b = sessionAt(600, extra + 100).stroopIndex;
    if (b > a) interferenceMonotonic = false;
  }
  check("larger interference never raises the index", interferenceMonotonic);

  const base = sessionAt(600, 240);
  check(
    "pipeline session reports exact medians",
    base.medianCongruentMs === 600 &&
      base.medianIncongruentMs === 840 &&
      base.interferenceMs === 240,
    JSON.stringify({ c: base.medianCongruentMs, i: base.medianIncongruentMs })
  );
  check("pipeline accuracy = 6/8 = 75% valid", base.valid === true);
}

section("Population simulation (N=500 realistic profiles)");
{
  // Users span the population anchors: overall median RT ~750ms (SD 160)
  // and interference ~120ms (SD 55). Simulated RT = per-user congruent base
  // (750 - 160*skill - userInt/2) x lognormal noise, plus the congruency
  // effect; ~2% of taps are anticipations; errors rise slightly for fast,
  // careless users. A calibrated engine must land mean IQ ~100 (SD ~15).
  const iqSamples: number[] = [];
  const rtSamples: number[] = [];
  const intSamples: number[] = [];
  const accSamples: number[] = [];
  let allValid = true;

  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(50_000 + user);
    const skill = randn(rng); // -1 slow .. +1 fast
    const userInt = Math.min(300, Math.max(10, 120 + 55 * randn(rng)));
    const congBase = 750 - 160 * skill - userInt / 2;
    const incongBase = congBase + userInt;
    const errP = Math.min(0.1, Math.max(0.02, 0.06 - 0.02 * skill));

    const stimuli = buildStimuli(rng, TRIAL_COUNT);
    const trials: StroopTrial[] = stimuli.map((stimulus) => {
      const base = stimulus.congruent ? congBase : incongBase;
      let rt = Math.max(230, base * Math.exp(0.1 * randn(rng)));
      if (rng() < 0.02) rt = 120 + rng() * 70; // occasional anticipation tap
      const correct = rng() > errP;
      const response = correct
        ? stimulus.ink
        : COLOR_IDS.filter((id) => id !== stimulus.ink)[Math.floor(rng() * 3)]!;
      return makeTrial(stimulus, response, rt);
    });

    const score = scoreSession(trials);
    if (!score.valid) allValid = false;
    iqSamples.push(score.stroopIndex);
    rtSamples.push(score.medianRtMs ?? 0);
    intSamples.push(score.interferenceMs ?? 0);
    accSamples.push(score.accuracy);
  }

  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
  };
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanRt = mean(rtSamples);
  const meanInt = mean(intSamples);
  const meanAcc = mean(accSamples);

  check("all 500 realistic users produce valid scores", allValid);
  check(
    "mean median RT near population anchor 750ms (700-800)",
    meanRt > 700 && meanRt < 800,
    String(meanRt.toFixed(1))
  );
  check(
    "mean interference near population anchor 120ms (90-150)",
    meanInt > 90 && meanInt < 150,
    String(meanInt.toFixed(1))
  );
  check(
    "mean Stroop Index near 100 (98-102)",
    meanIq > 98 && meanIq < 102,
    String(meanIq.toFixed(2))
  );
  check(
    "Stroop Index SD in plausible band (12-19, target ~15)",
    sdIq > 12 && sdIq < 19,
    String(sdIq.toFixed(2))
  );
  check("simulated accuracy comfortably above floor (>= 85%)", meanAcc >= 0.85, String(meanAcc.toFixed(3)));
  console.log(
    `  info   sim N=500: mean index=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)} | mean medianRT=${meanRt.toFixed(
      0
    )}ms | mean interference=${meanInt.toFixed(0)}ms | mean accuracy=${(meanAcc * 100).toFixed(1)}%`
  );
}

section("End-to-end pipeline coherence (3 profiles, full simulation)");
{
  const runProfile = (seed: number, skill: number, intNoise: number) => {
    const rng = mulberry32(seed);
    const userInt = Math.min(300, Math.max(10, 120 + 55 * intNoise));
    const congBase = 750 - 160 * skill - userInt / 2;
    const incongBase = congBase + userInt;
    const errP = Math.min(0.1, Math.max(0.02, 0.06 - 0.02 * skill));
    const stimuli = buildStimuli(rng, TRIAL_COUNT);
    const trials: StroopTrial[] = stimuli.map((stimulus) => {
      const base = stimulus.congruent ? congBase : incongBase;
      const rt = Math.max(230, base * Math.exp(0.1 * randn(rng)));
      const correct = rng() > errP;
      const response = correct
        ? stimulus.ink
        : COLOR_IDS.filter((id) => id !== stimulus.ink)[Math.floor(rng() * 3)]!;
      return makeTrial(stimulus, response, rt);
    });
    return scoreSession(trials);
  };

  const slow = runProfile(11, -1.2, 0.8);
  const avg = runProfile(12, 0, 0);
  const fast = runProfile(13, 1.4, -0.8);
  check("all three profiles valid", slow.valid && avg.valid && fast.valid);
  check(
    "slow < avg < fast Stroop Index",
    slow.stroopIndex < avg.stroopIndex && avg.stroopIndex < fast.stroopIndex,
    `${slow.stroopIndex} < ${avg.stroopIndex} < ${fast.stroopIndex}`
  );
  check(
    "slow interference > avg > fast",
    (slow.interferenceMs ?? 0) > (avg.interferenceMs ?? 0) &&
      (avg.interferenceMs ?? 0) > (fast.interferenceMs ?? 0),
    `${slow.interferenceMs} > ${avg.interferenceMs} > ${fast.interferenceMs}`
  );
  check("slow accuracy >= floor", slow.accuracy >= ACCURACY_FLOOR, String(slow.accuracy));
  check("avg accuracy >= floor", avg.accuracy >= ACCURACY_FLOOR);
  check("fast accuracy >= floor", fast.accuracy >= ACCURACY_FLOOR);
  check(
    "fast grade tier strictly better than slow",
    gradeForIndex(fast.stroopIndex).label !== gradeForIndex(slow.stroopIndex).label
  );
  check(
    "percentiles follow the same ordering",
    slow.percentile < avg.percentile && avg.percentile < fast.percentile
  );
  console.log(
    `  info   slow: index ${slow.stroopIndex} (${slow.grade.label}), interference ${slow.interferenceMs}ms | avg: ${avg.stroopIndex} (${avg.grade.label}), ${avg.interferenceMs}ms | fast: ${fast.stroopIndex} (${fast.grade.label}), ${fast.interferenceMs}ms`
  );
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
