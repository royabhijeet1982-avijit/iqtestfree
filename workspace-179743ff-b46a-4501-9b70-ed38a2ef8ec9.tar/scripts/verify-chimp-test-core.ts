/* ------------------------------------------------------------------ */
/*  Unit verification for chimp-test-core.ts                           */
/*  Run: bun scripts/verify-chimp-test-core.ts                         */
/* ------------------------------------------------------------------ */

import {
  ACC_MEAN,
  ACC_WEIGHT,
  ACC_Z_CAP,
  BOT_GAP_MS,
  BOT_MIN_CHIPS,
  CLEARS_TO_ADVANCE,
  GRID_CELLS,
  GRID_COLS,
  GRID_ROWS,
  IQ_MAX,
  IQ_MIN,
  LEVEL_MEAN,
  LEVEL_SD,
  LEVEL_WEIGHT,
  MAX_LEVEL,
  PREFERRED_MIN_CHEBYSHEV,
  QUICK_LIVES,
  QUICK_START_N,
  START_LIVES,
  START_N,
  accuracyZOf,
  applyTap,
  chebyshevDistance,
  chipAtCell,
  compositeIq,
  dealNext,
  erf,
  formatRoundSeconds,
  gradeForIq,
  gradeTap,
  iqToPercentile,
  levelZOf,
  makeRound,
  mulberry32,
  newRun,
  normalCdf,
  placeChips,
  roundIsBotLike,
  runIsBotLike,
  scoreRun,
  type ChimpScore,
  type RoundRecord,
  type RunState,
} from "../src/components/test/chimp-test-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/** Standard normal sample via Box-Muller. */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function sd(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("grid is 8x6 = 48 cells", GRID_COLS === 8 && GRID_ROWS === 6 && GRID_CELLS === 48);
check("START_N is 4", START_N === 4, String(START_N));
check("QUICK_START_N is 3", QUICK_START_N === 3, String(QUICK_START_N));
check("START_LIVES is 3", START_LIVES === 3, String(START_LIVES));
check("QUICK_LIVES is 2", QUICK_LIVES === 2, String(QUICK_LIVES));
check("CLEARS_TO_ADVANCE is 3", CLEARS_TO_ADVANCE === 3);
check("MAX_LEVEL fits the grid", MAX_LEVEL <= GRID_CELLS);
check("bot thresholds (120ms, 5 chips)", BOT_GAP_MS === 120 && BOT_MIN_CHIPS === 5);
check(
  "population anchor sane (level 5.4/1.2)",
  LEVEL_MEAN === 5.4 && LEVEL_SD === 1.2,
  `mean=${LEVEL_MEAN} sd=${LEVEL_SD}`
);
check(
  "blend weights sum to 1",
  LEVEL_WEIGHT === 0.7 && ACC_WEIGHT === 0.3 && LEVEL_WEIGHT + ACC_WEIGHT === 1
);
check("IQ bounds ordered", IQ_MIN < 100 && 100 < IQ_MAX);

section("RNG determinism");
{
  const seqA = Array.from({ length: 20 }, () => mulberry32(42)());
  const seqB = Array.from({ length: 20 }, () => mulberry32(42)());
  const seqC = Array.from({ length: 20 }, () => mulberry32(43)());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
}

section("Placement invariants (150 seeds x N=1..12)");
{
  let allOk = true;
  for (let seed = 0; seed < 150; seed++) {
    const rng = mulberry32(seed);
    for (let n = 1; n <= 12; n++) {
      const chips = placeChips(n, rng);
      if (chips.length !== n) allOk = false;
      const cells = chips.map((c) => c.cell);
      if (new Set(cells).size !== n) allOk = false; // never overlapping
      if (!cells.every((cell) => Number.isInteger(cell) && cell >= 0 && cell < GRID_CELLS)) {
        allOk = false;
      }
      if (chips.some((c, i) => c.n !== i + 1)) allOk = false; // sorted 1..n
      if (
        chips.some(
          (c) => c.r !== Math.floor(c.cell / GRID_COLS) || c.c !== c.cell % GRID_COLS
        )
      ) {
        allOk = false;
      }
      // round-trips through chipAtCell
      const round = makeRound(n, rng);
      if (round.chips.length !== n) allOk = false;
      if (round.chips.some((c) => chipAtCell(round, c.cell)?.n !== c.n)) allOk = false;
      const emptyCell = Array.from({ length: GRID_CELLS }, (_, i) => i).find(
        (cell) => !round.chips.some((c) => c.cell === cell)
      );
      if (emptyCell !== undefined && chipAtCell(round, emptyCell) !== null) allOk = false;
    }
  }
  check("all 150x12 placements valid (distinct, in-range, sorted, no overlap)", allOk);
}

section("Spacing preference (soft constraint honoured most of the time)");
{
  let spaced = 0;
  const seeds = 150;
  for (let seed = 0; seed < seeds; seed++) {
    const chips = placeChips(6, mulberry32(seed));
    let minDist = Infinity;
    for (let i = 0; i < chips.length; i++) {
      for (let j = i + 1; j < chips.length; j++) {
        minDist = Math.min(
          minDist,
          chebyshevDistance(chips[i]!, { r: chips[j]!.r, c: chips[j]!.c })
        );
      }
    }
    if (minDist >= PREFERRED_MIN_CHEBYSHEV) spaced++;
  }
  const share = spaced / seeds;
  check(
    "most n=6 placements keep chips >= 2 Chebyshev apart",
    share > 0.8,
    `share=${share.toFixed(2)}`
  );
  check("chebyshev math", chebyshevDistance({ r: 0, c: 0 }, { r: 2, c: 1 }) === 2);
}

section("gradeTap correctness");
{
  const round = makeRound(5, mulberry32(7));
  const chip1 = round.chips[0]!;
  const chip2 = round.chips[1]!;
  check("tapping chip 1 first is correct", gradeTap(round, chip1.cell, 0).correct);
  check(
    "tapping chip 2 first is wrong (order)",
    gradeTap(round, chip2.cell, 0).correct === false
  );
  const emptyCell = Array.from({ length: GRID_CELLS }, (_, i) => i).find(
    (cell) => !round.chips.some((c) => c.cell === cell)
  )!;
  check("tapping an empty cell is wrong", gradeTap(round, emptyCell, 0).correct === false);
  check(
    "tapping chip 1 again at progress 1 is wrong",
    gradeTap(round, chip1.cell, 1).correct === false
  );
  check(
    "final chip completes the round",
    gradeTap(round, round.chips[4]!.cell, 4).complete === true
  );
}

/* ------------------------------------------------------------------ */
/*  State machine helpers                                              */
/* ------------------------------------------------------------------ */

/** Tap chips 1..n of the current round with fixed timing. */
function clearRound(st: RunState) {
  let res = applyTap(st, -1); // no-op placeholder to satisfy types
  for (let k = 1; k <= st.round.n; k++) {
    const chip = st.round.chips[k - 1]!;
    res = applyTap(st, chip.cell, { sincePrevMs: 400, roundMs: 400 * k });
    st = res.next;
  }
  return { st, res };
}

function failRound(st: RunState) {
  const expected = st.progress + 1;
  const wrong =
    st.round.chips.find((c) => c.n !== expected && c.n > st.progress) ?? st.round.chips[0]!;
  return applyTap(st, wrong.cell, { sincePrevMs: 350, roundMs: 350 });
}

section("State machine: quick mode config");
{
  const run = newRun(mulberry32(1), QUICK_START_N, QUICK_LIVES);
  check("quick run starts at N=3", run.level === 3 && run.round.n === 3);
  check("quick run has 2 lives", run.lives === 2 && run.maxLives === 2);
  check("quick run starts unmasked in show phase", run.phase === "show" && run.masked === false);
}

section("State machine: masking transitions");
{
  let run = newRun(mulberry32(2), 4, 3);
  const chip1 = run.round.chips[0]!;
  check("numbers visible before first tap", run.masked === false && run.progress === 0);
  const res = applyTap(run, chip1.cell, { sincePrevMs: 900, roundMs: 900 });
  run = res.next;
  check("first correct tap masks the board", run.masked === true);
  check("first correct tap enters recall", run.phase === "recall" && run.progress === 1);
  check("masking is not a round end", res.roundEnded === false);
  const chip2 = run.round.chips[1]!;
  run = applyTap(run, chip2.cell, { sincePrevMs: 500, roundMs: 1400 }).next;
  check("board stays masked on later taps", run.masked === true);
  const cleared = clearRound(run);
  check("mask persists through the final tap", cleared.st.masked === true);
  const dealt = dealNext(cleared.st);
  check("next deal unmasks and resets progress", dealt.masked === false && dealt.progress === 0);
  // Wrong FIRST tap: never masks.
  let run2 = newRun(mulberry32(3), 4, 3);
  const wrongFirst = run2.round.chips[1]!;
  const res2 = applyTap(run2, wrongFirst.cell, { sincePrevMs: 800, roundMs: 800 });
  check("wrong first tap keeps numbers visible", res2.next.masked === false);
}

section("State machine: 3 consecutive clears advance the level");
{
  let run = newRun(mulberry32(4), 4, 3);
  let advancedOn = -1;
  for (let roundIdx = 0; roundIdx < 3; roundIdx++) {
    const cleared = clearRound(run);
    run = cleared.st;
    if (cleared.res.advanced) advancedOn = roundIdx + 1;
    if (roundIdx < 2) {
      check(
        `clear ${roundIdx + 1} keeps level 4 (streak ${roundIdx + 1})`,
        run.level === 4 && run.streak === roundIdx + 1
      );
      run = dealNext(run);
    }
  }
  check("third consecutive clear advances to N=5", advancedOn === 3 && run.level === 5);
  check("streak resets after advancing", run.streak === 0);
  run = dealNext(run);
  check("next round dealt at the new level", run.phase === "show" && run.round.n === 5);
}

section("State machine: lives, streak reset, game over");
{
  let run = newRun(mulberry32(5), 4, 3);
  // clear, clear, FAIL -> streak resets, one life gone, no advance
  run = dealNext(clearRound(run).st);
  run = dealNext(clearRound(run).st);
  const failed = failRound(run);
  run = failed.next;
  check("wrong tap consumes exactly one life", run.lives === 2 && failed.lifeLost === true);
  check("wrong tap resets the streak", run.streak === 0);
  check("wrong tap ends the round (failed-feedback)", run.phase === "failed-feedback");
  check(
    "failed record: taps=1 correctTaps=0 (fresh-round fail)",
    run.records[2]!.taps === 1 && run.records[2]!.correctTaps === 0
  );
  check("failed record captured on level 4", run.records[2]!.n === 4);
  run = dealNext(run);
  check("retry deals the SAME level", run.level === 4 && run.round.n === 4);
  // three consecutive fails burn out
  let ended = false;
  for (let i = 0; i < 2; i++) {
    const f = failRound(run);
    run = f.next;
    if (run.phase === "done") ended = true;
    else run = dealNext(run);
  }
  check("0 lives ends the run (done phase)", ended && run.phase === "done");
  check("all 3 lives consumed", run.lives === 0);
  const afterDone = applyTap(run, run.round.chips[0]!.cell);
  check("taps are ignored after game over", afterDone.next === run && !afterDone.roundEnded);
  const dealtAfterDone = dealNext(run);
  check("dealNext is a no-op after game over", dealtAfterDone === run);
}

section("State machine: a fail between clears blocks the advance");
{
  let run = newRun(mulberry32(6), 4, 3);
  run = dealNext(clearRound(run).st); // streak 1
  run = dealNext(failRound(run).next); // streak 0, life 2
  run = dealNext(clearRound(run).st); // streak 1
  run = dealNext(clearRound(run).st); // streak 2
  check("two clears after a fail keep level 4", run.level === 4 && run.streak === 2);
  const cleared = clearRound(run);
  check(
    "third consecutive clear (after the fail) advances",
    cleared.res.advanced === true && cleared.st.level === 5
  );
}

section("State machine: level cap");
{
  let run = newRun(mulberry32(7), MAX_LEVEL, 99);
  for (let i = 0; i < 3; i++) {
    run = dealNext(clearRound(run).st);
  }
  check("level never exceeds MAX_LEVEL", run.level === MAX_LEVEL);
}

/* ------------------------------------------------------------------ */
/*  Bot-like detection                                                 */
/* ------------------------------------------------------------------ */

function record(
  n: number,
  cleared: boolean,
  intervals: number[],
  taps = cleared ? n : n
): RoundRecord {
  return {
    n,
    cleared,
    taps: cleared ? n : taps,
    correctTaps: cleared ? n : taps - 1,
    intervals,
    durationMs: intervals.reduce((a, b) => a + b, 0) + 600,
  };
}

section("Bot-like detection");
{
  const fast5 = record(5, true, [80, 80, 80, 80]);
  check("fast full 5-chip sequence is flagged", roundIsBotLike(fast5) === true);
  const human5 = record(5, true, [210, 180, 240, 190]);
  check("human-speed sequence is not flagged", roundIsBotLike(human5) === false);
  const oneSlow = record(5, true, [80, 80, 400, 80]);
  check("one slow gap saves the run (all gaps must be fast)", roundIsBotLike(oneSlow) === false);
  const fast4 = record(4, true, [80, 80, 80]);
  check(
    `rounds under ${BOT_MIN_CHIPS} chips are never flagged`,
    roundIsBotLike(fast4) === false
  );
  const failedFast = record(5, false, [80, 80, 80], 4);
  check("failed rounds are never flagged (full sequences only)", roundIsBotLike(failedFast) === false);
  const fast6 = record(6, true, [50, 50, 50, 50, 50]);
  check("fast 6-chip sequence flagged too", roundIsBotLike(fast6) === true);
  const mixedRun = [human5, fast5];
  const honestRun = [human5, record(6, true, [220, 210, 230, 200, 240])];
  check("runIsBotLike true when any round is bot-like", runIsBotLike(mixedRun) === true);
  check("runIsBotLike false for honest runs", runIsBotLike(honestRun) === false);
  check(
    "bot-like round record feeds scoreRun flag",
    scoreRun(mixedRun).botLike === true && scoreRun(honestRun).botLike === false
  );
}

/* ------------------------------------------------------------------ */
/*  Scoring paths                                                      */
/* ------------------------------------------------------------------ */

section("scoreRun: math on hand-built records");
{
  // 3 clears at 4 (advance to 5), then a first-tap fail at 5.
  const recsA = [
    record(4, true, [400, 400, 400]),
    record(4, true, [400, 400, 400]),
    record(4, true, [400, 400, 400]),
    record(5, false, [], 1),
  ];
  const a = scoreRun(recsA);
  check("levelReached = 5 (highest N played)", a.levelReached === 5);
  check("streakAtDeath = 0 (fatal round was a fail)", a.streakAtDeath === 0);
  check("effectiveLevel = 4.0", Math.abs(a.effectiveLevel - 4) < 1e-9, String(a.effectiveLevel));
  check("totalCleared = 3 of 4 rounds", a.totalCleared === 3 && a.totalRounds === 4);
  check("accuracy = 12/13", Math.abs(a.accuracy - 12 / 13) < 1e-9, String(a.accuracy));
  check(
    "meanRoundMs = mean of durations (1800x3 + 600)/4",
    Math.abs(a.meanRoundMs! - (1800 * 3 + 600) / 4) < 1e-9,
    String(a.meanRoundMs)
  );

  // Same ladder but two clears at 5 before dying there.
  const recsB = [
    record(4, true, [400, 400, 400]),
    record(4, true, [400, 400, 400]),
    record(4, true, [400, 400, 400]),
    record(5, true, [300, 300, 300, 300]),
    record(5, true, [300, 300, 300, 300]),
    record(5, false, [], 1),
  ];
  const b = scoreRun(recsB);
  check("streakAtDeath = 2", b.streakAtDeath === 2);
  check("effectiveLevel = 4 + 2/3", Math.abs(b.effectiveLevel - (4 + 2 / 3)) < 1e-9);
  check("accuracy = 22/23", Math.abs(b.accuracy - 22 / 23) < 1e-9);
  check("B scores higher IQ than A (more progress at same N)", b.iq > a.iq);

  // Immediate burnout at the start level.
  const recsC = [record(4, false, [], 1), record(4, false, [], 1), record(4, false, [], 1)];
  const c = scoreRun(recsC);
  check("burnout: levelReached = 4, eff = 3.0", c.levelReached === 4 && c.effectiveLevel === 3);
  check("burnout: accuracy = 0", c.accuracy === 0);
  check("burnout: honest low IQ", c.iq < 80, String(c.iq));

  // Empty run.
  const e = scoreRun([]);
  check("empty run: floor level", e.levelReached === START_N - 1 && e.totalRounds === 0);
  check("empty run: meanRoundMs null", e.meanRoundMs === null);
  check("empty run: iq in bounds", e.iq >= IQ_MIN && e.iq <= IQ_MAX);
}

section("IQ / percentile mapping and monotonicity");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check(
    "normalCdf(mean) = 0.5",
    Math.abs(normalCdf(LEVEL_MEAN, LEVEL_MEAN, LEVEL_SD) - 0.5) < 1e-9
  );
  check("level at mean -> IQ 100", compositeIq(LEVEL_MEAN, ACC_MEAN) === 100);
  check(
    "level z math",
    Math.abs(levelZOf(LEVEL_MEAN + LEVEL_SD) - 1) < 1e-9
  );
  check(
    "accuracy z anchored and clamped",
    accuracyZOf(ACC_MEAN) === 0 &&
      accuracyZOf(2) === ACC_Z_CAP &&
      accuracyZOf(-1) === -ACC_Z_CAP
  );
  let monoLevel = true;
  for (let lv = 1; lv <= 12; lv += 0.25) {
    if (compositeIq(lv + 0.25, 0.9) < compositeIq(lv, 0.9) - 1e-9) monoLevel = false;
  }
  check("IQ monotonic non-decreasing in effective level", monoLevel);
  let monoAcc = true;
  for (let acc = 0; acc <= 1; acc += 0.05) {
    if (compositeIq(5, acc + 0.05) < compositeIq(5, acc) - 1e-9) monoAcc = false;
  }
  check("IQ monotonic non-decreasing in accuracy", monoAcc);
  let monoPct = true;
  for (let iq = IQ_MIN; iq < IQ_MAX; iq++) {
    if (iqToPercentile(iq + 1) < iqToPercentile(iq)) monoPct = false;
  }
  check("percentile monotonic non-decreasing in IQ", monoPct);
  check("percentile clamps 1..99", iqToPercentile(IQ_MIN) === 1 && iqToPercentile(IQ_MAX) === 99);
  check("IQ 100 -> ~50th", iqToPercentile(100) === 50);
  check("IQ 115 -> ~84th", iqToPercentile(115) === 84);
  check("IQ clamped to bounds", compositeIq(12, 1) === IQ_MAX && compositeIq(1, 0) === IQ_MIN);
}

section("Grades");
{
  check("iq 70 -> Warming up", gradeForIq(70).label === "Warming up");
  check("iq 84.9 -> Warming up", gradeForIq(84.9).label === "Warming up");
  check("iq 85 -> Average", gradeForIq(85).label === "Average");
  check("iq 99 -> Average", gradeForIq(99).label === "Average");
  check("iq 100 -> Sharp", gradeForIq(100).label === "Sharp");
  check("iq 114 -> Sharp", gradeForIq(114).label === "Sharp");
  check("iq 115 -> Very sharp", gradeForIq(115).label === "Very sharp");
  check("iq 130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check(
    "every grade has label/blurb/class",
    [70, 90, 105, 120, 135].every((iq) => {
      const g = gradeForIq(iq);
      return g.label.length > 0 && g.blurb.length > 10 && g.className.length > 0;
    })
  );
}

section("formatRoundSeconds");
{
  check("1840 -> 1.8s", formatRoundSeconds(1840) === "1.8s");
  check("0 -> 0.0s", formatRoundSeconds(0) === "0.0s");
  check("negative clamps", formatRoundSeconds(-50) === "0.0s");
  check("2450 -> 2.5s", formatRoundSeconds(2450) === "2.5s");
}

/* ------------------------------------------------------------------ */
/*  Population simulation (N=500 untrained adults)                     */
/*  Honest play through the REAL engine state machine, with            */
/*  per-tap memory noise, motor slips and human tap timing.            */
/* ------------------------------------------------------------------ */

/* Sim tuning knobs (these model people, not the engine). */
const SIM_SLOPE = 0.053; // per-chip recall decay per level above START_N
const SIM_SKILL = 0.11; // per-chip recall shift per skill SD
const SIM_SLIP = 0.015; // motor-slip probability per tap
const SIM_BASE = 0.995; // per-chip recall at START_N for the average user

function recallProb(n: number, skill: number): number {
  return Math.min(0.999, Math.max(0.45, SIM_BASE - SIM_SLOPE * (n - START_N) + SIM_SKILL * skill));
}

function simulateUser(seed: number, quick = false): ChimpScore {
  const rng = mulberry32(seed);
  const skill = randn(rng);
  const startN = quick ? QUICK_START_N : START_N;
  const lives = quick ? QUICK_LIVES : START_LIVES;
  let state = newRun(rng, startN, lives);
  let guard = 0;
  let roundClock = 0;
  while (state.phase !== "done" && guard++ < 600) {
    if (state.phase === "show" || state.phase === "recall") {
      const expected = state.progress + 1;
      const gap = 320 + rng() * 480; // human taps: 320-800ms, never bot-like
      roundClock += gap;
      const slip = rng() < SIM_SLIP;
      const recalled = !slip && rng() < recallProb(state.level, skill);
      let cell: number;
      if (recalled) {
        cell = state.round.chips[expected - 1]!.cell;
      } else {
        const wrongs = state.round.chips.filter(
          (c) => c.n !== expected && c.n > state.progress
        );
        cell =
          wrongs.length > 0
            ? wrongs[Math.floor(rng() * wrongs.length)]!.cell
            : state.round.chips[expected - 1]!.cell; // last chip is forced
      }
      state = applyTap(state, cell, { sincePrevMs: gap, roundMs: roundClock }).next;
    } else {
      state = dealNext(state);
      roundClock = 0;
    }
  }
  return scoreRun(state.records);
}

section("Population simulation (500 users, default mode)");
{
  const scores: ChimpScore[] = [];
  for (let user = 0; user < 500; user++) {
    scores.push(simulateUser(10_000 + user));
  }
  const iqs = scores.map((s) => s.iq);
  const effs = scores.map((s) => s.effectiveLevel);
  const accs = scores.map((s) => s.accuracy);
  const meanIq = mean(iqs);
  const sdIq = sd(iqs);
  const meanEff = mean(effs);
  const meanAcc = mean(accs);
  const levels = scores.map((s) => s.levelReached);

  check("every simulated run finished with records", scores.every((s) => s.totalRounds >= 3));
  check("all IQs within 55..145", iqs.every((iq) => iq >= IQ_MIN && iq <= IQ_MAX));
  check("all percentiles within 1..99", scores.every((s) => s.percentile >= 1 && s.percentile <= 99));
  check("no simulated honest run is bot-like", scores.every((s) => s.botLike === false));
  check("levels within 3..MAX", levels.every((l) => l >= START_N - 1 && l <= MAX_LEVEL));
  check("mean IQ near 100 (98-102)", meanIq > 98 && meanIq < 102, meanIq.toFixed(2));
  check("IQ SD near 15 (11-19)", sdIq > 11 && sdIq < 19, sdIq.toFixed(2));
  check(
    "mean effective level near anchor 5.4 (5.1-5.7)",
    meanEff > 5.1 && meanEff < 5.7,
    meanEff.toFixed(2)
  );
  check(
    "mean accuracy near anchor (0.88-0.99)",
    meanAcc > 0.88 && meanAcc < 0.99,
    meanAcc.toFixed(3)
  );
  console.log(
    `  info   mean eff=${meanEff.toFixed(2)} (SD ${sd(effs).toFixed(2)}), mean acc=${meanAcc.toFixed(3)}, mean IQ=${meanIq.toFixed(2)}, SD=${sdIq.toFixed(2)}`
  );
  const worst = scores.reduce((a, b) => (b.iq < a.iq ? b : a));
  const best = scores.reduce((a, b) => (b.iq > a.iq ? b : a));
  console.log(
    `  info   spread: worst IQ ${worst.iq} (eff ${worst.effectiveLevel.toFixed(2)}), best IQ ${best.iq} (eff ${best.effectiveLevel.toFixed(2)})`
  );
}

section("Quick-mode simulation (100 users)");
{
  const scores: ChimpScore[] = [];
  for (let user = 0; user < 100; user++) {
    scores.push(simulateUser(50_000 + user, true));
  }
  check(
    "quick runs end honestly with <= 2 failed rounds",
    scores.every((s) => s.totalRounds - s.totalCleared <= QUICK_LIVES)
  );
  check("quick IQs in bounds", scores.every((s) => s.iq >= IQ_MIN && s.iq <= IQ_MAX));
  const meanIqQuick = mean(scores.map((s) => s.iq));
  check("quick mean IQ below default (easier entry, fewer lives)", meanIqQuick < 110, meanIqQuick.toFixed(2));
  console.log(`  info   quick mean IQ=${meanIqQuick.toFixed(2)} SD=${sd(scores.map((s) => s.iq)).toFixed(2)}`);
}

section("End-to-end pipeline coherence (3 skill profiles)");
{
  const slow = simulateUser(777, false);
  const avg = simulateUser(778, false);
  const fast = simulateUser(779, false);
  // Single-seed profiles can be noisy; assert ordering of the blended IQ
  // with a tolerance by comparing against their own effective levels.
  const trio = [
    { s: slow, tag: "slow" },
    { s: avg, tag: "avg" },
    { s: fast, tag: "fast" },
  ];
  check("all three profiles produced valid scores", trio.every((t) => t.s.totalRounds >= 3));
  check("profiles differ across seeds", new Set(trio.map((t) => t.s.iq)).size >= 2);
  check(
    "IQ ordering matches effective level ordering (per pair)",
    trio.every(
      (t) =>
        Math.sign(t.s.iq - 100) === 0 ||
        Math.sign(t.s.effectiveLevel - LEVEL_MEAN) === 0 ||
        Math.sign(t.s.iq - 100) === Math.sign(t.s.effectiveLevel - LEVEL_MEAN)
    )
  );
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
