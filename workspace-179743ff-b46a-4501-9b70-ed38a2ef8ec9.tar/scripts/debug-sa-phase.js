const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 375, height: 667 } });
  await page.goto("http://localhost:3000/test/sustained-attention?quick=1", { waitUntil: "networkidle" });
  await page.click('[data-testid="sa-intro-cta"]');
  const seen = {};
  for (let i = 0; i < 120; i++) {
    const st = await page
      .evaluate(() => {
        const stage = document.querySelector('[data-testid="sa-stage"]');
        const digitEl = document.querySelector('[data-testid="sa-digit"]');
        return {
          stageExists: !!stage,
          phase: stage ? stage.getAttribute("data-phase") : null,
          trial: stage ? stage.getAttribute("data-trial") : null,
          digit: digitEl ? digitEl.getAttribute("data-digit") : null,
          htmlSnippet: stage ? stage.outerHTML.slice(0, 200) : null,
        };
      })
      .catch((e) => ({ err: String(e).slice(0, 100) }));
    const key = `${st.phase}|${st.digit !== null ? "digitShown" : "noDigit"}`;
    seen[key] = (seen[key] || 0) + 1;
    if (i === 30 || i === 60) console.log(i, JSON.stringify(st).slice(0, 260));
    await sleep(15);
  }
  console.log("DISTRIBUTION:", JSON.stringify(seen, null, 1));
  await browser.close();
})();
