/* ------------------------------------------------------------------ */
/*  Unit verification for visual-memory-core.ts                        */
/*  Run: bun scripts/verify-visual-memory-core.ts                      */
/* ------------------------------------------------------------------ */

import {
  BASE_OFF_MS,
  BASE_ON_MS,
  GRID_TILES,
  IQ_MAX,
  IQ_MIN,
  MIN_ON_MS,
  QUICK_LIVES,
  SPAN_FLOOR,
  SPAN_MEAN,
  SPAN_SD,
  SPAN_WEIGHT,
  SPEED_STEP_MS,
  SPEED_WEIGHT,
  SPEED_Z_CAP,
  START_LIVES,
  START_LEVEL,
  compositeIq,
  erf,
  gradeForIq,
  gradeClick,
  iqToPercentile,
  makeDistinctSequence,
  makeSequence,
  mulberry32,
  normalCdf,
  scoreRun,
  speedForLevel,
  speedZFromRecall,
  type LevelAttempt,
  type VisualMemoryScore,
} from "../src/components/test/visual-memory-core";

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("GRID_TILES is 9 (3x3)", GRID_TILES === 9, String(GRID_TILES));
check("START_LEVEL is 3", START_LEVEL === 3, String(START_LEVEL));
check("BASE_ON_MS is 700", BASE_ON_MS === 700, String(BASE_ON_MS));
check("BASE_OFF_MS is 250", BASE_OFF_MS === 250, String(BASE_OFF_MS));
check("MIN_ON_MS is 280", MIN_ON_MS === 280, String(MIN_ON_MS));
check("SPEED_STEP_MS is 60", SPEED_STEP_MS === 60, String(SPEED_STEP_MS));
check("START_LIVES is 2", START_LIVES === 2, String(START_LIVES));
check("QUICK_LIVES is 1", QUICK_LIVES === 1, String(QUICK_LIVES));
check("SPAN_FLOOR is 2", SPAN_FLOOR === 2, String(SPAN_FLOOR));
check(
  "population anchor 5.3 / 1.4",
  SPAN_MEAN === 5.3 && SPAN_SD === 1.4,
  `mean=${SPAN_MEAN} sd=${SPAN_SD}`
);
check(
  "weights 0.8 span / 0.2 speed",
  SPAN_WEIGHT === 0.8 && SPEED_WEIGHT === 0.2
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("makeSequence invariants (200 seeds x levels 3..12 = 2000 sequences)");
{
  let allOk = true;
  let noImmediateRepeat = true;
  let lengthsOk = true;
  for (let seed = 0; seed < 200; seed++) {
    const rng = mulberry32(seed);
    for (let level = 3; level <= 12; level++) {
      const seq = makeSequence(level, rng);
      if (seq.length !== level) lengthsOk = false;
      if (!seq.every((t) => Number.isInteger(t) && t >= 0 && t < GRID_TILES)) allOk = false;
      for (let i = 1; i < seq.length; i++) {
        if (seq[i] === seq[i - 1]) noImmediateRepeat = false;
      }
    }
  }
  check("every length equals its level", lengthsOk);
  check("tiles always within 0..8", allOk);
  check("no tile repeats immediately", noImmediateRepeat);
}

section("makeSequence distribution (tile coverage + uniformity)");
{
  const firstCounts = new Array<number>(GRID_TILES).fill(0);
  const tileCounts = new Array<number>(GRID_TILES).fill(0);
  const N = 900;
  for (let seed = 0; seed < N; seed++) {
    const seq = makeSequence(3, mulberry32(20_000 + seed));
    firstCounts[seq[0]!]! += 1;
    for (const t of seq) tileCounts[t]! += 1;
  }
  const expectedFirst = N / GRID_TILES;
  check(
    "every tile appears as a first tile (within 60%-140%)",
    firstCounts.every((c) => c > expectedFirst * 0.6 && c < expectedFirst * 1.4),
    firstCounts.join(",")
  );
  const expectedTiles = (N * 3) / GRID_TILES;
  check(
    "overall tile usage roughly uniform (within 80%-120%)",
    tileCounts.every((c) => c > expectedTiles * 0.8 && c < expectedTiles * 1.2),
    tileCounts.join(",")
  );
}

section("makeDistinctSequence (retry anti-memorisation)");
{
  const previous = [2, 7, 4];
  let alwaysDistinct = true;
  let noRepeatRule = true;
  for (let seed = 0; seed < 500; seed++) {
    const seq = makeDistinctSequence(3, mulberry32(seed), previous);
    if (seq.join(",") === previous.join(",")) alwaysDistinct = false;
    for (let i = 1; i < seq.length; i++) {
      if (seq[i] === seq[i - 1]) noRepeatRule = false;
    }
  }
  check("retry NEVER replays the failed sequence (500 seeds)", alwaysDistinct);
  check("retry sequences keep the no-immediate-repeat rule", noRepeatRule);

  const unique = new Set<string>();
  for (let seed = 0; seed < 200; seed++) {
    unique.add(makeSequence(5, mulberry32(50_000 + seed)).join(","));
  }
  check(
    "level-5 sequences are genuinely random across seeds (>=150 unique of 200)",
    unique.size >= 150,
    `unique=${unique.size}`
  );

  // adversarial: previous that shares a first tile with most redraws
  const prev2 = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  let distinctLong = true;
  for (let seed = 0; seed < 300; seed++) {
    const seq = makeDistinctSequence(9, mulberry32(90_000 + seed), prev2);
    if (seq.join(",") === prev2.join(",")) distinctLong = false;
  }
  check("distinct guarantee holds at level 9 too", distinctLong);
}

section("gradeClick paths");
{
  const seq = [3, 0, 8, 5];
  check("correct mid-sequence", gradeClick(seq, 0, 3).correct === true && gradeClick(seq, 0, 3).complete === false);
  check("correct second position", gradeClick(seq, 1, 0).correct === true);
  check("final correct click completes", gradeClick(seq, 3, 5).correct === true && gradeClick(seq, 3, 5).complete === true);
  check("non-final correct click not complete", gradeClick(seq, 2, 8).complete === false);
  check("wrong tile flagged", gradeClick(seq, 0, 4).correct === false && gradeClick(seq, 0, 4).complete === false);
  check("right tile wrong slot is wrong", gradeClick(seq, 2, 0).correct === false);
  check("index beyond sequence is wrong", gradeClick(seq, 10, 3).correct === false);
  const single = [6];
  check("single-tile sequence completes on first click", gradeClick(single, 0, 6).complete === true);
}

section("speedForLevel (fixed playback timing)");
{
  check("level 3 -> 700ms on", speedForLevel(3).onMs === 700);
  check("level 3 -> 250ms off", speedForLevel(3).offMs === 250);
  check("level 4 -> 640ms on", speedForLevel(4).onMs === 640);
  check("level 5 -> 580ms on", speedForLevel(5).onMs === 580);
  check("level 7 -> 460ms on", speedForLevel(7).onMs === 460);
  check("level 10 -> 280ms on", speedForLevel(10).onMs === 280);
  check("level 15 -> clamped at 280ms floor", speedForLevel(15).onMs === 280);
  let monotonic = true;
  for (let lv = 3; lv < 20; lv++) {
    if (speedForLevel(lv + 1).onMs > speedForLevel(lv).onMs) monotonic = false;
  }
  check("on-time never increases with level", monotonic);
  check("off-time constant at every level", [3, 5, 8, 13, 21].every((lv) => speedForLevel(lv).offMs === 250));
}

section("speedZFromRecall (small, capped speed bonus)");
{
  check("null recall -> neutral 0", speedZFromRecall(null) === 0);
  check("900ms -> z 0", Math.abs(speedZFromRecall(900)) < 1e-9);
  check("500ms -> z 1", Math.abs(speedZFromRecall(500) - 1) < 1e-9);
  check("1300ms -> z -1", Math.abs(speedZFromRecall(1300) + 1) < 1e-9);
  check("very fast 100ms -> capped +2", speedZFromRecall(100) === SPEED_Z_CAP);
  check("very slow 5000ms -> capped -2", speedZFromRecall(5000) === -SPEED_Z_CAP);
  let inBounds = true;
  for (let ms = 0; ms <= 6000; ms += 50) {
    const z = speedZFromRecall(ms);
    if (z < -SPEED_Z_CAP || z > SPEED_Z_CAP) inBounds = false;
  }
  check("speed z always within [-2, +2]", inBounds);
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check("normalCdf(+1sd) ~ 0.8413", Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6);
}

section("compositeIq (span-anchored IQ scale)");
{
  check("span 5.3, neutral speed -> IQ 100", compositeIq(5.3, 0) === 100, String(compositeIq(5.3, 0)));
  check("floor span 2 -> honest low 72", compositeIq(SPAN_FLOOR, 0) === 72, String(compositeIq(SPAN_FLOOR, 0)));
  check("span 6.7 (1sd) -> IQ 112", compositeIq(6.7, 0) === 112, String(compositeIq(6.7, 0)));
  check("span 3.9 (-1sd) -> IQ 88", compositeIq(3.9, 0) === 88, String(compositeIq(3.9, 0)));
  check("max speed bonus at mean span -> 106", compositeIq(5.3, SPEED_Z_CAP) === 106);
  check("max speed penalty at mean span -> 94", compositeIq(5.3, -SPEED_Z_CAP) === 94);
  check("extreme low clamps to 55", compositeIq(0, -SPEED_Z_CAP) === IQ_MIN);
  check("extreme high clamps to 145", compositeIq(20, SPEED_Z_CAP) === IQ_MAX);
  let monotonic = true;
  for (let span = 0; span <= 15; span += 0.5) {
    if (compositeIq(span + 0.5, 0) < compositeIq(span, 0)) monotonic = false;
  }
  check("IQ monotonic non-decreasing in span", monotonic);
  let bounded = true;
  for (let span = -5; span <= 25; span += 0.5) {
    for (const sz of [-2, -1, 0, 1, 2]) {
      const iq = compositeIq(span, sz);
      if (iq < IQ_MIN || iq > IQ_MAX) bounded = false;
    }
  }
  check("IQ always clamped to [55, 145]", bounded);
}

section("iqToPercentile");
{
  check("IQ 100 -> 50th", iqToPercentile(100) === 50, String(iqToPercentile(100)));
  check("IQ 115 -> ~84th", iqToPercentile(115) === 84, String(iqToPercentile(115)));
  check("IQ 85 -> ~16th", iqToPercentile(85) === 16, String(iqToPercentile(85)));
  check("IQ 55 clamps to 1st", iqToPercentile(IQ_MIN) === 1);
  check("IQ 145 clamps to 99th", iqToPercentile(IQ_MAX) === 99);
  let monotonic = true;
  for (let iq = IQ_MIN; iq < IQ_MAX; iq++) {
    if (iqToPercentile(iq + 1) < iqToPercentile(iq)) monotonic = false;
  }
  check("percentile monotonic non-decreasing in IQ", monotonic);
}

section("gradeForIq tiers");
{
  check("IQ 70 -> Building", gradeForIq(70).label === "Building");
  check("IQ 84.9 -> Building (boundary)", gradeForIq(84.9).label === "Building");
  check("IQ 85 -> Average", gradeForIq(85).label === "Average");
  check("IQ 99.4 -> Average", gradeForIq(99.4).label === "Average");
  check("IQ 100 -> Sharp", gradeForIq(100).label === "Sharp");
  check("IQ 114.6 -> Sharp", gradeForIq(114.6).label === "Sharp");
  check("IQ 115 -> Very sharp", gradeForIq(115).label === "Very sharp");
  check("IQ 129 -> Very sharp", gradeForIq(129).label === "Very sharp");
  check("IQ 130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check("every grade has blurb + class", [70, 90, 105, 120, 135].every((q) => {
    const g = gradeForIq(q);
    return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("scoreRun - golden path (clear 3..6, fail 7)");
{
  const attempts: LevelAttempt[] = [
    { level: 3, sequence: [1, 2, 3], correctClicks: 3, cleared: true },
    { level: 4, sequence: [4, 5, 6, 7], correctClicks: 4, cleared: true },
    { level: 5, sequence: [8, 0, 1, 2, 3], correctClicks: 5, cleared: true },
    { level: 6, sequence: [4, 3, 2, 1, 0, 8], correctClicks: 6, cleared: true },
    { level: 7, sequence: [5, 6, 7, 8, 0, 1, 2], correctClicks: 0, cleared: false },
  ];
  const score = scoreRun(attempts, Array.from({ length: 18 }, (_, i) => 600 + i * 10));
  check("span = 6 (highest cleared)", score.span === 6, String(score.span));
  check("tilesCorrect = 18", score.tilesCorrect === 18, String(score.tilesCorrect));
  check("attempts = 5", score.attempts === 5);
  check(
    "ladder 3..7 with 7 failed",
    score.ladder.length === 5 &&
      score.ladder.every((r, i) => r.level === i + 3) &&
      score.ladder[4]!.cleared === false &&
      score.ladder[0]!.cleared === true
  );
  check("mean recall computed", score.meanRecallMs !== null && Math.abs(score.meanRecallMs - 685) < 1e-9, String(score.meanRecallMs));
  check("iq = compositeIq(span, speedZ)", score.iq === compositeIq(score.span, score.speedZ));
  check("percentile matches IQ", score.percentile === iqToPercentile(score.iq));
  check("grade matches IQ", score.grade.label === gradeForIq(score.iq).label);
}

section("scoreRun - floor path (fail twice at level 3)");
{
  const attempts: LevelAttempt[] = [
    { level: 3, sequence: [1, 2, 3], correctClicks: 0, cleared: false },
    { level: 3, sequence: [4, 5, 6], correctClicks: 1, cleared: false },
  ];
  const score = scoreRun(attempts, [400]);
  check("run still scores (no crash)", typeof score.iq === "number" && Number.isFinite(score.iq));
  check("span floored at 2", score.span === SPAN_FLOOR, String(score.span));
  check("honest low IQ below Average tier", score.iq < 85, String(score.iq));
  check("tilesCorrect = 1", score.tilesCorrect === 1);
  check("ladder single failed level 3", score.ladder.length === 1 && score.ladder[0]!.level === 3 && !score.ladder[0]!.cleared);
  check("percentile clamped 1..99", score.percentile >= 1 && score.percentile <= 99);
}

section("scoreRun - retry-then-clear path");
{
  // fail L3 (life 1) -> clear L3 -> clear L4 -> fail L5 (life 2) -> end
  const attempts: LevelAttempt[] = [
    { level: 3, sequence: [1, 2, 3], correctClicks: 0, cleared: false },
    { level: 3, sequence: [7, 4, 1], correctClicks: 3, cleared: true },
    { level: 4, sequence: [2, 5, 8, 0], correctClicks: 4, cleared: true },
    { level: 5, sequence: [3, 6, 0, 1, 2], correctClicks: 2, cleared: false },
  ];
  const score = scoreRun(attempts, []);
  check("span = 4 (best cleared)", score.span === 4, String(score.span));
  check("tilesCorrect = 9 (effort counted in failed attempts)", score.tilesCorrect === 9, String(score.tilesCorrect));
  check("attempts = 4", score.attempts === 4);
  check("ladder 3,4,5 with 5 failed", score.ladder.length === 3 && !score.ladder[2]!.cleared && score.ladder[1]!.cleared);
  check("empty recall rts -> neutral speed", score.speedZ === 0 && score.meanRecallMs === null);
}

section("End-to-end pipeline coherence (3 simulated profiles)");
{
  const runProfile = (seed: number, mu: number, k: number, clickBase: number) => {
    const rng = mulberry32(seed);
    const attempts: LevelAttempt[] = [];
    const recallRts: number[] = [];
    let lives = START_LIVES;
    let level = START_LEVEL;
    while (lives > 0 && level < 20) {
      const seq = makeSequence(level, rng);
      const pPass = 1 / (1 + Math.exp((level - mu) / k));
      const pass = rng() < pPass;
      const correctClicks = pass ? level : Math.floor(rng() * level);
      for (let i = 0; i < correctClicks; i++) {
        recallRts.push(Math.max(250, clickBase * Math.exp(0.35 * randn(rng))));
      }
      attempts.push({ level, sequence: seq, correctClicks, cleared: pass });
      if (pass) level += 1;
      else lives -= 1;
    }
    return scoreRun(attempts, recallRts);
  };
  const weak = runProfile(1, 3.3, 0.85, 1150);
  const avg = runProfile(101, 5.2, 0.85, 950);
  const strong = runProfile(201, 7.7, 0.85, 640);
  check("all profiles produce finite scores", [weak, avg, strong].every((s) => Number.isFinite(s.iq) && Number.isFinite(s.percentile)));
  check("weak < avg < strong span", weak.span < avg.span && avg.span < strong.span,
    `${weak.span} < ${avg.span} < ${strong.span}`);
  check("weak < avg < strong IQ", weak.iq < avg.iq && avg.iq < strong.iq,
    `${weak.iq} < ${avg.iq} < ${strong.iq}`);
  check("strong faster recall than weak",
    (strong.meanRecallMs ?? 1e9) < (weak.meanRecallMs ?? 0));
  check("weak percentile <= avg <= strong", weak.percentile <= avg.percentile && avg.percentile <= strong.percentile);
  console.log(`  info   weak: span ${weak.span} IQ ${weak.iq} P${weak.percentile} | avg: span ${avg.span} IQ ${avg.iq} P${avg.percentile} | strong: span ${strong.span} IQ ${strong.iq} P${strong.percentile}`);
}

section("Population simulation (N=500 realistic staircase users)");
{
  // Each user gets a skill-driven mean span ability; per-level pass
  // probability follows a logistic psychometric curve; recall speed
  // scales with skill. Nothing here is used by the engine - it only
  // validates that the scoring maps a realistic population to ~100/15.
  const MU_BASE = 5.5;
  const MU_SLOPE = 1.3;
  const K = 1.0;
  const iqSamples: number[] = [];
  const spanSamples: number[] = [];
  for (let user = 0; user < 500; user++) {
    const rng = mulberry32(300_000 + user);
    const skill = randn(rng);
    const mu = MU_BASE + MU_SLOPE * skill;
    const clickBase = 950 * Math.exp(-0.28 * skill);
    const attempts: LevelAttempt[] = [];
    const recallRts: number[] = [];
    let lives = START_LIVES;
    let level = START_LEVEL;
    while (lives > 0 && level < 20) {
      const seq = makeSequence(level, rng);
      const pPass = 1 / (1 + Math.exp((level - mu) / K));
      const pass = rng() < pPass;
      const correctClicks = pass ? level : Math.floor(rng() * level);
      for (let i = 0; i < correctClicks; i++) {
        recallRts.push(Math.max(250, clickBase * Math.exp(0.35 * randn(rng))));
      }
      attempts.push({ level, sequence: seq, correctClicks, cleared: pass });
      if (pass) level += 1;
      else lives -= 1;
    }
    const score: VisualMemoryScore = scoreRun(attempts, recallRts);
    iqSamples.push(score.iq);
    spanSamples.push(score.span);
  }
  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
  };
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanSpan = mean(spanSamples);
  const sdSpan = sd(spanSamples);
  check("mean IQ within 100 +/- 2 (98..102)", meanIq > 98 && meanIq < 102, String(meanIq.toFixed(2)));
  check("IQ SD ~ 15 (13..17)", sdIq > 13 && sdIq < 17, String(sdIq.toFixed(2)));
  check("mean span near adult anchor 5.3 (4.9..5.7)", meanSpan > 4.9 && meanSpan < 5.7, String(meanSpan.toFixed(2)));
  console.log(`  info   simulated mean IQ=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)} | mean span=${meanSpan.toFixed(2)} span SD=${sdSpan.toFixed(2)}`);
}

section("Quick mode contract");
{
  check("quick run uses 1 life", QUICK_LIVES === 1 && START_LIVES === 2);
  // A quick-mode user fails once -> run over, single attempt recorded.
  const quickAttempts: LevelAttempt[] = [
    { level: 3, sequence: [1, 2, 3], correctClicks: 2, cleared: false },
  ];
  const quickScore = scoreRun(quickAttempts, [500, 480]);
  check("quick run ends after one failed attempt", quickScore.attempts === 1);
  check("quick failed run still floors span at 2", quickScore.span === SPAN_FLOOR);
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
