/**
 * Quick screenshots for Sustained Attention page (intro + digit stream).
 * Run: node scripts/screenshot-sustained-attention.js
 * Outputs: scripts/sa-intro.png, scripts/sa-stream.png
 * (Results view is verified numerically by verify-sustained-attention-flow.js)
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();

  // Desktop intro
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const dpage = await desktop.newPage();
  await dpage.goto(`${BASE}/test/sustained-attention`, { waitUntil: "networkidle" });
  await dpage.waitForTimeout(600);
  await dpage.screenshot({ path: "scripts/sa-intro.png", fullPage: false });
  console.log("saved scripts/sa-intro.png");
  await desktop.close();

  // Mobile digit phase (normal mode so the digit lingers 250ms)
  const mobile = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const mpage = await mobile.newPage();
  await mpage.goto(`${BASE}/test/sustained-attention`, { waitUntil: "networkidle" });
  await mpage.click('[data-testid="sa-intro-cta"]');
  let reached = false;
  for (let i = 0; i < 300; i++) {
    const phase = await mpage
      .$eval('[data-testid="sa-stage"]', (el) => el.getAttribute("data-phase"))
      .catch(() => null);
    if (phase === "digit") { reached = true; break; }
    await sleep(15);
  }
  if (reached) {
    await mpage.waitForTimeout(80);
    await mpage.screenshot({ path: "scripts/sa-stream.png", fullPage: false });
    console.log("saved scripts/sa-stream.png");
  } else {
    console.log("digit phase not reached in time - screenshot skipped");
  }
  await mobile.close();

  await browser.close();
  console.log("done");
})();
