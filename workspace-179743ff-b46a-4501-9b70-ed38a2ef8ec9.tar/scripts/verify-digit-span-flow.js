/**
 * Task 24-b verification: Digit Span test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-digit-span-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1): every shown digit is READ from the DOM
 *    (data-testid="ds-digit" while visible) and typed back via the
 *    ds-pad-btn-* buttons - forward phase as shown, backward phase
 *    reversed. Results assert both spans + IQ + percentile + ladder.
 *  - Chips/undo/clear exercised during the first input stage.
 *  - Retake: sequences differ between runs (anti-memorisation).
 *  - Anti-gaming: wrong input at the very first attempt of each phase
 *    -> run terminates cleanly with floor spans and an honest low IQ.
 *  - 375px: no horizontal overflow on intro / active / results.
 *  - zero console/page errors.
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function attachErrorCapture(page, errors) {
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
}

async function gotoWithRetry(p, url) {
  let lastRes = null;
  for (let i = 0; i < 3; i++) {
    lastRes = await p.goto(url, { waitUntil: "networkidle", timeout: 60000 });
    if (lastRes && lastRes.ok()) return lastRes;
    await sleep(2000);
  }
  throw new Error(`page did not load ok: ${url} (${lastRes ? lastRes.status() : "null"})`);
}

/** Poll the IQ chip until CountUp finishes animating (starts at 0). */
async function readIq(p) {
  let prev = -1;
  for (let i = 0; i < 40; i++) {
    const t = await p.$eval('[data-testid="ds-iq"]', (el) => el.textContent.trim()).catch(() => "0");
    const n = Number(t);
    if (Number.isFinite(n) && n > 0 && n === prev) return n; // stable across two reads
    prev = n;
    await sleep(150);
  }
  return 0;
}

/**
 * Read every shown digit from the DOM while the display stage is up.
 * The current digit lives in [data-testid="ds-digit"] with data-pos;
 * the stage carries data-total. Polls until the input stage opens.
 */
async function captureSequence(p) {
  const byPos = new Map();
  let total = 0;
  const deadline = Date.now() + 60_000;
  let firstPoll = true;
  while (Date.now() < deadline) {
    const inputOpen = await p.$('[data-testid="ds-input"]');
    if (firstPoll && inputOpen) {
      throw new Error("capture entered with input already open (display phase missed)");
    }
    firstPoll = false;
    const digitEl = await p.$('[data-testid="ds-digit"]');
    if (digitEl) {
      const info = await digitEl.evaluate((el) => ({
        text: el.textContent.trim(),
        pos: Number(el.getAttribute("data-pos")),
      }));
      if (info.text !== "" && info.pos >= 0 && !byPos.has(info.pos)) {
        byPos.set(info.pos, Number(info.text));
      }
    }
    if (inputOpen) {
      // The display stage (with data-total) UNMOUNTS when the input opens,
      // so derive the length from the captured positions: 0..N-1 all seen.
      total = byPos.size;
      break;
    }
    await sleep(30);
  }
  const seq = [];
  for (let i = 0; i < total; i++) seq.push(byPos.get(i));
  return { total, seq };
}

/** Type a sequence via the on-screen pad buttons.
 *  Waits for each button (the input stage mounts with an entrance
 *  animation) and verifies every press registered as a chip. */
async function typeSequence(p, seq) {
  for (let i = 0; i < seq.length; i++) {
    const d = seq[i];
    let btn = null;
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline) {
      btn = await p.$(`[data-testid="ds-pad-btn-${d}"]`);
      if (btn) break;
      await sleep(40);
    }
    if (!btn) throw new Error(`pad button ${d} never appeared`);
    const before = (await p.$$('[data-testid="ds-chip"]')).length;
    await btn.evaluate((el) => el.click());
    let registered = false;
    for (let t = 0; t < 25 && !registered; t++) {
      await sleep(30);
      registered = (await p.$$('[data-testid="ds-chip"]')).length > before;
    }
    if (!registered) {
      // one retry - guards against clicks swallowed during mount animation
      await btn.evaluate((el) => el.click());
      for (let t = 0; t < 25 && !registered; t++) {
        await sleep(30);
        registered = (await p.$$('[data-testid="ds-chip"]')).length > before;
      }
      if (!registered) throw new Error(`press on ${d} did not register`);
    }
  }
}

async function clickSubmit(p) {
  const submit = await p.$('[data-testid="ds-submit"]');
  if (submit) await submit.evaluate((el) => el.click());
}

/** Submit a guaranteed-wrong input: n nines (targets never repeat adjacent digits). */
async function submitWrong(p) {
  await p.waitForSelector('[data-testid="ds-digit-stage"]', { timeout: 15000 });
  const total = await p.$eval('[data-testid="ds-digit-stage"]', (el) =>
    Number(el.getAttribute("data-total"))
  );
  // The pad only mounts once the display ends and the input stage opens.
  await p.waitForFunction(
    () => !!document.querySelector('[data-testid="ds-pad-btn-9"]'),
    { timeout: 30000 }
  );
  for (let i = 0; i < total; i++) {
    const btn = await p.$('[data-testid="ds-pad-btn-9"]');
    await btn.evaluate((el) => el.click());
    await sleep(20);
  }
  await clickSubmit(p);
  return total;
}

/**
 * Play one phase to its end by following the DOM exposure.
 * dir "forward" types the captured sequence as shown; dir "backward"
 * types it reversed. Returns the captured sequences (one per attempt).
 */
async function playPhase(p, dir, { exerciseEditing = false } = {}) {
  const seqs = [];
  const endSel =
    dir === "forward" ? '[data-testid="ds-interphase"]' : '[data-testid="ds-results"]';
  const deadline = Date.now() + 240_000;
  let firstAttempt = true;
  while (Date.now() < deadline) {
    if (await p.$(endSel)) break;
    if (await p.$('[data-testid="ds-results"]')) break;
    const stage = await p.$('[data-testid="ds-digit-stage"]');
    if (!stage) { await sleep(40); continue; }

    const cap = await captureSequence(p);
    if (cap.seq.length === 0) { await sleep(120); continue; } // transient pre-display poll
    if (cap.seq.length !== cap.total || cap.seq.some((d) => !Number.isInteger(d))) {
      throw new Error(`capture incomplete for ${dir}: ${JSON.stringify(cap)}`);
    }
    seqs.push(cap.seq);

    await sleep(350); // let the input stage finish its entrance animation

    if (exerciseEditing && firstAttempt) {
      const padCount = await p.$$eval('[data-testid^="ds-pad-btn-"]', (els) => els.length);
      padCount === 10 ? ok("pad has 10 digit buttons (0-9)") : fail(`pad buttons: ${padCount}`);
      // chips + undo + clear exercise on the first input stage
      await typeSequence(p, cap.seq.slice(0, 2));
      const chipTexts = await p.$$eval('[data-testid="ds-chip"]', (els) =>
        els.map((el) => el.textContent.trim())
      );
      JSON.stringify(chipTexts) === JSON.stringify(cap.seq.slice(0, 2).map(String))
        ? ok(`chips mirror typed digits: [${chipTexts.join(",")}]`)
        : fail(`chips wrong: ${JSON.stringify(chipTexts)}`);
      const undo = await p.$('[data-testid="ds-undo"]');
      await undo.evaluate((el) => el.click());
      await sleep(60);
      const afterUndo = await p.$$eval('[data-testid="ds-chip"]', (els) => els.length);
      afterUndo === 1 ? ok("undo removes one chip") : fail(`undo: ${afterUndo} chips left`);
      const clear = await p.$('[data-testid="ds-clear"]');
      await clear.evaluate((el) => el.click());
      await sleep(60);
      const afterClear = await p.$$eval('[data-testid="ds-chip"]', (els) => els.length);
      afterClear === 0 ? ok("clear empties the chips") : fail(`clear: ${afterClear} chips left`);
    }
    firstAttempt = false;

    const answer = dir === "backward" ? cap.seq.slice().reverse() : cap.seq;
    await typeSequence(p, answer);
    await clickSubmit(p);

    const wDeadline = Date.now() + 20_000;
    while (Date.now() < wDeadline) {
      if (await p.$(endSel)) break;
      if (await p.$('[data-testid="ds-results"]')) break;
      if (!(await p.$('[data-testid="ds-submit"]'))) { await sleep(120); break; }
      await sleep(40);
    }
  }
  return seqs;
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  attachErrorCapture(p, errors);

  /* ---------------- SEO surface ---------------- */
  await gotoWithRetry(p, `${BASE}/test/digit-span`);
  console.log("— SEO checks —");
  const title = await p.title();
  title === "Free Digit Span Test - Number Memory | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("digit span test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/digit-span"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/digit-span"
    ? ok("BreadcrumbList: BrainMetrics > Digit Span Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="ds-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok(`FAQPage JSON-LD has 6 questions`)
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok(`visible FAQ has 6 items`)
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Digit") && h1.includes("Span Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const relatedText = await p.$eval("main", (el) => el.textContent);
  relatedText.includes("Try another test")
    ? ok("RelatedTests band rendered")
    : fail("RelatedTests band missing");

  /* ---------------- Run 1: golden path (quick mode) ---------------- */
  console.log("— Run 1: golden path (?quick=1, DOM-following play) —");
  await gotoWithRetry(p, `${BASE}/test/digit-span?quick=1`);
  const intro = await p.$('[data-testid="ds-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  await noHorizontalOverflow(p, "intro");
  const startBtn = await p.$('[data-testid="ds-intro-cta"]');
  if (!startBtn) { fail("intro CTA missing"); return finish(browser, errors); }
  await startBtn.click();

  await p.waitForSelector('[data-testid="ds-phase-forward"]', { timeout: 10000 });
  ok("forward phase started");
  await p.waitForSelector('[data-testid="ds-digit-stage"]', { timeout: 10000 });
  const attemptInfo = await p.$eval('[data-testid="ds-attempt-info"]', (el) => el.textContent.trim());
  /Length 4 · attempt 1 of 1/.test(attemptInfo)
    ? ok(`attempt info: "${attemptInfo}"`)
    : fail(`attempt info: ${attemptInfo}`);
  const fwdSeqs = await playPhase(p, "forward", { exerciseEditing: true });
  fwdSeqs.length >= 5
    ? ok(`forward played ${fwdSeqs.length} lengths (first: [${fwdSeqs[0].join(",")}])`)
    : fail(`forward only ${fwdSeqs.length} lengths survived`);
  await noHorizontalOverflow(p, "input stage");

  await p.waitForSelector('[data-testid="ds-interphase"]', { timeout: 10000 });
  const interphaseSpan = await p.$eval('[data-testid="ds-interphase-span"]', (el) =>
    Number(el.textContent.trim())
  );
  interphaseSpan >= 4
    ? ok(`interphase shows forward span ${interphaseSpan}`)
    : fail(`interphase span: ${interphaseSpan}`);
  const interCta = await p.$('[data-testid="ds-interphase-cta"]');
  await interCta.evaluate((el) => el.click());

  await p.waitForSelector('[data-testid="ds-phase-backward"]', { timeout: 10000 });
  ok("backward phase started");
  const bwdSeqs = await playPhase(p, "backward");
  bwdSeqs.length >= 5
    ? ok(`backward played ${bwdSeqs.length} lengths (first: [${bwdSeqs[0].join(",")}])`)
    : fail(`backward only ${bwdSeqs.length} lengths survived`);

  await p.waitForSelector('[data-testid="ds-results"]', { timeout: 10000 });
  ok("results screen reached");
  const iq = await readIq(p);
  iq >= 55 && iq <= 145 ? ok(`IQ: ${iq} (in range)`) : fail(`IQ: ${iq}`);
  const grade = await p.$eval('[data-testid="ds-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const pctText = await p.$eval('[data-testid="ds-percentile"]', (el) => el.textContent.trim());
  const pct = Number((pctText.match(/\d+/) || ["0"])[0]);
  pct >= 1 && pct <= 99 && pctText.includes("100 adults")
    ? ok(`percentile line: ${pctText}`)
    : fail(`percentile: ${pctText}`);
  const fwdSpan = await p.$eval('[data-testid="ds-forward-span"] p', (el) => Number(el.textContent.trim()));
  const bwdSpan = await p.$eval('[data-testid="ds-backward-span"] p', (el) => Number(el.textContent.trim()));
  const totalSpan = await p.$eval('[data-testid="ds-total-span"] p', (el) => Number(el.textContent.trim()));
  fwdSpan >= 4 ? ok(`forward span: ${fwdSpan}`) : fail(`forward span: ${fwdSpan}`);
  bwdSpan >= 4 ? ok(`backward span: ${bwdSpan}`) : fail(`backward span: ${bwdSpan}`);
  totalSpan === fwdSpan + bwdSpan
    ? ok(`total span ${totalSpan} = ${fwdSpan} + ${bwdSpan}`)
    : fail(`total span ${totalSpan} != ${fwdSpan} + ${bwdSpan}`);
  const fwdDots = await p.$$eval('[data-testid^="ds-ladder-forward-"]', (els) => els.length);
  const bwdDots = await p.$$eval('[data-testid^="ds-ladder-backward-"]', (els) => els.length);
  fwdDots === fwdSeqs.length
    ? ok(`forward ladder shows ${fwdDots} attempt dots`)
    : fail(`forward ladder dots ${fwdDots} != attempts ${fwdSeqs.length}`);
  bwdDots === bwdSeqs.length
    ? ok(`backward ladder shows ${bwdDots} attempt dots`)
    : fail(`backward ladder dots ${bwdDots} != attempts ${bwdSeqs.length}`);
  const quickNote = await p.$('[data-testid="ds-quick-note"]');
  quickNote ? ok("quick-mode note shown") : fail("quick-mode note missing");
  await noHorizontalOverflow(p, "results");

  /* ---------------- Run 2: retake, new sequences ---------------- */
  console.log("— Run 2: retake -> sequences re-randomised —");
  const retakeBtn = await p.$('[data-testid="ds-retake"]');
  if (!retakeBtn) { fail("retake button missing"); return finish(browser, errors); }
  await retakeBtn.evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="ds-phase-forward"]', { timeout: 10000 });
  const fwdSeqs2 = await playPhase(p, "forward");
  fwdSeqs2.length >= 1 ? ok(`retake forward first seq: [${fwdSeqs2[0].join(",")}]`) : fail("retake captured nothing");
  const seq1 = JSON.stringify(fwdSeqs[0]);
  const seq2 = JSON.stringify(fwdSeqs2[0]);
  seq1 !== seq2
    ? ok("first sequences differ between runs (anti-memorisation)")
    : fail("retake reused the same first sequence!");
  await p.waitForSelector('[data-testid="ds-interphase"]', { timeout: 10000 });
  ok("retake reached the interphase card");

  /* ---------------- Run 3: anti-gaming (wrong input) ---------------- */
  console.log("— Run 3: wrong input at first attempt -> honest floor —");
  await gotoWithRetry(p, `${BASE}/test/digit-span?quick=1`);
  await (await p.$('[data-testid="ds-intro-cta"]')).evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="ds-phase-forward"]', { timeout: 10000 });
  await submitWrong(p);
  await p.waitForSelector('[data-testid="ds-interphase"]', { timeout: 15000 });
  ok("forward phase terminated after the failed first attempt");
  await (await p.$('[data-testid="ds-interphase-cta"]')).evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="ds-phase-backward"]', { timeout: 10000 });
  await submitWrong(p);
  await p.waitForSelector('[data-testid="ds-results"]', { timeout: 15000 });
  ok("backward phase terminated after the failed first attempt");
  const agFwd = await p.$eval('[data-testid="ds-forward-span"] p', (el) => Number(el.textContent.trim()));
  const agBwd = await p.$eval('[data-testid="ds-backward-span"] p', (el) => Number(el.textContent.trim()));
  agFwd === 0 && agBwd === 0
    ? ok("floor spans (0 forward, 0 backward)")
    : fail(`floor spans expected, got fwd=${agFwd} bwd=${agBwd}`);
  const agIq = await readIq(p);
  agIq <= 70 ? ok(`honest low IQ: ${agIq}`) : fail(`IQ inflated on an all-wrong run: ${agIq}`);
  const agPctText = await p.$eval('[data-testid="ds-percentile"]', (el) => el.textContent.trim());
  const agPct = Number((agPctText.match(/\d+/) || ["99"])[0]);
  agPct <= 5 ? ok(`honest low percentile: ${agPctText}`) : fail(`percentile inflated: ${agPctText}`);
  const agLadderFwd = await p.$$eval('[data-testid^="ds-ladder-forward-"]', (els) => els.length);
  agLadderFwd === 1 ? ok("ladder records the single failed attempt") : fail(`ladder dots: ${agLadderFwd}`);
  const gradeOnFloor = await p.$eval('[data-testid="ds-grade"]', (el) => el.textContent.trim());
  gradeOnFloor.includes("Building")
    ? ok(`floor grade: ${gradeOnFloor}`)
    : fail(`floor grade: ${gradeOnFloor}`);

  /* ---------------- Mobile 375px: full run ---------------- */
  console.log("— Mobile 375px (full quick run) —");
  const mp = await ctx.newPage();
  attachErrorCapture(mp, errors);
  await mp.setViewportSize({ width: 375, height: 740 });
  await gotoWithRetry(mp, `${BASE}/test/digit-span?quick=1`);
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="ds-intro-cta"]')).evaluate((el) => el.click());
  await mp.waitForSelector('[data-testid="ds-digit-stage"]', { timeout: 10000 });
  await noHorizontalOverflow(mp, "digit display");
  const mFwd = await playPhase(mp, "forward");
  await mp.waitForSelector('[data-testid="ds-interphase"]', { timeout: 10000 });
  await (await mp.$('[data-testid="ds-interphase-cta"]')).evaluate((el) => el.click());
  await mp.waitForSelector('[data-testid="ds-phase-backward"]', { timeout: 10000 });
  const mBwd = await playPhase(mp, "backward");
  await mp.waitForSelector('[data-testid="ds-results"]', { timeout: 10000 });
  await noHorizontalOverflow(mp, "results");
  const mIq = await readIq(mp);
  mIq >= 55 && mIq <= 145 ? ok(`mobile IQ: ${mIq}`) : fail(`mobile IQ: ${mIq}`);
  mFwd.length >= 5 && mBwd.length >= 5
    ? ok(`mobile full run played (${mFwd.length} fwd / ${mBwd.length} bwd lengths)`)
    : fail(`mobile run short: ${mFwd.length} fwd / ${mBwd.length} bwd`);
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
