/* ------------------------------------------------------------------ */
/*  Unit verification for pattern-memory-core.ts                       */
/*  Run: bun scripts/verify-pattern-memory-core.ts                     */
/* ------------------------------------------------------------------ */

import {
  AFTER_SHOW_GAP_MS,
  AFTER_SHOW_GAP_MS_QUICK,
  CELL_COUNT,
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  GRID_SIZE,
  IQ_MAX,
  IQ_MIN,
  PRE_SHOW_MS,
  PRE_SHOW_MS_QUICK,
  ROUND_PATTERN_SIZES,
  ROUND_PEEKS,
  SCORE_MEAN,
  SCORE_SD,
  SHOW_MS,
  SHOW_MS_QUICK,
  TOTAL_SESSION_CELLS,
  buildPatternMemorySession,
  chebyshev,
  colOf,
  drawPattern,
  gradeForIq,
  iqToPercentile,
  mulberry32,
  patternIndex,
  rowOf,
  scoreSession,
  scoreSessionWithSession,
  shuffled,
  type Recall,
} from "../src/components/test/pattern-memory-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("GRID_SIZE is 5", GRID_SIZE === 5);
check("CELL_COUNT is 25", CELL_COUNT === 25);
check(
  "ROUND_PATTERN_SIZES is [3,4,5,6,7,8]",
  JSON.stringify(ROUND_PATTERN_SIZES) === "[3,4,5,6,7,8]"
);
check("ROUND_PEEKS is [2,2,1,1,0,0]", JSON.stringify(ROUND_PEEKS) === "[2,2,1,1,0,0]");
check("SHOW_MS strictly decreasing", SHOW_MS.every((v, i) => i === 0 || v < SHOW_MS[i - 1]!));
check(
  "quick timings all shorter than normal",
  SHOW_MS.every((v, i) => SHOW_MS_QUICK[i]! < v) &&
    AFTER_SHOW_GAP_MS_QUICK < AFTER_SHOW_GAP_MS &&
    FEEDBACK_MS_QUICK < FEEDBACK_MS &&
    PRE_SHOW_MS_QUICK < PRE_SHOW_MS
);
check(
  "population anchor 0.60 / 0.13",
  SCORE_MEAN === 0.6 && SCORE_SD === 0.13,
  `mean=${SCORE_MEAN} sd=${SCORE_SD}`
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);
check("TOTAL_SESSION_CELLS is 33", TOTAL_SESSION_CELLS === 33, String(TOTAL_SESSION_CELLS));

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("Board geometry helpers");
{
  check("rowOf(0) = 0, rowOf(24) = 4", rowOf(0) === 0 && rowOf(24) === 4);
  check("colOf(0) = 0, colOf(24) = 4", colOf(0) === 0 && colOf(24) === 4);
  check("rowOf(12) = 2, colOf(12) = 2", rowOf(12) === 2 && colOf(12) === 2);
  check("chebyshev same cell is 0", chebyshev(7, 7) === 0);
  check("chebyshev horizontal neighbours is 1", chebyshev(6, 7) === 1);
  check("chebyshev diagonal neighbours is 1", chebyshev(6, 12) === 1);
  check("chebyshev across board is 4", chebyshev(0, 24) === 4);
}

section("Session building: structure");
{
  const s = buildPatternMemorySession(12345);
  check("6 rounds", s.rounds.length === 6);
  check(
    "sizes match ROUND_PATTERN_SIZES",
    JSON.stringify(s.rounds.map((r) => r.size)) === JSON.stringify([3, 4, 5, 6, 7, 8])
  );
  check(
    "peeks match ROUND_PEEKS",
    JSON.stringify(s.rounds.map((r) => r.peeks)) === JSON.stringify([2, 2, 1, 1, 0, 0])
  );
  check(
    "showMs match SHOW_MS",
    JSON.stringify(s.rounds.map((r) => r.showMs)) === JSON.stringify(SHOW_MS)
  );
  check("every round has the right number of cells", s.rounds.every((r) => r.cells.length === r.size));
  const allInRange = s.rounds.every((r) => r.cells.every((c) => Number.isInteger(c) && c >= 0 && c < 25));
  check("all cell indices in 0..24", allInRange);
  const allDistinct = s.rounds.every((r) => new Set(r.cells).size === r.cells.length);
  check("no duplicate cells within a pattern", allDistinct);
  const sorted = s.rounds.every(
    (r) => JSON.stringify(r.cells) === JSON.stringify([...r.cells].sort((a, b) => a - b))
  );
  check("cells stored sorted ascending", sorted);
}

section("Session building: pattern quality rules");
{
  // Exhaustive over many seeds - the two quality rules are hard promises.
  let minSpacingViolation: string | null = null;
  let linePattern: string | null = null;
  for (let seed = 1; seed <= 300; seed++) {
    const s = buildPatternMemorySession(seed);
    for (const r of s.rounds) {
      for (let i = 0; i < r.cells.length; i++) {
        for (let j = i + 1; j < r.cells.length; j++) {
          if (chebyshev(r.cells[i]!, r.cells[j]!) < 2) {
            minSpacingViolation = `seed ${seed} round ${r.round}: ${r.cells[i]},${r.cells[j]}`;
          }
        }
      }
      const rows = new Set(r.cells.map(rowOf));
      const cols = new Set(r.cells.map(colOf));
      if (rows.size < 2 || cols.size < 2) linePattern = `seed ${seed} round ${r.round}`;
    }
    if (minSpacingViolation || linePattern) break;
  }
  check("no two pattern cells directly adjacent (min spacing 2)", minSpacingViolation === null, minSpacingViolation ?? "");
  check("no pattern confined to a single row or column", linePattern === null, linePattern ?? "");
}

section("Session building: reshuffle across seeds");
{
  const a = buildPatternMemorySession(1).rounds[0]!.cells.join(",");
  const b = buildPatternMemorySession(2).rounds[0]!.cells.join(",");
  const c = buildPatternMemorySession(999999).rounds[0]!.cells.join(",");
  check("different seeds give different patterns", a !== b || b !== c);
  const same = buildPatternMemorySession(777).rounds[2]!.cells.join(",");
  const same2 = buildPatternMemorySession(777).rounds[2]!.cells.join(",");
  check("same seed reproduces exactly", same === same2);
}

section("drawPattern edge cases");
{
  const rng = mulberry32(9);
  const single = drawPattern(1, rng);
  check("size 1 returns one valid cell", single.length === 1 && single[0]! >= 0 && single[0]! < 25);
  const big = drawPattern(8, rng);
  check("size 8 returns 8 distinct valid cells", big.length === 8 && new Set(big).size === 8);
  let threw = false;
  try {
    drawPattern(0, rng);
  } catch {
    threw = true;
  }
  check("size 0 throws", threw);
}

section("Scoring: perfect run");
{
  const session = buildPatternMemorySession(500);
  const recalls: Recall[] = session.rounds.map((r) => ({
    round: r.round,
    clicked: [...r.cells],
    peeksUsed: 0,
    rtMs: 1200,
  }));
  const score = scoreSessionWithSession(recalls, session);
  check("perfect accuracy 1.0", score.accuracy === 1, String(score.accuracy));
  check("perfect IQ is 145", score.iq === 145, String(score.iq));
  check("hits equal total cells 33", score.hits === 33 && score.totalCells === 33);
  check("zero wrong clicks", score.wrong === 0);
  check("percentile 99", score.percentile === 99);
  check("grade is Photographic", score.grade.label === "Photographic");
  check("avgRtMs present", score.avgRtMs !== null);
}

section("Scoring: mash-everything anti-gaming");
{
  const session = buildPatternMemorySession(500);
  const allCells = Array.from({ length: 25 }, (_, i) => i);
  const recalls: Recall[] = session.rounds.map((r) => ({
    round: r.round,
    clicked: allCells,
    peeksUsed: r.peeks,
    rtMs: 900,
  }));
  const score = scoreSessionWithSession(recalls, session);
  check("mash accuracy floors to 0", score.accuracy === 0, String(score.accuracy));
  check("mash IQ pins to 55", score.iq === 55, String(score.iq));
  check("percentile 1", score.percentile === 1);
  check("grade is Fading", score.grade.label === "Fading");
  check("wrong clicks counted", score.wrong === session.rounds.reduce((a, r) => a + (25 - r.size), 0));
  check("peeks capped at availability", score.peeksUsed <= score.peeksAvailable);
}

section("Scoring: wrong clicks cancel hits, never go negative");
{
  const session = buildPatternMemorySession(600);
  const r0 = session.rounds[0]!;
  // Click 2 correct + 5 wrong on a 3-cell pattern: (2-5)/3 -> floored 0.
  const recalls: Recall[] = [
    { round: 0, clicked: [...r0.cells.slice(0, 2), 0, 1, 2, 3, 4], peeksUsed: 0, rtMs: 1500 },
  ];
  const score = scoreSessionWithSession(recalls, session);
  check("round 0 floors at 0 with 2 hits 5 wrong", score.rounds[0]!.score === 0);
  check("absent rounds score 0", score.rounds[1]!.score === 0 && score.rounds[5]!.score === 0);
  check("accuracy = mean of six round scores", Math.abs(score.accuracy - score.rounds.reduce((a, s) => a + s.score, 0) / 6) < 1e-12);
}

section("Scoring: degenerate and partial sessions");
{
  const score = scoreSession([]);
  check("empty session -> IQ 55", score.iq === 55 && score.accuracy === 0);
  const session = buildPatternMemorySession(700);
  const partial = scoreSessionWithSession(
    [{ round: 2, clicked: [...session.rounds[2]!.cells], peeksUsed: 0, rtMs: null }],
    session
  );
  check("one perfect round of six -> 1/6 accuracy", Math.abs(partial.accuracy - 1 / 6) < 1e-9, String(partial.accuracy));
  check("avgRtMs null when only rtMs-less recalls", score.avgRtMs === null);
  check(
    "out-of-range cells ignored safely",
    scoreSessionWithSession([{ round: 0, clicked: [-3, 99, ...session.rounds[0]!.cells], peeksUsed: 0, rtMs: 100 }], session)
      .rounds[0]!.hits === 3
  );
  const nullSession = scoreSessionWithSession(
    [{ round: 0, clicked: [0, 1, 2], peeksUsed: 0, rtMs: 100 }],
    null
  );
  check("null session scores floor", nullSession.iq === 55 && nullSession.rounds.length === 0);
}

section("Index + percentile coherence");
{
  check("anchor mean 0.60 maps to IQ 100", patternIndex(0.6) === 100);
  check("0 gives IQ 55", patternIndex(0) === 55);
  check("1 gives IQ 145", patternIndex(1) === 145);
  check("clamped inside 55..145 over a fine sweep", true);
  let clamps = true;
  for (let i = -20; i <= 120; i++) {
    const iq = patternIndex(i / 100);
    if (iq < IQ_MIN || iq > IQ_MAX) clamps = false;
  }
  check("sweep stays within bounds", clamps);
  check("percentile always matches the IQ", iqToPercentile(100) >= 49 && iqToPercentile(100) <= 51);
  check("iqToPercentile(55) = 1", iqToPercentile(55) === 1);
  check("iqToPercentile(145) = 99", iqToPercentile(145) === 99);
}

section("Grading ladder");
{
  check("gradeForIq(60) Fading", gradeForIq(60).label === "Fading");
  check("gradeForIq(90) Average", gradeForIq(90).label === "Average");
  check("gradeForIq(105) Sharp", gradeForIq(105).label === "Sharp");
  check("gradeForIq(120) Very sharp", gradeForIq(120).label === "Very sharp");
  check("gradeForIq(140) Photographic", gradeForIq(140).label === "Photographic");
}

section("Statistical sanity: anchors produce the intended spread");
{
  // Simulate 400 random-strategy runs: mean round score should land far
  // below the 0.60 anchor (random clicking nets ~size/25 - misses).
  let sum = 0;
  const n = 400;
  for (let seed = 1; seed <= n; seed++) {
    const rng = mulberry32(seed * 7919);
    const session = buildPatternMemorySession(seed);
    const recalls: Recall[] = session.rounds.map((r) => {
      const clicks = shuffled(
        Array.from({ length: 25 }, (_, i) => i),
        rng
      ).slice(0, r.size);
      return { round: r.round, clicked: clicks, peeksUsed: 0, rtMs: null };
    });
    sum += scoreSessionWithSession(recalls, session).accuracy;
  }
  const randomMean = sum / n;
  // Expected per-round score for a size-matched random clicker is
  // 2*size/25 - 1 < 0 for every size, so flooring pins rounds at 0 and
  // only rare lucky overlaps lift the mean slightly above 0.
  check("random clicking floors near zero (anti-gaming works)", randomMean >= 0 && randomMean < 0.15, String(randomMean.toFixed(3)));
  check("random mean far below the 0.60 anchor", randomMean < 0.35, String(randomMean.toFixed(3)));
}

console.log(`\n----------------------------------------`);
console.log(`TOTAL: ${pass + fail}  PASS: ${pass}  FAIL: ${fail}`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
