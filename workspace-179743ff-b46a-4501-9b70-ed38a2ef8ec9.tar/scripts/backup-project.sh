#!/usr/bin/env bash
# ============================================================
# BrainMetrics Backup Script (Layer 2 + 3 protection)
# ------------------------------------------------------------
# Protects ALL created pages against deletion for any reason:
#   1. Auto-commits any dirty work into git (Layer 1)
#   2. Git bundle (FULL history) -> in-project  /home/z/my-project/backups
#   3. Git bundle + full tree tarball -> OUT-of-project /home/z/brainmetrics-backups
#      (survives a workspace-level rollback of /home/z/my-project)
#   4. Keeps last 10 of each backup type (retention)
#
# Usage:  bash scripts/backup-project.sh
# Restore: bash scripts/restore-project.sh --help
# ============================================================
set -euo pipefail

PROJECT="/home/z/my-project"
IN_PROJ="$PROJECT/backups"
OUT_PROJ="/home/z/brainmetrics-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"

mkdir -p "$IN_PROJ" "$OUT_PROJ"

cd "$PROJECT"

# ---- Step 1: never bundle an uncommitted workspace ----
DIRTY="$(git status --porcelain || true)"
if [ -n "$DIRTY" ]; then
  git add -A
  git commit -m "auto-backup: snapshot $STAMP (dirty tree auto-committed before bundling)" --quiet || true
  echo "[backup] dirty tree auto-committed"
fi

# ---- Step 2: git bundle = entire repo history in ONE file ----
BUNDLE="$OUT_PROJ/repo-$STAMP.bundle"
git bundle create "$BUNDLE" --all --quiet
git bundle verify "$BUNDLE" > /dev/null 2>&1 || { echo "[backup] ERROR: bundle verify failed"; exit 1; }

# In-project copy too (protects against accidental file deletion)
cp "$BUNDLE" "$IN_PROJ/repo-$STAMP.bundle"

# ---- Step 3: full working-tree tarball (committed + tracked state on disk) ----
TREE="$OUT_PROJ/tree-$STAMP.tar.gz"
tar -czf "$TREE" \
  --exclude='./node_modules' \
  --exclude='./.next' \
  --exclude='./.git' \
  --exclude='./backups' \
  --exclude='./tool-results' \
  --exclude='./.turbo' \
  -C "$PROJECT" .

# ---- Step 4: LATEST pointer for one-command restore ----
echo "$STAMP" > "$OUT_PROJ/LATEST"

# ---- Step 5: retention (keep newest 10 of each kind, per location) ----
ls -1t "$OUT_PROJ"/repo-*.bundle 2>/dev/null | tail -n +11 | xargs -r rm -f
ls -1t "$OUT_PROJ"/tree-*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f
ls -1t "$IN_PROJ"/repo-*.bundle  2>/dev/null | tail -n +11 | xargs -r rm -f

BUNDLE_MB=$(du -m "$BUNDLE" | cut -f1)
TREE_MB=$(du -m "$TREE" | cut -f1)
echo "[backup] OK $STAMP"
echo "[backup]   history -> $BUNDLE (${BUNDLE_MB}MB)"
echo "[backup]   tree    -> $TREE (${TREE_MB}MB)"
echo "[backup]   latest  -> $OUT_PROJ/LATEST ($STAMP)"
