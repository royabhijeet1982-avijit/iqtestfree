/**
 * Working Memory Test - unit verification for working-memory-core.ts
 * Run: bun /home/z/my-project/scripts/verify-working-memory-core.ts
 *
 * Covers:
 *  - mixForLevel table invariants for every level 2..9
 *  - buildSequence invariants across 300 seeds: distinct elements,
 *    correct counts per level, display always contains the exact
 *    multiset, display NEVER equals the sorted answer
 *  - differentSequence never returns an excluded sequence
 *  - gradeStreams: sorted answers pass, wrong order/short/long fail
 *  - submitAttempt anti-gaming: submit-before-show invalid, empty
 *    invalid, numbers-only valid with letter stream failed
 *  - spanOfAttempts / partialBonusOf boundary behaviour
 *  - spanToIq anchors (mean -> 100), monotonicity, clamps
 *  - iqToPercentile bounds + monotonicity
 *  - gradeForIq tier boundaries
 *  - scoreSession honest floor on all-invalid runs; stat coherence
 *  - 1000-user population simulation (capacity-based logistic model):
 *    mean IQ must land at 100 (+/- 3), SD in 12..18 - this is the
 *    calibration check for SPAN_MEAN / SPAN_SD
 *  - full-pipeline coherence: seeded session simulation through
 *    buildSequence -> submitAttempt -> scoreSession
 */
import {
  ATTEMPTS_PER_LEVEL,
  DIGITS,
  DISPLAY_GAP_MS,
  DISPLAY_MS,
  LETTERS,
  MAX_LEVEL,
  QUICK_DISPLAY_MS,
  QUICK_GAP_MS,
  QUICK_START_LEVEL,
  SPAN_MEAN,
  SPAN_SD,
  START_LEVEL,
  buildSequence,
  differentSequence,
  erf,
  gradeForIq,
  gradeStreams,
  iqToPercentile,
  mixForLevel,
  mulberry32,
  normalCdf,
  partialBonusOf,
  scoreSession,
  sessionConfig,
  spanOfAttempts,
  spanToIq,
  submitAttempt,
  type WmAttempt,
  type WmTarget,
} from "../src/components/test/working-memory-core";

let passed = 0;
let failed = 0;
function ok(msg: string) { passed++; console.log(`  PASS ${msg}`); }
function no(msg: string) { failed++; console.log(`  FAIL ${msg}`); }
function check(cond: boolean, msg: string) { cond ? ok(msg) : no(msg); }
function eq(a: unknown, b: unknown, msg: string) {
  check(JSON.stringify(a) === JSON.stringify(b), `${msg} (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`);
}

/* ------------------------- config constants ------------------------- */
console.log("— config constants —");
check(START_LEVEL === 2, `START_LEVEL 2`);
check(QUICK_START_LEVEL === 5, `QUICK_START_LEVEL 5`);
check(MAX_LEVEL === 9, `MAX_LEVEL 9`);
check(ATTEMPTS_PER_LEVEL === 2, `ATTEMPTS_PER_LEVEL 2`);
check(DISPLAY_MS === 1000 && DISPLAY_GAP_MS === 250, "normal pacing 1000/250");
check(QUICK_DISPLAY_MS === 450 && QUICK_GAP_MS === 120, "quick pacing 450/120");
check(LETTERS.length === 9 && new Set(LETTERS).size === 9, "9 distinct letters");
check(DIGITS.length === 9 && DIGITS.every((d) => d >= 1 && d <= 9), "digits 1-9, no 0");

const cfgFull = sessionConfig(false);
const cfgQuick = sessionConfig(true);
check(cfgFull.attemptsPerLevel === 2 && cfgQuick.attemptsPerLevel === 1, "attempts per level by mode");
eq([cfgFull.displayMs, cfgFull.gapMs], [1000, 250], "full config pacing");
eq([cfgQuick.displayMs, cfgQuick.gapMs], [450, 120], "quick config pacing");

/* ---------------------------- mix table ---------------------------- */
console.log("— mixForLevel —");
for (let level = 2; level <= 9; level++) {
  let balanced = true;
  for (let s = 0; s < 60; s++) {
    const rng = mulberry32(level * 1000 + s);
    const [n, l] = mixForLevel(level, rng);
    if (n + l !== level || n < 1 || l < 1) balanced = false;
  }
  check(balanced, `level ${level}: digit+letter == level, both >= 1 (60 seeds)`);
}
{
  // even levels are always balanced
  const rng = mulberry32(42);
  eq(mixForLevel(4, rng), [2, 2], "level 4 balanced 2+2");
  eq(mixForLevel(6, rng), [3, 3], "level 6 balanced 3+3");
  eq(mixForLevel(8, rng), [4, 4], "level 8 balanced 4+4");
}

/* -------------------------- buildSequence -------------------------- */
console.log("— buildSequence invariants (300 seeds x levels 2..9) —");
{
  let violations = 0;
  let displaySortedCount = 0;
  let total = 0;
  for (let s = 0; s < 300; s++) {
    const rng = mulberry32(10_000 + s);
    for (let level = 2; level <= 9; level++) {
      total++;
      const t = buildSequence(level, rng);
      if (t.digits.length + t.letters.length !== level) violations++;
      if (t.digits.length < 1 || t.letters.length < 1) violations++;
      if (Math.abs(t.digits.length - t.letters.length) > 1) violations++;
      if (new Set(t.digits).size !== t.digits.length) violations++;
      if (new Set(t.letters).size !== t.letters.length) violations++;
      if (t.digits.some((d) => d < 1 || d > 9)) violations++;
      if (t.letters.some((x) => !(LETTERS as readonly string[]).includes(x))) violations++;
      if (t.display.length !== level) violations++;
      // display must contain exactly the used digits + letters
      const displayDigits = t.display.filter((x) => x >= "0" && x <= "9");
      const displayLetters = t.display.filter((x) => (LETTERS as readonly string[]).includes(x));
      if (displayDigits.length + displayLetters.length !== level) violations++;
      if (JSON.stringify(displayDigits.map(Number).sort((a, b) => a - b)) !== JSON.stringify(t.sortedDigits)) violations++;
      if (JSON.stringify(displayLetters.slice().sort()) !== JSON.stringify(t.sortedLetters)) violations++;
      // sorted answers really are sorted
      if (!t.sortedDigits.every((d, i) => i === 0 || d > t.sortedDigits[i - 1])) violations++;
      if (!t.sortedLetters.every((c, i) => i === 0 || c > t.sortedLetters[i - 1])) violations++;
      // display order must not be the sorted answer
      const sortedAsDisplay = [...t.sortedDigits.map(String), ...t.sortedLetters];
      if (JSON.stringify(t.display) === JSON.stringify(sortedAsDisplay)) displaySortedCount++;
    }
  }
  check(violations === 0, `0 structural violations across ${total} sequences`);
  check(displaySortedCount === 0, `0 displays equal to the sorted answer (anti-parrot)`);
}

/* ------------------------ differentSequence ------------------------ */
console.log("— differentSequence —");
{
  const rng = mulberry32(777);
  const first = buildSequence(4, rng);
  const excl = [first];
  let allDifferent = true;
  for (let i = 0; i < 40; i++) {
    const next = differentSequence(4, rng, excl);
    if (excl.some((e) => JSON.stringify(e.display) === JSON.stringify(next.display))) allDifferent = false;
    excl.push(next);
  }
  check(allDifferent, "40 retries at level 4, none equals any earlier sequence");
  const sameDisplay = { ...first };
  const retry = differentSequence(4, rng, [sameDisplay]);
  check(JSON.stringify(retry.display) !== JSON.stringify(first.display), "excluded display never returned");
}

/* ---------------------------- grading ------------------------------ */
console.log("— gradeStreams —");
{
  const rng = mulberry32(2024);
  const t = buildSequence(4, rng); // 2 digits + 2 letters
  const good = gradeStreams(t, t.sortedDigits, t.sortedLetters);
  check(good.correct, "exact sorted answers pass");
  const swapped = gradeStreams(t, t.sortedLetters.map((_, i) => t.sortedDigits[t.sortedDigits.length - 1 - i]), t.sortedLetters);
  check(!swapped.digitStreamCorrect && swapped.letterStreamCorrect, "descending digits fail only the digit stream");
  const shortNum = gradeStreams(t, t.sortedDigits.slice(0, 1), t.sortedLetters);
  check(!shortNum.digitStreamCorrect && !shortNum.correct, "short digit stream fails");
  const longLet = gradeStreams(t, t.sortedDigits, [...t.sortedLetters, "A"]);
  check(!longLet.letterStreamCorrect, "extra letter fails the letter stream");
  const reordered = gradeStreams(t, [t.sortedDigits[1], t.sortedDigits[0]], t.sortedLetters);
  check(!reordered.digitStreamCorrect, "unsorted digits fail (order matters)");
}

/* ------------------------- submitAttempt --------------------------- */
console.log("— submitAttempt anti-gaming —");
{
  const rng = mulberry32(555);
  const t = buildSequence(3, rng);
  const notShown = submitAttempt({ level: 3, attemptIndex: 1, target: t, digitInput: t.sortedDigits, letterInput: t.sortedLetters, wasShown: false });
  check(!notShown.valid && notShown.invalidReason !== null, "submit-before-show is invalid");
  check(notShown.digitInput.length === 0, "invalid attempt wipes the recorded input");
  const empty = submitAttempt({ level: 3, attemptIndex: 1, target: t, digitInput: [], letterInput: [], wasShown: true });
  check(!empty.valid && empty.invalidReason !== null, "empty input is invalid");
  const numbersOnly = submitAttempt({ level: 3, attemptIndex: 1, target: t, digitInput: t.sortedDigits, letterInput: [], wasShown: true });
  check(numbersOnly.valid && !numbersOnly.correct && !numbersOnly.letterStreamCorrect, "numbers-only is valid but fails the letter stream");
  const full = submitAttempt({ level: 3, attemptIndex: 1, target: t, digitInput: t.sortedDigits, letterInput: t.sortedLetters, wasShown: true });
  check(full.valid && full.correct, "fully correct valid attempt passes");
}

/* ---------------------- span + partial bonus ----------------------- */
console.log("— spanOfAttempts / partialBonusOf —");
{
  const rng = mulberry32(9001);
  const mk = (level: number, attemptIndex: number, correct: boolean, valid = true, digitOk = correct, letterOk = correct): WmAttempt => ({
    level,
    attemptIndex,
    target: buildSequence(level, rng),
    digitInput: [],
    letterInput: [],
    correct,
    digitStreamCorrect: digitOk,
    letterStreamCorrect: letterOk,
    valid,
    invalidReason: valid ? null : "x",
  });
  const attempts = [mk(2, 1, true), mk(3, 1, false), mk(3, 2, true), mk(4, 1, false, true, true, false), mk(4, 2, false, true, false, false)];
  eq(spanOfAttempts(attempts), 3, "span = highest cleared level");
  eq(partialBonusOf(attempts, 3), 0.5, "one-stream recall at the boundary level earns 0.5");
  eq(partialBonusOf(attempts, 2), 0, "bonus only counts at the boundary level, not below");
  const bothWrong = [mk(2, 1, true), mk(3, 1, false, true, false, false), mk(3, 2, false, true, false, false)];
  eq(partialBonusOf(bothWrong, 2), 0, "no one-stream recall at the boundary -> 0");
  const bothRight = [mk(2, 1, true), mk(3, 1, true)];
  eq(partialBonusOf(bothRight, 3), 0, "no boundary failure -> 0");
  const invalidBoundary = [mk(2, 1, true), mk(3, 1, false, false, true, false)];
  eq(partialBonusOf(invalidBoundary, 2), 0, "invalid attempts never earn the bonus");
  eq(spanOfAttempts([mk(2, 1, false, false), mk(3, 1, true, false)]), 0, "invalid attempts never count toward span");
  const perfect: WmAttempt[] = [];
  for (let level = 2; level <= 9; level++) perfect.push(mk(level, 1, true));
  eq(partialBonusOf(perfect, 9), 0.5, "flawless full clear of level 9 earns +0.5");
  check(spanToIq(9.5) >= 130, `Exceptional tier reachable at the top (span 9.5 -> IQ ${spanToIq(9.5)})`);
  check(spanToIq(9) >= 115, `full clear without bonus still Well-above (IQ ${spanToIq(9)})`);
}

/* ----------------------------- IQ scale ---------------------------- */
console.log("— spanToIq / iqToPercentile / grades —");
check(spanToIq(SPAN_MEAN) === 100, `SPAN_MEAN maps to IQ 100`);
check(spanToIq(SPAN_MEAN + SPAN_SD) === 115, `+1 SD maps to 115`);
check(spanToIq(SPAN_MEAN - SPAN_SD) === 85, `-1 SD maps to 85`);
check(spanToIq(0) === 55 && spanToIq(-5) === 55, "floor clamp 55");
check(spanToIq(15) === 145 && spanToIq(30) === 145, "ceiling clamp 145");
{
  let monotonic = true;
  for (let s = 0; s < 20; s++) {
    const lo = spanToIq(1 + s * 0.25);
    const hi = spanToIq(1 + (s + 1) * 0.25);
    if (hi < lo) monotonic = false;
  }
  check(monotonic, "spanToIq monotonic non-decreasing");
}
check(iqToPercentile(100) === 50, "IQ 100 -> 50th percentile");
check(iqToPercentile(55) === 1 && iqToPercentile(145) === 99, "percentile clamps 1..99");
{
  let mono = true;
  for (let i = 60; i < 145; i += 5) if (iqToPercentile(i + 5) < iqToPercentile(i)) mono = false;
  check(mono, "percentile monotonic");
}
{
  const tiers = [70, 92, 107, 122, 140].map(gradeForIq);
  eq(tiers.map((t) => t.label), ["Building", "Average", "Above average", "Well above average", "Exceptional"], "grade tiers in order");
  check(gradeForIq(84).label === "Building" && gradeForIq(85).label !== "Building", "85 boundary leaves Building");
  check(gradeForIq(129).label === "Well above average" && gradeForIq(130).label === "Exceptional", "130 boundary -> Exceptional");
}

/* --------------------------- scoreSession -------------------------- */
console.log("— scoreSession —");
{
  const rng = mulberry32(31337);
  const allInvalid: WmAttempt[] = [
    submitAttempt({ level: 2, attemptIndex: 1, target: buildSequence(2, rng), digitInput: [], letterInput: [], wasShown: false }),
    submitAttempt({ level: 2, attemptIndex: 2, target: buildSequence(2, rng), digitInput: [], letterInput: [], wasShown: true }),
  ];
  const r = scoreSession(allInvalid, false);
  check(r.span === 0 && r.iq === 55, "all-invalid session -> honest floor (span 0, IQ 55)");
  check(r.percentile === 1 && r.grade.label === "Building", "floor percentile + Building grade");
  check(r.attempts === 2 && r.correct === 0, "attempt counts coherent");

  const goodRun: WmAttempt[] = [];
  for (let level = 2; level <= 5; level++) {
    const t = buildSequence(level, rng);
    goodRun.push(submitAttempt({ level, attemptIndex: 1, target: t, digitInput: t.sortedDigits, letterInput: t.sortedLetters, wasShown: true }));
  }
  const t6 = buildSequence(6, rng);
  goodRun.push(submitAttempt({ level: 6, attemptIndex: 1, target: t6, digitInput: t6.sortedDigits, letterInput: [], wasShown: true }));
  const r2 = scoreSession(goodRun, false);
  check(r2.span === 5, "clean run span 5");
  check(r2.partialBonus === 0.5, "one-stream miss at level 6 -> +0.5");
  check(r2.effectiveSpan === 5.5, "effective span 5.5");
  check(r2.iq === spanToIq(5.5), "iq consistent with spanToIq");
  check(r2.correct === 4 && r2.streamsPartlyCorrect === 1, "correct/partly counters coherent");
  check(r2.quick === false, "quick flag false");
}

/* --------------------- population simulation ----------------------- */
console.log("— 1000-user population simulation (calibration) —");
{
  // Gaussian via Box-Muller on mulberry32.
  const gauss = (rng: () => number) => {
    let u = 0, v = 0;
    while (u === 0) u = rng();
    while (v === 0) v = rng();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

  const simulateUser = (rng: () => number): { span: number; bonus: number } => {
    // Steep psychometric curve: recall a couple of levels below capacity
    // is near-certain, a couple above near-impossible (as in real span
    // data). Capacity N(5.5, 1.0); numbers sort slightly easier (+1).
    const capacity = Math.min(9, Math.max(2.5, 5.5 + 1.0 * gauss(rng)));
    const attempts: WmAttempt[] = [];
    let level = 2;
    while (level <= MAX_LEVEL) {
      let cleared = false;
      for (let a = 1; a <= 2; a++) {
        const t = buildSequence(level, rng);
        const pNum = sigmoid((0.6 * capacity + 1 - t.sortedDigits.length) / 0.3);
        const pLet = sigmoid((0.6 * capacity - t.sortedLetters.length) / 0.3);
        const numOk = rng() < pNum;
        const letOk = rng() < pLet;
        const att = submitAttempt({
          level,
          attemptIndex: a,
          target: t,
          digitInput: numOk ? t.sortedDigits : [],
          letterInput: letOk ? t.sortedLetters : [],
          wasShown: true,
        });
        attempts.push(att);
        if (att.correct) { cleared = true; break; }
      }
      if (!cleared) break;
      level++;
    }
    const span = spanOfAttempts(attempts);
    return { span, bonus: partialBonusOf(attempts, span) };
  };

  const rng = mulberry32(202_50101);
  const iqs: number[] = [];
  const spans: number[] = [];
  const N = 1000;
  for (let i = 0; i < N; i++) {
    const { span, bonus } = simulateUser(rng);
    spans.push(span + bonus);
    iqs.push(spanToIq(span + bonus));
  }
  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length - 1));
  };
  const mIq = mean(iqs), sdIq = sd(iqs), mSpan = mean(spans), sdSpan = sd(spans);
  console.log(`    simulated: mean partial span ${mSpan.toFixed(2)} (SD ${sdSpan.toFixed(2)}) -> mean IQ ${mIq.toFixed(1)} (SD ${sdIq.toFixed(1)})`);
  check(Math.abs(mIq - 100) <= 3, `simulation mean IQ 100 +/- 3 (got ${mIq.toFixed(1)})`);
  check(sdIq >= 12 && sdIq <= 18, `simulation IQ SD in 12..18 (got ${sdIq.toFixed(1)})`);
  const spanValues = new Set(spans.map((s) => Math.round(s * 2) / 2));
  check(spanValues.size >= 6, `partial spans spread over >= 6 distinct values (got ${spanValues.size})`);
  const medIq = iqs.slice().sort((a, b) => a - b)[Math.floor(N / 2)];
  check(medIq >= 95 && medIq <= 105, `median IQ 95..105 (got ${medIq})`);
}

/* --------------------- full-pipeline coherence --------------------- */
console.log("— seeded session pipeline coherence —");
{
  // Simulate a scripted session using ONLY public core functions, exactly
  // like the UI would, and confirm every invariant end to end.
  const rng = mulberry32(8675309);
  const attempts: WmAttempt[] = [];
  let level = START_LEVEL;
  let attemptsThisLevel = 1;
  let seenAtLevel: WmTarget[] = [];
  while (level <= MAX_LEVEL) {
    const t = seenAtLevel.length === 0 ? buildSequence(level, rng) : differentSequence(level, rng, seenAtLevel);
    seenAtLevel.push(t);
    // "user" recalls correctly with p=0.75, else submits digits only
    const succeed = rng() < 0.75;
    const att = submitAttempt({
      level,
      attemptIndex: attemptsThisLevel,
      target: t,
      digitInput: succeed ? t.sortedDigits : t.sortedDigits.slice(0, Math.max(0, t.sortedDigits.length - 1)),
      letterInput: succeed ? t.sortedLetters : t.sortedLetters,
      wasShown: true,
    });
    attempts.push(att);
    if (att.correct) {
      if (level === MAX_LEVEL) break;
      level++;
      attemptsThisLevel = 1;
      seenAtLevel = [];
    } else if (attemptsThisLevel >= ATTEMPTS_PER_LEVEL) {
      break;
    } else {
      attemptsThisLevel++;
    }
  }
  const result = scoreSession(attempts, false);
  check(result.attempts === attempts.length, "pipeline attempt count matches");
  check(result.correct === attempts.filter((a) => a.correct).length, "pipeline correct count matches");
  check(result.iq >= 55 && result.iq <= 145, `pipeline IQ in range (${result.iq})`);
  // retry sequences at the same level must differ from earlier ones there
  const byLevel = new Map<number, string[]>();
  let allDifferent = true;
  for (const a of attempts) {
    const key = a.target.display.join("-");
    const list = byLevel.get(a.level) ?? [];
    if (list.includes(key)) allDifferent = false;
    list.push(key);
    byLevel.set(a.level, list);
  }
  check(allDifferent, "no repeated display within any level across the session");
  // erf/normalCdf sanity
  check(Math.abs(erf(0)) < 1e-9 && Math.abs(erf(1) - 0.8427) < 1e-3, "erf sanity");
  check(Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9, "normalCdf at mean = 0.5");
}

console.log("\n=========================================");
console.log(`RESULTS: ${passed} PASS, ${failed} FAIL`);
if (failed > 0) process.exit(1);
console.log("ALL PASS");
