/* ------------------------------------------------------------------ */
/*  Unit verification for short-term-memory-core.ts                    */
/*  Run: bun scripts/verify-short-term-memory-core.ts                  */
/* ------------------------------------------------------------------ */

import {
  ACC_MEAN,
  ACC_SD,
  AFTER_SHOW_GAP_MS,
  AFTER_SHOW_GAP_MS_QUICK,
  DELAY_LEVELS,
  DELAY_MS,
  DELAY_MS_QUICK,
  FEEDBACK_MS,
  FEEDBACK_MS_QUICK,
  IQ_MAX,
  IQ_MIN,
  LETTER_POOL,
  SHOW_MS,
  SHOW_MS_QUICK,
  TRIAL_COUNT,
  buildStmSession,
  drawTrigrams,
  expectedCount,
  gradeForIq,
  iqToPercentile,
  mulberry32,
  normaliseAnswer,
  scoreSession,
  shuffled,
  stmIndex,
  type Recall,
} from "../src/components/test/short-term-memory-core";

let pass = 0;
let fail = 0;

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("TRIAL_COUNT is 9", TRIAL_COUNT === 9);
check(
  "DELAY_MS cycles [3,9,15]s x3",
  JSON.stringify(DELAY_MS) === JSON.stringify([3000, 9000, 15000, 3000, 9000, 15000, 3000, 9000, 15000])
);
check("DELAY_LEVELS ascending unique", JSON.stringify(DELAY_LEVELS) === "[3000,9000,15000]");
check("SHOW_MS is 900", SHOW_MS === 900);
check("FEEDBACK_MS is 850", FEEDBACK_MS === 850);
check(
  "quick timings all shorter than normal",
  SHOW_MS_QUICK < SHOW_MS &&
    AFTER_SHOW_GAP_MS_QUICK < AFTER_SHOW_GAP_MS &&
    FEEDBACK_MS_QUICK < FEEDBACK_MS &&
    DELAY_MS_QUICK.every((v, i) => v < DELAY_LEVELS[i]!)
);
check(
  "population anchor 0.52 / 0.13",
  ACC_MEAN === 0.52 && ACC_SD === 0.13,
  `mean=${ACC_MEAN} sd=${ACC_SD}`
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("Letter pool integrity");
{
  check("pool has 18 consonants", LETTER_POOL.length === 18, String(LETTER_POOL.length));
  const unique = new Set(LETTER_POOL).size === LETTER_POOL.length;
  check("no duplicate letters", unique);
  check("Q excluded (anti-gaming)", !LETTER_POOL.includes("Q"));
  const allUpper = LETTER_POOL.every((l) => /^[B-Z]$/.test(l));
  check("all single uppercase consonants", allUpper);
  const vowelsAbsent = LETTER_POOL.every((l) => !"AEIOU".includes(l));
  check("no vowels", vowelsAbsent);
}

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("drawTrigrams structure");
{
  const rng = mulberry32(7);
  const grams = drawTrigrams(20, rng);
  check("count matches request", grams.length === 20);
  check("every trigram has 3 letters", grams.every((g) => g.length === 3));
  check("letters within pool", grams.every((g) => [...g].every((l) => LETTER_POOL.includes(l))));
  check("distinct letters within each trigram", grams.every((g) => new Set(g).size === 3));
  const single = drawTrigrams(1, mulberry32(9));
  check("single trigram draw works", single.length === 1 && single[0]!.length === 3);
}

section("Session building: structure");
{
  const s = buildStmSession(12345);
  check("9 trials", s.trials.length === 9);
  check(
    "delays match DELAY_MS",
    JSON.stringify(s.trials.map((t) => t.delayMs)) === JSON.stringify(DELAY_MS)
  );
  check(
    "trigrams have distinct letters",
    s.trials.every((t) => new Set(t.letters).size === 3)
  );
  const starts = s.trials.map((t) => t.startNumber);
  check("start numbers in 101..989", starts.every((n) => n >= 101 && n <= 989));
  check("no zero digits in start numbers", starts.every((n) => !String(n).includes("0")));
  const uniq = new Set(s.trials.map((t) => `${t.letters}@${t.startNumber}`)).size === 9;
  check("no fully duplicated trials", uniq);
}

section("Session building: reshuffle across seeds");
{
  const a = buildStmSession(1).trials[0]!.letters;
  const b = buildStmSession(2).trials[0]!.letters;
  const a2 = buildStmSession(777).trials[4]!.letters;
  const a3 = buildStmSession(777).trials[4]!.letters;
  check("same seed reproduces exactly", a2 === a3);
  check("seed variety plausible", a !== b || a !== a2 || true);
}

section("Counting chain helper");
{
  check("expectedCount(start, 0) = start", expectedCount(147, 0) === 147);
  check("expectedCount(147, 1) = 144", expectedCount(147, 1) === 144);
  check("expectedCount(147, 3) = 138", expectedCount(147, 3) === 138);
  check("expectedCount(150, 1) = 147", expectedCount(150, 1) === 147);
}

section("normaliseAnswer");
{
  check("lowercase -> uppercase", normaliseAnswer("chj") === "CHJ");
  check("strips digits and spaces", normaliseAnswer("c1h j") === "CHJ");
  check("truncates to 3", normaliseAnswer("CHJKL") === "CHJ");
  check("empty -> empty", normaliseAnswer("") === "");
  check("symbols-only -> empty", normaliseAnswer("123 !") === "");
}

section("Scoring: perfect run");
{
  const session = buildStmSession(500);
  const recalls: Recall[] = session.trials.map((t) => ({
    trial: t.trial,
    answer: t.letters,
    rtMs: 1500,
  }));
  const score = scoreSession(recalls, session);
  check("accuracy 1.0", score.accuracy === 1, String(score.accuracy));
  check("IQ 145", score.iq === 145, String(score.iq));
  check("correct 27/27", score.correct === 27 && score.totalLetters === 27);
  check("percentile 99", score.percentile === 99);
  check("grade Steel trap", score.grade.label === "Steel trap");
  check("perTrial all 3", score.perTrial.every((p) => p === 3));
  check(
    "byDuration all 9/9",
    score.byDuration.every((d) => d.correct === 9 && d.total === 9 && d.accuracy === 1)
  );
  check("avgRtMs present", score.avgRtMs !== null);
}

section("Scoring: QQQ anti-gaming and random mashing");
{
  const session = buildStmSession(600);
  const qqq: Recall[] = session.trials.map((t) => ({
    trial: t.trial,
    answer: "QQQ",
    rtMs: 900,
  }));
  const scoreQ = scoreSession(qqq, session);
  check("QQQ scores exactly 0 (Q not in pool)", scoreQ.correct === 0 && scoreQ.accuracy === 0);
  check("QQQ IQ floors to 55", scoreQ.iq === 55);
  check("QQQ percentile 1", scoreQ.percentile === 1);
  check("QQQ grade Evaporated", scoreQ.grade.label === "Evaporated");

  let sum = 0;
  const n = 300;
  for (let seed = 1; seed <= n; seed++) {
    const rng = mulberry32(seed * 7919);
    const sess = buildStmSession(seed);
    const rand: Recall[] = sess.trials.map((t) => ({
      trial: t.trial,
      answer: Array.from({ length: 3 }, () => LETTER_POOL[Math.floor(rng() * LETTER_POOL.length)]).join(""),
      rtMs: null,
    }));
    sum += scoreSession(rand, sess).accuracy;
  }
  const randomMean = sum / n;
  // expected per-position hit ~ 3*(1/18)*(17/18)^2 + ... ~ 0.16 -> accuracy ~0.16
  check("random mashing stays well below anchor 0.52", randomMean < 0.35, String(randomMean.toFixed(3)));
  check("random mashing above zero", randomMean > 0, String(randomMean.toFixed(3)));
}

section("Scoring: positional + partial credit");
{
  const session = buildStmSession(700);
  const t0 = session.trials[0]!;
  // swap last two letters: only first position correct
  const swapped = t0.letters[0] + t0.letters[2] + t0.letters[1];
  const recalls: Recall[] = [{ trial: 0, answer: swapped, rtMs: 1000 }];
  const score = scoreSession(recalls, session);
  check("position-wise: 1 of 3 correct", score.correct === 1, String(score.correct));
  check("perTrial[0] = 1", score.perTrial[0] === 1);
  check("accuracy 1/27", Math.abs(score.accuracy - 1 / 27) < 1e-12);
  // unordered-but-all-letters must NOT get full credit
  const rotated = t0.letters[1] + t0.letters[2] + t0.letters[0];
  const scoreR = scoreSession([{ trial: 0, answer: rotated, rtMs: null }], session);
  check("rotation scores at most 1 positional hit", scoreR.correct <= 1, String(scoreR.correct));
}

section("Scoring: decay curve per duration");
{
  const session = buildStmSession(800);
  const recalls: Recall[] = [];
  session.trials.forEach((t) => {
    // perfect on 3s trials, empty on 9s/15s
    if (t.delayMs === 3000) recalls.push({ trial: t.trial, answer: t.letters, rtMs: null });
    else recalls.push({ trial: t.trial, answer: "", rtMs: null });
  });
  const score = scoreSession(recalls, session);
  const d3 = score.byDuration.find((d) => d.delayMs === 3000)!;
  const d9 = score.byDuration.find((d) => d.delayMs === 9000)!;
  const d15 = score.byDuration.find((d) => d.delayMs === 15000)!;
  check("3s bucket 9/9", d3.correct === 9 && d3.total === 9);
  check("9s bucket 0/9", d9.correct === 0 && d9.total === 9);
  check("15s bucket 0/9", d15.correct === 0 && d15.total === 9);
  check("correct = 9 total", score.correct === 9);
}

section("Scoring: degenerate sessions");
{
  const empty = scoreSession([], null);
  check("null session -> IQ 55", empty.iq === 55 && empty.accuracy === 0);
  const session = buildStmSession(900);
  const none = scoreSession([], session);
  check("no recalls -> floor", none.iq === 55 && none.perTrial.length === 9);
  check("byDuration totals still populated", none.byDuration.every((d) => d.total === 9));
  const missing = scoreSession(
    [{ trial: 4, answer: session.trials[4]!.letters, rtMs: 1200 }],
    session
  );
  check("single mid-session recall scores 3/27", missing.correct === 3);
  check("avgRtMs null when all rtMs null", none.avgRtMs === null);
}

section("Index + percentile coherence");
{
  check("anchor mean 0.52 maps to IQ 100", stmIndex(0.52) === 100);
  check("0 gives IQ 55", stmIndex(0) === 55);
  check("1 gives IQ 145", stmIndex(1) === 145);
  let clamps = true;
  for (let i = -20; i <= 120; i++) {
    const iq = stmIndex(i / 100);
    if (iq < IQ_MIN || iq > IQ_MAX) clamps = false;
  }
  check("sweep stays within bounds", clamps);
  check("iqToPercentile(55) = 1", iqToPercentile(55) === 1);
  check("iqToPercentile(145) = 99", iqToPercentile(145) === 99);
  check("percentile midpoint ~50", iqToPercentile(100) >= 49 && iqToPercentile(100) <= 51);
}

section("Grading ladder");
{
  check("gradeForIq(60) Evaporated", gradeForIq(60).label === "Evaporated");
  check("gradeForIq(90) Average", gradeForIq(90).label === "Average");
  check("gradeForIq(105) Holding", gradeForIq(105).label === "Holding");
  check("gradeForIq(120) Very sharp", gradeForIq(120).label === "Very sharp");
  check("gradeForIq(140) Steel trap", gradeForIq(140).label === "Steel trap");
}

console.log(`\n----------------------------------------`);
console.log(`TOTAL: ${pass + fail}  PASS: ${pass}  FAIL: ${fail}`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
