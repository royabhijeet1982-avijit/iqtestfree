/* ------------------------------------------------------------------ */
/*  Unit verification for sequence-memory-core.ts                      */
/*  Run: bun scripts/verify-sequence-memory-core.ts                     */
/* ------------------------------------------------------------------ */

import {
  BASE_OFF_MS,
  BASE_ON_MS,
  GRID_TILES,
  IQ_MAX,
  IQ_MIN,
  MIN_ON_MS,
  QUICK_OFF_MS,
  QUICK_ON_MS,
  SPAN_FLOOR,
  SPAN_MEAN,
  SPAN_SD,
  SPEED_STEP_MS,
  START_LEVEL,
  appendTile,
  buildRunSequence,
  erf,
  gradeClick,
  gradeForIq,
  iqToPercentile,
  mulberry32,
  normalCdf,
  scoreRun,
  spanIq,
  speedForLevel,
  timingForLevel,
  type LevelAttempt,
} from "../src/components/test/sequence-memory-core";

let pass = 0;
let fail = 0;

/** Standard normal sample via Box-Muller (shared by simulations). */
function randn(rng: () => number): number {
  const u = Math.max(1e-9, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function check(name: string, cond: boolean, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ""}`);
  }
}

function section(title: string) {
  console.log(`\n== ${title} ==`);
}

/* ---------------------------------------------------------------- */

section("Constants sanity");
check("GRID_TILES is 9 (3x3)", GRID_TILES === 9, String(GRID_TILES));
check("START_LEVEL is 1", START_LEVEL === 1, String(START_LEVEL));
check("BASE_ON_MS is 620", BASE_ON_MS === 620, String(BASE_ON_MS));
check("BASE_OFF_MS is 200", BASE_OFF_MS === 200, String(BASE_OFF_MS));
check("MIN_ON_MS is 320", MIN_ON_MS === 320, String(MIN_ON_MS));
check("SPEED_STEP_MS is 22", SPEED_STEP_MS === 22, String(SPEED_STEP_MS));
check("QUICK_ON_MS is 220", QUICK_ON_MS === 220, String(QUICK_ON_MS));
check("QUICK_OFF_MS is 80", QUICK_OFF_MS === 80, String(QUICK_OFF_MS));
check("SPAN_FLOOR is 0", SPAN_FLOOR === 0, String(SPAN_FLOOR));
check(
  "population anchor 7.4 / 1.5",
  SPAN_MEAN === 7.4 && SPAN_SD === 1.5,
  `mean=${SPAN_MEAN} sd=${SPAN_SD}`
);
check("IQ bounds 55..145", IQ_MIN === 55 && IQ_MAX === 145);

section("RNG determinism");
{
  const rngA = mulberry32(42);
  const rngB = mulberry32(42);
  const seqA = Array.from({ length: 20 }, () => rngA());
  const seqB = Array.from({ length: 20 }, () => rngB());
  check("mulberry32 deterministic per seed", JSON.stringify(seqA) === JSON.stringify(seqB));
  const rngC = mulberry32(43);
  const seqC = Array.from({ length: 20 }, () => rngC());
  check("different seed differs", JSON.stringify(seqA) !== JSON.stringify(seqC));
  check("rng output within [0,1)", seqA.every((v) => v >= 0 && v < 1));
}

section("appendTile / buildRunSequence invariants (500 seeds x lengths 1..14)");
{
  let lengthsOk = true;
  let rangeOk = true;
  let noTriple = true;
  let prefixStable = true;
  for (let seed = 0; seed < 500; seed++) {
    const rng = mulberry32(seed);
    let seq: number[] = [];
    for (let len = 1; len <= 14; len++) {
      const next = appendTile(seq, rng);
      if (next.length !== len) lengthsOk = false;
      // prefix-stable: next must equal seq + exactly one tile
      if (next.slice(0, seq.length).join(",") !== seq.join(",")) prefixStable = false;
      if (!next.every((t) => Number.isInteger(t) && t >= 0 && t < GRID_TILES)) rangeOk = false;
      for (let i = 2; i < next.length; i++) {
        if (next[i] === next[i - 1] && next[i] === next[i - 2]) noTriple = false;
      }
      seq = next;
    }
  }
  check("appendTile grows length by exactly one", lengthsOk);
  check("prefix never mutates (prefix-stable growth)", prefixStable);
  check("tiles always within 0..8", rangeOk);
  check("no tile appears three times in a row", noTriple);
}

section("buildRunSequence matches incremental appendTile");
{
  let matchOk = true;
  for (let seed = 0; seed < 200; seed++) {
    const rngA = mulberry32(seed);
    let inc: number[] = [];
    for (let i = 0; i < 10; i++) inc = appendTile(inc, rngA);
    const bulk = buildRunSequence(10, mulberry32(seed));
    if (inc.join(",") !== bulk.join(",")) matchOk = false;
  }
  check("bulk build equals incremental build (same seed)", matchOk);
}

section("Doubles allowed, still random (distribution)");
{
  let doublesSeen = 0;
  const firstCounts = new Array<number>(GRID_TILES).fill(0);
  const N = 900;
  for (let seed = 0; seed < N; seed++) {
    const seq = buildRunSequence(6, mulberry32(20_000 + seed));
    firstCounts[seq[0]!]! += 1;
    for (let i = 1; i < seq.length; i++) {
      if (seq[i] === seq[i - 1]) doublesSeen++;
    }
  }
  check("immediate doubles occur (>=20 of 5400 pairs)", doublesSeen >= 20, String(doublesSeen));
  const expectedFirst = N / GRID_TILES;
  check(
    "every tile appears as a first tile (within 60%-140%)",
    firstCounts.every((c) => c > expectedFirst * 0.6 && c < expectedFirst * 1.4),
    firstCounts.join(",")
  );
  const unique = new Set<string>();
  for (let seed = 0; seed < 200; seed++) {
    unique.add(buildRunSequence(5, mulberry32(50_000 + seed)).join(","));
  }
  check(
    "level-5 run sequences are genuinely random across seeds (>=150 unique of 200)",
    unique.size >= 150,
    `unique=${unique.size}`
  );
}

section("gradeClick paths");
{
  const seq = [3, 0, 8, 5];
  check("correct mid-sequence", gradeClick(seq, 0, 3).correct === true && gradeClick(seq, 0, 3).complete === false);
  check("correct second position", gradeClick(seq, 1, 0).correct === true);
  check("final correct click completes", gradeClick(seq, 3, 5).correct === true && gradeClick(seq, 3, 5).complete === true);
  check("non-final correct click not complete", gradeClick(seq, 2, 8).complete === false);
  check("wrong tile flagged", gradeClick(seq, 0, 4).correct === false && gradeClick(seq, 0, 4).complete === false);
  check("right tile wrong slot is wrong", gradeClick(seq, 2, 0).correct === false);
  check("index beyond sequence is wrong", gradeClick(seq, 10, 3).correct === false);
  const single = [6];
  check("level-1 sequence completes on first click", gradeClick(single, 0, 6).complete === true);
}

section("speedForLevel (fixed playback timing)");
{
  check("level 1 -> 620ms on", speedForLevel(1).onMs === 620);
  check("level 1 -> 200ms off", speedForLevel(1).offMs === 200);
  check("level 2 -> 598ms on", speedForLevel(2).onMs === 598);
  check("level 5 -> 532ms on", speedForLevel(5).onMs === 532);
  check("level 10 -> 422ms on", speedForLevel(10).onMs === 422);
  check("level 14 -> 334ms on", speedForLevel(14).onMs === 334);
  check("level 20 -> clamped at 320ms floor", speedForLevel(20).onMs === 320);
  let monotonic = true;
  for (let lv = 1; lv < 30; lv++) {
    if (speedForLevel(lv + 1).onMs > speedForLevel(lv).onMs) monotonic = false;
  }
  check("on-time never increases with level", monotonic);
  check("off-time constant at every level", [1, 4, 8, 13, 21].every((lv) => speedForLevel(lv).offMs === 200));
  check("quick mode shortens timing", timingForLevel(1, true).onMs === QUICK_ON_MS && timingForLevel(1, false).onMs === 620);
  check("quick off constant", timingForLevel(9, true).offMs === QUICK_OFF_MS);
}

section("erf / normalCdf accuracy");
{
  check("erf(0) = 0", Math.abs(erf(0)) < 1e-9);
  check("erf(1) ~ 0.8427", Math.abs(erf(1) - 0.8427007) < 1e-6, String(erf(1)));
  check("erf(-x) = -erf(x)", Math.abs(erf(-2) + erf(2)) < 1e-9);
  check("normalCdf(mean) = 0.5", Math.abs(normalCdf(100, 100, 15) - 0.5) < 1e-9);
  check("normalCdf(+1sd) ~ 0.8413", Math.abs(normalCdf(115, 100, 15) - 0.8413447) < 1e-6);
}

section("spanIq (pure span, IQ scale)");
{
  check("span 7 -> IQ 96", spanIq(7) === 96, String(spanIq(7)));
  check("span 8 -> IQ 106", spanIq(8) === 106, String(spanIq(8)));
  check("span 10 -> IQ 126", spanIq(10) === 126, String(spanIq(10)));
  check("span 11 -> IQ 136 (Exceptional reachable)", spanIq(11) === 136, String(spanIq(11)));
  check("floor span 0 -> clamped 55", spanIq(0) === IQ_MIN, String(spanIq(0)));
  check("span 12+ clamps to 145", spanIq(12) === IQ_MAX && spanIq(30) === IQ_MAX);
  let monotonic = true;
  for (let span = 0; span <= 14; span++) {
    if (spanIq(span + 1) < spanIq(span)) monotonic = false;
  }
  check("IQ monotonic non-decreasing in span", monotonic);
  let bounded = true;
  for (let span = -5; span <= 30; span++) {
    const iq = spanIq(span);
    if (iq < IQ_MIN || iq > IQ_MAX) bounded = false;
  }
  check("IQ always clamped to [55, 145]", bounded);
}

section("iqToPercentile");
{
  check("IQ 100 -> 50th", iqToPercentile(100) === 50, String(iqToPercentile(100)));
  check("IQ 115 -> ~84th", iqToPercentile(115) === 84, String(iqToPercentile(115)));
  check("IQ 85 -> ~16th", iqToPercentile(85) === 16, String(iqToPercentile(85)));
  check("IQ 55 clamps to 1st", iqToPercentile(IQ_MIN) === 1);
  check("IQ 145 clamps to 99th", iqToPercentile(IQ_MAX) === 99);
  let monotonic = true;
  for (let iq = IQ_MIN; iq < IQ_MAX; iq++) {
    if (iqToPercentile(iq + 1) < iqToPercentile(iq)) monotonic = false;
  }
  check("percentile monotonic non-decreasing in IQ", monotonic);
}

section("gradeForIq tiers");
{
  check("IQ 70 -> Building", gradeForIq(70).label === "Building");
  check("IQ 84.9 -> Building (boundary)", gradeForIq(84.9).label === "Building");
  check("IQ 85 -> Average", gradeForIq(85).label === "Average");
  check("IQ 99.4 -> Average", gradeForIq(99.4).label === "Average");
  check("IQ 100 -> Sharp", gradeForIq(100).label === "Sharp");
  check("IQ 114.6 -> Sharp", gradeForIq(114.6).label === "Sharp");
  check("IQ 115 -> Very sharp", gradeForIq(115).label === "Very sharp");
  check("IQ 129 -> Very sharp", gradeForIq(129).label === "Very sharp");
  check("IQ 130 -> Exceptional", gradeForIq(130).label === "Exceptional");
  check("span 5 -> IQ 76 -> Building", gradeForIq(spanIq(5)).label === "Building");
  check("span 8 -> IQ 104 -> Sharp", gradeForIq(spanIq(8)).label === "Sharp");
  check("span 11 -> IQ 136 -> Exceptional", gradeForIq(spanIq(11)).label === "Exceptional");
  check("every grade has blurb + class", [70, 90, 105, 120, 135].every((q) => {
    const g = gradeForIq(q);
    return g.blurb.length > 10 && g.className.length > 0 && g.label.length > 0;
  }));
}

section("scoreRun - golden path (clear 1..5, fail 6)");
{
  const run = buildRunSequence(6, mulberry32(777));
  const attempts: LevelAttempt[] = [];
  for (let lv = 1; lv <= 5; lv++) {
    attempts.push({ level: lv, sequence: run.slice(0, lv), correctClicks: lv, cleared: true });
  }
  attempts.push({ level: 6, sequence: run.slice(0, 6), correctClicks: 3, cleared: false });
  const score = scoreRun(attempts);
  check("span = 5 (highest cleared)", score.span === 5, String(score.span));
  check("deepest = 6 (failed level)", score.deepest === 6, String(score.deepest));
  check("tilesCorrect = 18 (5+4+3+2+1+3)", score.tilesCorrect === 18, String(score.tilesCorrect));
  check("tilesShown = 21 (1+2+..+6)", score.tilesShown === 21, String(score.tilesShown));
  check("attempts = 6 implied by ladder length", score.ladder.length === 6);
  check(
    "ladder 1..6 with 1-5 cleared, 6 failed",
    score.ladder.every((r, i) => r.level === i + 1) &&
      score.ladder.slice(0, 5).every((r) => r.cleared) &&
      score.ladder[5]!.cleared === false
  );
  check("iq = spanIq(span) = 76", score.iq === 76, String(score.iq));
  check("percentile matches IQ", score.percentile === iqToPercentile(score.iq));
  check("grade matches IQ", score.grade.label === gradeForIq(score.iq).label);
}

section("scoreRun - floor path (dies on level 1)");
{
  const attempts: LevelAttempt[] = [
    { level: 1, sequence: [4], correctClicks: 0, cleared: false },
  ];
  const score = scoreRun(attempts);
  check("run still scores (no crash)", typeof score.iq === "number" && Number.isFinite(score.iq));
  check("span floored at 0", score.span === SPAN_FLOOR, String(score.span));
  check("deepest = 1", score.deepest === 1);
  check("honest floor IQ 55", score.iq === IQ_MIN, String(score.iq));
  check("percentile = 1", score.percentile === 1);
  check("grade = Building", score.grade.label === "Building");
  check("tilesShown = 1", score.tilesShown === 1);
  check("ladder single failed level 1", score.ladder.length === 1 && score.ladder[0]!.level === 1 && !score.ladder[0]!.cleared);
}

section("scoreRun - empty run safety");
{
  const score = scoreRun([]);
  check("empty attempts -> floor span", score.span === SPAN_FLOOR);
  check("empty attempts -> no crash", Number.isFinite(score.iq));
  check("empty ladder", score.ladder.length === 0);
}

section("scoreRun - deep path (clear 1..11, fail 12)");
{
  const run = buildRunSequence(12, mulberry32(4242));
  const attempts: LevelAttempt[] = [];
  for (let lv = 1; lv <= 11; lv++) {
    attempts.push({ level: lv, sequence: run.slice(0, lv), correctClicks: lv, cleared: true });
  }
  attempts.push({ level: 12, sequence: run.slice(0, 12), correctClicks: 0, cleared: false });
  const score = scoreRun(attempts);
  check("span = 11", score.span === 11, String(score.span));
  check("IQ 136 -> Exceptional", score.iq === 136 && score.grade.label === "Exceptional");
  check("percentile >= 95", score.percentile >= 95, String(score.percentile));
  check("tilesShown = 78", score.tilesShown === 78, String(score.tilesShown));
  check("ladder 12 levels", score.ladder.length === 12);
}

section("End-to-end pipeline coherence (3 simulated profiles)");
{
  const runProfile = (seed: number, mu: number, k: number) => {
    const rng = mulberry32(seed);
    const attempts: LevelAttempt[] = [];
    let level = START_LEVEL;
    while (level < 30) {
      const run = buildRunSequence(level, rng);
      const pPass = 1 / (1 + Math.exp((level - mu) / k));
      const pass = rng() < pPass;
      const correctClicks = pass ? level : Math.floor(rng() * level);
      attempts.push({ level, sequence: run, correctClicks, cleared: pass });
      if (pass) level += 1;
      else break; // single life: one failure ends the run
    }
    return scoreRun(attempts);
  };
  const weak = runProfile(1, 5.0, 0.65);
  const avg = runProfile(101, 8.1, 0.65);
  const strong = runProfile(201, 11.4, 0.65);
  check("all profiles produce finite scores", [weak, avg, strong].every((s) => Number.isFinite(s.iq) && Number.isFinite(s.percentile)));
  check("weak < avg < strong span", weak.span < avg.span && avg.span < strong.span,
    `${weak.span} < ${avg.span} < ${strong.span}`);
  check("weak < avg < strong IQ", weak.iq < avg.iq && avg.iq < strong.iq,
    `${weak.iq} < ${avg.iq} < ${strong.iq}`);
  check("weak percentile <= avg <= strong", weak.percentile <= avg.percentile && avg.percentile <= strong.percentile);
  console.log(`  info   weak: span ${weak.span} IQ ${weak.iq} P${weak.percentile} | avg: span ${avg.span} IQ ${avg.iq} P${avg.percentile} | strong: span ${strong.span} IQ ${strong.iq} P${strong.percentile}`);
}

section("Population simulation (N=1000 realistic single-life users)");
{
  // Each user gets a skill-driven mean clearance level; per-level pass
  // probability follows a logistic psychometric curve; one failure ends
  // the run. Nothing here is used by the engine - it only validates
  // that the scoring maps a realistic population to ~100/15.
  const MU_BASE = 8.1;
  const MU_SLOPE = 1.4;
  const K = 0.65;
  const iqSamples: number[] = [];
  const spanSamples: number[] = [];
  for (let user = 0; user < 1000; user++) {
    const rng = mulberry32(300_000 + user);
    const skill = randn(rng);
    const mu = MU_BASE + MU_SLOPE * skill;
    const attempts: LevelAttempt[] = [];
    let level = START_LEVEL;
    while (level < 30) {
      const run = buildRunSequence(level, rng);
      const pPass = 1 / (1 + Math.exp((level - mu) / K));
      const pass = rng() < pPass;
      const correctClicks = pass ? level : Math.floor(rng() * level);
      attempts.push({ level, sequence: run, correctClicks, cleared: pass });
      if (pass) level += 1;
      else break;
    }
    const score = scoreRun(attempts);
    iqSamples.push(score.iq);
    spanSamples.push(score.span);
  }
  const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  const sd = (xs: number[]) => {
    const m = mean(xs);
    return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
  };
  const median = (xs: number[]) => {
    const s = [...xs].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)]!;
  };
  const meanIq = mean(iqSamples);
  const sdIq = sd(iqSamples);
  const meanSpan = mean(spanSamples);
  const sdSpan = sd(spanSamples);
  const distinctSpans = new Set(spanSamples).size;
  check("mean IQ within 100 +/- 3 (97..103)", meanIq > 97 && meanIq < 103, String(meanIq.toFixed(2)));
  check("IQ SD in 12..18", sdIq > 12 && sdIq < 18, String(sdIq.toFixed(2)));
  check("median IQ 95..105", median(iqSamples) >= 95 && median(iqSamples) <= 105, String(median(iqSamples)));
  check("mean span near anchor 7.4 (6.9..7.9)", meanSpan > 6.9 && meanSpan < 7.9, String(meanSpan.toFixed(2)));
  check("spans spread over >= 6 distinct values", distinctSpans >= 6, String(distinctSpans));
  check("no negative spans", spanSamples.every((s) => s >= SPAN_FLOOR));
  console.log(`  info   simulated mean IQ=${meanIq.toFixed(2)} SD=${sdIq.toFixed(2)} | mean span=${meanSpan.toFixed(2)} span SD=${sdSpan.toFixed(2)} | distinct spans=${distinctSpans}`);
}

section("Quick mode contract");
{
  check("quick timings are shorter than real ones", QUICK_ON_MS < speedForLevel(START_LEVEL).onMs && QUICK_OFF_MS < BASE_OFF_MS);
  check("quick mode is a timing change only", timingForLevel(3, true).onMs === timingForLevel(9, true).onMs);
  // A quick-mode user clears level 1 then fails level 2 -> run over.
  const quickAttempts: LevelAttempt[] = [
    { level: 1, sequence: [3], correctClicks: 1, cleared: true },
    { level: 2, sequence: [3, 7], correctClicks: 1, cleared: false },
  ];
  const quickScore = scoreRun(quickAttempts);
  check("quick run ends after one failed attempt", quickScore.deepest === 2 && quickScore.span === 1);
  check("single-life honesty: failed level in ladder", quickScore.ladder.length === 2 && !quickScore.ladder[1]!.cleared);
}

/* ---------------------------------------------------------------- */

console.log(`\n=========================================`);
console.log(`RESULTS: ${pass} PASS, ${fail} FAIL`);
if (fail > 0) process.exit(1);
console.log("ALL PASS");
