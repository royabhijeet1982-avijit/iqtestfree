/**
 * Task 23 verification: Processing Speed test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-processing-speed-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Full valid run 1 via pad clicks (?quick=1, 15s sprint)
 *  - Keyboard answering during run 1 (number keys)
 *  - Valid results: PSI, grade, percentile, accuracy 100%, epochs, insight
 *  - Run 2 (retake): key re-randomised vs run 1, second valid score
 *  - Anti-gaming: random mash run -> invalid, "not scored", reason shown
 *  - 375px: no horizontal overflow on intro / active / results
 *  - zero console/page errors
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll the PSI chip until CountUp finishes animating (starts at 0). */
async function readPsi(p) {
  let prev = -1;
  for (let i = 0; i < 40; i++) {
    const t = await p.$eval('[data-testid="ps-psi"]', (el) => el.textContent.trim()).catch(() => "0");
    const n = Number(t);
    if (Number.isFinite(n) && n > 0 && n === prev) return n; // stable across two reads
    prev = n;
    await sleep(150);
  }
  return 0;
}

/** Read the active coding key from the DOM: symbol -> digit map + pad order. */
async function readKey(p) {
  const pairs = await p.$$eval('[data-testid="ps-key"] [data-symbol]', (els) =>
    els.map((el) => ({ symbol: el.getAttribute("data-symbol"), digit: Number(el.getAttribute("data-digit")) }))
  );
  const padDigits = await p.$$eval('[data-testid^="ps-pad-"]', (els) =>
    els.map((el) => Number(el.getAttribute("data-testid").replace("ps-pad-", "")))
  );
  const map = {};
  for (const pair of pairs) map[pair.symbol] = pair.digit;
  return { map, padDigits };
}

/** Answer every trial correctly (mix of pad clicks and keyboard presses). */
async function sprintCorrectly(p, key) {
  let padResponses = 0;
  let keyResponses = 0;
  const deadline = Date.now() + 30_000; // safety net (sprint is 15s in quick mode)
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="ps-results"]')) break;
    const symbolEl = await p.$('[data-testid="ps-symbol"]');
    if (!symbolEl) { await sleep(50); continue; }
    const symbol = (await symbolEl.textContent()).trim();
    const digit = key.map[symbol];
    if (digit == null) { await sleep(30); continue; }
    try {
      if (keyResponses < 4) {
        // use the keyboard for the first 4 trials
        await p.keyboard.press(String(digit));
        keyResponses++;
      } else {
        const btn = await p.$(`[data-testid="ps-pad-${digit}"]`);
        if (!btn) { await sleep(30); continue; }
        // DOM-level click: skips actionability waits that race the timer
        await btn.evaluate((el) => el.click());
        padResponses++;
      }
    } catch {
      // sprint ended mid-click (phase unmounted) - loop re-checks results
    }
    await sleep(60);
  }
  return { padResponses, keyResponses };
}

/** Mash random pad buttons until the results screen appears. */
async function mashSprint(p) {
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="ps-results"]')) break;
    try {
      const pads = await p.$$('[data-testid^="ps-pad-"]');
      if (pads.length === 0) { await sleep(50); continue; }
      const btn = pads[Math.floor(Math.random() * pads.length)];
      await btn.evaluate((el) => el.click());
    } catch {
      // phase unmounted mid-click - loop re-checks results
    }
  }
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test/processing-speed`, { waitUntil: "networkidle" });
  console.log("— SEO checks —");
  const title = await p.title();
  title === "Free Processing Speed Test Online | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("processing speed test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/processing-speed"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/processing-speed"
    ? ok("BreadcrumbList: BrainMetrics > Processing Speed Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="ps-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok(`FAQPage JSON-LD has 6 questions`)
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok(`visible FAQ has 6 items`)
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Processing") && h1.includes("Speed Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);

  /* ---------------- Run 1: valid sprint (quick mode) ---------------- */
  console.log("— Run 1: valid sprint (?quick=1) —");
  await p.goto(`${BASE}/test/processing-speed?quick=1`, { waitUntil: "networkidle" });
  const intro = await p.$('[data-testid="ps-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  const startBtn = await p.$('[data-testid="ps-start"]');
  if (!startBtn) { fail("start button missing"); return finish(browser, errors); }
  await startBtn.click();

  // countdown shows the key
  await p.waitForSelector('[data-testid="ps-countdown"]', { timeout: 5000 });
  const pairsInCountdown = await p.$$eval('[data-testid="ps-countdown"] [data-testid^="ps-key-pair-"]', (els) => els.length);
  pairsInCountdown === 6 ? ok("countdown shows 6-pair key") : fail(`countdown pairs: ${pairsInCountdown}`);

  await p.waitForSelector('[data-testid="ps-active"]', { timeout: 6000 });
  ok("sprint started (active phase)");
  const timerText = await p.$eval('[data-testid="ps-timer"]', (el) => el.textContent.trim());
  /^\d+:\d{2}$/.test(timerText) ? ok(`timer format: ${timerText}`) : fail(`timer text: ${timerText}`);
  const padCount = await p.$$eval('[data-testid^="ps-pad-"]', (els) => els.length);
  padCount === 6 ? ok("pad has 6 digit buttons") : fail(`pad buttons: ${padCount}`);

  await noHorizontalOverflow(p, "active phase");

  const key1 = await readKey(p);
  const usedSymbols = Object.keys(key1.map);
  usedSymbols.length === 6 ? ok(`run-1 key parsed (${usedSymbols.join(" ")})`) : fail("run-1 key parse failed");

  const { padResponses, keyResponses } = await sprintCorrectly(p, key1);
  ok(`answered ${padResponses} via pad + ${keyResponses} via keyboard`);

  await p.waitForSelector('[data-testid="ps-results"]', { timeout: 8000 });
  ok("results screen reached");
  const psi = await readPsi(p);
  psi >= 55 && psi <= 145 ? ok(`PSI: ${psi} (in range)`): fail(`PSI: ${psi}`);
  const invalidOnRun1 = await p.$('[data-testid="ps-invalid"]');
  !invalidOnRun1 ? ok("valid path (no invalid card)") : fail("invalid card shown on a perfect run");
  const grade = await p.$eval('[data-testid="ps-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const percentile = await p.$eval('[data-testid="ps-percentile"]', (el) => el.textContent.trim());
  percentile.includes("Faster than") ? ok(`percentile line: ${percentile}`) : fail(`percentile: ${percentile}`);
  const accuracyText = await p.$eval('[data-testid="ps-stat-accuracy"] p', (el) => el.textContent.trim());
  accuracyText === "100%" ? ok(`accuracy 100% (perfect run)`) : fail(`accuracy: ${accuracyText}`);
  const rateText = await p.$eval('[data-testid="ps-stat-rate"] p', (el) => el.textContent.trim());
  Number(rateText) > 0 ? ok(`rate/min: ${rateText}`) : fail(`rate: ${rateText}`);
  const rtText = await p.$eval('[data-testid="ps-stat-rt"] p', (el) => el.textContent.trim());
  /^\d+\.\d\ds$/.test(rtText) ? ok(`avg time per item: ${rtText}`) : fail(`rt: ${rtText}`);
  const epochBars = await p.$$eval('[data-testid^="ps-epoch-"]', (els) => els.length);
  epochBars === 6 ? ok("6 throughput epoch bars render") : fail(`epoch bars: ${epochBars}`);
  const insight = await p.$eval('[data-testid="ps-results"] p.flex, [data-testid="ps-results"] p[class*="flex items-start"]', (el) => el.textContent).catch(() => "");
  insight.length > 20 ? ok(`pace insight present`) : fail(`insight: "${insight.slice(0, 40)}"`);
  await noHorizontalOverflow(p, "results");

  /* ---------------- Run 2: retake with new key ---------------- */
  console.log("— Run 2: retake -> key re-randomised —");
  const retakeBtn = await p.$('[data-testid="ps-retake"]');
  if (!retakeBtn) { fail("retake button missing"); return finish(browser, errors); }
  await retakeBtn.click();
  await p.waitForSelector('[data-testid="ps-active"]', { timeout: 8000 });
  const key2 = await readKey(p);
  const sameMapping = JSON.stringify(key1.map) === JSON.stringify(key2.map);
  !sameMapping ? ok("key mapping changed on retake (anti-memorisation)") : fail("retake reused the same key mapping!");
  const padChanged = JSON.stringify(key1.padDigits) !== JSON.stringify(key2.padDigits);
  padChanged ? ok("pad order also reshuffles") : ok("pad order coincidentally equal (acceptable)");
  await sprintCorrectly(p, key2);
  await p.waitForSelector('[data-testid="ps-results"]', { timeout: 8000 });
  const psi2 = await readPsi(p);
  psi2 >= 55 && psi2 <= 145 ? ok(`run-2 PSI: ${psi2}`) : fail(`run-2 PSI: ${psi2}`);

  /* ---------------- Run 3: mash (anti-gaming) ---------------- */
  console.log("— Run 3: random mashing -> must be invalid —");
  await p.goto(`${BASE}/test/processing-speed?quick=1`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="ps-start"]')).click();
  await p.waitForSelector('[data-testid="ps-active"]', { timeout: 8000 });
  await mashSprint(p);
  await p.waitForSelector('[data-testid="ps-results"]', { timeout: 8000 });
  const invalidCard = await p.$('[data-testid="ps-invalid"]');
  invalidCard ? ok("mash run flagged invalid") : fail("mash run was scored (anti-gaming FAILED)");
  const psiOnMash = await p.$('[data-testid="ps-psi"]');
  !psiOnMash ? ok("no PSI shown for invalid run") : fail("PSI rendered despite invalid");
  const notScored = await p.$eval('[data-testid="ps-results"]', (el) => el.textContent);
  notScored.includes("not scored") ? ok('"not scored" message shown') : fail("missing not-scored message");
  notScored.includes("ccuracy") ? ok("reason mentions accuracy") : fail("reason does not mention accuracy");
  const mashStats = await p.$$eval('[data-testid="ps-invalid"]', (els) => els.length);
  mashStats === 1 ? ok("invalid card renders raw stats") : fail("invalid card missing");

  /* ---------------- Mobile 375px ---------------- */
  console.log("— Mobile 375px —");
  const mp = await ctx.newPage();
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/processing-speed`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="ps-start"]')).click();
  await mp.waitForSelector('[data-testid="ps-active"]', { timeout: 8000 });
  await noHorizontalOverflow(mp, "active");
  const mkey = await readKey(mp);
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
