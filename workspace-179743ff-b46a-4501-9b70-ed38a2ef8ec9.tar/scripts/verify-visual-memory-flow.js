/**
 * Task 24-d verification: Visual Memory test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-visual-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1): the script WATCHES the playback by polling tile
 *    classes every 40ms, records the lit-tile order, then during RECALL clicks
 *    the recorded sequence via vm-tile buttons - clears levels 3..6, then
 *    deliberately misses at level 7 -> results (span, IQ, percentile, ladder)
 *  - Retake: second run's first playback sequence differs from run 1
 *  - Anti-gaming (default 2 lives): a deliberate wrong click consumes a life,
 *    the SAME length replays with a DIFFERENT sequence; failing again ends the
 *    run with the floor span (2) and an honest low IQ - no crash
 *  - 375px: no horizontal overflow on intro / active / results
 *  - zero console/page errors
 *
 * NOTE: the anti-gaming section runs WITHOUT ?quick=1 on purpose: the retry
 * behaviour (life consumed, new sequence) needs 2 lives; quick mode has 1.
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll a CountUp testid until the visible number matches its final value.
 *  The component exposes data-final, so animation frames cannot fool us. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.trim()),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.final > 0 && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/**
 * WATCH a playback: poll the 9 tiles every 40ms; whenever exactly one tile
 * carries is-lit / data-lit="true" and it differs from the previous lit tile,
 * record it. Returns the ordered sequence once the stage leaves playback.
 */
async function watchPlayback(p, timeoutMs = 30000) {
  const seq = [];
  const start = Date.now();
  let lastLit = -1;
  let sawPlayback = false;
  while (Date.now() - start < timeoutMs) {
    if (await p.$('[data-testid="vm-results"]')) break;
    const phase = await p
      .$eval('[data-testid="vm-stage"]', (el) => el.getAttribute("data-phase"))
      .catch(() => null);
    if (phase === "playback") {
      sawPlayback = true;
      const lit = await p.$$eval('[data-testid^="vm-tile-"]', (els) =>
        els
          .map((el, i) => ({
            i,
            lit: el.classList.contains("is-lit") || el.getAttribute("data-lit") === "true",
          }))
          .filter((x) => x.lit)
          .map((x) => x.i)
      );
      if (lit.length === 1 && lit[0] !== lastLit) {
        seq.push(lit[0]);
        lastLit = lit[0];
      }
    } else if (sawPlayback) {
      break; // recall or feedback reached - playback over
    }
    await sleep(40);
  }
  return seq;
}

/** Wait until the stage is in the recall phase (clickable). */
async function waitRecall(p, timeoutMs = 12000) {
  await p
    .waitForFunction(
      () => {
        const el = document.querySelector('[data-testid="vm-stage"]');
        return !!el && el.getAttribute("data-phase") === "recall";
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/** DOM-level click on a tile button (skips actionability waits). */
async function clickTile(p, tile) {
  const btn = await p.$(`[data-testid="vm-tile-${tile}"]`);
  if (!btn) throw new Error(`vm-tile-${tile} not found`);
  await btn.evaluate((el) => el.click());
}

/** Atomic snapshot of the active phase (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => ({
      results: !!document.querySelector('[data-testid="vm-results"]'),
      active: !!document.querySelector('[data-testid="vm-active"]'),
      phase: document.querySelector('[data-testid="vm-stage"]')?.getAttribute("data-phase") ?? null,
      levelText: document.querySelector('[data-testid="vm-level"]')?.textContent ?? null,
      statusText: document.querySelector('[data-testid="vm-status"]')?.textContent ?? null,
      livesLost: Array.from(
        document.querySelectorAll('[data-testid="vm-lives"] span[data-life-lost="true"]')
      ).length,
    }))
    .catch(() => null);
}

/** Click the whole recorded sequence back, one tile at a time. */
async function recallAll(p, seq) {
  for (const tile of seq) {
    const snap = await snapshot(p);
    if (!snap || snap.results) return false; // run ended early - abort quietly
    await waitRecall(p);
    await clickTile(p, tile);
    await sleep(60);
  }
  return true;
}

/** A tile that is guaranteed NOT to be the expected first tile. */
const wrongTileFor = (seq) => (seq[0] + 1) % 9;

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test/visual-memory`, { waitUntil: "networkidle" });
  console.log("- SEO checks -");
  const title = await p.title();
  title === "Free Visual Memory Test Online | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("visual memory test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/visual-memory"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/visual-memory"
    ? ok("BreadcrumbList: BrainMetrics > Visual Memory Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="vm-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok("FAQPage JSON-LD has 6 questions")
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok("visible FAQ has 6 items")
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Visual") && h1.includes("Memory Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const related = await p.$eval("#related-tests-heading", (el) => el.textContent.trim()).catch(() => null);
  related === "Try another test" ? ok("RelatedTests band renders") : fail(`RelatedTests: ${related}`);

  /* ---------------- Golden path (quick mode) ---------------- */
  console.log("- Run 1: golden path (?quick=1) -");
  await p.goto(`${BASE}/test/visual-memory?quick=1`, { waitUntil: "networkidle" });
  const intro = await p.$('[data-testid="vm-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  const startBtn = await p.$('[data-testid="vm-intro-cta"]');
  if (!startBtn) { fail("start button missing"); return finish(browser, errors); }
  await startBtn.click();

  await p.waitForSelector('[data-testid="vm-active"]', { timeout: 12000 });
  ok("run started (active phase)");
  const lives1 = await p.$$eval('[data-testid="vm-lives"] span', (els) => els.length);
  lives1 === 1 ? ok("quick mode shows 1 life") : fail(`quick lives: ${lives1}`);

  const MAX_CLEAR = 6;
  let firstSeqRun1 = null;
  let goldenGuard = 0;
  let earlyEnd = null;
  while (goldenGuard < 12) {
    const snap0 = await snapshot(p);
    if (!snap0 || snap0.results) { earlyEnd = `run ended before level ${goldenGuard + 3}`; break; }
    const seq = await watchPlayback(p, 30000);
    const snap = await snapshot(p);
    if (!snap || snap.results) {
      earlyEnd = `run ended during/after level-${3 + goldenGuard} playback (watched [${seq.join(", ")}])`;
      break;
    }
    if (!snap.levelText) {
      fail(`vm-level missing while active (phase=${snap.phase}, status=${snap.statusText})`);
      break;
    }
    const level = Number(snap.levelText.replace(/[^0-9]/g, ""));
    if (seq.length !== level) {
      fail(`playback watch captured ${seq.length}/${level} tiles (phase=${snap.phase})`);
      break;
    }
    if (!firstSeqRun1) {
      firstSeqRun1 = seq;
      ok(`watched level-3 playback: tiles [${seq.join(", ")}] (observed via is-lit)`);
    }
    if (level <= MAX_CLEAR) {
      await waitRecall(p);
      const status = await p.$eval('[data-testid="vm-status"]', (el) => el.textContent.trim());
      status.includes("Your turn") ? ok(`level ${level} recall status ok`) : fail(`status: ${status}`);
      if (level === 3) {
        const prog = await p.$eval('[data-testid="vm-progress"]', (el) => el.textContent.trim());
        prog === "0 / 3" ? ok("progress chip: 0 / 3") : fail(`progress: ${prog}`);
      }
      const completed = await recallAll(p, seq);
      if (!completed) { earlyEnd = `a recall click failed at level ${level} (quick run over)`; break; }
    } else {
      // deliberate first-position miss at level 7 -> quick run ends by design
      await waitRecall(p);
      await clickTile(p, wrongTileFor(seq));
      break;
    }
  }
  if (earlyEnd) fail(`golden path ended early: ${earlyEnd}`);
  await p.waitForSelector('[data-testid="vm-results"]', { timeout: 15000 });
  ok("results screen reached");

  const span = await readStable(p, "vm-span");
  span === MAX_CLEAR ? ok(`visual span: ${span} (cleared 3..${MAX_CLEAR})`) : fail(`span: ${span}`);
  const iq = await readStable(p, "vm-iq");
  iq >= 55 && iq <= 145 ? ok(`memory IQ: ${iq} (in range)`) : fail(`IQ: ${iq}`);
  const grade = await p.$eval('[data-testid="vm-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const percentile = await p.$eval('[data-testid="vm-percentile"]', (el) => el.textContent.trim());
  percentile.includes("Better than") ? ok(`percentile line: ${percentile}`) : fail(`percentile: ${percentile}`);
  const ladder = await p.$$eval('[data-testid="vm-ladder"] [data-status]', (els) =>
    els.map((el) => ({ id: el.getAttribute("data-testid"), status: el.getAttribute("data-status") }))
  );
  const clearedOk =
    ladder.length === 5 &&
    ["3", "4", "5", "6"].every((lv, i) => ladder[i].id === `vm-ladder-level-${lv}` && ladder[i].status === "cleared") &&
    ladder[4].id === "vm-ladder-level-7" && ladder[4].status === "failed";
  clearedOk ? ok("level ladder: 3-6 cleared, 7 failed") : fail(`ladder: ${JSON.stringify(ladder)}`);
  const tiles = await p.$eval('[data-testid="vm-stat-tiles"] p', (el) => el.textContent.trim());
  Number(tiles) === 18 ? ok(`tiles recalled: ${tiles}`) : fail(`tiles: ${tiles}`);
  const recallStat = await p.$eval('[data-testid="vm-stat-recall"] p', (el) => el.textContent.trim());
  /^\d+\.\d\ds$/.test(recallStat) ? ok(`avg recall speed: ${recallStat}`) : fail(`recall stat: ${recallStat}`);
  const retakeBtn = await p.$('[data-testid="vm-retake"]');
  retakeBtn ? ok("retake button present") : fail("retake button missing");

  /* ---------------- Run 2: retake, new sequence ---------------- */
  console.log("- Run 2: retake -> first playback differs -");
  let seq2 = null;
  let retakeAttempts = 0;
  while (retakeAttempts < 3 && !seq2) {
    retakeAttempts++;
    const btn = await p.$('[data-testid="vm-retake"]');
    if (!btn) { fail("retake button missing (run 2)"); break; }
    await btn.click();
    await p.waitForSelector('[data-testid="vm-active"]', { timeout: 12000 });
    const s = await watchPlayback(p, 30000);
    const snap = await snapshot(p);
    if (!snap || snap.results || s.length !== 3) {
      fail(`run-2 playback capture failed (tiles=${s.length}, results=${snap ? snap.results : "n/a"})`);
      break;
    }
    if (s.join(",") !== firstSeqRun1.join(",")) {
      seq2 = s;
      ok(`run-2 first playback [${s.join(", ")}] differs from run 1 [${firstSeqRun1.join(", ")}]`);
      // end run 2 quickly with a deliberate miss (1 life in quick mode)
      await waitRecall(p);
      await clickTile(p, wrongTileFor(s));
    } else {
      // astronomically unlikely collision - end and retake again
      await waitRecall(p);
      await clickTile(p, wrongTileFor(s));
    }
    await p.waitForSelector('[data-testid="vm-results"]', { timeout: 15000 });
  }
  seq2 ? ok("retake dealt a fresh pattern (anti-memorisation)") : fail("retake replayed the same first sequence");

  /* ---------------- Anti-gaming: deliberate miss, retry, floor score ---------------- */
  console.log("- Run 3: anti-gaming (default 2 lives) -");
  await p.goto(`${BASE}/test/visual-memory`, { waitUntil: "networkidle" });
  await (await p.$('[data-testid="vm-intro-cta"]')).click();
  await p.waitForSelector('[data-testid="vm-active"]', { timeout: 12000 });
  const lives3 = await p.$$eval('[data-testid="vm-lives"] span', (els) => els.length);
  lives3 === 2 ? ok("default mode shows 2 lives") : fail(`default lives: ${lives3}`);

  const seqA = await watchPlayback(p, 30000);
  if (seqA.length !== 3) fail(`run-3 playback captured ${seqA.length}/3 tiles`);
  await waitRecall(p);
  await clickTile(p, wrongTileFor(seqA));
  await sleep(250);
  const lostDots = await p.$$eval('[data-testid="vm-lives"] span', (els) =>
    els.filter((e) => e.getAttribute("data-life-lost") === "true").length
  );
  lostDots === 1 ? ok("wrong click consumed exactly one life") : fail(`lost dots: ${lostDots}`);
  const litDuringFeedback = await p.$$eval('[data-testid^="vm-tile-"]', (els) =>
    els.filter((e) => e.getAttribute("data-lit") === "true").length
  );
  litDuringFeedback >= 1 ? ok("missed tile revealed during feedback") : fail("no reveal tile lit");

  const seqB = await watchPlayback(p, 30000);
  if (seqB.length !== 3) {
    fail(`retry playback captured ${seqB.length}/3 tiles`);
  } else if (seqB.join(",") !== seqA.join(",")) {
    ok(`retry replays a NEW sequence [${seqB.join(", ")}] != [${seqA.join(", ")}] (same length 3)`);
  } else {
    fail("retry replayed the identical sequence (anti-gaming FAILED)");
  }
  await waitRecall(p);
  await clickTile(p, wrongTileFor(seqB));
  await p.waitForSelector('[data-testid="vm-results"]', { timeout: 15000 });
  ok("run ended after second miss (no crash)");
  const floorSpan = await readStable(p, "vm-span");
  floorSpan === 2 ? ok(`floor span recorded: ${floorSpan}`) : fail(`floor span: ${floorSpan}`);
  const lowIq = await readStable(p, "vm-iq");
  lowIq < 85 ? ok(`honest low IQ: ${lowIq}`) : fail(`low IQ: ${lowIq}`);
  const lowPct = await p.$eval('[data-testid="vm-percentile"]', (el) => el.textContent.trim());
  lowPct.includes("Better than") ? ok(`low percentile line: ${lowPct}`) : fail(`percentile: ${lowPct}`);
  const failLadder = await p.$$eval('[data-testid="vm-ladder"] [data-status]', (els) =>
    els.map((el) => el.getAttribute("data-status"))
  );
  failLadder.length === 1 && failLadder[0] === "failed"
    ? ok("ladder shows the failed level 3 attempt")
    : fail(`ladder: ${JSON.stringify(failLadder)}`);

  /* ---------------- Mobile 375px ---------------- */
  console.log("- Mobile 375px -");
  const mp = await ctx.newPage();
  const merrors = [];
  mp.on("pageerror", (e) => merrors.push("pageerror: " + e.message));
  mp.on("console", (m) => { if (m.type() === "error") merrors.push("console: " + m.text()); });
  await mp.setViewportSize({ width: 375, height: 740 });
  await mp.goto(`${BASE}/test/visual-memory?quick=1`, { waitUntil: "networkidle" });
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="vm-intro-cta"]')).click();
  await mp.waitForSelector('[data-testid="vm-active"]', { timeout: 12000 });
  await noHorizontalOverflow(mp, "active (playback)");
  const mseq = await watchPlayback(mp, 30000);
  await waitRecall(mp);
  await noHorizontalOverflow(mp, "active (recall)");
  await clickTile(mp, wrongTileFor(mseq)); // 1 life -> results
  await mp.waitForSelector('[data-testid="vm-results"]', { timeout: 15000 });
  await noHorizontalOverflow(mp, "results");
  await mp.close();
  merrors.forEach((e) => errors.push("mobile " + e));

  /* ---------------- Console errors ---------------- */
  console.log("- Console -");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
