/**
 * Quick screenshots for Short-Term Memory page (intro + delay task).
 * Run: node scripts/screenshot-short-term-memory.js
 * Outputs: scripts/stm-intro.png, scripts/stm-delay.png
 * (Results view is verified numerically by verify-short-term-memory-flow.js)
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();

  // Desktop intro
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const dpage = await desktop.newPage();
  await dpage.goto(`${BASE}/test/short-term-memory`, { waitUntil: "networkidle" });
  await dpage.waitForTimeout(600);
  await dpage.screenshot({ path: "scripts/stm-intro.png", fullPage: false });
  console.log("saved scripts/stm-intro.png");
  await desktop.close();

  // Mobile delay-task phase (quick mode)
  const mobile = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const mpage = await mobile.newPage();
  await mpage.goto(`${BASE}/test/short-term-memory?quick=1`, { waitUntil: "networkidle" });
  await mpage.click('[data-testid="stm-intro-cta"]');
  let reached = false;
  for (let i = 0; i < 300; i++) {
    const phase = await mpage
      .$eval('[data-testid="stm-stage"]', (el) => el.getAttribute("data-phase"))
      .catch(() => null);
    if (phase === "delay") { reached = true; break; }
    await sleep(20);
  }
  if (reached) {
    await mpage.waitForTimeout(250);
    await mpage.screenshot({ path: "scripts/stm-delay.png", fullPage: false });
    console.log("saved scripts/stm-delay.png");
  } else {
    console.log("delay phase not reached in time - screenshot skipped");
  }
  await mobile.close();

  await browser.close();
  console.log("done");
})();
