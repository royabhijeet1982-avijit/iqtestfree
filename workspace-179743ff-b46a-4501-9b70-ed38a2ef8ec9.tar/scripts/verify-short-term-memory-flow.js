/**
 * Task C verification: Short-Term Memory (Brown-Peterson) flow + SEO.
 * Run: node /home/z/my-project/scripts/verify-short-term-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1, 375px): driver polls each trial's SHOW phase and
 *    captures data-letters, waits for RECALL, types the exact trigram,
 *    submits -> accuracy 100%, IQ 145, Steel trap, percentile 99, all trial
 *    chips 3/3, all decay bars 100
 *  - Anti-cheat: data-letters present ONLY during show (absent during delay
 *    and recall phases)
 *  - Retake: second run's first trigram differs from run 1 (fresh draw)
 *  - Anti-gaming (?quick=1): typing QQQ for every trial -> accuracy 0,
 *    IQ 55 floor, percentile 1, Evaporated (Q excluded from the pool)
 *  - 375px: no horizontal overflow on intro / recall / results
 *  - zero console/page errors across all runs
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Read a CountUp testid until the visible number matches data-final. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.replace(/[^0-9.-]/g, "")),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/** First integer embedded in an element's text. */
async function readFirstInt(p, testid) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval(`[data-testid="${testid}"]`, (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/\d+/);
      if (m) return Number(m[0]);
    }
    await sleep(150);
  }
  return -1;
}

/** "Better than 99 in 100 adults" -> 99. */
async function readPercentile(p) {
  for (let i = 0; i < 20; i++) {
    const txt = await p
      .$eval('[data-testid="stm-percentile"]', (el) => el.textContent)
      .catch(() => null);
    if (txt) {
      const m = txt.match(/Better than (\d+)/);
      if (m) return Number(m[1]);
    }
    await sleep(150);
  }
  return -1;
}

/** Atomic snapshot (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => {
      const stage = document.querySelector('[data-testid="stm-stage"]');
      const trigram = document.querySelector('[data-testid="stm-trigram"]');
      return {
        results: !!document.querySelector('[data-testid="stm-results"]'),
        intro: !!document.querySelector('[data-testid="stm-intro"]'),
        countdown: !!document.querySelector('[data-testid="stm-countdown"]'),
        phase: stage ? stage.getAttribute("data-phase") : null,
        trial: (() => {
          const chip = document.querySelector('[data-testid="stm-round-chip"]');
          return chip ? parseInt(chip.textContent.replace(/[^0-9]/g, ""), 10) : 0;
        })(),
        letters: trigram ? trigram.getAttribute("data-letters") : null,
      };
    })
    .catch(() => null);
}

/**
 * Wait until a run has ACTUALLY begun (intro / countdown / stage, no
 * results). Critical for the retake path where the old results panel is
 * still mid-exit (~400ms AnimatePresence).
 */
async function waitForRunStart(p, timeoutMs = 15000) {
  await p
    .waitForFunction(
      () => {
        const intro = document.querySelector('[data-testid="stm-intro"]');
        const countdown = document.querySelector('[data-testid="stm-countdown"]');
        const results = document.querySelector('[data-testid="stm-results"]');
        const stage = document.querySelector('[data-testid="stm-stage"]');
        return !!intro || !!countdown || (!!stage && !results);
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/**
 * Play one full session. answerFor(trialIdx, trigram) -> string to type.
 * Returns { trigrams: {1: "...", ...}, sawLettersDuringDelay: bool }.
 */
async function playSession(p, answerFor) {
  await waitForRunStart(p);
  const hasIntro = await p.$('[data-testid="stm-intro"]');
  if (hasIntro) await p.click('[data-testid="stm-intro-cta"]');
  const t0 = Date.now();

  const trigrams = {};
  let sawLettersDuringDelay = false;
  let lastTrialCaptured = 0;
  let sawResults = false;

  while (Date.now() - t0 < 150000) {
    const st = await snapshot(p);
    if (!st) { await sleep(30); continue; }
    if (st.results) { sawResults = true; break; }

    if (st.phase === "show" && st.trial >= 1 && st.letters) {
      trigrams[st.trial] = st.letters;
      lastTrialCaptured = st.trial;
    }
    if (st.phase === "delay" && st.letters) {
      sawLettersDuringDelay = true; // anti-cheat violated if ever true
    }
    if (st.phase === "recall" && st.trial >= lastTrialCaptured) {
      const answer = answerFor(st.trial, trigrams[st.trial] || "");
      await p.fill('[data-testid="stm-recall-input"]', answer).catch(() => {});
      await p.click('[data-testid="stm-recall-submit"]').catch(() => {});
      await sleep(80);
    }
    await sleep(20);
  }
  await sleep(400);
  return { trigrams, sawLettersDuringDelay, sawResults };
}

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 375, height: 667 } });
  const page = await context.newPage();

  const consoleErrors = [];
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });
  page.on("pageerror", (e) => consoleErrors.push(String(e)));

  /* ------------------------- SEO surface ------------------------- */
  console.log("SEO surface:");
  await page.goto(`${BASE}/test/short-term-memory`, { waitUntil: "networkidle", timeout: 30000 });

  const title = await page.title();
  if (/short.?term memory test/i.test(title)) ok(`title: ${title}`); else fail(`title: ${title}`);

  const desc = await page
    .$eval('meta[name="description"]', (el) => el.getAttribute("content"))
    .catch(() => null);
  if (desc && desc.length > 80) ok(`description (${desc.length} chars)`); else fail("description missing/short");

  const canonical = await page
    .$eval('link[rel="canonical"]', (el) => el.getAttribute("href"))
    .catch(() => null);
  if (canonical && canonical.includes("/test/short-term-memory")) ok(`canonical: ${canonical}`);
  else fail(`canonical: ${canonical}`);

  const jsonLdTypes = await page
    .$$eval('script[type="application/ld+json"]', (els) =>
      els.map((el) => {
        try { return JSON.parse(el.textContent)["@type"]; } catch { return "PARSE_ERROR"; }
      })
    )
    .catch(() => []);
  if (
    jsonLdTypes.includes("WebApplication") &&
    jsonLdTypes.includes("BreadcrumbList") &&
    jsonLdTypes.includes("FAQPage")
  )
    ok(`JSON-LD x3: ${jsonLdTypes.join(", ")}`);
  else fail(`JSON-LD types: ${jsonLdTypes.join(", ")}`);

  const h1 = await page.$eval("h1", (el) => el.textContent.trim()).catch(() => null);
  if (h1 && /short.?term/i.test(h1)) ok(`h1: ${h1}`); else fail(`h1: ${h1}`);

  const faqCount = await page.$$eval('[data-testid^="stm-faq-item-"]', (els) => els.length).catch(() => 0);
  if (faqCount === 6) ok(`FAQ parity: 6 items rendered`); else fail(`FAQ items: ${faqCount} (expected 6)`);

  /* ------------------------- golden path ------------------------- */
  console.log("\nGolden path (?quick=1, 375px):");
  await page.goto(`${BASE}/test/short-term-memory?quick=1`, { waitUntil: "networkidle" });
  await page.waitForSelector('[data-testid="stm-intro"]', { timeout: 15000 });

  const run1 = await playSession(page, (_t, gram) => gram);

  const acc1 = await readStable(page, "stm-accuracy");
  const iq1 = await readStable(page, "stm-iq");
  const grade1 = await page.$eval('[data-testid="stm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct1 = await readPercentile(page);
  const correct1 = await readFirstInt(page, "stm-stat-correct");

  if (acc1 === 100) ok(`accuracy 100%`); else fail(`accuracy ${acc1} (expected 100)`);
  if (iq1 === 145) ok(`IQ 145`); else fail(`IQ ${iq1} (expected 145)`);
  if (grade1.includes("Steel trap")) ok(`grade Steel trap`); else fail(`grade: ${grade1}`);
  if (pct1 === 99) ok(`percentile 99`); else fail(`percentile ${pct1}`);
  if (correct1 === 27) ok(`correct 27/27`); else fail(`correct ${correct1} (expected 27)`);

  const captured = Object.keys(run1.trigrams).length;
  if (captured === 9) ok(`all 9 trigrams captured`); else fail(`trigrams captured: ${captured} (expected 9)`);
  if (!run1.sawLettersDuringDelay) ok(`anti-cheat: data-letters absent outside show phase`);
  else fail(`anti-cheat: trigram leaked outside show phase`);

  const chips = [];
  for (let i = 0; i < 9; i++) {
    const v = await page
      .$eval(`[data-testid="stm-trial-chip-${i}"]`, (el) => el.textContent.trim())
      .catch(() => "?");
    chips.push(v);
  }
  if (chips.every((c) => c === "3/3")) ok(`all trial chips 3/3`); else fail(`trial chips: ${chips.join(",")}`);

  const durBars = [];
  for (const ms of [3000, 9000, 15000]) {
    const v = await page
      .$eval(`[data-testid="stm-duration-${ms}"]`, (el) => Number(el.getAttribute("data-final")))
      .catch(() => -1);
    durBars.push(v);
  }
  if (durBars.every((v) => v === 100)) ok(`decay bars all 100%`); else fail(`decay bars: ${durBars.join(",")}`);

  const gram1 = run1.trigrams[1] || "";

  /* ---------------------------- retake ---------------------------- */
  console.log("\nRetake (fresh trigrams):");
  await page.click('[data-testid="stm-retake"]');
  await sleep(300);
  const run2 = await playSession(page, (_t, gram) => gram);
  const gram2 = run2.trigrams[1] || "";
  if (gram2 && gram1 && gram1 !== gram2) ok(`first trigram changed between runs (${gram1} -> ${gram2})`);
  else fail(`retake trigram identical or missing: ${gram1} vs ${gram2}`);
  const iq2 = await readStable(page, "stm-iq");
  if (iq2 === 145) ok(`retake IQ also 145`); else fail(`retake IQ ${iq2}`);

  /* -------------------------- anti-gaming -------------------------- */
  console.log("\nAnti-gaming (QQQ every trial):");
  await page.click('[data-testid="stm-retake"]');
  await sleep(300);
  const run3 = await playSession(page, () => "QQQ");
  const acc3 = await readStable(page, "stm-accuracy");
  const iq3 = await readStable(page, "stm-iq");
  const grade3 = await page.$eval('[data-testid="stm-grade"]', (el) => el.textContent.trim()).catch(() => "");
  const pct3 = await readPercentile(page);
  if (acc3 === 0) ok(`accuracy floored to 0`); else fail(`QQQ accuracy ${acc3} (expected 0)`);
  if (iq3 === 55) ok(`IQ pinned to 55 floor`); else fail(`QQQ IQ ${iq3} (expected 55)`);
  if (grade3.includes("Evaporated")) ok(`grade Evaporated`); else fail(`QQQ grade: ${grade3}`);
  if (pct3 === 1) ok(`percentile 1`); else fail(`QQQ percentile ${pct3}`);
  if (run3.sawResults) ok(`session completed normally`);
  else fail(`anti-gaming session did not finish`);

  /* ------------------------- 375px overflow ------------------------- */
  console.log("\n375px overflow:");
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth
  );
  if (overflow <= 0) ok(`no horizontal overflow (${overflow}px)`);
  else fail(`horizontal overflow ${overflow}px`);

  /* --------------------------- console errors --------------------------- */
  console.log("\nConsole:");
  if (consoleErrors.length === 0) ok("zero console/page errors across all runs");
  else {
    fail(`${consoleErrors.length} console error(s):`);
    consoleErrors.slice(0, 5).forEach((e) => console.error("    " + e.slice(0, 200)));
  }

  await browser.close();
  console.log(`\n----------------------------------------`);
  console.log(`TOTAL CHECKS FAILED: ${failures}`);
  if (failures > 0) process.exit(1);
  console.log("ALL PASS");
})();
