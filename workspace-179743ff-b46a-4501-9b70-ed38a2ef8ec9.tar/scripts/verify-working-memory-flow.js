/**
 * Working Memory Test - flow + SEO verification (Playwright).
 * Run: node /home/z/my-project/scripts/verify-working-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1): every shown element is READ from the DOM
 *    (wm-element while visible) and sorted back via the wm-pad-num-*
 *    and wm-pad-let-* buttons - numbers ascending, letters alphabetical.
 *    A perfect quick run clears levels 5..9, so the results must show
 *    span 9, the +0.5 flawless bonus note, and an IQ >= 120.
 *  - Undo/clear exercised on the first input stage.
 *  - Retake: the first sequence differs between runs (anti-memorisation).
 *  - Anti-gaming: nines-only input at the first attempt -> run ends with
 *    floor span and an honest low IQ (no inflation).
 *  - 375px: no horizontal overflow on intro / display / results.
 *  - zero console/page errors.
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function attachErrorCapture(page, errors) {
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
}

async function gotoWithRetry(p, url) {
  let lastRes = null;
  for (let i = 0; i < 3; i++) {
    lastRes = await p.goto(url, { waitUntil: "networkidle", timeout: 60000 });
    if (lastRes && lastRes.ok()) return lastRes;
    await sleep(2000);
  }
  throw new Error(`page did not load ok: ${url} (${lastRes ? lastRes.status() : "null"})`);
}

/** Poll the IQ chip until CountUp finishes animating (starts at 0). */
async function readIq(p) {
  let prev = -1;
  for (let i = 0; i < 40; i++) {
    const t = await p.$eval('[data-testid="wm-iq"]', (el) => el.textContent.trim()).catch(() => "0");
    const n = Number(t);
    if (Number.isFinite(n) && n > 0 && n === prev) return n; // stable across two reads
    prev = n;
    await sleep(150);
  }
  return 0;
}

/**
 * Read every shown element from the DOM while the display stage is up.
 * The current element lives in [data-testid="wm-element"] with data-pos;
 * the stage carries data-total. Polls until the input stage opens.
 */
async function captureSequence(p) {
  const byPos = new Map();
  const deadline = Date.now() + 60_000;
  let firstPoll = true;
  while (Date.now() < deadline) {
    const inputOpen = await p.$('[data-testid="wm-input"]');
    if (firstPoll && inputOpen) {
      throw new Error("capture entered with input already open (display phase missed)");
    }
    firstPoll = false;
    const el = await p.$('[data-testid="wm-element"]');
    if (el) {
      const info = await el.evaluate((e) => ({
        text: e.textContent.trim(),
        pos: Number(e.getAttribute("data-pos")),
      }));
      if (info.text !== "" && info.pos >= 0 && !byPos.has(info.pos)) {
        byPos.set(info.pos, info.text);
      }
    }
    if (inputOpen) break;
    await sleep(30);
  }
  const display = [];
  for (let i = 0; i < byPos.size; i++) display.push(byPos.get(i));
  const digits = display.filter((x) => /^\d$/.test(x)).map(Number).sort((a, b) => a - b);
  const letters = display.filter((x) => !/^\d$/.test(x)).sort();
  return { total: byPos.size, display, digits, letters };
}

/** Press a pad button and verify the corresponding chip count grew. */
async function pressAndVerify(p, padSel, chipSel, label) {
  let btn = null;
  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    btn = await p.$(padSel);
    if (btn) {
      const disabled = await btn.evaluate((el) => (el).disabled);
      if (!disabled) break;
      btn = null;
    }
    await sleep(40);
  }
  if (!btn) throw new Error(`${label} pad button never appeared/enabled`);
  const before = (await p.$$eval(chipSel, (els) => els.length)).valueOf();
  await btn.evaluate((el) => el.click());
  let registered = false;
  for (let t = 0; t < 25 && !registered; t++) {
    await sleep(30);
    registered = (await p.$$eval(chipSel, (els) => els.length)) > before;
  }
  if (!registered) {
    // one retry - guards against clicks swallowed during mount animation
    await btn.evaluate((el) => el.click());
    for (let t = 0; t < 25 && !registered; t++) {
      await sleep(30);
      registered = (await p.$$eval(chipSel, (els) => els.length)) > before;
    }
    if (!registered) throw new Error(`press on ${label} did not register`);
  }
}

async function typeAnswer(p, digits, letters) {
  for (const d of digits) await pressAndVerify(p, `[data-testid="wm-pad-num-${d}"]`, '[data-testid="wm-chip-num"]', `num ${d}`);
  for (const l of letters) await pressAndVerify(p, `[data-testid="wm-pad-let-${l}"]`, '[data-testid="wm-chip-let"]', `let ${l}`);
}

async function clickSubmit(p) {
  const submit = await p.$('[data-testid="wm-submit"]');
  if (submit) await submit.evaluate((el) => el.click());
}

/** Fill the number stream with nines until the pad disables - guaranteed
 *  wrong (targets never repeat a digit) - then submit. */
async function submitWrong(p) {
  await p.waitForSelector('[data-testid="wm-display-stage"]', { timeout: 15000 });
  await p.waitForFunction(
    () => !!document.querySelector('[data-testid="wm-pad-num-9"]'),
    { timeout: 30000 }
  );
  for (let i = 0; i < 9; i++) {
    const btn = await p.$('[data-testid="wm-pad-num-9"]');
    if (!btn) break;
    const disabled = await btn.evaluate((el) => el.disabled);
    if (disabled) break;
    await btn.evaluate((el) => el.click());
    await sleep(30);
  }
  await clickSubmit(p);
}

/**
 * Play one full run to results by following the DOM exposure, typing
 * the sorted answer for every attempt. Returns the captured display
 * sequences (one per attempt).
 */
async function playRun(p, { exerciseEditing = false } = {}) {
  const seqs = [];
  const deadline = Date.now() + 240_000;
  let firstAttempt = true;
  while (Date.now() < deadline) {
    if (await p.$('[data-testid="wm-results"]')) break;
    const stage = await p.$('[data-testid="wm-display-stage"]');
    if (!stage) { await sleep(40); continue; }

    const cap = await captureSequence(p);
    if (cap.display.length === 0 || cap.digits.length === 0 || cap.letters.length === 0) {
      await sleep(120);
      continue;
    }
    if (cap.display.length !== cap.total) {
      throw new Error(`capture incomplete: ${JSON.stringify(cap)}`);
    }
    seqs.push(cap.display);

    await sleep(350); // let the input stage finish its entrance animation

    if (exerciseEditing && firstAttempt) {
      const numPadCount = await p.$$eval('[data-testid^="wm-pad-num-"]', (els) => els.length);
      numPadCount === 9 ? ok("number pad has 9 buttons (1-9)") : fail(`num pad buttons: ${numPadCount}`);
      const letPadCount = await p.$$eval('[data-testid^="wm-pad-let-"]', (els) => els.length);
      letPadCount === 9 ? ok("letter pad has 9 buttons") : fail(`letter pad buttons: ${letPadCount}`);
      // type two correct digits, then undo + clear
      await pressAndVerify(p, `[data-testid="wm-pad-num-${cap.digits[0]}"]`, '[data-testid="wm-chip-num"]', "num editing");
      const afterOne = await p.$$eval('[data-testid="wm-chip-num"]', (els) => els.length);
      afterOne === 1 ? ok("number chip registered") : fail(`number chips after press: ${afterOne}`);
      const undo = await p.$('[data-testid="wm-undo"]');
      await undo.evaluate((el) => el.click());
      await sleep(60);
      const afterUndo = await p.$$eval('[data-testid="wm-chip-num"]', (els) => els.length);
      afterUndo === 0 ? ok("undo removes the number chip") : fail(`undo: ${afterUndo} chips left`);
    }
    firstAttempt = false;

    await typeAnswer(p, cap.digits, cap.letters);
    await clickSubmit(p);

    const wDeadline = Date.now() + 20_000;
    while (Date.now() < wDeadline) {
      if (await p.$('[data-testid="wm-results"]')) break;
      if (await p.$('[data-testid="wm-display-stage"]')) break;
      await sleep(40);
    }
  }
  return seqs;
}

async function noHorizontalOverflow(p, label) {
  const overflow = await p.evaluate(() => {
    const d = document.documentElement;
    return { scrollW: d.scrollWidth, clientW: d.clientWidth, bodyScrollW: document.body.scrollWidth };
  });
  const clean = overflow.scrollW <= overflow.clientW && overflow.bodyScrollW <= overflow.clientW;
  clean
    ? ok(`375px ${label}: no horizontal overflow (${overflow.scrollW}<=${overflow.clientW})`)
    : fail(`375px ${label}: OVERFLOW scrollW=${overflow.scrollW} clientW=${overflow.clientW}`);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  attachErrorCapture(p, errors);

  /* ---------------- SEO surface ---------------- */
  await gotoWithRetry(p, `${BASE}/test/working-memory`);
  console.log("— SEO checks —");
  const title = await p.title();
  title === "Free Working Memory Test Online - Letter-Number Sequencing | BrainMetrics"
    ? ok(`title: ${title}`)
    : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.length >= 140 && desc.length <= 165 && desc.includes("working memory test")
    ? ok(`description (${desc.length}c)`)
    : fail(`description (${desc.length}c): ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test/working-memory"
    ? ok(`canonical: ${canonical}`)
    : fail(`canonical: ${canonical}`);
  const jsonld = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent); } catch { return { "@type": "PARSE-ERROR" }; } })
  );
  const types = jsonld.map((o) => o["@type"]);
  ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
    types.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const webApp = jsonld.find((o) => o["@type"] === "WebApplication");
  webApp && webApp.offers && webApp.offers.price === "0"
    ? ok("WebApplication offer price 0 (free)")
    : fail("WebApplication missing free offer");
  const breadcrumb = jsonld.find((o) => o["@type"] === "BreadcrumbList");
  breadcrumb && breadcrumb.itemListElement.length === 2 &&
    breadcrumb.itemListElement[1].item === "https://brainmetrics.app/test/working-memory"
    ? ok("BreadcrumbList: BrainMetrics > Working Memory Test")
    : fail("BreadcrumbList wrong");
  const faqLd = jsonld.find((o) => o["@type"] === "FAQPage");
  const faqVisible = await p.$$eval('[data-testid^="wm-faq-item-"]', (els) =>
    els.map((el) => el.querySelector("summary").textContent.trim())
  );
  faqLd && faqLd.mainEntity.length === 6
    ? ok(`FAQPage JSON-LD has 6 questions`)
    : fail(`FAQPage JSON-LD count: ${faqLd ? faqLd.mainEntity.length : "none"}`);
  faqVisible.length === 6
    ? ok(`visible FAQ has 6 items`)
    : fail(`visible FAQ items: ${faqVisible.length}`);
  const parityOk =
    faqLd && faqVisible.length === faqLd.mainEntity.length &&
    faqVisible.every((q, i) => q.startsWith(faqLd.mainEntity[i].name.slice(0, 25)));
  parityOk ? ok("FAQ visible copy matches JSON-LD (parity)") : fail("FAQ parity broken");
  const h1 = await p.$eval("h1", (el) => el.textContent.replace(/\s+/g, " ").trim());
  h1.includes("Working") && h1.includes("Memory Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const relatedText = await p.$eval("main", (el) => el.textContent);
  relatedText.includes("Try another test")
    ? ok("RelatedTests band rendered")
    : fail("RelatedTests band missing");

  /* ---------------- Run 1: golden path (quick mode) ---------------- */
  console.log("— Run 1: golden path (?quick=1, DOM-following play) —");
  await gotoWithRetry(p, `${BASE}/test/working-memory?quick=1`);
  const intro = await p.$('[data-testid="wm-intro"]');
  intro ? ok("intro renders") : fail("intro missing");
  await noHorizontalOverflow(p, "intro");
  const startBtn = await p.$('[data-testid="wm-intro-cta"]');
  if (!startBtn) { fail("intro CTA missing"); return finish(browser, errors); }
  await startBtn.click();

  await p.waitForSelector('[data-testid="wm-test-active"]', { timeout: 10000 });
  ok("run started");
  await p.waitForSelector('[data-testid="wm-display-stage"]', { timeout: 10000 });
  const attemptInfo = await p.$eval('[data-testid="wm-attempt-info"]', (el) => el.textContent.trim());
  /attempt 1 of 1/.test(attemptInfo)
    ? ok(`attempt info: "${attemptInfo}"`)
    : fail(`attempt info: ${attemptInfo}`);
  const seqs = await playRun(p, { exerciseEditing: true });
  seqs.length >= 4
    ? ok(`played ${seqs.length} levels (first: [${seqs[0].join(" ")}])`)
    : fail(`only ${seqs.length} levels survived`);
  await noHorizontalOverflow(p, "input stage");

  await p.waitForSelector('[data-testid="wm-results"]', { timeout: 10000 });
  ok("results screen reached");
  const iq = await readIq(p);
  iq >= 120 && iq <= 145 ? ok(`IQ: ${iq} (perfect quick run range)`) : fail(`IQ: ${iq}`);
  const grade = await p.$eval('[data-testid="wm-grade"]', (el) => el.textContent.trim());
  grade.length > 0 ? ok(`grade chip: ${grade}`) : fail("grade missing");
  const pctText = await p.$eval('[data-testid="wm-percentile"]', (el) => el.textContent.trim());
  const pct = Number((pctText.match(/\d+/) || ["0"])[0]);
  pct >= 1 && pct <= 99 && pctText.includes("100 adults")
    ? ok(`percentile line: ${pctText}`)
    : fail(`percentile: ${pctText}`);
  const span = await p.$eval('[data-testid="wm-span"] p', (el) => Number(el.textContent.trim()));
  span === 9 ? ok(`span: ${span} (full clear)`) : fail(`span: ${span} (expected 9)`);
  const bonusNote = await p.$('[data-testid="wm-bonus-note"]');
  bonusNote ? ok("flawless +0.5 bonus note shown") : fail("bonus note missing on a full clear");
  const ladderDots = await p.$$eval('[data-testid^="wm-ladder-"]', (els) => els.length);
  ladderDots === seqs.length
    ? ok(`ladder shows ${ladderDots} attempt dots`)
    : fail(`ladder dots ${ladderDots} != attempts ${seqs.length}`);
  const quickNote = await p.$('[data-testid="wm-quick-note"]');
  quickNote ? ok("quick-mode note shown") : fail("quick-mode note missing");
  await noHorizontalOverflow(p, "results");

  /* ---------------- Run 2: retake, new sequences ---------------- */
  console.log("— Run 2: retake -> sequences re-randomised —");
  const retakeBtn = await p.$('[data-testid="wm-retake"]');
  if (!retakeBtn) { fail("retake button missing"); return finish(browser, errors); }
  await retakeBtn.evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="wm-test-active"]', { timeout: 10000 });
  const seqs2 = await playRun(p);
  seqs2.length >= 1 ? ok(`retake first seq: [${seqs2[0].join(" ")}]`) : fail("retake captured nothing");
  JSON.stringify(seqs[0]) !== JSON.stringify(seqs2[0])
    ? ok("first sequences differ between runs (anti-memorisation)")
    : fail("retake reused the same first sequence!");
  await p.waitForSelector('[data-testid="wm-results"]', { timeout: 10000 });
  ok("retake reached results");

  /* ---------------- Run 3: anti-gaming (wrong input) ---------------- */
  console.log("— Run 3: nines-only input at first attempt -> honest floor —");
  await gotoWithRetry(p, `${BASE}/test/working-memory?quick=1`);
  await (await p.$('[data-testid="wm-intro-cta"]')).evaluate((el) => el.click());
  await p.waitForSelector('[data-testid="wm-test-active"]', { timeout: 10000 });
  await submitWrong(p);
  await p.waitForSelector('[data-testid="wm-results"]', { timeout: 15000 });
  ok("run terminated after the failed first attempt");
  const agSpan = await p.$eval('[data-testid="wm-span"] p', (el) => Number(el.textContent.trim()));
  agSpan === 0 ? ok("floor span (0)") : fail(`floor span expected, got ${agSpan}`);
  const agIq = await readIq(p);
  agIq <= 70 ? ok(`honest low IQ: ${agIq}`) : fail(`IQ inflated on an all-wrong run: ${agIq}`);
  const agPctText = await p.$eval('[data-testid="wm-percentile"]', (el) => el.textContent.trim());
  const agPct = Number((agPctText.match(/\d+/) || ["99"])[0]);
  agPct <= 5 ? ok(`honest low percentile: ${agPctText}`) : fail(`percentile inflated: ${agPctText}`);
  const agLadder = await p.$$eval('[data-testid^="wm-ladder-"]', (els) => els.length);
  agLadder === 1 ? ok("ladder records the single failed attempt") : fail(`ladder dots: ${agLadder}`);
  const gradeOnFloor = await p.$eval('[data-testid="wm-grade"]', (el) => el.textContent.trim());
  gradeOnFloor.includes("Building")
    ? ok(`floor grade: ${gradeOnFloor}`)
    : fail(`floor grade: ${gradeOnFloor}`);

  /* ---------------- Mobile 375px: full run ---------------- */
  console.log("— Mobile 375px (full quick run) —");
  const mp = await ctx.newPage();
  attachErrorCapture(mp, errors);
  await mp.setViewportSize({ width: 375, height: 740 });
  await gotoWithRetry(mp, `${BASE}/test/working-memory?quick=1`);
  await noHorizontalOverflow(mp, "intro");
  await (await mp.$('[data-testid="wm-intro-cta"]')).evaluate((el) => el.click());
  await mp.waitForSelector('[data-testid="wm-display-stage"]', { timeout: 10000 });
  await noHorizontalOverflow(mp, "display stage");
  const mSeqs = await playRun(mp);
  await mp.waitForSelector('[data-testid="wm-results"]', { timeout: 10000 });
  await noHorizontalOverflow(mp, "results");
  const mIq = await readIq(mp);
  mIq >= 120 && mIq <= 145 ? ok(`mobile IQ: ${mIq}`) : fail(`mobile IQ: ${mIq}`);
  mSeqs.length >= 4
    ? ok(`mobile full run played (${mSeqs.length} levels)`)
    : fail(`mobile run short: ${mSeqs.length} levels`);
  await mp.close();

  /* ---------------- Console errors ---------------- */
  console.log("— Console —");
  errors.length === 0
    ? ok("zero console/page errors")
    : fail(`console errors: ${errors.slice(0, 5).join(" | ")}`);

  await finish(browser, errors);

  async function finish(browser, errs) {
    await browser.close();
    console.log("\n=========================================");
    if (failures > 0) {
      console.error(`RESULTS: ${failures} FAILURES`);
      process.exit(1);
    }
    console.log("RESULTS: ALL PASS");
  }
})().catch((e) => { console.error(e); process.exit(1); });
