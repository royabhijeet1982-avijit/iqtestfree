// Quick static-export smoke test: pages render + zero console errors
const { chromium } = require('playwright');

(async () => {
  const pages = [
    { url: 'http://localhost:8080/', expect: 'body' },
    { url: 'http://localhost:8080/test/', expect: 'body' },
    { url: 'http://localhost:8080/test/reaction-time/', expect: '[data-testid*="rt-"], main, body' },
    { url: 'http://localhost:8080/test/chimp-test/', expect: '[data-testid*="chimp-"], main, body' },
    { url: 'http://localhost:8080/test/word-memory/', expect: '[data-testid*="word-"], main, body' },
  ];

  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 375, height: 667 } });
  let pass = 0, fail = 0;

  for (const p of pages) {
    const page = await context.newPage();
    const errors = [];
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', e => errors.push(String(e)));
    try {
      const resp = await page.goto(p.url, { waitUntil: 'networkidle', timeout: 20000 });
      if (!resp.ok()) throw new Error('HTTP ' + resp.status());
      await page.waitForTimeout(800);
      const visible = await page.locator(p.expect).first().isVisible().catch(() => false);
      if (!visible) throw new Error('no visible content');
      if (errors.length > 0) throw new Error('console errors: ' + errors.slice(0, 2).join(' | '));
      console.log('PASS  ' + p.url);
      pass++;
    } catch (e) {
      console.log('FAIL  ' + p.url + '  ->  ' + e.message);
      fail++;
    }
    await page.close();
  }

  // horizontal overflow check on one test page (mobile 375px)
  const page = await context.newPage();
  await page.goto('http://localhost:8080/test/reaction-time/', { waitUntil: 'networkidle' });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  console.log(overflow <= 0 ? 'PASS  no horizontal overflow @375px (' + overflow + ')' : 'FAIL  horizontal overflow ' + overflow + 'px');
  overflow <= 0 ? pass++ : fail++;
  await page.close();

  // client-side navigation check: click a link from home -> test page
  const cpage = await context.newPage();
  const cerrors = [];
  cpage.on('console', m => { if (m.type() === 'error') cerrors.push(m.text()); });
  cpage.on('pageerror', e => cerrors.push(String(e)));
  try {
    await cpage.goto('http://localhost:8080/', { waitUntil: 'networkidle' });
    const link = cpage.locator('a[href*="reaction-time"], a[href*="chimp-test"]').first();
    await link.click();
    await cpage.waitForURL('**/test/**', { timeout: 10000 });
    await cpage.waitForTimeout(1200);
    if (cerrors.length > 0) throw new Error('client-nav console errors: ' + cerrors.slice(0, 2).join(' | '));
    console.log('PASS  client-side Link navigation -> ' + cpage.url());
    pass++;
  } catch (e) {
    console.log('FAIL  client-side Link navigation -> ' + e.message);
    fail++;
  }
  await cpage.close();

  await browser.close();
  console.log('\nTOTAL: ' + (pass + fail) + '  PASS: ' + pass + '  FAIL: ' + fail);
  process.exit(fail > 0 ? 1 : 0);
})();
