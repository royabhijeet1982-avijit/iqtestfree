/**
 * Task 11 verification: age-group IQ test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-iq-flow.js
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  ✗ ${m}`); };
const ok = (m) => console.log(`  ✓ ${m}`);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const p = await ctx.newPage();
  const errors = [];
  p.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });

  /* ---------------- SEO surface ---------------- */
  await p.goto(`${BASE}/test`, { waitUntil: "networkidle" });
  console.log("— SEO checks —");
  const title = await p.title();
  title.includes("Free Online IQ Test") ? ok(`title: ${title}`) : fail(`title: ${title}`);
  const desc = await p.$eval('meta[name="description"]', (el) => el.content);
  desc.includes("kids, teens and adults") ? ok(`desc mentions age groups (${desc.length}c)`) : fail(`desc: ${desc}`);
  const canonical = await p.$eval('link[rel="canonical"]', (el) => el.href);
  canonical === "https://brainmetrics.app/test" ? ok(`canonical: ${canonical}`) : fail(`canonical: ${canonical}`);
  const jsonldTypes = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => { try { return JSON.parse(e.textContent)["@type"]; } catch { return "PARSE-ERROR"; } })
  );
  const flat = jsonldTypes.flat();
  ["WebApplication", "BreadcrumbList", "FAQPage", "Organization", "WebSite"].forEach((t) =>
    flat.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t}`)
  );
  const faqJsonLd = await p.$$eval('script[type="application/ld+json"]', (els) =>
    els.map((e) => JSON.parse(e.textContent)).find((o) => o["@type"] === "FAQPage")
  );
  faqJsonLd && faqJsonLd.mainEntity.length === 7
    ? ok(`FAQPage JSON-LD has 7 questions`)
    : fail(`FAQPage JSON-LD count: ${faqJsonLd ? faqJsonLd.mainEntity.length : "none"}`);
  const faqVisible = await p.$$eval("#faq details", (els) => els.length);
  faqVisible === 7 ? ok(`visible FAQ has 7 items`) : fail(`visible FAQ items: ${faqVisible}`);
  const h1 = await p.$eval("h1", (el) => el.textContent.trim());
  h1.includes("Free Online") && h1.includes("IQ Test") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);
  const badge = await p.$eval("main span", (el) => el.textContent);
  badge.includes("3 age groups") && badge.includes("12 questions per set")
    ? ok(`hero badge: ${badge.trim()}`)
    : fail(`hero badge: ${badge.trim()}`);
  const heroText = await p.$eval("main", (el) => el.textContent);
  ["kids", "teens", "adults"].every((g) => heroText.toLowerCase().includes(g))
    ? ok("hero copy names all three age groups")
    : fail("age groups missing from hero copy");

  const robots = await fetch(`${BASE}/robots.txt`);
  const sitemap = await fetch(`${BASE}/sitemap.xml`);
  robots.status === 200 ? ok("robots.txt 200") : fail(`robots.txt ${robots.status}`);
  sitemap.status === 200 ? ok("sitemap.xml 200") : fail(`sitemap.xml ${sitemap.status}`);

  /* ---------------- Age picker ---------------- */
  console.log("— Age picker —");
  const cards = await p.$$eval('#test-app button[aria-label^="Start the"]', (els) =>
    els.map((e) => e.getAttribute("aria-label"))
  );
  cards.length === 3 ? ok(`3 age-group cards: ${cards.map((c) => c.split(",")[0].replace("Start the ", "")).join(", ")}`) : fail(`cards: ${cards.length}`);
  for (const g of ["Kids", "Teens", "Adults"]) {
    const note = await p.$eval(`#test-app button[aria-label^="Start the ${g}"]`, (el) => el.textContent);
    note.includes("10 question sets ready")
      ? ok(`${g} card shows "10 question sets ready"`)
      : fail(`${g} footnote: ${note.match(/[^\n]*question sets[^\n]*/)?.[0] ?? note.slice(0, 80)}`);
  }

  /* ---------------- Attempt 1: Kids ---------------- */
  console.log("— Attempt 1 (Kids) —");
  await p.click('#test-app button[aria-label^="Start the Kids"]');
  await p.waitForSelector('[aria-live="polite"] h3');
  const readPrompt = () => p.$eval('[aria-live="polite"] h3', (el) => el.textContent.trim());
  const readProgress = () =>
    p.$eval('[role="progressbar"]', (el) => `${el.getAttribute("aria-valuenow")}/${el.getAttribute("aria-valuemax")}`);
  (await readProgress()) === "1/12" ? ok('progress starts at "1 of 12"') : fail(`progress: ${await readProgress()}`);

  const prompts1 = [];
  for (let i = 0; i < 12; i++) {
    prompts1.push(await readPrompt());
    await p.click('[role="group"][aria-label="Answer options"] button >> nth=0');
    if (i < 11) await p.click('button:has-text("Next question")');
    else await p.click('button:has-text("See my results")');
  }
  await p.waitForSelector("text=Your result");
  ok("answered 12 questions → results screen");
  const reviews = await p.$$eval("#test-app details", (els) => els.length);
  reviews === 12 ? ok(`question review shows 12 items`) : fail(`review items: ${reviews}`);
  const resultText = await p.$eval("#test-app", (el) => el.textContent);
  /set “/.test(resultText) ? ok("results show the set name") : fail("set name missing on results");
  resultText.includes("Kids set") ? ok("results label the age group (Kids set)") : fail("age group label missing on results");

  /* ---------------- Attempt 2: retake = new set ---------------- */
  console.log("— Attempt 2 (retake) —");
  const name1 = (resultText.match(/set “(.+?)”/) || [])[1];
  await p.click('button:has-text("Retake — new 12 questions")');
  await p.waitForSelector('[aria-live="polite"] h3');
  const prompts2 = [await readPrompt()];
  (await readProgress()) === "1/12" ? ok("retake restarts at question 1/12") : fail(`progress: ${await readProgress()}`);
  for (let i = 0; i < 12; i++) {
    if (i > 0) prompts2.push(await readPrompt());
    await p.click('[role="group"][aria-label="Answer options"] button >> nth=1');
    if (i < 11) await p.click('button:has-text("Next question")');
    else await p.click('button:has-text("See my results")');
  }
  await p.waitForSelector("text=Your result");
  const resultText2 = await p.$eval("#test-app", (el) => el.textContent);
  const name2 = (resultText2.match(/set “(.+?)”/) || [])[1];
  const sameSet = JSON.stringify(prompts1) === JSON.stringify(prompts2);
  const sameName = name1 === name2;
  const overlap = prompts1.filter((q) => prompts2.includes(q)).length;
  (!sameSet && !sameName)
    ? ok(`retake dealt a DIFFERENT set (“${name1}” → “${name2}”, shared questions: ${overlap}/12)`)
    : (!sameSet ? ok(`retake dealt different questions within same-ish draw (“${name1}” vs “${name2}”)`) : fail("retake served the identical set"));
  console.log(`    attempt1 set: ${name1} | attempt2 set: ${name2}`);

  /* ---------------- Attempt 3: full Teens run ---------------- */
  console.log("— Attempt 3 (Teens, full run) —");
  await p.click('button:has-text("Change age group")');
  await p.waitForSelector('#test-app button[aria-label^="Start the Teens"]');
  ok("back on the age picker");
  await p.click('#test-app button[aria-label^="Start the Teens"]');
  await p.waitForSelector('[aria-live="polite"] h3');
  (await readProgress()) === "1/12" ? ok("teens track starts at 1/12") : fail(`teens progress: ${await readProgress()}`);
  const teensPrompts = [];
  for (let i = 0; i < 12; i++) {
    teensPrompts.push(await readPrompt());
    await p.click('[role="group"][aria-label="Answer options"] button >> nth=0');
    if (i < 11) await p.click('button:has-text("Next question")');
    else await p.click('button:has-text("See my results")');
  }
  await p.waitForSelector("text=Your result");
  const teensText = await p.$eval("#test-app", (el) => el.textContent);
  const teensName = (teensText.match(/set “(.+?)”/) || [])[1];
  const TEENS_SETS = ["Circuit", "Nova", "Pixel", "Vector", "Cipher", "Quasar", "Matrix", "Photon", "Zenith", "Cascade"];
  TEENS_SETS.includes(teensName) ? ok(`teens served a dedicated teen set (“${teensName}”)`) : fail(`teens set name: ${teensName}`);
  teensText.includes("Teens set") ? ok('results label the age group ("Teens set")') : fail("teens group label missing on results");
  const teensOverlap = prompts1.filter((q) => teensPrompts.includes(q));
  teensOverlap.length === 0
    ? ok(`zero kids questions appeared in the teens run (12/12 distinct)`)
    : fail(`kids questions leaked into teens: ${teensOverlap[0]}`);
  await p.screenshot({ path: "/tmp/iq-teens-results.png", fullPage: false });

  /* ---------------- Attempt 4: full Adults run ---------------- */
  console.log("— Attempt 4 (Adults, full run) —");
  await p.click('button:has-text("Change age group")');
  await p.waitForSelector('#test-app button[aria-label^="Start the Adults"]');
  await p.click('#test-app button[aria-label^="Start the Adults"]');
  await p.waitForSelector('[aria-live="polite"] h3');
  (await readProgress()) === "1/12" ? ok("adults track starts at 1/12") : fail(`adults progress: ${await readProgress()}`);
  const adultsPrompts = [];
  for (let i = 0; i < 12; i++) {
    adultsPrompts.push(await readPrompt());
    await p.click('[role="group"][aria-label="Answer options"] button >> nth=0');
    if (i < 11) await p.click('button:has-text("Next question")');
    else await p.click('button:has-text("See my results")');
  }
  await p.waitForSelector("text=Your result");
  const adultsText = await p.$eval("#test-app", (el) => el.textContent);
  const adultsName = (adultsText.match(/set “(.+?)”/) || [])[1];
  const ADULTS_SETS = ["Sage", "Oracle", "Enigma", "Apex", "Prism", "Vertex", "Axiom", "Lumen", "Onyx", "Meridian"];
  ADULTS_SETS.includes(adultsName) ? ok(`adults served a dedicated adult set (“${adultsName}”)`) : fail(`adults set name: ${adultsName}`);
  adultsText.includes("Adults set") ? ok('results label the age group ("Adults set")') : fail("adults group label missing on results");
  const kidLeak = adultsPrompts.filter((q) => prompts1.includes(q) || prompts2.includes(q));
  const teenLeak = adultsPrompts.filter((q) => teensPrompts.includes(q));
  kidLeak.length === 0 && teenLeak.length === 0
    ? ok(`zero kids/teens questions appeared in the adults run`)
    : fail(`leaks into adults: ${[...kidLeak, ...teenLeak][0]}`);
  await p.screenshot({ path: "/tmp/iq-adults-results.png", fullPage: false });

  /* ---------------- Mobile 375px ---------------- */
  const mp = await ctx.newPage();
  await mp.setViewportSize({ width: 375, height: 812 });
  await mp.goto(`${BASE}/test`, { waitUntil: "networkidle" });
  const overflow = await mp.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth
  );
  overflow === 0 ? ok("375px: no horizontal overflow on picker") : fail(`375px overflow: ${overflow}px`);
  await mp.click('#test-app button[aria-label^="Start the Kids"]');
  await mp.waitForSelector('[aria-live="polite"] h3');
  const mOverflow = await mp.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth
  );
  mOverflow === 0 ? ok("375px in-test: no overflow") : fail(`375px in-test overflow: ${mOverflow}px`);
  await mp.screenshot({ path: "/tmp/iq-mobile-12.png", fullPage: false });

  /* ---------------- Errors ---------------- */
  errors.length === 0 ? ok("zero console/page errors") : fail(`${errors.length} errors: ${errors.slice(0, 3).join(" | ")}`);

  await browser.close();
  console.log(failures === 0 ? "\n✓ ALL BROWSER CHECKS PASSED" : `\n✗ ${failures} FAILURES`);
  process.exit(failures === 0 ? 0 : 1);
})().catch((e) => { console.error("SCRIPT ERROR:", e); process.exit(1); });
