/* Round 2: check Tailwind 4 CSS individual properties (scale/translate/rotate)
 * and retry footer link hover (scroll settle issue). */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto("http://localhost:3000", { waitUntil: "networkidle" });

  const results = {};

  // 1. Footer link: translate slide (retry with explicit mouse move)
  const footerLink = page.locator("footer nav[aria-label='Tests'] a").first();
  await footerLink.scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  const box = await footerLink.boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 5 });
  await page.waitForTimeout(500);
  results.footerLink = await footerLink.evaluate((el) => {
    const cs = getComputedStyle(el);
    return { hovered: el.matches(":hover"), translate: cs.translate, color: cs.color };
  });

  // 2. Quick stats icon: scale property (group-hover:scale-110)
  const stat = page.locator("section[aria-label='Why BrainMetrics'] li").first();
  await stat.scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  const sbox = await stat.boundingBox();
  await page.mouse.move(sbox.x + sbox.width / 2, sbox.y + sbox.height / 2, { steps: 5 });
  await page.waitForTimeout(500);
  results.quickStatIcon = await stat.evaluate((el) => {
    const icon = el.querySelector("span span, span");
    const cs = getComputedStyle(icon);
    return {
      hovered: el.matches(":hover"),
      scale: cs.scale,
      backgroundColor: cs.backgroundColor,
    };
  });

  // 3. Navbar logo: scale property (hover:scale-[1.03])
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await page.waitForTimeout(600);
  const logoBox = await page.locator("header nav a").first().boundingBox();
  await page.mouse.move(logoBox.x + logoBox.width / 2, logoBox.y + logoBox.height / 2, { steps: 5 });
  await page.waitForTimeout(500);
  results.navLogo = await page.locator("header nav a").first().evaluate((el) => {
    const cs = getComputedStyle(el);
    return { hovered: el.matches(":hover"), scale: cs.scale };
  });

  // 4. Tool card icon tile: scale + rotate (group-hover:scale-110 -rotate-6)
  const card = page.locator("#popular-tests article").nth(1);
  await card.scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  const cbox = await card.boundingBox();
  await page.mouse.move(cbox.x + cbox.width / 2, cbox.y + cbox.height / 2, { steps: 5 });
  await page.waitForTimeout(500);
  results.toolCardIcon = await card.evaluate((el) => {
    const icon = el.querySelector("span span, span");
    const cs = getComputedStyle(icon);
    return {
      hovered: el.matches(":hover"),
      scale: cs.scale,
      rotate: cs.rotate,
    };
  });

  // 5. Hero secondary button: lift + border tint
  const heroBtn = page.locator("main section:first-of-type a[href='#all-tests']").first();
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await page.waitForTimeout(600);
  const hbox = await heroBtn.boundingBox();
  if (hbox) {
    await page.mouse.move(hbox.x + hbox.width / 2, hbox.y + hbox.height / 2, { steps: 5 });
    await page.waitForTimeout(500);
    results.heroSecondaryBtn = await heroBtn.evaluate((el) => {
      const cs = getComputedStyle(el);
      return {
        hovered: el.matches(":hover"),
        translate: cs.translate,
        borderColor: cs.borderColor,
      };
    });
  }

  // 6. Learn section chip brighten (group-hover)
  const chip = page.locator("#learn article").first();
  await chip.scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  const lbox = await chip.boundingBox();
  await page.mouse.move(lbox.x + lbox.width / 2, lbox.y + lbox.height / 2, { steps: 5 });
  await page.waitForTimeout(500);
  results.learnChip = await chip.evaluate((el) => {
    const chipEl = el.querySelector("span");
    const cs = getComputedStyle(chipEl);
    return { hovered: el.matches(":hover"), backgroundColor: cs.backgroundColor };
  });

  console.log(JSON.stringify(results, null, 2));
  await browser.close();
})();
