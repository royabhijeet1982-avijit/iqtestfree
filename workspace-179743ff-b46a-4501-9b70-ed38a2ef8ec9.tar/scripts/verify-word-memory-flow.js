/**
 * Task 28 verification: Word Memory test flow + SEO checks.
 * Run: node /home/z/my-project/scripts/verify-word-memory-flow.js
 *
 * Covers:
 *  - SEO surface (title, description, canonical, JSON-LD x3, FAQ parity, h1)
 *  - Golden path (?quick=1, 375px viewport): a CONTINUOUS background watcher
 *    polls [data-testid="wm-study-word"] from the instant the run starts
 *    (through countdown -> study -> interlude -> recognize, all rounds) so
 *    no study word can be missed. During each round's RECOGNIZE the script
 *    answers "I saw it" for watched words, "It's new" otherwise ->
 *    accuracy 100%, IQ 145, Exceptional, percentile 99, d' > 4, round
 *    bars 100/100/100, hits 36 / CR 36 / FA 0
 *  - Input lock: a rogue "A" keypress during STUDY is ignored (buttons not
 *    rendered, recognize still starts at 0 judgements)
 *  - Retake: second run's round-1 study list differs from run 1 (fresh draw)
 *  - Anti-gaming (?quick=1): mashing "It's new" for EVERY word -> accuracy
 *    50%, IQ 55 floor, percentile 1, Building, d' ~ 0 - bias cannot win
 *  - 375px: no horizontal overflow on intro / recognize / results
 *  - zero console/page errors across all runs
 */
const { chromium } = require("/home/z/.npm-global/lib/node_modules/playwright");

const BASE = "http://localhost:3000";
let failures = 0;
const fail = (m) => { failures++; console.error(`  x ${m}`); };
const ok = (m) => console.log(`  + ${m}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Read a CountUp testid until the visible number matches data-final. */
async function readStable(p, testid) {
  let last = -1;
  for (let i = 0; i < 40; i++) {
    const r = await p
      .$eval(`[data-testid="${testid}"]`, (el) => ({
        shown: Number(el.textContent.replace(/[^0-9.-]/g, "")),
        final: Number(el.getAttribute("data-final")),
      }))
      .catch(() => null);
    if (r && Number.isFinite(r.final) && r.shown === r.final) return r.shown;
    if (r && Number.isFinite(r.shown)) last = r.shown;
    await sleep(150);
  }
  return last;
}

/** Atomic snapshot of the active stage (single roundtrip, never throws). */
async function snapshot(p) {
  return p
    .evaluate(() => {
      const stage = document.querySelector('[data-testid="wm-stage"]');
      const wordEl = document.querySelector('[data-testid="wm-word"]');
      return {
        results: !!document.querySelector('[data-testid="wm-results"]'),
        active: !!document.querySelector('[data-testid="wm-active"]'),
        intro: !!document.querySelector('[data-testid="wm-intro"]'),
        phase: stage ? stage.getAttribute("data-phase") : null,
        word: wordEl ? wordEl.textContent.trim() : null,
        progress: document.querySelector('[data-testid="wm-progress"]')?.textContent ?? "",
      };
    })
    .catch(() => null);
}

async function waitRecognize(p, timeoutMs = 30000) {
  await p
    .waitForFunction(
      () => {
        const el = document.querySelector('[data-testid="wm-stage"]');
        return !!el && el.getAttribute("data-phase") === "recognize";
      },
      undefined,
      { timeout: timeoutMs }
    )
    .catch(() => {});
}

/**
 * CONTINUOUS study watcher: started immediately after the run begins and
 * polls until results. Reads ONLY wm-study-word (never wm-word), so words
 * exiting the recognize stream can never contaminate the study lists.
 * Returns { "1": [...], "2": [...], "3": [...] }.
 */
function startStudyWatcher(p) {
  const byRound = { 1: [], 2: [], 3: [] };
  const state = { done: false };
  (async () => {
    let last = null;
    const start = Date.now();
    while (!state.done && Date.now() - start < 120000) {
      const st = await p
        .evaluate(() => {
          const el = document.querySelector('[data-testid="wm-study-word"]');
          const chip = document.querySelector('[data-testid="wm-round-chip"]');
          const results = !!document.querySelector('[data-testid="wm-results"]');
          const round = chip ? parseInt(chip.textContent.replace(/[^0-9]/g, ""), 10) : 0;
          return { word: el ? el.textContent.trim() : null, round, results };
        })
        .catch(() => null);
      if (st) {
        if (st.results) break;
        if (st.word && st.round >= 1 && st.round <= 3 && st.word !== last) {
          byRound[st.round].push(st.word);
          last = st.word;
        }
      }
      await sleep(15);
    }
    state.done = true;
  })();
  return { byRound, state };
}

/**
 * Answer the recognition stream. studySet = words watched during the
 * current round's study phase (empty set = mash "new" anti-gaming mode).
 * Words are unique within a session, so tracking the last answered word
 * is race-safe.
 */
async function respondStream(p, studySet) {
  let responded = 0;
  let lastWord = null;
  const start = Date.now();
  while (Date.now() - start < 60000) {
    const st = await snapshot(p);
    if (!st || st.results) break;
    if (st.phase !== "recognize") break;
    if (!st.word || st.word === lastWord) {
      await sleep(30);
      continue;
    }
    const wantOld = studySet.has(st.word);
    const btn = await p.$(`[data-testid="${wantOld ? "wm-btn-old" : "wm-btn-new"}"]`);
    if (!btn) {
      await sleep(60);
      continue;
    }
    await btn.evaluate((el) => el.click());
    responded += 1;
    lastWord = st.word;
    // Wait until the next word replaces this one (or the round ends).
    await p
      .waitForFunction(
        (prev) => {
          const stage = document.querySelector('[data-testid="wm-stage"]');
          if (!stage) return true;
          if (stage.getAttribute("data-phase") !== "recognize") return true;
          const el = document.querySelector('[data-testid="wm-word"]');
          return !!el && el.textContent.trim() !== prev;
        },
        st.word,
        { timeout: 5000 }
      )
      .catch(() => {});
  }
  return responded;
}

/** Horizontal-overflow probe (375px guard). */
async function overflow(p) {
  return p.evaluate(() => ({
    scrollW: document.documentElement.scrollWidth,
    clientW: document.documentElement.clientWidth,
  }));
}

async function newPage(browser, { width = 1440, height = 900 } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height } });
  const page = await ctx.newPage();
  page.errors = [];
  page.on("pageerror", (e) => page.errors.push(`pageerror: ${e.message}`));
  page.on("console", (msg) => {
    if (msg.type() === "error") page.errors.push(`console: ${msg.text()}`);
  });
  page.ctx = ctx;
  return page;
}

(async () => {
  const browser = await chromium.launch();
  const allErrors = [];

  try {
    /* ==================== 1. SEO surface (default viewport) ==================== */
    console.log("\n== SEO surface ==");
    {
      const p = await newPage(browser);
      const resp = await p.goto(`${BASE}/test/word-memory`, { waitUntil: "domcontentloaded", timeout: 60000 });
      resp && resp.status() === 200 ? ok("GET /test/word-memory -> 200") : fail(`status ${resp && resp.status()}`);
      await p.waitForSelector('[data-testid="wm-intro"]', { timeout: 60000 });

      const title = await p.title();
      title.includes("Word Memory Test") ? ok(`title: ${title}`) : fail(`title missing topic: ${title}`);

      const desc = await p.$eval('meta[name="description"]', (el) => el.content).catch(() => "");
      desc.includes("word memory test") ? ok("meta description present") : fail(`bad description: ${desc}`);

      const canonical = await p
        .$eval('link[rel="canonical"]', (el) => el.getAttribute("href"))
        .catch(() => "");
      canonical.endsWith("/test/word-memory") ? ok(`canonical: ${canonical}`) : fail(`canonical: ${canonical}`);

      const ldTypes = await p.$$eval('script[type="application/ld+json"]', (els) =>
        els.map((el) => {
          try { return JSON.parse(el.textContent)["@type"]; } catch { return "PARSE_ERROR"; }
        })
      );
      ["WebApplication", "BreadcrumbList", "FAQPage"].forEach((t) =>
        ldTypes.includes(t) ? ok(`JSON-LD ${t}`) : fail(`missing JSON-LD ${t} (got ${ldTypes.join(",")})`)
      );

      const faqCount = await p.$$eval('script[type="application/ld+json"]', (els) => {
        for (const el of els) {
          try {
            const j = JSON.parse(el.textContent);
            if (j["@type"] === "FAQPage") return j.mainEntity.length;
          } catch {}
        }
        return -1;
      });
      faqCount === 6 ? ok("FAQPage JSON-LD has 6 questions") : fail(`FAQPage count ${faqCount}`);

      const h1 = await p.$eval("h1", (el) => el.textContent.trim()).catch(() => "");
      h1.includes("Word") && h1.includes("Memory") ? ok(`h1: ${h1}`) : fail(`h1: ${h1}`);

      const visibleFaq = await p.$$eval('[data-testid^="wm-faq-item-"]', (els) => els.length);
      visibleFaq === 6 ? ok("visible FAQ items = 6 (parity)") : fail(`visible FAQ ${visibleFaq}`);

      const related = await p.$$eval(
        'section a[href^="/test/"]',
        (els) => els.map((el) => el.getAttribute("href")).filter((h) => h && h !== "/test" && h !== "/test/word-memory")
      );
      related.length >= 3
        ? ok(`RelatedTests renders ${related.length} live links, none self`)
        : fail(`related links: ${related.join(",")}`);

      allErrors.push(...p.errors);
      await p.ctx.close();
    }

    /* ==================== 2. Golden path (?quick=1 @ 375px) ==================== */
    console.log("\n== Golden path (?quick=1, perfect play, 375px) ==");
    {
      const p = await newPage(browser, { width: 375, height: 812 });
      await p.goto(`${BASE}/test/word-memory?quick=1`, { waitUntil: "domcontentloaded", timeout: 60000 });
      await p.waitForSelector('[data-testid="wm-intro"]', { timeout: 60000 });

      const ovIntro = await overflow(p);
      ovIntro.scrollW <= ovIntro.clientW ? ok(`intro 375px: no overflow (${ovIntro.scrollW})`) : fail(`intro overflow ${ovIntro.scrollW}>${ovIntro.clientW}`);

      await p.$eval('[data-testid="wm-intro-cta"]', (el) => el.click());

      // Continuous watcher starts the instant the run begins - it never
      // stops until results, so no study word can slip past.
      const watcher = startStudyWatcher(p);
      const LENS = { 1: 8, 2: 12, 3: 16 };

      for (let r = 1; r <= 3; r++) {
        if (r === 1) {
          // Input lock probe while the first study plays: rogue keypress.
          await p
            .waitForFunction(
              () => document.querySelector('[data-testid="wm-stage"]')?.getAttribute("data-phase") === "study",
              undefined,
              { timeout: 20000 }
            )
            .catch(() => {});
          await p.keyboard.press("a");
          const rogue = await p.$('[data-testid="wm-btn-old"]').catch(() => null);
          if (!rogue) ok("study phase: judgement buttons not rendered (input locked)");
          else fail("study phase: judgement buttons visible");
        }

        await waitRecognize(p);
        const watched = watcher.byRound[r];
        if (watched.length === LENS[r]) {
          ok(`round ${r}: watched ${watched.length} study words`);
        } else {
          fail(`round ${r}: watched ${watched.length} study words, expected ${LENS[r]} (${watched.join(",")})`);
        }
        if (new Set(watched).size === watched.length) ok(`round ${r}: no duplicate sightings`);
        else fail(`round ${r}: duplicate sightings`);

        if (r === 1) {
          const st = await snapshot(p);
          st.progress.startsWith("0") ? ok(`recognize starts at ${st.progress.trim()} (rogue input ignored)`) : fail(`progress at recognize start: ${st.progress}`);
          const ovRec = await overflow(p);
          ovRec.scrollW <= ovRec.clientW ? ok(`recognize 375px: no overflow (${ovRec.scrollW})`) : fail(`recognize overflow ${ovRec.scrollW}`);
        }
        await respondStream(p, new Set(watched));
      }

      await p.waitForSelector('[data-testid="wm-results"]', { timeout: 20000 });
      watcher.state.done = true;
      ok("results reached after 3 perfect rounds");

      const acc = await readStable(p, "wm-accuracy");
      acc === 100 ? ok(`accuracy = ${acc}%`) : fail(`accuracy ${acc}, expected 100`);
      const iq = await readStable(p, "wm-iq");
      iq === 145 ? ok(`iq = ${iq} (ceiling)`) : fail(`iq ${iq}, expected 145`);

      const grade = await p.$eval('[data-testid="wm-grade"]', (el) => el.textContent.trim()).catch(() => "");
      grade.includes("Exceptional") ? ok(`grade: ${grade}`) : fail(`grade: ${grade}`);

      const pct = await p.$eval('[data-testid="wm-percentile"]', (el) => el.textContent).catch(() => "");
      pct.includes("99") ? ok(`percentile: ${pct.trim()}`) : fail(`percentile: ${pct}`);

      const dp = await p.$eval('[data-testid="wm-stat-dprime"]', (el) => parseFloat(el.textContent.replace(/[^0-9.]/g, ""))).catch(() => -1);
      dp > 4 ? ok(`d' = ${dp} (> 4, clean separation)`) : fail(`d' = ${dp}`);

      for (let r = 0; r < 3; r++) {
        const ra = await p.$eval(`[data-testid="wm-round-acc-${r}"]`, (el) => Number(el.getAttribute("data-final"))).catch(() => -1);
        ra === 100 ? ok(`round ${r + 1} bar = ${ra}%`) : fail(`round ${r + 1} bar = ${ra}`);
      }

      const num = (sel) =>
        p.$eval(sel, (el) => Number(el.textContent.replace(/[^0-9]/g, ""))).catch(() => -1);
      const hits = await num('[data-testid="wm-stat-hits"]');
      const cr = await num('[data-testid="wm-stat-cr"]');
      const fa = await num('[data-testid="wm-stat-fa"]');
      hits === 36 && cr === 36 && fa === 0 ? ok(`stats: hits ${hits}, CR ${cr}, FA ${fa}`) : fail(`stats: hits ${hits}, CR ${cr}, FA ${fa}`);

      const ovResults = await overflow(p);
      ovResults.scrollW <= ovResults.clientW ? ok(`results 375px: no overflow (${ovResults.scrollW})`) : fail(`results overflow ${ovResults.scrollW}`);

      /* ---------- 3. Retake: fresh words ---------- */
      console.log("\n== Retake freshness ==");
      const run1FirstRound = watcher.byRound[1].join(",");
      await p.$eval('[data-testid="wm-retake"]', (el) => el.click());
      // Watch round 1 of run 2 (same continuous technique, early start).
      const run2Words = [];
      {
        let last = null;
        const start = Date.now();
        while (Date.now() - start < 30000) {
          const st = await p
            .evaluate(() => {
              const el = document.querySelector('[data-testid="wm-study-word"]');
              const stage = document.querySelector('[data-testid="wm-stage"]');
              return {
                word: el ? el.textContent.trim() : null,
                phase: stage ? stage.getAttribute("data-phase") : null,
              };
            })
            .catch(() => null);
          if (st && st.phase === "study" && st.word && st.word !== last) {
            run2Words.push(st.word);
            last = st.word;
          }
          if (st && (st.phase === "interlude" || st.phase === "recognize")) break;
          await sleep(15);
        }
      }
      run2Words.length === 8 && run2Words.join(",") !== run1FirstRound
        ? ok("retake: round-1 study list is fresh (differs from run 1)")
        : fail(`retake list len ${run2Words.length}, same=${run2Words.join(",") === run1FirstRound}`);

      allErrors.push(...p.errors);
      await p.ctx.close();
    }

    /* ==================== 4. Anti-gaming: mash NEW (?quick=1) ==================== */
    console.log("\n== Anti-gaming: mash 'It's new' for everything ==");
    {
      const p = await newPage(browser);
      await p.goto(`${BASE}/test/word-memory?quick=1`, { waitUntil: "domcontentloaded", timeout: 60000 });
      await p.waitForSelector('[data-testid="wm-intro"]', { timeout: 60000 });
      await p.$eval('[data-testid="wm-intro-cta"]', (el) => el.click());

      for (let r = 0; r < 3; r++) {
        await waitRecognize(p); // study + interlude play out untouched
        await respondStream(p, new Set()); // always "It's new"
      }

      await p.waitForSelector('[data-testid="wm-results"]', { timeout: 20000 });

      const acc = await readStable(p, "wm-accuracy");
      acc === 50 ? ok(`accuracy = ${acc}% (chance floor)`) : fail(`accuracy ${acc}, expected 50`);
      const iq = await readStable(p, "wm-iq");
      iq === 55 ? ok(`iq = ${iq} (floor)`) : fail(`iq ${iq}, expected 55`);

      const grade = await p.$eval('[data-testid="wm-grade"]', (el) => el.textContent.trim()).catch(() => "");
      grade.includes("Building") ? ok(`grade: ${grade}`) : fail(`grade: ${grade}`);

      const pct = await p.$eval('[data-testid="wm-percentile"]', (el) => el.textContent).catch(() => "");
      pct.includes("1") ? ok(`percentile: ${pct.trim()}`) : fail(`percentile: ${pct}`);

      const dp = await p.$eval('[data-testid="wm-stat-dprime"]', (el) => parseFloat(el.textContent.replace(/[^0-9.]/g, ""))).catch(() => 99);
      Math.abs(dp) < 0.3 ? ok(`d' = ${dp} (pure bias, no sensitivity)`) : fail(`d' = ${dp}`);

      allErrors.push(...p.errors);
      await p.ctx.close();
    }

    /* ==================== 5. Console errors ==================== */
    console.log("\n== Console / page errors ==");
    allErrors.length === 0
      ? ok("zero console/page errors across all runs")
      : fail(`${allErrors.length} errors:\n    ${allErrors.slice(0, 10).join("\n    ")}`);
  } finally {
    await browser.close();
  }

  console.log(
    failures === 0
      ? "\n==== word-memory flow: ALL PASS ====\n"
      : `\n==== word-memory flow: ${failures} FAILURE(S) ====\n`
  );
  process.exit(failures === 0 ? 0 : 1);
})();
